<?php
// Débogage (à retirer en production)
ini_set('display_errors', 0); // Modifié pour la production
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. SÉCURITÉ : Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// SÉCURITÉ : Générer un jeton CSRF pour les formulaires de renouvellement
$_SESSION['csrf_token'] = $_SESSION['csrf_token'] ?? bin2hex(random_bytes(32));

// 3. CONNEXION À LA BASE DE DONNÉES
require_once 'db_connection.php';

// (Optionnel) badge_sentinel si tu l'utilises déjà
if (file_exists(__DIR__ . '/badge_sentinel.php')) {
    require_once 'badge_sentinel.php';
}

// 4. Initialisation des variables
$prenom = $_SESSION['user_prenom'] ?? '';
$contrats_en_cours = [];
$contrats_en_attente_renouvellement = [];
$contrats_clotures = [];
$montant_total_investi = 0;
$somme_ponderee_rendements = 0;
$somme_montants_pour_ponderation = 0;
$rendement_moyen_pondere = 0;
$somme_contrats_en_cours = 0;
$somme_rendements_actuels = 0;
$available_products = [];
$promo_codes_for_js = [];
$referral_codes_for_js = [];

try {
    $user_id = (int)$_SESSION['user_id'];
    
    // --- LECTURE DES CODES PROMO (avec gestion de la cumulabilité) ---
    $codes_stmt = $pdo->prepare("
        SELECT code, discount_percent, montant_reduction, cumulable
        FROM promo_codes 
        WHERE is_active = 1 
          AND (usage_limit IS NULL OR usage_count < usage_limit)
          AND (starts_at IS NULL OR starts_at <= NOW())
          AND (ends_at IS NULL OR ends_at >= NOW())
          AND (user_id IS NULL OR user_id = :user_id)
    ");
    $codes_stmt->execute(['user_id' => $user_id]);
    foreach ($codes_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $type = null; $valeur = 0;
        if (!empty($row['discount_percent'])) { $type = 'percent'; $valeur = (float)$row['discount_percent']; }
        elseif (!empty($row['montant_reduction'])) { $type = 'amount'; $valeur = (float)$row['montant_reduction']; }
        if ($type) {
            $promo_codes_for_js[strtoupper($row['code'])] = [
                'valid'     => true,
                'type'      => $type,
                'value'     => (float)$valeur,
                'label'     => htmlspecialchars($row['code'], ENT_QUOTES, 'UTF-8'),
                'stackable' => (bool)$row['cumulable']
            ];
        }
    }

    // --- LECTURE DES CODES PARRAIN (depuis users.code_parrain) ---
    $refStmt = $pdo->query("
        SELECT UPPER(code_parrain) AS code
        FROM users
        WHERE code_parrain IS NOT NULL AND code_parrain <> ''
    ");
    foreach ($refStmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $code = $r['code'];
        $referral_codes_for_js[$code] = [
            'valid'     => true,
            'type'      => 'none', // suivi parrain uniquement, pas de remise
            'value'     => 0,
            'label'     => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
            'stackable' => true
        ];
    }
    
    // --- Requête des contrats + statuts calculés ---
    $stmt = $pdo->prepare("
        SELECT 
            c.id, c.user_prenom, c.date_souscription, c.montant, c.apport, c.taux_moyen, 
            c.statut AS statut_contrat_db, c.produit_id,
            p.name AS produit_name, p.descriptif, p.duree_mois, p.taux AS produit_taux, p.prix,
            dr.statut AS statut_retrait, dr.montant AS montant_retrait,

            DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH) AS date_fin_calculee,
            DATE_ADD(DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH), INTERVAL 30 DAY) AS deadline_renouvellement,

            CASE
                WHEN dr.statut = 'En attente' THEN 'en_attente_paiement'
                WHEN c.statut IN ('Clôturé', 'Renouvelé') THEN 'cloture'
                WHEN NOW() < DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH) THEN 'en_cours'
                WHEN NOW() BETWEEN DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH) AND DATE_ADD(DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH), INTERVAL 30 DAY) THEN 'en_attente_renouvellement'
                ELSE 'cloture'
            END AS statut_calcule
        FROM contrats AS c
        JOIN produits AS p ON c.produit_id = p.id
        LEFT JOIN demandes_retrait AS dr ON c.id = dr.contrat_id AND dr.user_id = c.user_id
        WHERE c.user_id = :user_id
        ORDER BY 
            CASE statut_calcule
                WHEN 'en_attente_renouvellement' THEN 1
                WHEN 'en_cours' THEN 2
                WHEN 'en_attente_paiement' THEN 3
                ELSE 4
            END,
            c.date_souscription DESC
    ");
    $stmt->execute(['user_id' => $user_id]);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $statut = $row['statut_calcule'];
        $date_souscription = new DateTime($row['date_souscription']);
        $date_fin = new DateTime($row['date_fin_calculee']);
        $deadline_renouvellement = new DateTime($row['deadline_renouvellement']);
        $aujourdhui = new DateTime();
        
        $statut_class = '';
        $pourcentage_temps_ecoule = 0;

        switch ($statut) {
            case 'en_cours':
                $statut_class = 'status-en-cours';
                if ($date_fin > $date_souscription) {
                    $pourcentage_temps_ecoule = (($aujourdhui->getTimestamp() - $date_souscription->getTimestamp()) / ($date_fin->getTimestamp() - $date_souscription->getTimestamp())) * 100;
                }
                $somme_ponderee_rendements += $row['montant'] * $row['taux_moyen'];
                $somme_montants_pour_ponderation += $row['montant'];
                break;
            case 'en_attente_renouvellement':
                $statut_class = 'status-en-attente';
                $pourcentage_temps_ecoule = 100;
                break;
            case 'en_attente_paiement':
                $statut_class = 'status-paiement-attente';
                $pourcentage_temps_ecoule = 100;
                break;
            default:
                $statut = 'cloture';
                $statut_class = 'status-cloture';
                $pourcentage_temps_ecoule = 100;
                break;
        }

        if ($statut === 'en_cours') {
            $montant_total_investi += $row['apport'];
        }
        
        $pourcentage_temps_ecoule = max(0, min(100, $pourcentage_temps_ecoule));
        
        $rendement_total_contrat = $row['montant'] * ($row['taux_moyen'] / 100);
        $rendement_actuel = $rendement_total_contrat * ($pourcentage_temps_ecoule / 100);

        $contrat_data = [
            'id' => (int)$row['id'],
            'date_souscription' => $row['date_souscription'],
            'montant' => (float)$row['montant'],
            'apport' => (float)$row['apport'],
            'taux_moyen' => (float)$row['taux_moyen'],
            'rendement_total_contrat' => (float)$rendement_total_contrat,
            'rendement_actuel' => (float)$rendement_actuel,
            'pourcentage_temps_ecoule' => (float)$pourcentage_temps_ecoule,
            'produit_id' => (int)$row['produit_id'],
            'produit_name' => $row['produit_name'],
            'produit_taux' => (float)$row['produit_taux'],
            'produit_descriptif' => $row['descriptif'],
            'duree_mois' => (int)$row['duree_mois'],
            'statut' => $statut,
            'statut_class' => $statut_class,
            'temps_restant_renouvellement' => $deadline_renouvellement->getTimestamp(),
            'date_fin' => $date_fin->format('d/m/Y'),
            'montant_retrait' => $row['montant_retrait'],
            'db_statut' => $row['statut_contrat_db']
        ];
        
        if ($statut === 'en_cours') {
            $contrats_en_cours[] = $contrat_data;
        } elseif ($statut === 'en_attente_renouvellement') {
            $contrats_en_attente_renouvellement[] = $contrat_data;
        } else {
            $contrats_clotures[] = $contrat_data;
        }
    }
    
    foreach ($contrats_en_cours as $contrat) {
        $somme_contrats_en_cours += $contrat['montant'] + $contrat['rendement_actuel'];
        $somme_rendements_actuels += $contrat['rendement_actuel'];
    }

    if ($somme_montants_pour_ponderation > 0) {
        $rendement_moyen_pondere = $somme_ponderee_rendements / $somme_montants_pour_ponderation;
    }
    
    $products_stmt = $pdo->query("SELECT id, name, descriptif, prix, duree_mois, taux FROM produits WHERE is_active = 1 ORDER BY id ASC");
    $available_products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("ERREUR TECHNIQUE : " . $e->getMessage());
} finally {
    $pdo = null;
}

// Banners message
if (isset($_SESSION['error_message'])) {
    echo '<div id="global-error-banner" style="position:sticky;top:0;z-index:9999;background:#fdecea;color:#b71c1c;padding:12px 15px;text-align:center;font-weight:600;border-bottom:1px solid #f5c2c7;">'
        . htmlspecialchars($_SESSION['error_message']) .
        '</div>';
    unset($_SESSION['error_message']);
}
$FORM_ERRORS = $_SESSION['form_errors'] ?? [];
unset($_SESSION['form_errors']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mes Récoltes - Mon Plant Fraise</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
<style>
  :root{--primary-color:#2E7D32;--primary-color-light:#C8E6C9;--primary-gradient:linear-gradient(135deg, #4CAF50, #2E7D32);--warning-color:#FFA000;--info-color:#2196F3;--text-color:#212121;--text-color-light:#757575;--background-color:#F4F6F8;--card-background-color:#ffffff;--border-radius:12px;--box-shadow:0 4px 12px rgba(0,0,0,0.08);}
  body{background-color:var(--background-color);font-family:'Roboto',sans-serif;margin:0;display:flex;color:var(--text-color);}
  .sidebar{background-color:var(--card-background-color);width:260px;height:100vh;padding:20px;position:fixed;top:0;left:0;box-shadow:0 2px 10px rgba(0, 0, 0, 0.1);display:flex;flex-direction:column;z-index:1000;transition:transform 0.3s ease-in-out;}
  .sidebar-header{margin-bottom:30px;}
  .sidebar-header a img{max-width:80%;height:auto;display:block;margin:0 auto;}
  .sidebar ul{list-style-type:none;padding:0;margin:0;}
  .sidebar ul li a{display:flex;align-items:center;padding:12px 10px;margin-bottom:8px;text-decoration:none;color:var(--text-color-light);border-radius:var(--border-radius);font-weight:500;transition:background-color 0.2s ease, color 0.2s ease;}
  .sidebar ul li a .material-symbols-outlined{margin-right:15px;font-size:22px;}
  .sidebar ul li a:hover{background-color:#eeeeee;}
  .sidebar ul li a[href="recoltes.php"]{background-color:var(--primary-color);color:white;}
  .container{margin-left:280px;padding:30px;width:calc(100% - 280px);transition:margin-left 0.3s ease-in-out;}
  .main-header{font-family:'Poppins',sans-serif;font-size:28px;font-weight:700;margin-bottom:20px;}
  .summary-card{background:var(--primary-gradient);color:white;padding:20px;border-radius:var(--border-radius);margin-bottom:25px;box-shadow:0 6px 15px rgba(46,125,50,0.4);}
  .summary-card h3{margin-top:0;font-size:16px;font-weight:400;opacity:0.9;}
  .summary-card .summary-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px;margin-top:15px;}
  .summary-card .summary-item{font-size:14px;}
  .summary-card .summary-item strong{display:block;font-family:'Poppins',sans-serif;font-size:22px;font-weight:700;}
  .contracts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:25px;}
  .card{background-color:var(--card-background-color);border-radius:var(--border-radius);box-shadow:var(--box-shadow);margin-bottom:15px;overflow:hidden;padding:0;position:relative;}
  .card-header{padding:12px 18px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #eee;}
  .card-header h3{margin:0;font-size:18px;font-weight:500;}
  .card-content{padding:18px;}
  .status-en-cours .card-header{background-color:var(--primary-color-light);}
  .status-en-attente .card-header{background-color:#FFF3E0;}
  .status-cloture .card-header{background-color:#E0E0E0;color:var(--text-color-light);}
  .status-badge{font-size:12px;font-weight:500;padding:4px 10px;border-radius:16px;color:white;}
  .status-cloture .status-badge{background-color:#757575;}
  .status-en-attente .status-badge{background-color:var(--warning-color);}
  .status-paiement-attente .card-header { background-color: #E3F2FD; }
  .status-paiement-attente .status-badge { background-color: var(--info-color); color: #fff; }
  .info-item{display:flex;align-items:center;margin-bottom:12px;font-size:15px;color:var(--text-color-light);}
  .info-item .material-symbols-outlined{font-size:20px;margin-right:12px;color:var(--primary-color);}
  .info-item strong{color:var(--text-color);font-weight:500;margin-left:5px;}
  .rendement-actuel{color:var(--primary-color)!important;font-weight:700!important;}
  .progress-bar-container{background-color:#e0e0e0;border-radius:20px;overflow:hidden;margin-top:15px;}
  .progress-bar{height:10px;border-radius:20px;transition:width 0.5s;background:var(--primary-gradient);}
  .btn-renew, .quick-action-btn{display:inline-block;flex-grow:1;box-sizing:border-box;padding:12px;background-color:var(--warning-color);color:white;text-decoration:none;border:none;border-radius:8px;font-weight:700;cursor:pointer;transition:background-color 0.2s ease;font-size:14px;text-align:center;}
  .btn-renew:hover, .quick-action-btn:hover{background-color:#FB8C00;}
  .btn-renew { width: 100%; margin-top: 10px; background-color: var(--primary-color); }
  .quick-action-btn { background-color: #f0f0f0; color: #333; display:flex; align-items:center; justify-content:center; gap:8px; border: 1px solid #ddd; }
  .quick-actions { display:flex; gap:10px; }
  .no-contracts-message{background-color:#fff;padding:20px;border-radius:var(--border-radius);text-align:center;color:var(--text-color-light);}
  .final-yield-summary{background-color:var(--primary-color-light);border:1px solid var(--primary-color);color:var(--primary-color);padding:15px;margin-bottom:20px;border-radius:8px;text-align:center;}
  .final-yield-summary small{display:block;font-size:14px;}
  .final-yield-summary strong{display:block;font-family:'Poppins',sans-serif;font-size:24px;margin:5px 0;color:#212121;}
  .final-yield-summary span{font-size:13px;opacity:0.8;}
  .popup-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(0,0,0,0.7);display:none;justify-content:center;align-items:center;z-index:2000;}
  #renewal-popup-overlay .popup-content { max-width: 800px; }
  #details-popup-overlay .popup-content { max-width: 650px; }
  .popup-content{background-color:#fff;padding:25px;border-radius:var(--border-radius);box-shadow:0 5px 15px rgba(0,0,0,0.3);width:100%;position:relative;max-height:90vh;overflow-y:auto;box-sizing: border-box;}
  .popup-close-btn{position:absolute;top:10px;right:15px;font-size:28px;font-weight:bold;color:#aaa;cursor:pointer;}
  .popup-content h2{font-family:'Poppins',sans-serif;margin-top:0;color:var(--primary-color);text-align:center;}
  .popup-header-summary{text-align:center;margin-bottom:20px;}
  .popup-header-summary strong{font-family:'Poppins';font-size:32px;color:#212121;}
  .popup-header-summary span{color:var(--text-color-light);}
  .slider-container{padding:10px 0;}
  .slider{-webkit-appearance:none;width:100%;height:8px;background:#ddd;border-radius:5px;outline:none;}
  .slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:24px;height:24px;background:var(--primary-color);border-radius:50%;cursor:pointer;border:3px solid #fff;box-shadow:0 0 5px rgba(0,0,0,0.2);}
  .slider::-moz-range-thumb{width:24px;height:24px;background:var(--primary-color);border-radius:50%;cursor:pointer;border:3px solid #fff;box-shadow:0 0 5px rgba(0,0,0,0.2);}
  .slider-labels{display:flex;justify-content:space-between;font-size:12px;color:var(--text-color-light);padding:0 5px;}
  .preset-buttons { display: flex; justify-content: space-around; margin-bottom: 15px; gap: 10px; }
  .preset-btn { padding: 8px 12px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 20px; cursor: pointer; font-size: 13px; }
  .preset-btn:hover { background-color: #eee; }
  .calculation-results{display:flex;flex-direction:column;gap:10px;margin-top:20px;background-color:#f7f7f7;padding:15px;border-radius:8px;}
  .calculation-box{width:100%;text-align:center;}
  .calculation-box small{color:var(--text-color-light);}
  .calculation-box strong{font-size:20px;display:block;color:var(--primary-color);}
  .iban-section{margin-top:15px;}
  .iban-section input{width:100%;box-sizing:border-box;padding:10px;border-radius:5px;border:1px solid #ccc;}
  .iban-section input.input-error { border-color:#d32f2f !important; box-shadow:0 0 0 2px rgba(211,47,47,.15); }
  .form-feedback.error { color:#d32f2f; font-weight:600; }
  .popup-actions{display:flex;flex-direction:column;gap:10px;margin-top:25px;}
  .popup-btn{width:100%;padding:12px 24px;border:none;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer;box-sizing:border-box;}
  .popup-btn.primary{background-color:var(--primary-color);color:white;order:1;}
  .popup-btn.secondary{background-color:#eee;color:#333;order:2;}
  .hidden{display:none!important;}
  .allocation-section h3{font-family:'Poppins',sans-serif;font-size:16px;text-align:left;margin-bottom:10px; border-bottom: 2px solid var(--primary-color-light); padding-bottom: 5px;}
  .allocation-progress{margin-bottom:20px;}
  .progress-bar-track{background-color:#e0e0e0;border-radius:20px;height:12px;overflow:hidden;}
  .progress-bar-fill{background:var(--primary-gradient);height:100%;width:0%;border-radius:20px;transition:width 0.5s ease;}
  .progress-bar-fill.is-over { background: var(--warning-color); }
  .progress-text{font-size:14px;color:var(--text-color-light);margin-top:8px;text-align:center;}
  .product-list{border:1px solid #eee;padding:10px;border-radius:8px;margin-bottom:15px;max-height:280px;overflow-y:auto;}
  .product-list::-webkit-scrollbar{width:7px;}
  .product-list::-webkit-scrollbar-thumb{border-radius:4px;background-color:rgba(0,0,0,.5);}
  .product-item{display:flex;flex-direction:column;gap:10px;padding:10px;border-bottom:1px solid #f0f0f0;}
  .product-item:last-child{border-bottom:none;}
  .product-item-info strong{display:block;}
  .product-item-info span{font-size:12px;color:var(--text-color-light);}
  .add-product-btn{padding:5px 15px;background-color:var(--primary-color-light);color:var(--primary-color);border:1px solid var(--primary-color);cursor:pointer;border-radius:20px;font-weight:bold;align-self:flex-end;}
  .add-product-btn:hover{background-color:var(--primary-color);color:white;}
  #reinvestment-cart .cart-item{display:flex;justify-content:space-between;align-items:center;background-color:#f9f9f9;padding:8px 12px;border-radius:5px;margin-bottom:5px;font-size:14px;}
  .remove-item-btn{cursor:pointer;color:#cc0000;font-weight:bold;}
  .toast-notification{position:fixed;top:-100px;right:20px;background-color:var(--primary-color);color:white;padding:15px 25px;border-radius:8px;z-index:3000;font-size:16px;box-shadow:0 3px 10px rgba(0,0,0,0.2);opacity:0;transition:opacity 0.5s, top 0.5s;}
  .countdown-timer{font-size:14px;font-weight:500;margin-top:10px;text-align:center;}
  #top-up-section{margin-top:15px;padding:15px;background-color:#fff8e1;border:1px solid #ffecb3;border-radius:8px;text-align:center;}
  #top-up-section label{font-size:14px;font-weight:500;color:#6d4c41;}
  .accordion-item{background-color:var(--card-background-color);border-radius:var(--border-radius);box-shadow:var(--box-shadow);margin-bottom:20px;overflow:hidden;}
  .accordion-header{display:flex;justify-content:space-between;align-items:center;padding:15px 20px;cursor:pointer;border-bottom:1px solid transparent;transition:border-color 0.3s ease;}
  .accordion-header h2{margin:0;font-family:'Poppins',sans-serif;font-size:20px;}
  .accordion-header .material-symbols-outlined{font-size:28px;transition:transform 0.3s ease-in-out;}
  .accordion-item:not(.is-open) .accordion-header{border-color:#eee;}
  .accordion-item.is-open .accordion-header .material-symbols-outlined{transform:rotate(180deg);}
  .accordion-content{padding:0 20px;max-height:0;overflow:hidden;transition:max-height 0.5s ease-in-out, padding 0.5s ease-in-out;}
  .accordion-content .contracts-grid, .accordion-content .no-contracts-message{padding-top:20px;padding-bottom:20px;}
  .card[data-details]{cursor:pointer;transition:transform 0.2s ease, box-shadow 0.2s ease;}
  .card[data-details]:hover{transform:translateY(-5px);box-shadow:0 8px 20px rgba(0,0,0,0.12);}
  .toggle-btn { display:none; }

  @media (max-width: 992px) {
    .sidebar { transform: translateX(-100%); }
    .sidebar.open { transform: translateX(0); }
    .container { margin-left: 0; width: 100%; padding: 15px; box-sizing: border-box; }
    .toggle-btn { display:flex; align-items:center; justify-content:center; position:fixed; top:15px; left:15px; background-color:var(--primary-color); color:#fff; border:none; border-radius:50%; width:50px; height:50px; cursor:pointer; z-index:1001; box-shadow:0 2px 5px rgba(0,0,0,0.3); }
    .main-header { padding-top: 60px; }
  }
  @media (max-width: 768px) {
    .main-header { font-size: 24px; }
    .summary-card .summary-grid { grid-template-columns: 1fr; gap: 15px; }
    .contracts-grid { grid-template-columns: 1fr; }
    .accordion-header h2 { font-size: 18px; }
    .popup-content { width: 95%; padding: 20px 15px; }
  }
</style>
</head>
<body>

<?php
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    echo "<script>document.addEventListener('DOMContentLoaded', function() { const t=document.getElementById('toast-notification'); if(t){t.textContent=".json_encode($success_message)."; t.style.top='20px'; t.style.opacity='1'; setTimeout(()=>{t.style.top='-100px'; t.style.opacity='0';},4000);} });</script>";
    unset($_SESSION['success_message']);
}
?>

<button class="toggle-btn" id="menu-toggle">
    <span class="material-symbols-outlined">menu</span>
</button>
  
<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Mes Récoltes & Contrats</h1>
  
    <div class="summary-card">
        <h3>Bonjour <strong><?php echo htmlspecialchars($prenom); ?></strong> ! Votre portefeuille en un clin d'œil :</h3>
        <div class="summary-grid">
            <div class="summary-item">
                Valeur Actuelle (Contrats en cours)
                <strong><?php echo number_format($somme_contrats_en_cours, 2, ',', ' '); ?> €</strong>
            </div>
            <div class="summary-item">
                Gains Actuels (Contrats en cours)
                <strong>+ <?php echo number_format($somme_rendements_actuels, 2, ',', ' '); ?> €</strong>
            </div>
            <div class="summary-item">
                Montant Total Investi (Actif)
                <strong><?php echo number_format($montant_total_investi, 2, ',', ' '); ?> €</strong>
            </div>
            <div class="summary-item">
                Rendement Moyen Pondéré
                <strong><?php echo number_format($rendement_moyen_pondere, 2, ',', ' '); ?> %</strong>
            </div>
        </div>
    </div>
  
    <div class="contracts-section">
        <div class="accordion-item is-open">
            <div class="accordion-header">
                <h2>En cours (<?php echo count($contrats_en_cours); ?>)</h2>
                <span class="material-symbols-outlined">expand_less</span>
            </div>
            <div class="accordion-content" style="max-height:1000px;">
                <?php if (!empty($contrats_en_cours)) : ?>
                    <div class="contracts-grid">
                        <?php foreach ($contrats_en_cours as $contrat) :
                            $cardDataB64 = base64_encode(json_encode($contrat));
                        ?>
                            <div class="card <?php echo $contrat['statut_class']; ?>" data-details-b64="<?php echo htmlspecialchars($cardDataB64, ENT_QUOTES, 'UTF-8'); ?>">
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($contrat['produit_name']) . ' (' . number_format($contrat['produit_taux'], 1, ',', '') . '%) - ' . number_format($contrat['montant'], 0, ' ', ' ') . ' €'; ?></h3>
                                </div>
                                <div class="card-content">
                                    <div class="info-item"><span class="material-symbols-outlined">calendar_month</span> Souscrit le: <strong><?php echo date('d/m/Y', strtotime($contrat['date_souscription'])); ?></strong></div>
                                    <div class="info-item"><span class="material-symbols-outlined">account_balance_wallet</span> Investi: <strong><?php echo number_format($contrat['apport'], 2, ',', ' '); ?> €</strong></div>
                                    <div class="info-item"><span class="material-symbols-outlined">trending_up</span> Rend. actuel: <strong class="rendement-actuel"><?php echo number_format($contrat['rendement_actuel'], 2, ',', ' '); ?> €</strong></div>
                                    <div class="info-item"><span class="material-symbols-outlined">emoji_events</span> Rend. final estimé: <strong><?php echo number_format($contrat['rendement_total_contrat'], 2, ',', ' '); ?> €</strong></div>
                                    <div class="progress-bar-container"><div class="progress-bar" style="width: <?php echo $contrat['pourcentage_temps_ecoule']; ?>%;"></div></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="no-contracts-message">Vous n'avez aucun contrat en cours de récolte.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="accordion-item">
            <div class="accordion-header">
                <h2>En attente de renouvellement (<?php echo count($contrats_en_attente_renouvellement); ?>)</h2>
                <span class="material-symbols-outlined">expand_more</span>
            </div>
            <div class="accordion-content">
                <?php if (!empty($contrats_en_attente_renouvellement)) : ?>
                    <div class="contracts-grid">
                        <?php foreach ($contrats_en_attente_renouvellement as $contrat) :
                            $b64 = base64_encode(json_encode($contrat));
                        ?>
                            <div class="card <?php echo $contrat['statut_class']; ?>">
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($contrat['produit_name']) . ' (' . number_format($contrat['produit_taux'], 1, ',', '') . '%) - ' . number_format($contrat['montant'], 0, ' ', ' ') . ' €'; ?></h3>
                                    <span class="status-badge">À renouveler</span>
                                </div>
                                <div class="card-content">
                                    <?php $total_disponible = $contrat['montant'] + $contrat['rendement_total_contrat']; ?>
                                    <div class="final-yield-summary">
                                        <small>Félicitations ! Votre capital est disponible :</small>
                                        <strong><?php echo number_format($total_disponible, 2, ',', ' '); ?> €</strong>
                                        <span>(Capital de <?php echo number_format($contrat['montant'], 2, ',', ' '); ?> € + Gains de <?php echo number_format($contrat['rendement_total_contrat'], 2, ',', ' '); ?> €)</span>
                                    </div>
                                    
                                    <div class="quick-actions">
                                        <button class="quick-action-btn js-reinvest-all" data-cid="<?php echo (int)$contrat['id']; ?>">
                                            <span class="material-symbols-outlined">refresh</span> Tout Réinvestir
                                        </button>
                                        <button class="quick-action-btn js-withdraw-all" data-cid="<?php echo (int)$contrat['id']; ?>">
                                            <span class="material-symbols-outlined">savings</span> Tout Retirer
                                        </button>
                                    </div>
                                    
                                    <button class="btn-renew js-open-popup" data-contrat-b64="<?php echo htmlspecialchars($b64, ENT_QUOTES, 'UTF-8'); ?>">Gérer (Personnalisé)</button>
                                    <div class="countdown-timer" data-deadline="<?php echo (int)$contrat['temps_restant_renouvellement']; ?>">Calcul...</div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="no-contracts-message">Vous n'avez aucun contrat en attente de renouvellement.</p>
                <?php endif; ?>
            </div>
        </div>
      
        <div class="accordion-item">
            <div class="accordion-header">
                <h2>Historique (<?php echo count($contrats_clotures); ?>)</h2>
                <span class="material-symbols-outlined">expand_more</span>
            </div>
            <div class="accordion-content">
                <?php if (!empty($contrats_clotures)) : ?>
                    <div class="contracts-grid">
                        <?php foreach ($contrats_clotures as $contrat) : 
                            $is_finalized = ($contrat['statut'] !== 'en_attente_paiement');
                            $overlay_message = $is_finalized ? ((trim((string)$contrat['db_statut']) === 'Renouvelé') ? 'Renouvelé' : 'Fonds récupérés') : '';
                            $cardDataB64 = base64_encode(json_encode($contrat));
                        ?>
                            <div class="card <?php echo $contrat['statut_class']; ?>" data-details-b64="<?php echo htmlspecialchars($cardDataB64, ENT_QUOTES, 'UTF-8'); ?>">
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($contrat['produit_name']) . ' (' . number_format($contrat['produit_taux'], 1, ',', '') . '%) - ' . number_format($contrat['montant'], 0, ' ', ' ') . ' €'; ?></h3>
                                    <?php if ($contrat['statut'] === 'en_attente_paiement'): ?>
                                        <span class="status-badge">Paiement en attente</span>
                                    <?php else: ?>
                                        <span class="status-badge">Clôturé</span>
                                    <?php endif; ?>
                                </div>
                                 <div class="card-content <?php echo $is_finalized ? 'is-grayed-out' : ''; ?>">
                                    <div class="info-item"><span class="material-symbols-outlined">calendar_month</span> Souscrit le: <strong><?php echo date('d/m/Y', strtotime($contrat['date_souscription'])); ?></strong></div>
                                    <?php if ($contrat['statut'] === 'en_attente_paiement'): ?>
                                        <div class="info-item retrait-info">
                                            <span class="material-symbols-outlined">hourglass_top</span>
                                            Retrait demandé: <strong><?php echo number_format($contrat['montant_retrait'] ?? 0, 2, ',', ' '); ?> €</strong>
                                        </div>
                                        <div class="info-item retrait-info">
                                            <span class="material-symbols-outlined">info</span>
                        <span>Votre demande est en cours de traitement.</span>
                                        </div>
                                    <?php else: ?>
                                        <div class="info-item"><span class="material-symbols-outlined">account_balance_wallet</span> Investi: <strong><?php echo number_format($contrat['apport'], 2, ',', ' '); ?> €</strong></div>
                                        <div class="info-item"><span class="material-symbols-outlined">emoji_events</span> Rendement final atteint: <strong><?php echo number_format($contrat['rendement_total_contrat'], 2, ',', ' '); ?> €</strong></div>
                                    <?php endif; ?>
                                </div>
                                <?php if ($is_finalized): ?>
                                <div class="card-overlay">
                                    <span class="overlay-message"><?php echo $overlay_message; ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="no-contracts-message">Vous n'avez aucun contrat dans votre historique.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- POPUP principal (renouvellement / réinvestissement) -->
<div id="renewal-popup-overlay" class="popup-overlay">
    <div class="popup-content">
        <span class="popup-close-btn" onclick="closeRenewalPopup()">&times;</span>

        <div id="popup-step-choice">
            <h2>Que souhaitez-vous faire ?</h2>
            <div class="popup-header-summary">
                <strong id="popup-total-amount">0,00 €</strong>
                <span id="popup-amount-details" style="display:block;"></span>
            </div>
            
            <div class="preset-buttons">
                <button class="preset-btn" data-value="0">Retrait Total</button>
                <button class="preset-btn" data-value="gains">Réinvestir les Gains</button>
                <button class="preset-btn" data-value="100">Réinvestir le Total</button>
            </div>

            <div class="slider-container">
                <input type="range" min="0" max="100" value="100" step="1" class="slider" id="reinvest-slider">
                <div class="slider-labels"><span>Retrait</span><span>Réinvestir</span></div>
            </div>
            <div class="calculation-results">
                <div class="calculation-box"><small>Montant à réinvestir</small><strong id="amount-reinvest">0,00 €</strong></div>
                <div class="calculation-box"><small>Montant à virer</small><strong id="amount-withdraw">0,00 €</strong></div>
            </div>
            <div id="iban-section" class="iban-section hidden">
                <label for="iban-input">Votre IBAN pour le virement</label>
                <input type="text" id="iban-input" placeholder="FR76...">
                <small class="form-feedback"></small>
            </div>
            <div class="popup-actions">
                <button id="popup-cta-choice" class="popup-btn primary">Étape suivante</button>
            </div>
        </div>

        <div id="popup-step-allocate" class="hidden">
            <h2>Allouez votre réinvestissement</h2>
            <div class="allocation-progress">
                <div class="progress-bar-track"><div class="progress-bar-fill" id="allocation-bar-fill"></div></div>
                <div class="progress-text">Alloué : <strong id="allocated-amount">0,00 €</strong> / <strong id="total-to-allocate">0,00 €</strong><span id="top-up-warning"></span></div>
            </div>
            
            <div class="allocation-section">
                <div class="allocation-columns" style="display:grid;grid-template-columns:1fr 1fr;gap:25px;">
                    <div class="product-column">
                        <h3>1. Choisissez vos produits</h3>
                        <div id="product-list" class="product-list"></div>
                    </div>
                    <div class="cart-column">
                        <h3>2. Votre panier</h3>
                        <div id="reinvestment-cart" class="product-list">
                            <p id="cart-empty-msg" style="color:#999;text-align:center;">Votre panier est vide.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="top-up-section" class="hidden">
                <input type="checkbox" id="top-up-checkbox" name="accept_top_up">
                <label for="top-up-checkbox">Oui, je souhaite compléter par un versement de <strong id="top-up-amount">0,00 €</strong>.</label>
            </div>
            <div class="popup-actions">
                <button type="button" class="popup-btn secondary" id="popup-back-to-choice-btn">Retour</button>
                <button id="popup-cta-allocate" class="popup-btn primary" disabled>Étape suivante</button>
            </div>
        </div>

        <div id="popup-step-confirm" class="hidden">
            <h2>Récapitulatif de votre choix</h2>
            <div class="calculation-results">
                <div class="calculation-box"><small>Valeur des nouveaux contrats</small><strong id="confirm-reinvest">0,00 €</strong></div>
                <div class="calculation-box"><small>Montant viré (retrait)</small><strong id="confirm-withdraw">0,00 €</strong></div>
            </div>

            <div id="confirm-codes-and-payment" style="margin-top:16px;padding:14px;border:1px solid #eee;border-radius:8px;background:#fafafa;">
                <h3 style="margin:0 0 10px 0;font-family:'Poppins',sans-serif;font-size:18px;color:#212121;">Codes & paiement</h3>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                    <div class="iban-section">
                        <label for="promo-code-input">Code promo <span id="promo-status-icon"></span></label>
                        <input type="text" id="promo-code-input" placeholder="EX: BIENVENUE20" style="text-transform:uppercase;">
                        <small id="promo-feedback" class="form-feedback"></small>
                    </div>
                    <div class="iban-section">
                        <label for="referral-code-input">Code parrain <span id="referral-status-icon"></span></label>
                        <input type="text" id="referral-code-input" placeholder="EX: PARRAIN123" style="text-transform:uppercase;">
                        <small id="referral-feedback" class="form-feedback"></small>
                    </div>
                </div>

                <div class="iban-section" style="margin-top:6px;">
                    <label style="display:block;margin-bottom:6px;">Mode de paiement</label>

                    <div class="payment-toggle" id="payment-toggle" style="display:flex;gap:12px;flex-wrap:wrap;">
                        <button type="button" class="payment-btn active" data-value="full" aria-pressed="true">Paiement comptant</button>
                        <button type="button" class="payment-btn" data-value="12x" aria-pressed="false">12 mensualités</button>
                    </div>

                    <input type="radio" name="payment_plan_choice" value="full" id="payment-choice-full" class="visually-hidden" checked>
                    <input type="radio" name="payment_plan_choice" value="12x" id="payment-choice-12x" class="visually-hidden">
                </div>
            </div>

            <div id="discount-live-panel" class="calculation-results" style="margin-top:12px;">
                <div class="calculation-box" style="width:100%;">
                    <small>Détails des remises</small>
                    <div id="discount-lines" style="font-size:14px;color:#444;margin-top:6px;">
                        <em>Aucune remise appliquée pour le moment.</em>
                    </div>
                </div>
            </div>

            <div id="payable-live-panel" class="calculation-results" style="margin-top:12px;background:#eef7ee;">
                <div class="calculation-box"><small>À régler aujourd’hui</small><strong id="confirm-top-up-after-discount">0,00 €</strong></div>
                <div class="calculation-box"><small>Si 12 mensualités</small><strong id="confirm-monthly-12x">0,00 € / mois</strong></div>
            </div>

            <div id="confirm-iban-section" class="iban-section hidden">
                <label>Sur le compte IBAN :</label>
                <input type="text" id="confirm-iban" readonly style="background:#f0f0f0;border:1px solid #ddd;">
            </div>

            <form id="renewal-form" action="create-checkout-session.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" id="popup-contract-id" name="contract_id">
                <input type="hidden" id="popup-withdraw-amount" name="withdraw_amount">
                <input type="hidden" id="popup-iban-value" name="iban">
                <input type="hidden" id="popup-top-up-amount" name="top_up_amount" value="0">
                <input type="hidden" id="popup-promo-code" name="promo_code" value="">
                <input type="hidden" id="popup-referral-code" name="referral_code" value="">
                <input type="hidden" id="popup-payment-plan" name="payment_plan" value="full">
                <input type="hidden" id="popup-top-up-after-discount" name="top_up_after_discount" value="0">
                <input type="hidden" id="popup-monthly-12x" name="monthly_12x" value="0">
                <input type="hidden" id="popup-contract-discount" name="contract_discount_total" value="0">
                <div id="new-contracts-inputs"></div>
                <div class="popup-actions">
                    <button type="button" class="popup-btn secondary" id="popup-back-btn">Retour</button>
                    <button type="submit" class="popup-btn primary">Je confirme et je finalise</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Popup détails -->
<div id="details-popup-overlay" class="popup-overlay">
    <div class="popup-content popup-details-card" style="padding:0;border-top:5px solid var(--primary-color);overflow:hidden;">
        <span class="popup-close-btn" id="close-details-popup">&times;</span>
        <div class="popup-header-details" style="display:flex;align-items:center;background-color:#f9f9f9;padding:20px 25px;border-bottom:1px solid #eee;">
            <div class="header-icon-container" style="background-color:var(--primary-color-light);color:var(--primary-color);border-radius:50%;width:50px;height:50px;display:flex;align-items:center;justify-content:center;margin-right:20px;">
                <span class="material-symbols-outlined" id="details-icon">grass</span>
            </div>
            <div>
                <h2 id="details-popup-title" style="margin:0 0 5px 0;font-size:22px;color:var(--text-color);text-align:left;">Détails du contrat</h2>
                <span class="status-badge" id="details-status-badge"></span>
            </div>
        </div>
        <div class="popup-kpi-section" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:20px 25px;background-color:#fff;">
            <div class="kpi-box" style="background-color:#f7f9fc;border-radius:var(--border-radius);padding:15px;text-align:center;border:1px solid #eef;">
                <span style="font-size:14px;color:var(--text-color-light);">Investissement Initial</span>
                <strong id="details-apport" style="display:block;font-size:24px;font-family:'Poppins',sans-serif;color:var(--primary-color);margin-top:5px;">0,00 €</strong>
            </div>
            <div class="kpi-box" style="background-color:#f7f9fc;border-radius:var(--border-radius);padding:15px;text-align:center;border:1px solid #eef;">
                <span style="font-size:14px;color:var(--text-color-light);">Gain Final Estimé</span>
                <strong id="details-rendement-final" style="display:block;font-size:24px;font-family:'Poppins',sans-serif;color:var(--primary-color);margin-top:5px;">0,00 €</strong>
            </div>
        </div>
        <div class="popup-details-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:20px 25px;border-top:1px solid #eee;">
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">calendar_today</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Date de souscription</span><strong id="details-date-souscription" style="font-size:16px;color:var(--text-color);font-weight:500;">--/--/----</strong></div></div>
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">event_available</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Date de fin du contrat</span><strong id="details-date-fin" style="font-size:16px;color:var(--text-color);font-weight:500;">--/--/----</strong></div></div>
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">hourglass_top</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Durée</span><strong id="details-duree" style="font-size:16px;color:var(--text-color);font-weight:500;">-- mois</strong></div></div>
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">percent</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Taux annuel moyen</span><strong id="details-taux" style="font-size:16px;color:var(--text-color);font-weight:500;">-- %</strong></div></div>
        </div>
        <div class="popup-progress-section" style="padding:20px 25px;border-top:1px solid #eee;">
            <h4 style="margin:0 0 10px 0;font-size:16px;font-weight:500;text-align:center;">Progression du contrat</h4>
            <div class="progress-bar-container"><div class="progress-bar" id="details-progress-bar" style="width: 0%;"></div></div>
            <div class="progress-labels" style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-color-light);margin-top:8px;"><span id="details-progress-start">--/--/----</span><span id="details-progress-end">--/--/----</span></div>
        </div>
        <div class="details-description" style="background-color:#f9f9f9;padding:20px 25px;border-top:1px solid #eee;">
            <h4 style="margin:0 0 8px 0;font-size:16px;font-weight:500;">Descriptif du produit</h4>
            <p id="details-descriptif" style="margin:0;font-size:14px;line-height:1.6;color:var(--text-color-light);"></p>
        </div>
    </div>
</div>

<div id="toast-notification" class="toast-notification"></div>

<!-- Formulaire “actions rapides” (réinvestir tout / retirer tout) -->
<form id="quick-action-form" action="create-checkout-session.php" method="POST" style="display:none;">
    <input type="hidden" name="csrf_token" id="quick-action-csrf" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
    <input type="hidden" name="contract_id" id="quick-action-contract-id">
    <input type="hidden" name="action_type" id="quick-action-type">
    <input type="hidden" name="iban" id="quick-action-iban">
</form>

<script>
/* ======== Données côté client ======== */
const serverCodes   = <?php echo json_encode($promo_codes_for_js); ?>;
const availableProducts = <?php echo json_encode($available_products); ?>;
const referralCodes = <?php echo json_encode($referral_codes_for_js); ?>;

const fmt = v => (Number(v||0)).toLocaleString('fr-FR', {style:'currency', currency:'EUR'});

/* ======== État global ======== */
let currentContractData = {};
let totalToAllocate = 0;
let reinvestmentCart = [];
let codeInfo = { promo: null, referral: null };
let lastAddTs = 0;

/* ======== Helpers ======== */
function normalizeCode(v){ return (v||'').toString().trim().toUpperCase(); }
function showToast(msg){
  const t=document.getElementById('toast-notification'); if(!t) return;
  t.textContent = msg; t.style.top='20px'; t.style.opacity='1';
  setTimeout(()=>{ t.style.top='-100px'; t.style.opacity='0'; }, 4000);
}

/* ======== Sidebar ======== */
document.getElementById('menu-toggle')?.addEventListener('click',()=>document.querySelector('.sidebar')?.classList.toggle('open'));

/* ======== Countdown ======== */
document.querySelectorAll('.countdown-timer').forEach(timer => {
  const deadline = parseInt(timer.getAttribute('data-deadline'), 10) * 1000;
  if (isNaN(deadline) || deadline <= 0) { timer.style.display='none'; return; }
  const itv=setInterval(()=>{
    const d=deadline-Date.now(); if(d<0){ timer.textContent='Délai expiré'; clearInterval(itv); return; }
    const days=Math.floor(d/86400000), hours=Math.floor((d%86400000)/3600000), mins=Math.floor((d%3600000)/60000), secs=Math.floor((d%60000)/1000);
    timer.textContent=`Temps restant : ${days}j ${hours}h ${mins}m ${secs}s`;
  },1000);
});

/* ======== Accordéons ======== */
document.querySelectorAll('.accordion-item').forEach(item=>{
  const header=item.querySelector('.accordion-header');
  const content=item.querySelector('.accordion-content');
  header?.addEventListener('click',()=>{
    item.classList.toggle('is-open');
    if(!content) return;
    const icon=header.querySelector('.material-symbols-outlined');
    if(item.classList.contains('is-open')) { content.style.maxHeight=(content.scrollHeight+40)+'px'; if(icon) icon.textContent='expand_less'; }
    else { content.style.maxHeight='0px'; if(icon) icon.textContent='expand_more'; }
  });
});

/* ======== Actions rapides ======== */
document.addEventListener('click',(e)=>{
  const btnRe = e.target.closest('.js-reinvest-all');
  if(btnRe){
    const cid = Number(btnRe.dataset.cid||0);
    if(!cid) return;
    if(confirm("Confirmez-vous le réinvestissement total (capital + gains) dans le même produit ?")){
      const f=document.getElementById('quick-action-form');
      f.querySelector('#quick-action-contract-id').value=cid;
      f.querySelector('#quick-action-type').value='reinvest_all';
      f.submit();
    }
    return;
  }
  const btnWd = e.target.closest('.js-withdraw-all');
  if(btnWd){
    const cid = Number(btnWd.dataset.cid||0);
    if(!cid) return;
    const iban = prompt("Veuillez confirmer votre IBAN pour le virement complet :");
    if(iban && iban.trim().length>=10){
      const f=document.getElementById('quick-action-form');
      f.querySelector('#quick-action-contract-id').value=cid;
      f.querySelector('#quick-action-type').value='withdraw_all';
      f.querySelector('#quick-action-iban').value=iban.trim();
      f.submit();
    }
    return;
  }
});

/* ======== Détails contrat (data base64 -> JSON) ======== */
const detailsPopup = document.getElementById('details-popup-overlay');
const closeDetailsBtn = document.getElementById('close-details-popup');
document.querySelectorAll('.card[data-details-b64]').forEach(card=>{
  card.addEventListener('click',(e)=>{
    // ne pas ouvrir si clic sur un bouton dans la carte
    if(e.target.closest('button')) return;
    try{
      const b64 = card.getAttribute('data-details-b64')||'';
      const data = JSON.parse(atob(b64));
      const statutInfo = {
        'en_cours': { text:'En cours', class:'status-en-cours' },
        'cloture': { text:'Clôturé', class:'status-cloture' },
        'en_attente_renouvellement': { text:'À renouveler', class:'status-en-attente' },
        'en_attente_paiement': { text:'Paiement en attente', class:'status-paiement-attente' }
      };
      const info = statutInfo[data.statut] || { text:data.statut, class:'' };
      const ds = new Date(data.date_souscription);

      document.getElementById('details-popup-title').textContent = `${data.produit_name} - ${fmt(data.montant)}`;
      const badge = document.getElementById('details-status-badge');
      badge.textContent = info.text;
      badge.className = `status-badge ${info.class.replace('status-','')}`;
      document.getElementById('details-apport').textContent = fmt(data.apport);
      document.getElementById('details-rendement-final').textContent = fmt(data.rendement_total_contrat);
      document.getElementById('details-date-souscription').textContent = ds.toLocaleDateString('fr-FR');
      document.getElementById('details-date-fin').textContent = data.date_fin;
      document.getElementById('details-duree').textContent = `${data.duree_mois} mois`;
      document.getElementById('details-taux').textContent = `${Number(data.taux_moyen||0).toFixed(2)} %`;
      document.getElementById('details-progress-bar').style.width = `${Number(data.pourcentage_temps_ecoule||0)}%`;
      document.getElementById('details-progress-start').textContent = ds.toLocaleDateString('fr-FR');
      document.getElementById('details-progress-end').textContent = data.date_fin;
      document.getElementById('details-descriptif').textContent = data.produit_descriptif||'';

      detailsPopup.style.display='flex';
    }catch(err){ console.error('parse details', err); }
  });
});
closeDetailsBtn?.addEventListener('click',()=>detailsPopup.style.display='none');
detailsPopup?.addEventListener('click',(e)=>{ if(e.target===detailsPopup) detailsPopup.style.display='none'; });

/* ======== Popup renouvellement ======== */
const popupOverlay = document.getElementById('renewal-popup-overlay');
const stepChoice   = document.getElementById('popup-step-choice');
const stepAllocate = document.getElementById('popup-step-allocate');
const stepConfirm  = document.getElementById('popup-step-confirm');
const slider       = document.getElementById('reinvest-slider');
const promoCodeInput    = document.getElementById('promo-code-input');
const referralCodeInput = document.getElementById('referral-code-input');
const hiddenPromo       = document.getElementById('popup-promo-code');
const hiddenReferral    = document.getElementById('popup-referral-code');
const ibanInput         = document.getElementById('iban-input');
const choiceCtaBtn      = document.getElementById('popup-cta-choice');
const renewalForm       = document.getElementById('renewal-form');

function openRenewalPopupObj(obj){
  currentContractData = obj || {};
  const capital = Number(currentContractData.montant)||0;
  const gains   = Number(currentContractData.rendement_total_contrat)||0;
  const total   = capital + gains;

  document.getElementById('popup-contract-id').value = currentContractData.id||'';
  document.getElementById('popup-total-amount').textContent = fmt(total);
  document.getElementById('popup-amount-details').textContent = `(Capital de ${fmt(capital)} + Gains de ${fmt(gains)})`;

  // reset
  slider.value = 100;
  reinvestmentCart = [];
  updateSliderAmounts(100);
  stepChoice.classList.remove('hidden');
  stepAllocate.classList.add('hidden');
  stepConfirm.classList.add('hidden');

  if (promoCodeInput) promoCodeInput.value='';
  if (referralCodeInput) referralCodeInput.value='';
  onCodeChanged('promo',''); onCodeChanged('referral',''); codeInfo={promo:null,referral:null};

  popupOverlay.style.display='flex';
}
function closeRenewalPopup(){ popupOverlay.style.display='none'; }

// Bouton “Gérer (Personnalisé)” — dataset base64
document.querySelectorAll('.js-open-popup').forEach(btn=>{
  btn.addEventListener('click',()=>{
    try{
      const b64 = btn.getAttribute('data-contrat-b64')||'';
      const data = JSON.parse(atob(b64));
      openRenewalPopupObj(data);
    }catch(err){ console.error('open popup', err); }
  });
});

function updateSliderAmounts(pct){
  pct = Math.min(100, Math.max(0, Number(pct)||0));
  const total = (Number(currentContractData.montant)||0) + (Number(currentContractData.rendement_total_contrat)||0);
  const reinv = Math.round((total * (pct/100) + Number.EPSILON)*100)/100;
  const wd    = Math.round(((total - reinv) + Number.EPSILON)*100)/100;

  document.getElementById('amount-reinvest').textContent = fmt(reinv);
  document.getElementById('amount-withdraw').textContent = fmt(wd);

  const needIban = wd >= 0.01;
  const ibanSec  = document.getElementById('iban-section');
  const fb       = ibanSec?.querySelector('.form-feedback');
  ibanSec?.classList.toggle('hidden', !needIban);
  if(!needIban && ibanInput){
    ibanInput.value=''; ibanInput.classList.remove('input-error'); if(fb) fb.textContent='';
  }
  choiceCtaBtn.textContent = (reinv > 0.01) ? 'Étape suivante' : 'Confirmer le retrait total';
}
slider.addEventListener('input', e => updateSliderAmounts(e.target.value));

/* === Allocation produits === */
function enforcePlantTypeRules(){
  const list = document.getElementById('product-list');
  if(!list || !currentContractData || !currentContractData.produit_id) return;
  list.querySelectorAll('.product-item').forEach(item=>{
    const btn = item.querySelector('.add-product-btn');
    if(!btn) return;
    const index = btn.getAttribute('data-index');
    const p = availableProducts[index]; if(!p) return;
    const keepRadio = item.querySelector(`input[name="plant_type_${p.id}"][value="mature"]`);
    const keepLabel = keepRadio ? keepRadio.closest('label') : null;
    const allowed = Number(p.id) === Number(currentContractData.produit_id);
    if(keepRadio){
      keepRadio.disabled = !allowed;
      if(!allowed){
        keepRadio.checked=false;
        const newRadio = item.querySelector(`input[name="plant_type_${p.id}"][value="new"]`);
        if(newRadio) newRadio.checked = true;
        if(keepLabel){ keepLabel.style.opacity=.4; keepLabel.title="Option disponible uniquement pour le même produit."; }
      }else{
        if(keepLabel){ keepLabel.style.opacity=1; keepLabel.title=""; }
      }
    }
  });
}

function updateAllocationProgress(){
  const cartEl=document.getElementById('reinvestment-cart');
  const emptyMsg=document.getElementById('cart-empty-msg');
  const allocatedEl=document.getElementById('allocated-amount');
  const totalEl=document.getElementById('total-to-allocate');
  const warnEl=document.getElementById('top-up-warning');
  const bar=document.getElementById('allocation-bar-fill');
  if(!cartEl||!emptyMsg||!allocatedEl||!totalEl||!warnEl||!bar) return;

  cartEl.querySelectorAll('.cart-item').forEach(el=>el.remove());
  emptyMsg.style.display = reinvestmentCart.length>0 ? 'none':'block';

  let allocated=0;
  reinvestmentCart.forEach((it,idx)=>{
    const qty=Number(it.qty||1), unit=Number(it.prix||0), line=qty*unit;
    allocated += line;
    const plantTypeText = (it.plantType==='mature')?'Plants matures':'Jeunes pousses';
    cartEl.insertAdjacentHTML('beforeend',
      `<div class="cart-item" data-index="${idx}">
        <span>${it.name} (${plantTypeText}) — ${fmt(unit)} × ${qty} <strong>= ${fmt(line)}</strong></span>
        <span>
          <button type="button" class="qty-minus" aria-label="Diminuer">−</button>
          <button type="button" class="qty-plus" aria-label="Augmenter">+</button>
          <button type="button" class="remove-item-btn" data-index="${idx}" aria-label="Supprimer">×</button>
        </span>
      </div>`);
  });

  allocatedEl.textContent = fmt(allocated);
  totalEl.textContent = fmt(totalToAllocate);

  if(allocated > totalToAllocate){
    bar.style.width='100%'; bar.classList.add('is-over');
    const topUp = allocated - totalToAllocate;
    warnEl.innerHTML = `<br><span style="color:var(--warning-color);">(Versement complémentaire : ${fmt(topUp)})</span>`;
    document.getElementById('top-up-amount').textContent = fmt(topUp);
    document.getElementById('top-up-section').classList.remove('hidden');
  }else{
    const pct = totalToAllocate>0 ? (allocated/totalToAllocate)*100 : 0;
    bar.style.width = `${pct}%`; bar.classList.remove('is-over');
    warnEl.innerHTML = ''; document.getElementById('top-up-section').classList.add('hidden');
    const cb = document.getElementById('top-up-checkbox'); if(cb) cb.checked=false;
  }
  document.getElementById('popup-cta-allocate').disabled = (reinvestmentCart.length===0);
}

/* Étape 1 -> Étape 2 */
document.getElementById('popup-cta-choice').addEventListener('click',()=>{
  const reinv = parseFloat((document.getElementById('amount-reinvest').textContent||'0').replace(/[^\d,.-]/g,'').replace(',','.'))||0;
  totalToAllocate = reinv;

  if (totalToAllocate < 0.01) { // retrait total
    reinvestmentCart=[];
    goToConfirmStep();
    return;
  }

  stepChoice.classList.add('hidden');
  stepAllocate.classList.remove('hidden');
  document.getElementById('total-to-allocate').textContent = fmt(totalToAllocate);

  const list = document.getElementById('product-list');
  list.innerHTML='';
  availableProducts.forEach((p, index)=>{
    list.insertAdjacentHTML('beforeend', `
      <div class="product-item">
        <div class="product-item-info">
          <strong>${p.name} - ${fmt(parseFloat(p.prix||0))}</strong>
          <span>Durée: ${p.duree_mois} mois</span>
          <div class="plant-choice-toggle" style="margin-top:8px;font-size:13px;">
            <label><input type="radio" name="plant_type_${p.id}" value="new" checked> Jeunes Pousses</label>
            <label style="margin-left:10px;"><input type="radio" name="plant_type_${p.id}" value="mature"> Garder mes plants</label>
          </div>
        </div>
        <button class="add-product-btn" data-index="${index}" type="button">Ajouter</button>
      </div>
    `);
  });
  enforcePlantTypeRules();
  updateAllocationProgress();
});

/* Step 2: add/remove/qty */
document.getElementById('product-list').addEventListener('click',(e)=>{
  const btn=e.target.closest('.add-product-btn'); if(!btn) return;
  const now=Date.now(); if(now-lastAddTs<250) return; lastAddTs=now;

  const idx=btn.getAttribute('data-index');
  const base={...availableProducts[idx]};
  const plant = (document.querySelector(`input[name="plant_type_${base.id}"]:checked`)?.value)||'new';

  const existing = reinvestmentCart.find(it => Number(it.id)===Number(base.id) && (it.plantType||'new')===plant);
  if(existing){ existing.qty=(existing.qty||1)+1; }
  else { base.plantType=plant; base.qty=1; reinvestmentCart.push(base); }
  updateAllocationProgress();
});

document.getElementById('reinvestment-cart').addEventListener('click',(e)=>{
  const row=e.target.closest('.cart-item'); if(!row) return;
  const idx=Number(row.dataset.index); const it=reinvestmentCart[idx]; if(!it) return;

  if(e.target.classList.contains('qty-plus')) it.qty=(it.qty||1)+1;
  else if(e.target.classList.contains('qty-minus')) it.qty=Math.max(1,(it.qty||1)-1);
  else if(e.target.classList.contains('remove-item-btn')) reinvestmentCart.splice(idx,1);
  else return;

  updateAllocationProgress();
});

/* Étape 2 -> Étape 1 (retour) */
document.getElementById('popup-back-to-choice-btn').addEventListener('click',()=>{
  stepAllocate.classList.add('hidden'); stepChoice.classList.remove('hidden');
});

/* Codes promo / parrain */
function getCodeInfo(code){ const c=normalizeCode(code); if(!c) return null; return serverCodes[c]||{valid:false}; }
function getRefInfo(code){ const c=normalizeCode(code); if(!c) return null; return referralCodes[c]||{valid:false}; }
function computeDiscount(obj, base){
  if(!obj||!obj.valid||base<=0) return 0;
  if(obj.type==='percent') return Math.max(0, (Number(obj.value)/100)*base);
  if(obj.type==='amount') return Math.min(base, Math.max(0, Number(obj.value)));
  return 0; // type none => 0
}
function renderDiscountLines(base, promoObj, refObj){
  let html=''; let total=0;
  if(promoObj && !promoObj.stackable && refObj && !refObj.stackable){
    const pd=computeDiscount(promoObj,base), rd=computeDiscount(refObj,base);
    if(pd>=rd) refObj=null; else promoObj=null;
  }
  if(promoObj?.valid){ const d=computeDiscount(promoObj, base); total+=d; html+=`<div>• ${promoObj.label||'Code promo'}: -${fmt(d)}</div>`; }
  if(refObj?.valid){
    const remaining = (promoObj?.stackable) ? (base-total) : base;
    const d=computeDiscount(refObj, remaining); total+=d;
    if(refObj.type==='none') html+=`<div>• Code Parrain reconnu : ${refObj.label||''} (pas de remise, suivi parrain)</div>`;
    else html+=`<div>• Code Parrain: -${fmt(d)}</div>`;
  }
  if(!html) html='<em>Aucune remise appliquée pour le moment.</em>';
  else html += `<div style="margin-top:6px;font-weight:700;">Total remises : -${fmt(total)}</div>`;
  document.getElementById('discount-lines').innerHTML=html;
  return total;
}

function recalcDiscountsAndTotals(){
  const round2 = v => Math.round((Number(v)+Number.EPSILON)*100)/100;
  const gross = reinvestmentCart.reduce((s,it)=> s+(Number(it.prix)||0)*(Number(it.qty||1)),0);
  const disc  = renderDiscountLines(gross, codeInfo.promo, codeInfo.referral);
  const net   = Math.max(0, round2(gross - disc));

  const totalAvail = (Number(currentContractData.montant)||0) + (Number(currentContractData.rendement_total_contrat)||0);
  const useFromAvail = Math.min(net, Number(totalToAllocate)||0);

  const provisionalWithdraw = round2(totalAvail - useFromAvail);
  const provisionalTopUp    = Math.max(0, round2(net - (Number(totalToAllocate)||0)));

  let finalWithdraw=0, finalTopUp=0;
  if (provisionalWithdraw >= provisionalTopUp){
    finalWithdraw = round2(provisionalWithdraw - provisionalTopUp);
    finalTopUp = 0;
  } else {
    finalTopUp = round2(provisionalTopUp - provisionalWithdraw);
    finalWithdraw = 0;
  }

  document.getElementById('confirm-reinvest').textContent = fmt(gross);
  document.getElementById('confirm-withdraw').textContent = fmt(finalWithdraw);
  document.getElementById('confirm-top-up-after-discount').textContent = fmt(finalTopUp);

  const plan = (document.querySelector('input[name="payment_plan_choice"]:checked')||{}).value || 'full';
  const monthly = (plan==='12x' && finalTopUp>0) ? round2(finalTopUp/12) : 0;
  document.getElementById('confirm-monthly-12x').textContent = (plan==='12x' && finalTopUp>0)? `${fmt(monthly)} / mois` : `${fmt(0)} / mois`;

  document.getElementById('popup-withdraw-amount').value       = finalWithdraw.toFixed(2);
  const topUpBrut = Math.max(0, round2(gross - (Number(totalToAllocate)||0)));
  document.getElementById('popup-top-up-amount').value         = topUpBrut.toFixed(2);
  document.getElementById('popup-top-up-after-discount').value = finalTopUp.toFixed(2);
  document.getElementById('popup-monthly-12x').value           = monthly.toFixed(2);
  document.getElementById('popup-contract-discount').value     = round2(disc).toFixed(2);
}

function onCodeChanged(kind, val){
  const norm = normalizeCode(val);
  const data = (kind==='referral')? getRefInfo(norm) : getCodeInfo(norm);
  codeInfo[kind] = data;

  const icon = document.getElementById(`${kind}-status-icon`);
  const fb   = document.getElementById(`${kind}-feedback`);
  if(icon && fb){
    if(!norm){ icon.textContent=''; fb.textContent=''; }
    else if(data?.valid){ icon.textContent='✅'; fb.textContent=(kind==='referral' && data.type==='none')?'Code parrain reconnu (pas de remise).':'Code valide !'; fb.style.color='green'; }
    else { icon.textContent='❌'; fb.textContent=(kind==='referral')?'Code parrain invalide.':'Code invalide ou expiré.'; fb.style.color='red'; }
  }
  if(kind==='promo') document.getElementById('popup-promo-code').value = norm;
  if(kind==='referral') document.getElementById('popup-referral-code').value = norm;

  recalcDiscountsAndTotals();
}
promoCodeInput?.addEventListener('input', e=>onCodeChanged('promo', e.target.value));
referralCodeInput?.addEventListener('input', e=>onCodeChanged('referral', e.target.value));

/* Paiement toggle */
function setPaymentPlan(val){
  document.getElementById('popup-payment-plan').value = val;
  document.getElementById('payment-choice-full').checked = (val==='full');
  document.getElementById('payment-choice-12x').checked  = (val==='12x');
  document.querySelectorAll('.payment-btn').forEach(b=>{
    const active = (b.dataset.value===val);
    b.classList.toggle('active', active);
    b.setAttribute('aria-pressed', active?'true':'false');
  });
  recalcDiscountsAndTotals();
}
document.getElementById('payment-toggle')?.addEventListener('click',(e)=>{
  const btn=e.target.closest('.payment-btn'); if(!btn) return;
  setPaymentPlan(btn.dataset.value);
});
setPaymentPlan('full');

/* Étape 2 -> Étape 3 */
function goToConfirmStep(){
  stepAllocate.classList.add('hidden'); stepChoice.classList.add('hidden'); stepConfirm.classList.remove('hidden');

  const wd = parseFloat((document.getElementById('amount-withdraw').textContent||'0').replace(/[^\d,.-]/g,'').replace(',','.'))||0;
  const showIban = wd > 0.01;
  document.getElementById('confirm-iban-section').classList.toggle('hidden', !showIban);
  if(showIban) document.getElementById('confirm-iban').value = ibanInput.value||'';
  document.getElementById('popup-iban-value').value = ibanInput.value||'';

  const cont = document.getElementById('new-contracts-inputs'); cont.innerHTML='';
  reinvestmentCart.forEach((it,i)=>{
    cont.insertAdjacentHTML('beforeend', `
      <input type="hidden" name="new_products[${i}][id]" value="${it.id}">
      <input type="hidden" name="new_products[${i}][plant_type]" value="${it.plantType}">
      <input type="hidden" name="new_products[${i}][quantity]" value="${Number(it.qty||1)}">
    `);
  });

  // sync codes puis recalc
  onCodeChanged('promo', promoCodeInput?promoCodeInput.value:'');
  onCodeChanged('referral', referralCodeInput?referralCodeInput.value:'');
  recalcDiscountsAndTotals();
}
document.getElementById('popup-cta-allocate').addEventListener('click', goToConfirmStep);

/* Retours */
document.getElementById('popup-back-btn').addEventListener('click',()=>{
  stepConfirm.classList.add('hidden');
  if (totalToAllocate > 0.01) stepAllocate.classList.remove('hidden');
  else stepChoice.classList.remove('hidden');
});

/* Presets Étape 1 */
stepChoice.addEventListener('click',(e)=>{
  const b=e.target.closest('.preset-btn'); if(!b) return;
  const action=b.dataset.value;
  const total =(Number(currentContractData.montant)||0)+(Number(currentContractData.rendement_total_contrat)||0);
  let pct=100;
  if(action==='0') pct=0;
  else if(action==='100') pct=100;
  else if(action==='gains'){
    const gains=Number(currentContractData.rendement_total_contrat)||0;
    pct= total>0 ? (gains/total)*100 : 0;
  }
  slider.value=pct; slider.dispatchEvent(new Event('input'));
});

/* Soumission finale */
renewalForm.addEventListener('submit', function(e){
  e.preventDefault();
  recalcDiscountsAndTotals();

  const wd = parseFloat(document.getElementById('popup-withdraw-amount').value||'0');
  const ibanHidden = document.getElementById('popup-iban-value');
  const topUpBrut  = parseFloat(document.getElementById('popup-top-up-amount').value||'0');

  if (wd>0){
    if(!ibanHidden.value || ibanHidden.value.trim().length<10){
      const fb = document.querySelector('#iban-section .form-feedback');
      if(fb){ fb.textContent='Veuillez renseigner un IBAN valide.'; }
      ibanInput.classList.add('input-error');
      alert("Veuillez renseigner un IBAN valide pour le virement.");
      return;
    }
  } else {
    ibanHidden.value=''; ibanHidden.disabled=true;
  }

  if (topUpBrut>0 && !document.getElementById('top-up-checkbox').checked){
    if(!confirm("Vous avez un versement complémentaire à régler, mais la case de confirmation n'est pas cochée. Continuer quand même ?")) return;
  }

  this.submit();
});

/* Erreurs de formulaire (retour serveur) */
(function(){
  const formErrors = <?php echo json_encode($FORM_ERRORS ?? []); ?>;
  if(!formErrors || !Object.keys(formErrors).length) return;
  const overlay=document.getElementById('renewal-popup-overlay');
  overlay.style.display='flex';
  stepChoice.classList.remove('hidden'); stepAllocate.classList.add('hidden'); stepConfirm.classList.add('hidden');
  setTimeout(()=>{ const iban=document.getElementById('iban-input'); if(iban && formErrors.iban){ iban.classList.add('input-error'); const fb=iban.parentElement.querySelector('.form-feedback'); if(fb){ fb.textContent=formErrors.iban; } iban.focus(); }},50);
})();
</script>
</body>
</html>
<?php
// ======================================================================
// recoltes.php — version front + AJAX compatible avec create-checkout-session.php
// - Ne modifie PAS la logique serveur de create-checkout-session.php
// - Envoi AJAX (fetch) avec headers JSON et 'X-Requested-With: XMLHttpRequest'
// - Redirige vers success.php?session_id=manual si {"id":"manual"}
// - Redirige vers Stripe si {"id":"cs_..."}
// ======================================================================

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/db_connection.php';

// -------- Auth minimal --------
if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit();
}
$userId = (int)$_SESSION['user_id'];

// -------- CSRF token --------
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$CSRF = $_SESSION['csrf_token'];

// -------- Clé publique Stripe --------
$stripePublic = defined('STRIPE_PUBLIC_KEY')
    ? STRIPE_PUBLIC_KEY
    : (getenv('STRIPE_PUBLIC_KEY') ?: ($_SERVER['STRIPE_PUBLIC_KEY'] ?? ''));

// -------- Récup des contrats utilisateur (exemple simple, adapte si besoin) --------
$stmt = $pdo->prepare("
    SELECT c.id, c.produit_id, c.montant, c.apport, c.taux_moyen, c.statut, c.date_fin,
           p.name AS produit_name, p.prix, p.taux
    FROM contrats c
    JOIN produits p ON p.id = c.produit_id
    WHERE c.user_id = ?
    ORDER BY c.id DESC
");
$stmt->execute([$userId]);
$contrats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------- Titre carte (légèrement recalibré pour responsive) --------
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mes récoltes</title>
<link rel="preconnect" href="https://js.stripe.com">
<link rel="stylesheet" href="/assets/css/style.css">
<style>
/* Ajuste le titre de carte pour ne pas casser en mobile */
.card-title {
  font-size: clamp(1.15rem, 1.6vw, 1.5rem);
  line-height: 1.2;
  font-weight: 700;
  margin: 0 0 .5rem 0;
}
.badge {
  display:inline-block; padding:.25rem .5rem; border-radius:999px;
  font-size:.78rem; background:#f5f5f5; border:1px solid #e7e7e7;
}
.card {background:#fff; border-radius:16px; box-shadow:0 6px 24px rgba(0,0,0,.06); padding:16px; margin:12px 0;}
.btn {cursor:pointer; border:0; border-radius:10px; padding:.7rem 1rem; font-weight:600}
.btn-primary{background:#d81b60; color:#fff}
.btn-outline{background:#fff; border:1px solid #ddd}
.btn-row{display:flex; gap:.5rem; flex-wrap:wrap}
.row{display:grid; gap:14px; grid-template-columns:1fr}
@media (min-width: 900px){ .row{grid-template-columns:repeat(2,1fr)} }
.input, select {width:100%; padding:.65rem .75rem; border:1px solid #ddd; border-radius:10px}
label{font-size:.9rem; color:#444; margin:.4rem 0 .2rem}
.modal-backdrop{position:fixed; inset:0; background:rgba(0,0,0,.45); display:none; align-items:center; justify-content:center; z-index:1000}
.modal{background:#fff; border-radius:14px; padding:18px; max-width:440px; width:92%}
.modal.show + .modal-backdrop, .modal-backdrop.show{display:flex}
.help{font-size:.85rem; color:#666}
.error{background:#ffe9e9; color:#8a1f1f; padding:.6rem .7rem; border-radius:8px; margin-top:.6rem; display:none}
.success{background:#e9ffe9; color:#1f8a1f; padding:.6rem .7rem; border-radius:8px; margin-top:.6rem; display:none}
</style>
<script src="https://js.stripe.com/v3/"></script>
</head>
<body>

<div class="container" style="max-width:1100px;margin:24px auto;padding:0 16px">

  <h1 class="card-title">Mes contrats & opérations</h1>
  <p class="help">Renouvelez, réinvestissez ou retirez en quelques clics. Toutes les actions se finalisent sur la page de confirmation.</p>

  <?php foreach ($contrats as $c): 
      $cid = (int)$c['id'];
      $statut = $c['statut'] ?: '';
      $base = (float)($c['montant'] ?? $c['apport']);
      $rend = $base * ((float)$c['taux_moyen'] / 100.0);
      $dispo = $base + $rend;
  ?>
  <div class="card" id="contract-<?php echo $cid; ?>">
    <div style="display:flex; justify-content:space-between; align-items:baseline; gap:12px; flex-wrap:wrap">
      <div>
        <div class="card-title">
          <?php echo h($c['produit_name']); ?>
        </div>
        <div class="help">
          Contrat #<?php echo $cid; ?> • Statut: <span class="badge"><?php echo h($statut); ?></span>
        </div>
      </div>
      <div style="text-align:right">
        <div><strong>Disponible estimé :</strong> <?php echo number_format($dispo, 2, ',', ' '); ?> €</div>
        <div class="help">Base <?php echo number_format($base, 2, ',', ' '); ?> € + Rendement <?php echo number_format($rend, 2, ',', ' '); ?> €</div>
      </div>
    </div>

    <hr style="border:none;border-top:1px solid #eee;margin:12px 0">

    <!-- Actions rapides -->
    <div class="btn-row">
      <button class="btn btn-primary" 
              onclick="actionReinvestAll(<?php echo $cid; ?>)">Tout réinvestir</button>

      <button class="btn btn-outline" 
              onclick="openWithdrawAll(<?php echo $cid; ?>)">Tout retirer</button>

      <button class="btn btn-outline"
              onclick="openCustomRenew(<?php echo $cid; ?>)">Renouvellement personnalisé</button>
    </div>

    <div class="error" id="err-<?php echo $cid; ?>"></div>
    <div class="success" id="ok-<?php echo $cid; ?>"></div>
  </div>
  <?php endforeach; ?>

</div>

<!-- Modale IBAN pour "Tout retirer" -->
<div class="modal-backdrop" id="backdrop-withdraw">
  <div class="modal" id="modal-withdraw">
    <h2 class="card-title">Retirer 100% — IBAN requis</h2>
    <p class="help">Saisissez votre IBAN (ex. FR76…)</p>
    <form onsubmit="return submitWithdrawAll(event);">
      <input type="hidden" id="withdraw_contract_id" value="">
      <label for="iban">IBAN</label>
      <input class="input" id="iban" name="iban" required placeholder="FR76…">
      <div class="error" id="err-withdraw"></div>
      <div style="display:flex; gap:.5rem; margin-top:12px">
        <button class="btn btn-primary" type="submit">Valider</button>
        <button class="btn btn-outline" type="button" onclick="closeWithdrawAll()">Annuler</button>
      </div>
    </form>
  </div>
</div>

<!-- Modale Renouvellement personnalisé (exemple simple: 1 produit & quantité) -->
<div class="modal-backdrop" id="backdrop-custom">
  <div class="modal" id="modal-custom">
    <h2 class="card-title">Renouvellement personnalisé</h2>
    <form onsubmit="return submitCustomRenew(event);">
      <input type="hidden" id="custom_contract_id" value="">
      <label for="product_id">Produit</label>
      <select class="input" id="product_id" required>
        <?php
        // Liste rapide des produits actifs
        $pstmt = $pdo->query("SELECT id, name FROM produits WHERE is_active = 1 ORDER BY name ASC");
        foreach ($pstmt->fetchAll(PDO::FETCH_ASSOC) as $p) {
            echo '<option value="'.(int)$p['id'].'">'.h($p['name']).'</option>';
        }
        ?>
      </select>
      <label for="quantity">Quantité</label>
      <input class="input" id="quantity" type="number" min="1" step="1" value="1">
      <div class="help">Une remise ou un code peuvent s’appliquer dans l’étape suivante si configuré côté page.</div>
      <div class="error" id="err-custom"></div>
      <div style="display:flex; gap:.5rem; margin-top:12px">
        <button class="btn btn-primary" type="submit">Continuer</button>
        <button class="btn btn-outline" type="button" onclick="closeCustomRenew()">Annuler</button>
      </div>
    </form>
  </div>
</div>

<script>
// =============================
// Helpers UI modales
// =============================
function qs(id){ return document.getElementById(id); }

function openWithdrawAll(contractId){
  qs('withdraw_contract_id').value = String(contractId);
  qs('err-withdraw').style.display = 'none';
  document.getElementById('backdrop-withdraw').classList.add('show');
}
function closeWithdrawAll(){
  document.getElementById('backdrop-withdraw').classList.remove('show');
}

function openCustomRenew(contractId){
  qs('custom_contract_id').value = String(contractId);
  qs('err-custom').style.display='none';
  document.getElementById('backdrop-custom').classList.add('show');
}
function closeCustomRenew(){
  document.getElementById('backdrop-custom').classList.remove('show');
}

// =============================
// Stripe init
// =============================
const STRIPE_PUBLIC_KEY = <?php echo json_encode($stripePublic); ?>;
let stripe = null;
if (STRIPE_PUBLIC_KEY) {
  stripe = Stripe(STRIPE_PUBLIC_KEY);
}

// =============================
// Cœur : POST vers create-checkout-session.php (AJAX)
// - en-têtes 'X-Requested-With' + 'Accept: application/json' pour déclencher le mode AJAX
// - gère {"id":"manual"} et {"id":"cs_..."}
// =============================
async function postToCreate(formDataObj) {
  // Injection sécurisée du CSRF depuis PHP
  formDataObj['csrf_token'] = <?php echo json_encode($CSRF); ?>;

  const body = new URLSearchParams();
  for (const [k, v] of Object.entries(formDataObj)) {
    if (typeof v === 'object') {
      body.append(k, JSON.stringify(v));
    } else {
      body.append(k, String(v));
    }
  }

  const res = await fetch('/create-checkout-session.php', {
    method: 'POST',
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Accept': 'application/json'
    },
    body
  });

  const isJson = (res.headers.get('content-type') || '').includes('application/json');
  if (!isJson) {
    // Garde-fou : si jamais le serveur renvoyait autre chose
    const tx = await res.text();
    throw new Error('Réponse inattendue du serveur: ' + tx.slice(0, 200));
  }
  const data = await res.json();

  if (!res.ok) {
    const msg = (data && data.error) ? data.error : 'Erreur serveur.';
    const field = data && data.field ? data.field : null;
    const err = new Error(msg);
    err.field = field;
    throw err;
  }
  return data; // { id: 'manual' } ou { id: 'cs_...' }
}

// =============================
// Actions rapides : Tout réinvestir
// =============================
async function actionReinvestAll(contractId){
  const err = document.getElementById('err-'+contractId);
  const ok  = document.getElementById('ok-'+contractId);
  if (err) err.style.display='none';
  if (ok)  ok.style.display='none';

  try {
    const payload = {
      action_type: 'reinvest_all',
      contract_id: contractId
      // create s'occupe du reste ; AJAX activé par les headers
    };
    const data = await postToCreate(payload);
    if (data && data.id === 'manual') {
      // Succès manuel → success.php
      window.location.assign('/success.php?session_id=manual');
      return;
    }
    if (data && typeof data.id === 'string' && data.id.startsWith('cs_')) {
      if (!stripe) throw new Error("Clé publique Stripe manquante");
      await stripe.redirectToCheckout({ sessionId: data.id });
      return;
    }
    throw new Error("Réponse inattendue.");
  } catch(e) {
    if (err){ err.textContent = e.message || 'Erreur'; err.style.display='block'; }
  }
}

// =============================
// Actions rapides : Tout retirer (avec IBAN)
// =============================
async function submitWithdrawAll(ev){
  ev.preventDefault();
  const contractId = qs('withdraw_contract_id').value;
  const iban = qs('iban').value.trim();
  const errBox = qs('err-withdraw');
  errBox.style.display = 'none';

  try {
    if (!iban){ throw new Error("Merci de renseigner un IBAN."); }
    const payload = {
      action_type: 'withdraw_all',
      contract_id: contractId,
      iban: iban
    };
    const data = await postToCreate(payload);
    // Toujours success manuel pour withdraw_all
    if (data && data.id === 'manual') {
      window.location.assign('/success.php?session_id=manual');
      return false;
    }
    throw new Error("Réponse inattendue.");
  } catch(e) {
    errBox.textContent = (e && e.message) ? e.message : 'Erreur';
    errBox.style.display = 'block';
  }
  return false;
}
function openWithdrawAllFromBtn(cid){ openWithdrawAll(cid); }

// =============================
// Renouvellement personnalisé : 1 produit (exemple simple)
// =============================
async function submitCustomRenew(ev){
  ev.preventDefault();
  const cid = qs('custom_contract_id').value;
  const pid = qs('product_id').value;
  const qty = Math.max(1, parseInt(qs('quantity').value || '1', 10));
  const errBox = qs('err-custom');
  errBox.style.display = 'none';

  try {
    // create attend 'new_products' (array d’objets {id, quantity, plant_type})
    const newProducts = [{ id: Number(pid), quantity: qty, plant_type: 'mature' }];

    const payload = {
      action_type: 'renewal_custom',
      contract_id: cid,
      new_products: newProducts
      // S’il y a des remises/codes côté UI, ajoute:
      // contract_discount_total: 0,
      // promo_code: '...',
      // referral_code: '...'
    };

    const data = await postToCreate(payload);

    if (data && data.id === 'manual') {
      // Cas 0 € → success direct
      window.location.assign('/success.php?session_id=manual');
      return false;
    }
    if (data && typeof data.id === 'string' && data.id.startsWith('cs_')) {
      if (!stripe) throw new Error("Clé publique Stripe manquante");
      await stripe.redirectToCheckout({ sessionId: data.id });
      return false;
    }
    throw new Error("Réponse inattendue.");
  } catch(e) {
    errBox.textContent = (e && e.message) ? e.message : 'Erreur';
    errBox.style.display = 'block';
  }
  return false;
}
</script>

</body>
</html>
