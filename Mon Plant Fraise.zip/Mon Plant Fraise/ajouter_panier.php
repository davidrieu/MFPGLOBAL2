<?php
// On démarre la session pour pouvoir la manipuler
session_start();

// On s'assure que l'utilisateur est bien connecté
if (!isset($_SESSION['user_id'])) {
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'Utilisateur non connecté']);
    exit();
}

// On récupère les données du produit envoyées par le JavaScript (en format JSON)
$json_str = file_get_contents('php://input');
$produit = json_decode($json_str, true);

// On vérifie que les données nécessaires sont bien là
if (!$produit || !isset($produit['id']) || !isset($produit['nom']) || !isset($produit['prix'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Données du produit invalides']);
    exit();
}

// On initialise le panier en session s'il n'existe pas encore
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// On cherche si le produit existe déjà dans le panier pour simplement augmenter la quantité
$itemKey = null;
foreach ($_SESSION['cart'] as $key => $item) {
    if ($item['id'] === $produit['id']) {
        $itemKey = $key;
        break;
    }
}

if ($itemKey !== null) {
    // Le produit existe, on incrémente la quantité
    $_SESSION['cart'][$itemKey]['quantity']++;
} else {
    // Le produit n'existe pas, on l'ajoute avec toutes ses informations
    $_SESSION['cart'][] = [
        'id'       => $produit['id'],     // L'ID est maintenant inclus !
        'name'     => $produit['nom'],
        'price'    => $produit['prix'],
        'quantity' => 1
    ];
}

// On renvoie une réponse de succès au JavaScript
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => 'Produit ajouté au panier',
    'cart' => $_SESSION['cart'] // On renvoie le panier à jour
]);
?>