<?php
// Ce fichier vérifie si l'utilisateur connecté fait partie de la "Team Sentinel"
// et affiche un badge si la condition est remplie.

// On s'assure que la session est bien démarrée.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// On vérifie si un utilisateur est connecté
if (isset($_SESSION['user_id'])) {
    
    // On a besoin de la connexion à la base de données.
    // Si db_connection.php n'est pas déjà inclus, on le fait.
    if (!isset($pdo)) {
        require_once 'db_connection.php';
    }

    try {
        // 1. Récupérer le code parrain de l'utilisateur connecté
        $userId = $_SESSION['user_id'];
        $stmt = $pdo->prepare("SELECT parrain FROM users WHERE id = :user_id");
        $stmt->execute([':user_id' => $userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // 2. Vérifier si le code parrain correspond
        if ($user && $user['parrain'] === 'MPF102569') {
            
            // 3. Si oui, on affiche le HTML et le CSS du badge
            echo <<<HTML
                <style>
                    /* Style du badge Team Sentinel */
                    .sentinel-badge {
                        position: fixed; /* Reste fixe même au défilement */
                        bottom: 25px; /* Légèrement plus haut pour une meilleure visibilité */
                        right: 25px; /* Légèrement plus à gauche */
                        z-index: 1000; /* S'affiche au-dessus des autres éléments */
                        
                        display: flex;
                        align-items: center;
                        gap: 12px; /* Espace légèrement augmenté entre le logo et le texte */
                        
                        background-color: #2c3e50; /* Couleur de fond sombre */
                        color: #ffffff; /* Texte blanc */
                        padding: 10px 20px; /* Rembourrage légèrement augmenté */
                        border-radius: 50px; /* Forme de pilule */
                        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Ombre plus prononcée */
                        
                        font-family: Arial, sans-serif;
                        font-size: 16px; /* Texte légèrement plus grand */
                        font-weight: bold;
                        text-decoration: none;
                        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
                    }
                    .sentinel-badge:hover {
                        transform: scale(1.08); /* Effet de grossissement plus prononcé au survol */
                        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4); /* Ombre plus intense au survol */
                    }
                    .sentinel-badge img {
                        width: 32px; /* Taille du logo augmentée pour être plus visible */
                        height: 32px;
                    }
                </style>

                <a href="#" class="sentinel-badge">
                    <img src="/images/logo_sentinel.png" alt="Logo Sentinel">
                    <span>Team Sentinel</span>
                </a>
            HTML;
        }
    } catch (Exception $e) {
        // En cas d'erreur de base de données, on l'enregistre sans planter la page
        error_log("Erreur lors de la vérification du badge Sentinel: " . $e->getMessage());
    }
}
?>