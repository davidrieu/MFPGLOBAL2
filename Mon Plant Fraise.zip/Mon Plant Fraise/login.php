<?php
// Debug (à retirer en prod)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Démarrer la session
session_start();

// 2. Inclure la connexion à la base de données (PDO)
require_once 'db_connection.php';

// Si l'utilisateur est déjà connecté, on le redirige
if (isset($_SESSION['user_id'])) {
    header('Location: espace-client.php');
    exit();
}

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (empty(trim($_POST['email'])) || empty(trim($_POST['password']))) {
        $error_message = 'Veuillez remplir tous les champs.';
    } else {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        try {
            $sql = "SELECT id, prenom, password FROM users WHERE email = :email LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->execute();

            if ($stmt->rowCount() !== 1) {
                $error_message = 'L\'email ou le mot de passe est incorrect.';
            } else {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user && password_verify($password, $user['password'])) {
                    session_regenerate_id(true);

                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_prenom'] = $user['prenom'];

                    header('Location: recoltes.php');
                    exit();
                } else {
                    $error_message = 'L\'email ou le mot de passe est incorrect.';
                }
            }
        } catch (PDOException $e) {
            $error_message = "Erreur technique. Veuillez réessayer plus tard.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Mon Plant Fraise</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <style>
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --primary-color: #2E7D32;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;
            --text-color: #212121;
            --text-color-light: #757575;
            --error-color: #c62828;
            --error-bg-color: #ffebee;
            --border-radius: 12px;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--background-color);
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            width: 100%;
            max-width: 900px;
            height: 600px;
            max-height: 90vh;
            background-color: var(--card-background-color);
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .branding-panel {
            background: var(--primary-gradient);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            text-align: center;
        }
        .branding-panel h1 {
            font-family: 'Poppins', sans-serif;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .branding-panel p {
            font-size: 16px;
            opacity: 0.9;
        }

        .form-panel {
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        /* NOUVEAU : Style pour le conteneur du logo dans le formulaire */
        .form-logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-logo-container img {
            max-width: 200px;
            height: auto;
        }

        .form-panel h2 {
            font-family: 'Poppins', sans-serif;
            font-size: 28px;
            color: var(--text-color);
            margin-top: 0;
            margin-bottom: 25px;
            text-align: center;
        }

        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-color);
            font-weight: 500;
        }
        .input-wrapper { position: relative; }
        .input-wrapper .material-symbols-outlined {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-color-light);
        }
        .form-group input {
            width: 100%;
            padding: 12px 12px 12px 45px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px var(--primary-color-light);
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background: var(--primary-gradient);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .btn-submit:hover {
            box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4);
            transform: translateY(-2px);
        }

        .error-message {
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: var(--error-bg-color);
            color: var(--error-color);
            padding: 12px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            border: 1px solid var(--error-color);
        }

        .links { text-align: center; margin-top: 20px; font-size: 14px; }
        .links a { color: var(--primary-color); text-decoration: none; font-weight: 500; }
        .links a:hover { text-decoration: underline; }

        @media (max-width: 900px) {
            .login-wrapper {
                grid-template-columns: 1fr;
                width: 100%;
                height: 100%;
                max-height: 100%;
                border-radius: 0;
                box-shadow: none;
            }
            .branding-panel { display: none; }
            .form-panel {
                padding: 20px;
                justify-content: center;
                max-width: 400px;
                margin: 0 auto;
            }
            body { align-items: stretch; }
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="branding-panel">
             <!-- MODIFIÉ : Le logo a été déplacé d'ici -->
            <h1>Votre Jardin Financier</h1>
            <p>Connectez-vous pour voir vos récoltes grandir.</p>
        </div>
        <div class="form-panel">

            <!-- NOUVEAU : Conteneur pour le logo -->
            <div class="form-logo-container">
                 <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise">
            </div>

            <h2>Connexion</h2>
            
            <?php if (!empty($error_message)): ?>
                <div class="error-message">
                    <span class="material-symbols-outlined">warning</span>
                    <span><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label for="email">Adresse Email</label>
                    <div class="input-wrapper">
                        <span class="material-symbols-outlined">mail</span>
                        <input type="email" name="email" id="email" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <div class="input-wrapper">
                        <span class="material-symbols-outlined">lock</span>
                        <input type="password" name="password" id="password" required>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn-submit">Se connecter</button>
                </div>
            </form>
            
            <div class="links">
                <a href="demande_reset.php">Mot de passe oublié ?</a>
            </div>
        </div>
    </div>
</body>
</html>
