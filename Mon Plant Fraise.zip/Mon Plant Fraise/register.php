<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - Mon Plant Fraise</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            color: #333;
            background-color: #f8f8f8;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .register-container {
            background-color: #fff;
            padding: 40px 50px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 450px;
            box-sizing: border-box;
            text-align: center;
        }
        .register-container h1 {
            color: #6B8E23;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .register-container p {
            font-size: 1rem;
            color: #666;
            margin-bottom: 30px;
        }
        .register-form .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .register-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .register-form input[type="text"],
        .register-form input[type="email"],
        .register-form input[type="tel"],
        .register-form input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
            font-family: 'Montserrat', sans-serif;
            box-sizing: border-box; /* Important pour le padding */
        }
        .register-form button {
            background-color: #6B8E23;
            color: #fff;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }
        .register-form button:hover {
            background-color: #5A7C1F;
        }
        .login-link {
            margin-top: 25px;
            font-size: 0.9rem;
        }
        .login-link a {
            color: #6B8E23;
            font-weight: 600;
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="register-container">
        <h1>Créez votre compte</h1>
        <p>Rejoignez l'aventure et suivez votre engagement.</p>

        <?php
        // Ici, vous pouvez ajouter un message si l'inscription a échoué
        if (isset($_GET['error'])) {
            echo '<p style="color: red; font-weight: bold; margin-bottom: 20px;">' . htmlspecialchars($_GET['error']) . '</p>';
        }
        ?>

        <form class="register-form" action="process_register.php" method="POST">
            <div class="form-group">
                <label for="nom_complet">Nom Complet *</label>
                <input type="text" id="nom_complet" name="nom_complet" required>
            </div>
            <div class="form-group">
                <label for="email">Adresse E-mail *</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="telephone">Téléphone</label>
                <input type="tel" id="telephone" name="telephone">
            </div>
            <div class="form-group">
                <label for="password">Mot de passe *</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="password_confirm">Confirmez le mot de passe *</label>
                <input type="password" id="password_confirm" name="password_confirm" required>
            </div>
            <button type="submit">M'inscrire</button>
        </form>

        <p class="login-link">
            Déjà un compte ? <a href="login.php">Connectez-vous</a>
        </p>
    </div>

</body>
</html>