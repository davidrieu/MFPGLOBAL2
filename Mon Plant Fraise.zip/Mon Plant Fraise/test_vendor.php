<?php
require __DIR__ . '/vendor/autoload.php';

$okOptions = class_exists(Dompdf\Options::class) ? 'OUI' : 'NON';
$path = __DIR__ . '/vendor/dompdf/dompdf/src/Options.php';
echo "Fichier Options.php existe: " . (file_exists($path) ? 'OUI' : 'NON') . " => $path\n";
echo "class_exists(Dompdf\\Options): $okOptions\n";

// Si Composer 2 est présent :
if (class_exists(Composer\InstalledVersions::class)) {
  $packages = Composer\InstalledVersions::getInstalledPackages();
  echo "Paquets installés:\n";
  foreach ($packages as $p) {
    if (stripos($p, 'dompdf') !== false) echo " - $p\n";
  }
}
