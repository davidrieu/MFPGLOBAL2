<?php

require_once 'db_connection.php';
include 'back_to_top.php';

$products = []; // Initialise la variable pour éviter les erreurs

try {
    // 2. RÉCUPÉRATION DES PRODUITS
    // On ajoute une condition pour ne récupérer que les produits en stock, pour ne pas afficher des cartes vides.
    // Si vous souhaitez tout de même afficher les produits indisponibles, remplacez par : "SELECT * FROM products ORDER BY variety_name ASC"
    $stmt = $pdo->query("SELECT * FROM products ORDER BY stock_grams > 0 DESC, variety_name ASC");
    $products = $stmt->fetchAll();

} catch (PDOException $e) {
    // Gérer l'erreur de requête si nécessaire
    die("Erreur lors de la récupération des produits : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commander - Mon Plant Fraise</title>
    <link rel="icon" href="images/logo-mpf.jpeg" type="image/jpeg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
<style>
    /* Styles Généraux */
    body, html {
        margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; color: #333; line-height: 1.6; background-color: #f8f8f8;
    }
    .container {
        width: 90%; max-width: 1200px; margin: 0 auto; padding: 20px 0;
    }

    /* --- En-tête --- */
    header {
        display: flex; justify-content: space-between; align-items: center; padding: 15px 5%; background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    .logo { display: flex; align-items: center; font-weight: 700; font-size: 1.2rem; text-decoration: none; color: #333; }
    .logo img { height: 50px; margin-right: 10px; }
    .main-menu a { text-decoration: none; color: #555; margin-left: 25px; font-weight: 500; transition: color 0.3s ease; }
    .main-menu a:hover { color: #6B8E23; }
    #menu-toggle, .hamburger-menu { display: none; }

    /* --- Bannière --- */
    .banner { background-image: url('/images/banniere-commander.png'); background-size: cover; background-position: center; height: 300px; display: flex; justify-content: center; align-items: center; color: #fff; text-align: center; position: relative; }
    .banner::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0,0,0,0.4); z-index: 1; }
    .banner h1 { font-size: 3rem; font-weight: 700; z-index: 2; text-shadow: 0 2px 5px rgba(0,0,0,0.3); padding: 0 15px; }

    /* Section Commande */
    .order-section { padding: 40px 0; text-align: center; }
    .order-section h2 { font-size: 2.2rem; margin-bottom: 40px; color: #333; }
    
    /* --- STRUCTURE DE LA PAGE AVEC PANIER --- */
    .content-wrapper { display: flex; gap: 30px; align-items: flex-start; }
    .product-column { flex: 3; }
    .cart-column { flex: 1; position: sticky; top: 20px; background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); }
    .cart-column h3 { margin-top: 0; color: #6B8E23; font-size: 1.5rem; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }

    /* --- GRILLE DE CARTES PRODUITS --- */
    .variety-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px; }
    .variety-card { background-color: #fff; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); overflow: hidden; display: flex; flex-direction: column; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .variety-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
    .variety-card img { width: 100%; height: 180px; object-fit: cover; }
    .variety-content { padding: 20px; display: flex; flex-direction: column; flex-grow: 1; text-align: left; }
    .variety-content h3 { margin-top: 0; font-size: 1.5rem; color: #333; margin-bottom: 15px; }
    
    /* --- Styles pour la zone d'actions --- */
    .product-actions { margin-top: auto; }
    .options-selector { display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px; }
    .options-selector label { font-weight: 600; font-size: 0.9em; }
    .options-selector select { padding: 8px; border-radius: 5px; border: 1px solid #ccc; flex-grow: 1; margin-left: 10px; }
    .price-display { text-align: right; font-size: 1.6rem; font-weight: 700; color: #6B8E23; margin-bottom: 20px; }
    
    .cart-controls { display: flex; align-items: center; gap: 15px; }
    .quantity-control { display: flex; align-items: center; }
    .quantity-control button { background-color: #eee; border: 1px solid #ddd; padding: 8px 12px; font-size: 1rem; cursor: pointer; }
    .quantity-control input { width: 40px; text-align: center; border: 1px solid #ccc; border-left: none; border-right: none; padding: 8px 0; font-size: 1rem; }
    
    .add-to-cart-button { flex-grow: 1; background-color: #6B8E23; color: white; border: none; padding: 10px 15px; border-radius: 5px; font-weight: 600; cursor: pointer; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .add-to-cart-button:hover { background-color: #5A7C1F; }
    .add-to-cart-button .material-symbols-outlined { font-size: 1.5rem; }
    
    /* Style pour le message "Indisponible" */
    .unavailable-notice { padding: 30px 10px; margin-top: 20px; text-align: center; background-color: #f9f9f9; border-radius: 6px; color: #999; flex-grow: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; }
    .unavailable-notice .material-symbols-outlined { font-size: 2.5rem; }
    .unavailable-notice p { margin: 5px 0 0 0; font-weight: 600; }
    .unavailable-notice span { font-size: 0.9em; }
    
    /* --- Styles du Panier --- */
    #cart-items-list-sidebar { min-height: 80px; max-height: 400px; overflow-y: auto; margin-bottom: 20px; }
    .cart-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px dashed #eee; }
    #empty-cart-message-sidebar { text-align: center; color: #777; padding: 20px 0; }
    .summary-line.total { display: flex; justify-content: space-between; font-size: 1.4em; font-weight: 700; color: #6B8E23; margin-top: 15px; padding-top: 10px; border-top: 1px solid #eee; }
    .validate-order-button { background-color: #6B8E23; color: #fff; border: none; padding: 15px 30px; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: background-color 0.3s ease; width: 100%; margin-top: 30px; border-radius: 5px; }
    .validate-order-button:hover { background-color: #5A7C1F; }

    /* --- Styles pour le panier flottant et la modale --- */
    #floating-cart-btn {
        display: none; position: fixed; bottom: 20px; right: 20px; width: 60px; height: 60px; background-color: #6B8E23; color: white; border: none; border-radius: 50%; box-shadow: 0 4px 12px rgba(0,0,0,0.2); cursor: pointer; z-index: 1000; justify-content: center; align-items: center;
    }
    #cart-item-count {
        position: absolute; top: -5px; right: -5px; background-color: #e74c3c; color: white; border-radius: 50%; width: 24px; height: 24px; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; border: 2px solid white;
    }
    .cart-modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 2000; display: none; align-items: center; justify-content: center;
    }
    .cart-modal-overlay.open { display: flex; }
    .cart-modal-content { background-color: #fff; border-radius: 8px; width: 90%; max-width: 500px; max-height: 80vh; display: flex; flex-direction: column; }
    .cart-modal-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid #eee; }
    .cart-modal-header h3 { margin: 0; color: #6B8E23; font-size: 1.5rem; }
    .cart-modal-close { background: none; border: none; font-size: 2rem; cursor: pointer; color: #999; }
    .cart-modal-body { padding: 20px; overflow-y: auto; }
    .cart-modal-footer { padding: 20px; border-top: 1px solid #eee; }

    /* --- RESPONSIVE --- */
    @media (max-width: 992px) {
        .content-wrapper { flex-direction: column; }
        .cart-column { display: none; }
        #floating-cart-btn { display: flex; }
    }
    @media (max-width: 768px) {
        .hamburger-menu { display: block; cursor: pointer; z-index: 1001; }
        .hamburger-menu span { display: block; width: 25px; height: 3px; background-color: #333; margin: 5px 0; transition: 0.3s; }
        .main-menu { display: none; flex-direction: column; position: absolute; top: 70px; left: 0; width: 100%; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 10px 0; z-index: 1000; }
        .main-menu a { margin: 10px 0; text-align: center; width: 100%; }
        #menu-toggle:checked ~ .main-menu { display: flex; }
        .banner h1 { font-size: 2.2rem; }
        .order-section h2 { font-size: 1.8rem; }
        .variety-content h3 { font-size: 1.3rem; }
        .variety-grid { grid-template-columns: 1fr; }
    }
    /* Style pour le bouton "Retour en haut" */
    #scrollTopBtn {
        display: none; position: fixed; bottom: 20px; right: 30px; z-index: 1000; border: none; outline: none; background-color: #6B8E23; color: white; cursor: pointer; padding: 10px; border-radius: 50%; width: 50px; height: 50px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); transition: background-color 0.3s, transform 0.2s; align-items: center; justify-content: center;
    }
    #scrollTopBtn:hover {
        background-color: #5A7C1F; transform: scale(1.1);
    }
    #scrollTopBtn .material-symbols-outlined {
        font-size: 2rem;
    }
</style>
</head>
<body>
    <header>
        <a href="index.php" class="logo">
            <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise">
        </a>
        <div class="nav-container">
            <input type="checkbox" id="menu-toggle" style="display: none;"/>
            <label for="menu-toggle" class="hamburger-menu">
                <span></span><span></span><span></span>
            </label>
            <nav class="main-menu">
                <a href="index.php">Accueil</a>
                <a href="commander.php">Commander mes fruits</a>
                <a href="espace-client.php">Espace Client</a>
            </nav>
        </div>
    </header>

    <div class="banner">
        <h1>Composez votre panier de fruits frais</h1>
    </div>

    <div class="container order-section">
        <h2>Découvrez nos variétés gourmandes à venir récupérer sur place 🍓</h2>

        <div class="content-wrapper">
            <div class="product-column">
                <div id="product-grid-container" class="variety-grid">
                    
                    <?php foreach ($products as $product): ?>
                        <div class="variety-card" data-product-id="<?php echo $product['id']; ?>">
                            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['variety_name']); ?>">
                            <div class="variety-content">
                                <h3><?php echo htmlspecialchars($product['variety_name']); ?></h3>
                                
                                <?php if ($product['stock_grams'] > 0): ?>
                                    <div class="product-actions">
                                        <div class="options-selector">
                                            <label for="weight-select-<?php echo $product['id']; ?>">Poids :</label>
                                            <select class="weight-select" id="weight-select-<?php echo $product['id']; ?>">
                                                <option value="200gr" data-price="<?php echo $product['price_200g']; ?>">
                                                    200gr - <?php echo number_format($product['price_200g'], 2, ',', ' '); ?> €
                                                </option>
                                                <option value="500gr" data-price="<?php echo $product['price_500g']; ?>">
                                                    500gr - <?php echo number_format($product['price_500g'], 2, ',', ' '); ?> €
                                                </option>
                                                <option value="1kg" data-price="<?php echo $product['price_1kg']; ?>">
                                                    1kg - <?php echo number_format($product['price_1kg'], 2, ',', ' '); ?> €
                                                </option>
                                            </select>
                                        </div>

                                        <div class="price-display">
                                            <?php echo number_format($product['price_200g'], 2, ',', ' '); ?> €
                                        </div>
                                        
                                        <div class="cart-controls">
                                            <div class="quantity-control">
                                                <button onclick="changeQuantity(this, -1)">-</button>
                                                <input type="number" value="1" min="1" readonly>
                                                <button onclick="changeQuantity(this, 1)">+</button>
                                            </div>
                                            <button class="add-to-cart-button" data-variety="<?php echo htmlspecialchars($product['variety_name']); ?>">
                                                <span class="material-symbols-outlined">add_shopping_cart</span>
                                                Ajouter
                                            </button>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="unavailable-notice">
                                        <span class="material-symbols-outlined">inventory_2</span>
                                        <p>Indisponible</p>
                                        <span>Cette variété est momentanément en rupture de stock.</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>

                </div>
            </div>

            <div class="cart-column">
                <h3>Votre Panier</h3>
                <div id="cart-items-list-sidebar">
                    <p id="empty-cart-message-sidebar">Votre panier est vide pour le moment.</p>
                </div>
                
                <form id="checkout-form-sidebar" action="recapitulatif.php" method="POST">
                    <div id="cart-summary-total-sidebar">
                        <div class="summary-line total">
                            <strong>Total Provisoire :</strong>
                            <span id="cart-total-price-sidebar">0,00 €</span>
                        </div>
                        <input type="hidden" name="cart_data" id="cart-data-input-sidebar">
                        <button type="submit" class="validate-order-button">Valider ma commande</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <button id="floating-cart-btn" aria-label="Voir le panier">
        <span class="material-symbols-outlined">shopping_cart</span>
        <span id="cart-item-count">0</span>
    </button>
    
    <div class="cart-modal-overlay" id="cart-modal">
        <div class="cart-modal-content">
            <div class="cart-modal-header">
                <h3>Votre Panier</h3>
                <button class="cart-modal-close" id="cart-modal-close" aria-label="Fermer">&times;</button>
            </div>
            <div class="cart-modal-body">
                <div id="cart-items-list-modal">
                    <p id="empty-cart-message-modal">Votre panier est vide pour le moment.</p>
                </div>
            </div>
            <div class="cart-modal-footer">
                 <form id="checkout-form-modal" action="recapitulatif.php" method="POST">
                    <div id="cart-summary-total-modal">
                        <div class="summary-line total">
                            <strong>Total Provisoire :</strong>
                            <span id="cart-total-price-modal">0,00 €</span>
                        </div>
                        <input type="hidden" name="cart_data" id="cart-data-input-modal">
                        <button type="submit" class="validate-order-button">Valider ma commande</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<script>
    let cart = []; // Panier global
    const formatCurrency = (amount) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    function updateCartDisplay() {
        const sidebarList = document.getElementById('cart-items-list-sidebar');
        const sidebarTotalPrice = document.getElementById('cart-total-price-sidebar');
        const modalList = document.getElementById('cart-items-list-modal');
        const modalTotalPrice = document.getElementById('cart-total-price-modal');
        const itemCountBadge = document.getElementById('cart-item-count');
        
        let total = 0;
        let totalItems = 0;
        let cartHTML = '';

        if (cart.length === 0) {
            cartHTML = '<p id="empty-cart-message">Votre panier est vide pour le moment.</p>';
        } else {
            cart.forEach((item, index) => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                totalItems += item.quantity;
                
                cartHTML += `
                    <div class="cart-item">
                        <div class="cart-item-details">
                            <strong>${item.name} (${item.weight})</strong>
                            <span>${item.quantity} x ${formatCurrency(item.price)} = ${formatCurrency(itemTotal)}</span>
                        </div>
                        <button class="remove-item-btn" data-index="${index}" style="background:none; border:none; cursor:pointer; color: #cc0000;">
                            <span class="material-symbols-outlined">delete</span>
                        </button>
                    </div>
                `;
            });
        }
        
        sidebarList.innerHTML = cartHTML.replace('id="empty-cart-message"', 'id="empty-cart-message-sidebar"');
        modalList.innerHTML = cartHTML.replace('id="empty-cart-message"', 'id="empty-cart-message-modal"');
        sidebarTotalPrice.textContent = formatCurrency(total);
        modalTotalPrice.textContent = formatCurrency(total);
        itemCountBadge.textContent = totalItems;
        itemCountBadge.style.display = totalItems > 0 ? 'flex' : 'none';
    }

    function addToCart(varietyName, weight, price, quantity) {
        const existingItemIndex = cart.findIndex(item => item.name === varietyName && item.weight === weight);

        if (existingItemIndex > -1) {
            cart[existingItemIndex].quantity += quantity;
        } else {
            cart.push({ name: varietyName, weight: weight, price: price, quantity: quantity });
        }
        updateCartDisplay();
    }

    function removeFromCart(index) {
        cart.splice(index, 1);
        updateCartDisplay();
    }

    function changeQuantity(button, change) {
        const input = button.parentNode.querySelector('input');
        let currentValue = parseInt(input.value);
        currentValue += change;
        if (currentValue < 1) {
            currentValue = 1;
        }
        input.value = currentValue;
    }

    document.addEventListener('DOMContentLoaded', () => {
        const gridContainer = document.getElementById('product-grid-container');
        
        document.body.addEventListener('click', (e) => {
            const removeButton = e.target.closest('.remove-item-btn');
            if (removeButton) {
                const index = parseInt(removeButton.dataset.index);
                removeFromCart(index);
            }
        });

        gridContainer.addEventListener('click', (e) => {
            const button = e.target.closest('.add-to-cart-button');
            if (!button) return; 

            const card = button.closest('.variety-card');
            const variety = button.dataset.variety;
            const quantityInput = card.querySelector('.quantity-control input');
            const weightSelect = card.querySelector('.weight-select');
            
            const selectedOption = weightSelect.options[weightSelect.selectedIndex];
            const weight = selectedOption.value;
            const price = parseFloat(selectedOption.dataset.price);
            const quantity = parseInt(quantityInput.value);

            addToCart(variety, weight, price, quantity);

            button.innerHTML = '<span class="material-symbols-outlined">done</span> Ajouté !';
            setTimeout(() => {
                button.innerHTML = '<span class="material-symbols-outlined">add_shopping_cart</span> Ajouter';
            }, 1500);
        });

        gridContainer.addEventListener('change', (e) => {
            if (e.target.classList.contains('weight-select')) {
                const select = e.target;
                const card = select.closest('.variety-card');
                const priceDisplay = card.querySelector('.price-display');
                
                const selectedOption = select.options[select.selectedIndex];
                const price = parseFloat(selectedOption.dataset.price);

                priceDisplay.textContent = formatCurrency(price);
            }
        });
        
        function handleCheckoutSubmit(event) {
            event.preventDefault(); 
            if (cart.length === 0) {
                alert("Votre panier est vide ! Vous ne pouvez pas continuer.");
                return;
            }
            const cartDataInput = event.target.querySelector('input[name="cart_data"]');
            cartDataInput.value = JSON.stringify(cart);
            event.target.submit(); 
        }
        
        document.getElementById('checkout-form-sidebar').addEventListener('submit', handleCheckoutSubmit);
        document.getElementById('checkout-form-modal').addEventListener('submit', handleCheckoutSubmit);

        const floatingCartBtn = document.getElementById('floating-cart-btn');
        const cartModal = document.getElementById('cart-modal');
        const closeModalBtn = document.getElementById('cart-modal-close');

        floatingCartBtn.addEventListener('click', () => cartModal.classList.add('open'));
        closeModalBtn.addEventListener('click', () => cartModal.classList.remove('open'));
        cartModal.addEventListener('click', (e) => {
            if (e.target === cartModal) {
                cartModal.classList.remove('open');
            }
        });

        updateCartDisplay();
    });
</script>
</body>
</html>