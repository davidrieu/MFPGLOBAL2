<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>Rapport de Diagnostic du Serveur</h1>";

// 1. Vérification de la version de PHP
echo "<h2>1. Version de PHP</h2>";
echo "Version : " . phpversion();
if (version_compare(phpversion(), '7.2.0', '<')) {
    echo " <strong style='color:red;'>AVERTISSEMENT : Votre version de PHP est très ancienne et pourrait causer des problèmes avec Composer.</strong>";
} else {
    echo " <strong style='color:green;'>OK</strong>";
}
echo "<hr>";

// 2. Vérification du chemin de l'autoloader
echo "<h2>2. Fichier Autoloader de Composer</h2>";
$autoloader_path = __DIR__ . '/vendor/autoload.php';
echo "Chemin absolu testé : " . $autoloader_path . "<br>";

if (file_exists($autoloader_path)) {
    echo "Statut : <strong style='color:green;'>Trouvé !</strong><br>";
    
    // 3. Vérification des permissions de lecture
    if (is_readable($autoloader_path)) {
        echo "Permissions : <strong style='color:green;'>Lisible.</strong><br>";
        
        // 4. On essaie de l'inclure
        require_once $autoloader_path;
        echo "Inclusion : <strong style='color:green;'>Inclus avec succès.</strong><br>";
        
        // 5. LE TEST FINAL : La classe existe-t-elle APRES inclusion ?
        if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            echo "Vérification de la classe PHPMailer : <strong style='color:green;'>TROUVÉE ET CHARGÉE ! Le problème est ailleurs.</strong>";
        } else {
            echo "Vérification de la classe PHPMailer : <strong style='color:red;'>NON TROUVÉE ! L'installation de Composer est corrompue ou incomplète.</strong>";
        }
        
    } else {
        echo "Permissions : <strong style='color:red;'>NON LISIBLE ! Le serveur n'a pas la permission de lire le fichier. C'est un problème de permissions (chmod).</strong>";
    }
    
} else {
    echo "Statut : <strong style='color:red;'>NON TROUVÉ ! Le dossier 'vendor' ou le fichier 'autoload.php' n'existe pas à cet emplacement.</strong>";
}
echo "<hr>";