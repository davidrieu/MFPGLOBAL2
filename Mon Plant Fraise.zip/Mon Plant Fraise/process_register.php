<?php
// Démarrer la session pour les messages de statut
session_start();

// 1. Connexion à la base de données (vous devez avoir ce fichier)
// Ce fichier doit initialiser une variable $pdo
require 'db_connection.php'; 

// 2. Vérifier si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 3. Récupérer et nettoyer les données du formulaire
    $nom_complet = trim($_POST['nom_complet']);
    $email = trim($_POST['email']);
    $telephone = trim($_POST['telephone']); // Peut être vide
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    $errors = [];

    // 4. Validation des données
    // --- Vérifications de base ---
    if (empty($nom_complet) || empty($email) || empty($password) || empty($password_confirm)) {
        $errors[] = "Tous les champs marqués d'une * sont requis.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format d'email invalide.";
    }

    if (strlen($password) < 8) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
    }

    if ($password !== $password_confirm) {
        $errors[] = "Les mots de passe ne correspondent pas.";
    }

    // --- Séparation Prénom / Nom ---
    $prenom = '';
    $name = '';
    $parts = explode(' ', $nom_complet, 2); // Sépare au premier espace
    $prenom = $parts[0];
    if (isset($parts[1])) {
        $name = $parts[1];
    } else {
        // Si un seul mot est entré pour "Nom Complet"
        $errors[] = "Veuillez saisir votre prénom ET votre nom de famille.";
    }
    
    // 5. Vérifier si l'email existe déjà (si pas d'erreurs jusqu'ici)
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "Cette adresse e-mail est déjà utilisée.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur de base de données. Veuillez réessayer.";
            // Loggez $e->getMessage() pour le débogage côté serveur
        }
    }

    // 6. Gérer les erreurs
    if (!empty($errors)) {
        $error_message = implode(" ", $errors);
        header("Location: register.php?error=" . urlencode($error_message));
        exit;
    }

    // 7. Si tout est valide : Préparer l'insertion
    try {
        // Hacher le mot de passe
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Générer un code de parrainage unique
        // Ex: "MPF-A1B2C3D4" (Mon Plant Fraise - code)
        $sponsorship_code = 'MPF-' . strtoupper(bin2hex(random_bytes(4)));

        // Définir les statuts par défaut
        $statut_default = 'en_attente'; // Ou 'actif' selon votre logique
        $verifie_default = 0; // 0 = non vérifié

        // Préparer la requête SQL
        $sql = "INSERT INTO users (
                    prenom, 
                    name, 
                    email, 
                    telephone, 
                    password, 
                    sponsorship_code, 
                    statut, 
                    verifie, 
                    registration_date 
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $pdo->prepare($sql);
        
        // Exécuter l'insertion
        if ($stmt->execute([
            $prenom,
            $name,
            $email,
            $telephone,
            $hashed_password,
            $sponsorship_code,
            $statut_default,
            $verifie_default
        ])) {
            // Succès
            // Rediriger vers la page de connexion avec un message de succès
            header("Location: login.php?register=success");
            exit;
        } else {
            // Echec de l'insertion
            header("Location: register.php?error=" . urlencode("Une erreur est survenue lors de la création du compte."));
            exit;
        }

    } catch (PDOException $e) {
        // Gérer les erreurs PDO (ex: contrainte unique)
        header("Location: register.php?error=" . urlencode("Erreur d'inscription: " . $e->getMessage()));
        exit;
    }

} else {
    // Si la page est accédée sans POST (directement par URL)
    header("Location: register.php");
    exit;
}
?>