<?php
// cgv.php — Conditions Générales de Vente / Prestation de Services (Mon Plant Fraise)
// Version: 13/10/2025
header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>CGV — Mon Plant Fraise</title>
  <meta name="description" content="Conditions générales de vente et de prestation de services de Mon Plant Fraise.">
  <style>
    :root{
      --primary:#d82449;
      --ink:#1b1b1b;
      --muted:#666;
      --bg:#fff;
      --card:#fafafa;
      --radius:14px;
      --shadow:0 6px 20px rgba(0,0,0,.06);
    }
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Helvetica,Arial,sans-serif;
      color:var(--ink); background:var(--bg); line-height:1.6;
    }
    header{
      padding:24px 20px;
      background:linear-gradient(180deg,var(--card),#fff);
      border-bottom:1px solid #eee;
      position:sticky;top:0;z-index:10;
    }
    .wrap{max-width:980px;margin:0 auto;padding:0 20px}
    h1{font-size:clamp(1.6rem,2vw+1rem,2.2rem);margin:0 0 6px}
    .meta{color:var(--muted);font-size:.95rem;margin-top:2px}

    /* Sommaire rétractable */
    .toc{
      margin-top:14px;
      background:#fff;
      border:1px solid #eee;
      border-radius:999px;
      display:inline-flex;
      align-items:center;
      gap:10px;
      padding:6px 10px 6px 6px;
      box-shadow:var(--shadow);
    }
    .toc-toggle{
      appearance:none;border:0;background:var(--primary);color:#fff;
      padding:8px 14px;border-radius:999px;cursor:pointer;font-weight:600;
    }
    .toc-toggle:focus{outline:2px solid #0002;outline-offset:2px}
    .toc-label{color:#333;font-weight:600;margin-left:2px}
    .anchors{
      margin-top:10px;
      padding:10px;
      background:#fff;
      border:1px solid #eee;
      border-radius:16px;
      box-shadow:var(--shadow);
    }
    .anchors a{
      display:inline-block;margin:6px 8px 4px 0;padding:8px 12px;
      border:1px solid #eee;border-radius:999px;text-decoration:none;color:#333;background:#fafafa
    }
    /* Cacher par défaut sur petits écrans */
    @media (max-width: 799px){
      #toc-links[hidden]{display:none}
    }

    main{padding:28px 0 60px}
    section{
      background:var(--card); border:1px solid #eee; border-radius:var(--radius);
      padding:22px; margin:18px 0;
    }
    h2{margin-top:0;font-size:1.25rem}
    h3{margin-top:1.2rem;font-size:1.05rem}
    ul{padding-left:20px}
    .note{background:#fff3f6;border-left:4px solid var(--primary);padding:12px 14px;border-radius:10px;margin:.6rem 0}
    .grid{display:grid;gap:14px}
    @media (min-width:800px){.grid{grid-template-columns:1fr 1fr}}
    footer{padding:34px 20px;border-top:1px solid #eee;color:#666}
    .small{font-size:.95rem}
    .legal-table{width:100%;border-collapse:collapse;margin:.6rem 0}
    .legal-table th,.legal-table td{border:1px solid #e8e8e8;padding:10px;vertical-align:top}
    .legal-table th{background:#f8f8f8;text-align:left}
  </style>
</head>
<body>
  <header>
    <div class="wrap">
      <h1>Conditions Générales de Vente &amp; de Prestation de Services</h1>
      <div class="meta">Mon Plant Fraise — Version du <strong>13/10/2025</strong></div>

      <!-- Sommaire rétractable -->
      <div class="toc" role="region" aria-labelledby="toc-title">
        <button class="toc-toggle" id="toc-toggle" aria-expanded="false" aria-controls="toc-links">
          Sommaire
        </button>
        <span class="toc-label" id="toc-title">Accéder aux sections</span>
      </div>

      <div class="anchors" id="toc-links" hidden>
        <a href="#1">1. Identification & champ d’application</a>
        <a href="#2">2. Définitions</a>
        <a href="#3">3. Offres & descriptifs</a>
        <a href="#4">4. Commande & compte</a>
        <a href="#5">5. Prix & paiements</a>
        <a href="#6">6. Exécution & performances</a>
        <a href="#7">7. Droit de rétractation</a>
        <a href="#8">8. Disponibilité & substitution</a>
        <a href="#9">9. Durée, sortie & rachat</a>
        <a href="#10">10. Responsabilité & force majeure</a>
        <a href="#11">11. Données personnelles</a>
        <a href="#12">12. Réclamations & médiation</a>
        <a href="#13">13. Droit applicable & juridiction</a>
        <a href="#annexe">Annexe — Formulaire de rétractation</a>
      </div>
    </div>
  </header>

  <main class="wrap">

    <section id="1">
      <h2>1. Identification &amp; champ d’application</h2>
      <table class="legal-table">
        <tr><th>Vendeur / Prestataire</th><td><strong>MON PLANT FRAISE</strong>, 27 Avenue de la Tour de Fer, 74490 Saint-Jeoire, France — RCS Annecy <strong>939&nbsp;694&nbsp;345</strong>.</td></tr>
        <tr><th>Contact</th><td>Courriel : <a href="mailto:contact@monplantfraise.fr">contact@monplantfraise.fr</a> — Support : <a href="mailto:support@monplantfraise.fr">support@monplantfraise.fr</a></td></tr>
        <tr><th>Site</th><td><a href="https://www.monplantfraise.fr">www.monplantfraise.fr</a></td></tr>
      </table>
      <p>Les présentes CGV/CGPS régissent la vente de services d’investissement agricole participatif (souscription de plants de fraisiers et gestion associée) proposés sur le Site. Elles complètent, le cas échéant, les Conditions Particulières propres à chaque offre. En cas de contradiction, les Conditions Particulières prévalent.</p>
    </section>

    <section id="2">
      <h2>2. Définitions</h2>
      <ul>
        <li><strong>Client / Investisseur&nbsp;:</strong> toute personne souscrivant une offre de services d’investissement agricole participatif à des fins n’entrant pas dans le cadre de son activité professionnelle.</li>
        <li><strong>Offres «&nbsp;Packs&nbsp;» / Offres par variété&nbsp;:</strong> formules d’investissement définies ci-dessous.</li>
        <li><strong>Espace personnel&nbsp;:</strong> interface sécurisée permettant le suivi des contrats, plants et rendements.</li>
      </ul>
    </section>

    <section id="3">
      <h2>3. Offres &amp; descriptifs</h2>
      <p>Mon Plant Fraise propose des <strong>Offres « Packs »</strong> (diversification de variétés) et des <strong>Offres par variété</strong> (souscription unitaire par variété). Les principales caractéristiques (montant minimum, durée, modalités de culture, rendement estimé) sont précisées sur chaque fiche offre et dans les Conditions Particulières associées. Les exemples ci-dessous sont fournis à titre informatif et peuvent évoluer.</p>

      <div class="grid">
        <div>
          <h3>Packs (exemples)</h3>
          <ul>
            <li><strong>Pack Investisseur</strong> — engagement 12&nbsp;mois, rendement estimé 40&nbsp;%/an (profil diversifié).</li>
            <li><strong>Pack Professionnel</strong> — engagement 12&nbsp;mois, rendement estimé 35&nbsp;%/an.</li>
            <li><strong>Pack Intermédiaire</strong> — engagement 12&nbsp;mois, rendement estimé 30&nbsp;%/an.</li>
            <li><strong>Pack Médium</strong> — engagement 12&nbsp;mois, rendement estimé 25&nbsp;%/an.</li>
            <li><strong>Pack Démarrage</strong> — engagement 12&nbsp;mois, rendement estimé 10&nbsp;%/an.</li>
          </ul>
        </div>
        <div>
          <h3>Variétés (exemples)</h3>
          <ul>
            <li><strong>Yellow Wonder</strong> — rendement estimé 40&nbsp;%/an.</li>
            <li><strong>Charlotte</strong> — rendement estimé 15&nbsp;%/an.</li>
            <li><strong>Gariguette</strong> — rendement estimé 25&nbsp;%/an.</li>
            <li><strong>Pineberry / Snow&nbsp;White / Anablanca</strong> — rendement estimé 35&nbsp;%/an.</li>
            <li><strong>Maestro</strong> — rendement estimé 10&nbsp;%/an.</li>
            <li><strong>Framberry</strong> — rendement estimé 30&nbsp;%/an.</li>
          </ul>
        </div>
      </div>
      <div class="note small">
        Nota : les offres et descriptifs sont inspirés des CGPS internes et peuvent être mis à jour. Se reporter aux fiches officielles au moment de la souscription.
      </div>
    </section>

    <section id="4">
      <h2>4. Processus de commande &amp; compte client</h2>
      <ol>
        <li><strong>Création de compte</strong> (identité, e-mail, adresse, moyens de paiement) et acceptation des CGV/CGPS.</li>
        <li><strong>Sélection</strong> de l’offre (Pack ou variété), vérification du récapitulatif, acceptation des Conditions Particulières.</li>
        <li><strong>Paiement sécurisé</strong> (voir §5). Un accusé de réception est envoyé et l’espace personnel est activé (documents, suivi des plants, rapports, rendements).</li>
      </ol>
      <p>Le Client mandate Mon Plant Fraise pour l’approvisionnement des plants, leur culture/gestion, la récolte, la commercialisation des fruits et l’encaissement des produits de vente, dans les conditions du Contrat.</p>
    </section>

    <section id="5">
      <h2>5. Prix, taxes &amp; paiements</h2>
      <ul>
        <li><strong>Prix</strong> : affichés TTC sauf mention contraire. Les frais applicables (ex. gestion, options) sont précisés avant paiement.</li>
        <li><strong>Méthodes de paiement</strong> : Carte bancaire (via Stripe), Apple&nbsp;Pay et/ou Google&nbsp;Pay lorsque disponibles, virement SEPA, PayPal (si proposé), et le cas échéant crypto-actifs pour les offres explicitement éligibles.</li>
        <li><strong>Facturation</strong> : une facture électronique est mise à disposition dans l’espace personnel et/ou envoyée par e-mail.</li>
        <li><strong>Lutte anti-fraude</strong> : des contrôles (KYC/justificatifs) peuvent être requis avant validation définitive (conformité LCB-FT).</li>
        <li><strong>Taxes</strong> : la TVA et/ou autres taxes sont appliquées selon la réglementation en vigueur et la nature du service.</li>
      </ul>
    </section>

    <section id="6">
      <h2>6. Exécution des services &amp; performances</h2>
      <p>Les plants sont implantés sur des exploitations sélectionnées. Mon Plant Fraise applique des pratiques horticoles responsables et conformes. Les rendements demeurent aléatoires (facteurs climatiques, phytosanitaires, marchés, etc.). Des rapports de suivi sont communiqués via l’espace personnel.</p>
      <h3>Facteurs de risques (extraits)</h3>
      <ul>
        <li>Variabilité des rendements et des prix de vente.</li>
        <li>Aléas climatiques (gel, sécheresse, grêle…), maladies et ravageurs.</li>
        <li>Risques de contrepartie et de performance des exploitations partenaires.</li>
        <li>Risques réglementaires/juridiques et fiscaux.</li>
        <li>Illiquidité et risque de perte en capital partielle ou totale.</li>
      </ul>
      <p class="small">Le Client est invité à consulter les documents d’information propres à chaque offre et à solliciter ses conseils habituels (juridique, fiscal, financier).</p>
    </section>

    <section id="7">
      <h2>7. Droit de rétractation (vente à distance)</h2>
      <p>Le Client consommateur dispose d’un délai de <strong>14 jours calendaires</strong> à compter de la conclusion du contrat pour se rétracter, sans motif ni pénalité. Pour exercer ce droit, il adresse une déclaration dénuée d’ambiguïté (ou le formulaire en <a href="#annexe">annexe</a>) à <a href="mailto:retractation@monplantfraise.fr">retractation@monplantfraise.fr</a> ou à l’adresse postale du siège. Le remboursement intervient sous 14 jours au plus tard à compter de l’information de la rétractation, par le même moyen de paiement sauf accord différent.</p>
    </section>

    <section id="8">
      <h2>8. Disponibilité des plants &amp; substitution</h2>
      <p>En cas d’indisponibilité totale/partielle post-commande, le Client sera informé par e-mail. Il pourra choisir entre (i) une offre de substitution équivalente ou supérieure ou (ii) le remboursement intégral sous 30 jours. Sans réponse sous 15 jours, le remboursement sera appliqué.</p>
    </section>

    <section id="9">
      <h2>9. Durée, indisponibilité d’une sortie anticipée &amp; mécanisme de rachat</h2>
      <ul>
        <li><strong>Durée d’engagement standard</strong> : 12&nbsp;mois (sauf stipulation contraire dans les Conditions Particulières).</li>
        <li><strong>Sortie anticipée</strong> : non proposée compte tenu du cycle agricole, sauf force majeure dûment justifiée et acceptée.</li>
        <li><strong>Rachat en fin de période</strong> : Mon Plant Fraise rachète les plants au Client (prix = investissement initial + intérêts produits selon l’offre). La cession est formalisée automatiquement à l’échéance, sauf demande expresse de versement en nature (livraison de fraises) si l’offre le prévoit.</li>
      </ul>
    </section>

    <section id="10">
      <h2>10. Responsabilité &amp; force majeure</h2>
      <p>Mon Plant Fraise exécute ses obligations avec diligence. Sa responsabilité ne saurait être engagée en cas de force majeure (au sens de l’art. 1218 C. civil), notamment aléas météorologiques exceptionnels, catastrophes naturelles, épidémies, conflits, grèves, décisions administratives rendant la prestation impossible. Pendant la durée de l’empêchement, Mon Plant Fraise est suspendue de ses obligations sans indemnité.</p>
      <h3>Assurances</h3>
      <p>Mon Plant Fraise dispose d’une responsabilité civile professionnelle pour ses activités de gestion/culture/commercialisation. Cette assurance ne couvre pas les pertes agricoles aléatoires ni les pertes financières liées à la variabilité des rendements.</p>
      <h3>Convention de preuve</h3>
      <p>Les enregistrements électroniques (journaux, e-mails, opérations via l’espace personnel) font foi. En cas de signature électronique, le procédé a la même valeur qu’une signature manuscrite.</p>
    </section>

    <section id="11">
      <h2>11. Données personnelles</h2>
      <p>Mon Plant Fraise traite les données dans le cadre de l’exécution du contrat, du respect d’obligations légales (comptabilité, LCB-FT), de son intérêt légitime (information des Clients) et du consentement (prospection). Droits RGPD : accès, rectification, effacement, limitation/opposition, portabilité, ne pas faire l’objet d’une décision automatisée, réclamation auprès de la CNIL. Contact DPO : <a href="mailto:dpo@monplantfraise.fr">dpo@monplantfraise.fr</a>.</p>
      <p>Durées de conservation indicatives : 3 ans (prospection) après fin du contrat, 5 ans (preuve) et 10 ans (obligations comptables).</p>
    </section>

    <section id="12">
      <h2>12. Réclamations &amp; médiation</h2>
      <p>Réclamation : <a href="mailto:reclamation@monplantfraise.fr">reclamation@monplantfraise.fr</a> ou courrier au siège. En l’absence de résolution sous 2 mois, le Client peut recourir à un médiateur de la consommation (art. L.612-1 C. conso.) ou à tout mode amiable (conciliation).</p>
    </section>

    <section id="13">
      <h2>13. Droit applicable, langue &amp; juridiction</h2>
      <ul>
        <li><strong>Droit applicable</strong> : français. Langue du contrat : français.</li>
        <li><strong>Compétence</strong> : juridictions françaises. Pour les consommateurs, compétence des juridictions prévues aux articles R.631-3 C. conso. Pour les professionnels, compétence des juridictions du ressort de la Cour d’appel de Lyon.</li>
      </ul>
    </section>

    <section id="annexe">
      <h2>Annexe — Formulaire de rétractation</h2>
      <p>À compléter uniquement si vous souhaitez vous rétracter dans les 14 jours.</p>
      <pre class="small" style="white-space:pre-wrap;border:1px solid #eee;padding:14px;border-radius:10px;background:#fff">
À l’attention de MON PLANT FRAISE, 27 Avenue de la Tour de Fer, 74490 Saint-Jeoire, France — retractation@monplantfraise.fr

Je vous notifie ma rétractation du contrat ci-dessous :
— Commandé le : …………………
— Nom : ………………………………………
— Adresse : …………………………………
— E-mail (optionnel) : ……………………

Date : ……………………   Signature (si papier) : ……………………
      </pre>
    </section>

  </main>

  <footer>
    <div class="wrap small">
      © <?php echo date('Y'); ?> Mon Plant Fraise — CGV/CGPS. Dernière mise à jour : 13/10/2025.
    </div>
  </footer>

  <script>
    // Sommaire rétractable
    (function(){
      const btn = document.getElementById('toc-toggle');
      const panel = document.getElementById('toc-links');

      // Par défaut: ouvert sur desktop, fermé sur mobile
      const isMobile = () => window.matchMedia('(max-width: 799px)').matches;
      function setDefault(){
        if(isMobile()){
          panel.hidden = true;
          btn.setAttribute('aria-expanded','false');
        }else{
          panel.hidden = false;
          btn.setAttribute('aria-expanded','true');
        }
      }
      setDefault();
      window.addEventListener('resize', setDefault);

      btn.addEventListener('click', function(){
        const expanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', String(!expanded));
        panel.hidden = expanded;
      });

      // Fermer le sommaire si on clique à l'extérieur (mobile)
      document.addEventListener('click', (e)=>{
        if(isMobile()){
          if(!panel.hidden && !panel.contains(e.target) && e.target !== btn && !btn.contains(e.target)){
            panel.hidden = true;
            btn.setAttribute('aria-expanded','false');
          }
        }
      });

      // Fermer après un clic sur un lien (améliore l'UX mobile)
      panel.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click', ()=>{
          if(isMobile()){
            panel.hidden = true;
            btn.setAttribute('aria-expanded','false');
          }
        });
      });
    })();
  </script>
</body>
</html>

