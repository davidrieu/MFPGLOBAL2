<?php
// ====================================================================================
// profil.php — Espace client MPF : Profil (users only)
// Champs gérés (table `users`) : telephone, adresse, date_naissance,
// nationalite, lieu_naissance, adresse_l1, adresse_l2, code_postal, ville, pays,
// iban, mandat_prelevement. (Email, Nom, Prénom sont en lecture seule ici)
// ====================================================================================

declare(strict_types=1);

// Démarrer la session en premier
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Inclure la connexion DB et autres dépendances
require_once 'db_connection.php'; // Doit définir $pdo
require_once 'badge_sentinel.php'; // Si utilisé

// ===== Protection CSRF =====
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

// Fonctions utilitaires
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function post(string $key, string $default = ''): string {
    return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : $default;
}

// Variables pour les messages flash
$flash_success = '';
$flash_error   = '';

// ID de l'utilisateur connecté
$user_id = (int)$_SESSION['user_id'];

// Initialiser les données utilisateur avec des valeurs par défaut
$user = [
    'id'                => $user_id,
    'name'              => '',
    'prenom'            => '',
    'email'             => '',
    'telephone'         => '',
    'adresse'           => '',
    'date_naissance'    => '',
    'nationalite'       => '',
    'lieu_naissance'    => '',
    'adresse_l1'        => '',
    'adresse_l2'        => '',
    'code_postal'       => '',
    'ville'             => '',
    'pays'              => 'France',
    'iban'              => '',
    'mandat_prelevement'=> 0,
];

// Variables pour les statistiques des contrats
$stats_contrats = ['en_cours' => 0, 'en_attente' => 0, 'echu' => 0];

// ===== CHARGEMENT INITIAL DES DONNÉES =====
try {
    $st = $pdo->prepare("
        SELECT id, name, prenom, email, telephone, adresse,
               date_naissance, nationalite, lieu_naissance,
               adresse_l1, adresse_l2, code_postal, ville, pays,
               iban, mandat_prelevement
        FROM users
        WHERE id = :id
        LIMIT 1
    ");
    $st->execute([':id' => $user_id]);
    $db_user_data = $st->fetch(PDO::FETCH_ASSOC);

    if ($db_user_data) {
        foreach ($user as $key => $defaultValue) {
            if (isset($db_user_data[$key]) && $db_user_data[$key] !== null) {
                $user[$key] = $db_user_data[$key];
            }
        }
        if (empty($user['pays'])) $user['pays'] = 'France';
    } else {
        error_log("Erreur critique: Utilisateur ID {$user_id} connecté mais non trouvé en base.");
        unset($_SESSION['user_id']);
        header('Location: login.php?error=user_not_found');
        exit();
    }

    $stmt_contrats = $pdo->prepare(
        "SELECT c.statut, c.date_souscription, COALESCE(p.duree_mois, 12) AS duree_mois
         FROM contrats c
         LEFT JOIN produits p ON c.produit_id = p.id
         WHERE c.user_id = :uid"
    );
    $stmt_contrats->execute([':uid' => $user_id]);
    $contrats = $stmt_contrats->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $aujourdhui = new DateTimeImmutable();
    foreach ($contrats as $contrat) {
        try {
            $date_souscription = new DateTimeImmutable($contrat['date_souscription']);
            $duree_mois = (int)$contrat['duree_mois'];
            if ($duree_mois <= 0) $duree_mois = 12;
            $date_fin = $date_souscription->add(new DateInterval("P{$duree_mois}M"));

            if ($aujourdhui < $date_fin) {
                if (strtolower((string)$contrat['statut']) === 'en_attente') {
                    $stats_contrats['en_attente']++;
                } else {
                    $stats_contrats['en_cours']++;
                }
            } else {
                $stats_contrats['echu']++;
            }
        } catch (Exception $dateEx) {
            error_log("Erreur date contrat (user {$user_id}): " . $dateEx->getMessage());
        }
    }

} catch (PDOException $e) {
    error_log("Erreur PDO chargement profil user {$user_id}: " . $e->getMessage());
    die('ERREUR TECHNIQUE : Impossible de charger les informations. Veuillez réessayer plus tard.');
} catch (Throwable $e) {
    error_log("Erreur Throwable chargement profil user {$user_id}: " . $e->getMessage());
    die('ERREUR TECHNIQUE : Une erreur inattendue est survenue.');
}


// ===== TRAITEMENT POST (mise à jour) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted_csrf = post('csrf_token');

    // Champs modifiables
    $telephone     = post('telephone');
    $adresse       = post('adresse');
    $date_n        = post('date_naissance');
    $nationalite   = post('nationalite');
    $lieu_naiss    = post('lieu_naissance');
    $adresse_l1    = post('adresse_l1');
    $adresse_l2    = post('adresse_l2');
    $code_postal   = post('code_postal');
    $ville         = post('ville');
    $pays          = post('pays', 'France');
    $iban_raw      = post('iban');

    // IMPORTANT : on ne restreint plus le format IBAN.
    // On normalise seulement pour la DB (UPPERCASE + sans espaces).
    $iban          = strtoupper(str_replace(' ', '', $iban_raw));

    $mandat        = isset($_POST['mandat_prelevement']) ? 1 : 0;

    // Repopuler $user pour réaffichage en cas d'erreur
    $user['telephone']          = $telephone;
    $user['adresse']            = $adresse;
    $user['date_naissance']     = $date_n;
    $user['nationalite']        = $nationalite;
    $user['lieu_naissance']     = $lieu_naiss;
    $user['adresse_l1']         = $adresse_l1;
    $user['adresse_l2']         = $adresse_l2;
    $user['code_postal']        = $code_postal;
    $user['ville']              = $ville;
    $user['pays']               = $pays;
    $user['iban']               = $iban; // affichage (sera reformaté en JS)
    $user['mandat_prelevement'] = $mandat;

    try {
        // 1) CSRF
        if (!hash_equals($csrf, $submitted_csrf)) {
            throw new RuntimeException("Erreur de sécurité (jeton invalide). Veuillez réessayer.");
        }

        // 2) Validations allégées
        if ($telephone !== '' && !preg_match('/^[0-9\s\+\-\(\)]{8,}$/', $telephone)) {
            throw new RuntimeException("Le format du numéro de téléphone est invalide.");
        }

        if ($date_n !== '') {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_n)) {
                throw new RuntimeException("Le format de la date de naissance doit être AAAA-MM-JJ.");
            }
            $d = DateTime::createFromFormat('Y-m-d', $date_n);
            if (!$d || $d->format('Y-m-d') !== $date_n || $d > new DateTime()) {
                throw new RuntimeException("La date de naissance est invalide ou future.");
            }
        }

        // ⚠️ IBAN : AUCUNE restriction de format côté serveur.

        // Autres limites de longueur
        if (mb_strlen($adresse_l1) > 255) throw new RuntimeException("Adresse (ligne 1) trop longue.");
        if (mb_strlen($adresse_l2) > 255) throw new RuntimeException("Adresse (ligne 2) trop longue.");
        if (mb_strlen($code_postal) > 20) throw new RuntimeException("Code postal trop long.");
        if (mb_strlen($ville) > 100) throw new RuntimeException("Nom de ville trop long.");
        if (mb_strlen($pays) > 100) throw new RuntimeException("Nom de pays trop long.");
        if (mb_strlen($nationalite) > 100) throw new RuntimeException("Nationalité trop longue.");
        if (mb_strlen($lieu_naiss) > 100) throw new RuntimeException("Lieu de naissance trop long.");

        // 3) Update
        $sql = "UPDATE users SET
                    telephone = :tel,
                    adresse = :adr,
                    date_naissance = :dnaiss,
                    nationalite = :nat,
                    lieu_naissance = :lnaiss,
                    adresse_l1 = :a1,
                    adresse_l2 = :a2,
                    code_postal = :cp,
                    ville = :ville,
                    pays = :pays,
                    iban = :iban,
                    mandat_prelevement = :mandat
                WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([
            ':tel'    => $telephone,
            ':adr'    => $adresse,
            ':dnaiss' => ($date_n !== '' ? $date_n : null),
            ':nat'    => $nationalite,
            ':lnaiss' => $lieu_naiss,
            ':a1'     => $adresse_l1,
            ':a2'     => $adresse_l2,
            ':cp'     => $code_postal,
            ':ville'  => $ville,
            ':pays'   => ($pays !== '' ? $pays : 'France'),
            ':iban'   => $iban,
            ':mandat' => $mandat,
            ':id'     => $user_id
        ]);

        if (!$success) {
            $errorInfo = $stmt->errorInfo();
            error_log("Erreur PDO UPDATE profil user {$user_id}: " . ($errorInfo[2] ?? 'Inconnue'));
            throw new RuntimeException("Une erreur est survenue lors de l'enregistrement. Veuillez réessayer.");
        }

        header("Location: profil.php?ok=1");
        exit();

    } catch (PDOException $e) {
        error_log("Erreur PDO UPDATE profil user {$user_id}: " . $e->getMessage());
        $flash_error = "Erreur de base de données lors de la sauvegarde. Veuillez réessayer.";
    } catch (Throwable $e) {
        $flash_error = $e->getMessage();
    }
}

if (isset($_GET['ok']) && $_GET['ok'] == '1') {
    $flash_success = "Vos informations ont été mises à jour avec succès.";
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mon Profil - Mon Plant Fraise</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

<style>
    *, *::before, *::after { box-sizing: border-box; }
    :root{
        --primary-color:#2E7D32; --primary-color-dark:#1B5E20; --primary-color-light:#C8E6C9;
        --primary-gradient:linear-gradient(135deg,#43A047,#2E7D32);
        --warning-color:#FFA000; --grey-color:#9E9E9E;
        --text-color:#212121; --text-color-light:#757575;
        --background-color:#F4F6F8; --card-background-color:#ffffff;
        --border-radius:12px; --box-shadow:0 4px 12px rgba(0,0,0,0.08);
    }
    body{ background:var(--background-color); font-family:'Roboto',Arial,sans-serif; margin:0; display:flex; color:var(--text-color); }

    /* Sidebar + container */
    .sidebar{ background:var(--card-background-color); width:260px; height:100vh; padding:20px; position:fixed; top:0; left:0;
              box-shadow:0 2px 10px rgba(0,0,0,.08); display:flex; flex-direction:column; z-index:1000; transition:transform .3s ease; }
    .sidebar-header{ margin-bottom:30px; text-align:center; }
    .sidebar-header a img{ max-width:80%; height:auto; }
    .sidebar ul{ list-style:none; padding:0; margin:0; }
    .sidebar ul li a{ display:flex; align-items:center; gap:12px; padding:12px 10px; margin-bottom:8px; text-decoration:none;
                      color:var(--text-color-light); border-radius:10px; font-weight:500; transition:.2s; }
    .sidebar ul li a:hover{ background:#eee; }
    .sidebar ul li a.active{ background:var(--primary-color); color:#fff; }
    .container{ margin-left:260px; padding:30px; width:calc(100% - 260px); transition:.3s; }

    .main-header{ font-family:'Poppins',sans-serif; font-size:28px; font-weight:700; margin:10px 0 25px; }

    .alert{ padding:14px 16px; border-radius:10px; margin-bottom:18px; font-weight:500;}
    .alert-success{ background:#E8F5E9; border:1px solid #A5D6A9; color:#1B5E20;}
    .alert-error{ background:#FFEBEE; border:1px solid #FFCDD2; color:#C62828;}

    .card{ background:var(--card-background-color); padding:0; margin-bottom:25px; box-shadow:var(--box-shadow); border-radius:var(--border-radius); overflow:hidden; }
    .card h2{ font-family:'Poppins',sans-serif; color:var(--text-color); margin:0; font-size:20px; font-weight:600; padding:20px 24px; border-bottom:1px solid #eee; }
    .card-body{ padding:20px 24px; }

    .stats-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:16px; }
    .stat-item{ display:flex; align-items:center; gap:14px; background:#F9F9F9; padding:16px; border-radius:12px; border-left:5px solid; }
    .stat-item.en-cours{ border-color:var(--primary-color); }
    .stat-item.en-attente{ border-color:var(--warning-color); }
    .stat-item.echu{ border-color:var(--grey-color); }
    .stat-item .icon{ font-size:28px; }
    .stat-item.en-cours .icon{ color:var(--primary-color); }
    .stat-item.en-attente .icon{ color:var(--warning-color); }
    .stat-item.echu .icon{ color:var(--grey-color); }
    .stat-info .count{ font-family:'Poppins',sans-serif; font-size:26px; font-weight:700; }
    .stat-info .label{ font-size:13px; color:var(--text-color-light); }

    .form-grid{ display:grid; grid-template-columns:repeat(12,1fr); gap:18px; }
    .col-6{ grid-column:span 6; }
    .col-12{ grid-column:span 12; }

    .form-group label{ display:block; margin:0 0 6px; font-weight:500; font-size:14px; }
    .form-group input, .form-group textarea, .form-group select{
        width:100%; padding:12px; border:1px solid #ddd; border-radius:10px; font-size:1rem; background:#fff; color:var(--text-color);
        transition:border-color .2s, box-shadow .2s;
    }
    .form-group input:disabled, .form-group textarea:disabled, .form-group select:disabled{
        background:#f6f6f6; color:#757575; border-color:#eee; cursor:not-allowed;
    }
    .form-group input:focus, .form-group textarea:focus, .form-group select:focus{
        outline:none; border-color:var(--primary-color); box-shadow:0 0 0 3px var(--primary-color-light);
    }
    .form-group textarea{ resize:vertical; min-height:80px; }
    .input-iban{ text-transform:uppercase; }

    .card-footer{
        position:sticky; bottom:0; background:#fff; padding:14px 16px; border-top:1px solid #eee; display:flex; gap:12px; justify-content:flex-end;
    }

    .btn{
        padding:12px 20px; border:none; border-radius:999px; cursor:pointer; font-size:15px; font-weight:700; text-decoration:none; display:inline-flex;
        align-items:center; gap:8px; transition:transform .15s ease, box-shadow .15s ease;
    }
    .btn:active{ transform:translateY(1px); }
    .btn-primary{ background:var(--primary-gradient); color:#fff; box-shadow:0 6px 16px rgba(46,125,50,.35);}
    .btn-primary:hover{ box-shadow:0 8px 20px rgba(46,125,50,.45); }
    .btn-secondary{ background:#111; color:#fff; box-shadow:0 6px 16px rgba(0,0,0,.25); }
    .btn-secondary:hover{ box-shadow:0 8px 20px rgba(0,0,0,.35); }

    /* Bouton flottant “Modifier” sur mobile */
    #floatingEdit{
        display:none; position:fixed; right:16px; bottom:16px; z-index:1100;
    }

    /* Toggle sidebar sur mobile */
    .toggle-btn{ display:none; align-items:center; justify-content:center; position:fixed; top:15px; left:15px; background:var(--primary-color);
                 color:#fff; border:none; border-radius:50%; width:50px; height:50px; cursor:pointer; z-index:1101; box-shadow:0 2px 5px rgba(0,0,0,.3); font-size:24px; }

    @media (max-width: 1100px){
        .form-grid{ grid-template-columns:repeat(6,1fr); }
        .col-6{ grid-column:span 3; }
        .col-12{ grid-column:span 6; }
    }
    @media (max-width: 900px){
        .container{ margin-left:0; width:100%; padding:18px; }
        .sidebar{ transform:translateX(-100%); }
        .sidebar.open{ transform:translateX(0); }
        .toggle-btn{ display:flex; }
        .card-footer{ justify-content:center; }
    }
    @media (max-width: 640px){
        .form-grid{ grid-template-columns:1fr; }
        .col-6, .col-12{ grid-column:span 1; }
        .btn{ width:100%; justify-content:center; }
        #floatingEdit{ display:inline-flex; }
    }
</style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()" aria-label="Ouvrir le menu">☰</button>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php" class="active"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Mon Profil</h1>

    <?php if ($flash_success): ?>
        <div class="alert alert-success"><?= h($flash_success) ?></div>
    <?php endif; ?>
    <?php if ($flash_error): ?>
        <div class="alert alert-error"><?= h($flash_error) ?></div>
    <?php endif; ?>

    <div class="card">
        <h2>Aperçu de vos contrats</h2>
        <div class="card-body">
            <div class="stats-grid">
                <div class="stat-item en-cours">
                    <span class="material-symbols-outlined icon">play_circle</span>
                    <div class="stat-info">
                        <div class="count"><?= (int)$stats_contrats['en_cours'] ?></div>
                        <div class="label">En cours</div>
                    </div>
                </div>
                <div class="stat-item en-attente">
                    <span class="material-symbols-outlined icon">pending</span>
                    <div class="stat-info">
                        <div class="count"><?= (int)$stats_contrats['en_attente'] ?></div>
                        <div class="label">En attente</div>
                    </div>
                </div>
                <div class="stat-item echu">
                    <span class="material-symbols-outlined icon">check_circle</span>
                    <div class="stat-info">
                        <div class="count"><?= (int)$stats_contrats['echu'] ?></div>
                        <div class="label">Échus</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <form method="post" action="profil.php" id="profileForm" enctype="application/x-www-form-urlencoded">
        <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

        <div class="card">
            <h2>Identité & Coordonnées</h2>
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-group col-6">
                        <label for="name">Nom</label>
                        <input type="text" id="name" value="<?= h($user['name']) ?>" disabled>
                    </div>
                    <div class="form-group col-6">
                        <label for="prenom">Prénom</label>
                        <input type="text" id="prenom" value="<?= h($user['prenom']) ?>" disabled>
                    </div>

                    <div class="form-group col-12">
                        <label for="email">Email (identifiant)</label>
                        <input type="email" id="email" name="email_display" value="<?= h($user['email']) ?>" disabled>
                    </div>

                    <div class="form-group col-6">
                        <label for="telephone">Téléphone</label>
                        <input type="tel" id="telephone" name="telephone" value="<?= h($user['telephone']) ?>" placeholder="Par exemple : +33 6 12 34 56 78" disabled>
                    </div>

                    <div class="form-group col-12">
                        <label for="adresse">Adresse (champ historique)</label>
                        <textarea id="adresse" name="adresse" rows="2" placeholder="Par exemple : 12 rue des Fraises, 74000 Annecy" disabled><?= h($user['adresse']) ?></textarea>
                    </div>

                    <div class="form-group col-6">
                        <label for="adresse_l1">Adresse Ligne 1</label>
                        <input type="text" id="adresse_l1" name="adresse_l1" value="<?= h($user['adresse_l1']) ?>" placeholder="Par exemple : 12 rue des Fraises" disabled>
                    </div>
                    <div class="form-group col-6">
                        <label for="adresse_l2">Adresse Ligne 2</label>
                        <input type="text" id="adresse_l2" name="adresse_l2" value="<?= h($user['adresse_l2']) ?>" placeholder="Par exemple : Appartement B, Lieu-dit Les Vergers" disabled>
                    </div>
                    <div class="form-group col-4">
                        <label for="code_postal">Code postal</label>
                        <input type="text" id="code_postal" name="code_postal" value="<?= h($user['code_postal']) ?>" placeholder="Par exemple : 74000" disabled>
                    </div>
                    <div class="form-group col-4">
                        <label for="ville">Ville</label>
                        <input type="text" id="ville" name="ville" value="<?= h($user['ville']) ?>" placeholder="Par exemple : Annecy" disabled>
                    </div>
                    <div class="form-group col-4">
                        <label for="pays">Pays</label>
                        <input type="text" id="pays" name="pays" value="<?= h($user['pays']) ?>" placeholder="Par exemple : France" disabled>
                    </div>

                    <div class="form-group col-6">
                        <label for="date_naissance">Date de naissance</label>
                        <input type="date" id="date_naissance" name="date_naissance" value="<?= h($user['date_naissance']) ?>" disabled max="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="form-group col-3">
                        <label for="nationalite">Nationalité</label>
                        <input type="text" id="nationalite" name="nationalite" value="<?= h($user['nationalite']) ?>" placeholder="Par exemple : Française" disabled>
                    </div>
                    <div class="form-group col-3">
                        <label for="lieu_naissance">Lieu de naissance (Ville, Pays)</label>
                        <input type="text" id="lieu_naissance" name="lieu_naissance" value="<?= h($user['lieu_naissance']) ?>" placeholder="Par exemple : Paris, France" disabled>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <h2>Informations bancaires</h2>
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-group col-12">
                        <label for="iban">IBAN (pour les retraits)</label>
                        <!-- IMPORTANT : plus de pattern/title pour ne pas bloquer -->
                        <input type="text" id="iban" name="iban" class="input-iban"
                               value="<?= h($user['iban']) ?>"
                               placeholder="Par exemple : FR76 3000 4000 5012 3456 7890 189" disabled>
                    </div>

                    <div class="form-group form-group-checkbox col-12">
                        <label for="mandat_prelevement" style="display:flex; align-items:center; gap:8px;">
                            <input type="checkbox" id="mandat_prelevement" name="mandat_prelevement" value="1" <?= !empty($user['mandat_prelevement']) ? 'checked' : '' ?> disabled>
                            Mandat de prélèvement SEPA autorisé (pour les paiements en plusieurs fois)
                        </label>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <button type="button" id="editBtn" class="btn btn-secondary">
                    <span class="material-symbols-outlined">edit</span> Modifier mes informations
                </button>
                <button type="submit" id="saveBtn" class="btn btn-primary" style="display:none;">
                    <span class="material-symbols-outlined">save</span> Enregistrer les modifications
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Bouton flottant (mobile) pour modifier -->
<button type="button" id="floatingEdit" class="btn btn-secondary">
    <span class="material-symbols-outlined">edit</span> Modifier
</button>

<script>
function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('open'); }

document.addEventListener('DOMContentLoaded', function(){
    const editBtn     = document.getElementById('editBtn');
    const floatEdit   = document.getElementById('floatingEdit');
    const saveBtn     = document.getElementById('saveBtn');
    const profileForm = document.getElementById('profileForm');

    // Tous les champs éditables du formulaire (sauf nom/prénom/email)
    const editableFields = profileForm.querySelectorAll(
        'input:not(#name):not(#prenom):not(#email), textarea, select'
    );

    function enterEditMode(){
        editableFields.forEach(field => { if (field.disabled) field.disabled = false; });
        if (editBtn) editBtn.style.display = 'none';
        if (floatEdit) floatEdit.style.display = 'none';
        if (saveBtn) saveBtn.style.display = 'inline-flex';
        const firstEditable = document.getElementById('telephone') || document.getElementById('adresse_l1');
        if (firstEditable){ firstEditable.focus(); }
        // Fermer la sidebar si ouverte en mobile pour laisser la place
        document.getElementById('sidebar').classList.remove('open');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    if (editBtn)   editBtn.addEventListener('click', enterEditMode);
    if (floatEdit) floatEdit.addEventListener('click', enterEditMode);

    // IBAN : formatage visuel par groupe de 4 — sans bloquer la saisie ni la soumission
    const ibanEl = document.getElementById('iban');
    if (ibanEl){
        ibanEl.addEventListener('input', (e) => {
            const input = e.target;
            const clean = input.value.toUpperCase().replace(/[^A-Z0-9]/g,'');
            const withSpaces = clean.replace(/(.{4})/g,'$1 ').trim();
            input.value = withSpaces;
            try{ input.setSelectionRange(withSpaces.length, withSpaces.length); }catch(_){}
        });
        // Mise en forme initiale
        if (ibanEl.value){
            const clean = ibanEl.value.toUpperCase().replace(/[^A-Z0-9]/g,'');
            ibanEl.value = clean.replace(/(.{4})/g,'$1 ').trim();
        }
    }

    // Si erreur serveur, on reste en mode édition
    <?php if ($flash_error): ?>
        if (editBtn) editBtn.style.display = 'none';
        if (floatEdit) floatEdit.style.display = 'none';
        if (saveBtn) saveBtn.style.display = 'inline-flex';
        editableFields.forEach(field => { field.disabled = false; });

        (function(){
            const msg = <?= json_encode(strtolower($flash_error)) ?>;
            let id = null;
            if (msg.includes('téléphone')) id = 'telephone';
            else if (msg.includes('date de naissance')) id = 'date_naissance';
            else if (msg.includes('iban')) id = 'iban';
            else if (msg.includes('adresse (ligne 1)')) id = 'adresse_l1';
            if (id){
                const el = document.getElementById(id);
                if (el){ el.focus(); el.scrollIntoView({behavior:'smooth', block:'center'}); }
            }
        })();
    <?php endif; ?>
});
</script>

</body>
</html>
