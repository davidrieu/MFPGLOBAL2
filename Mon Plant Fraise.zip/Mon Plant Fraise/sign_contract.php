<?php
// sign_contract.php — Signature d’un contrat (client) avec accès admin en lecture
declare(strict_types=1);

session_start();

// (Débogage à retirer en prod)
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// ===== Dépendances
require_once __DIR__ . '/db_connection.php';

// Charger lib PDF (pour régénérer après signature)
$PDF_LIB_PATHS = [
    __DIR__ . '/lib/contracts_pdf_draft.php',
    __DIR__ . '/admin/lib/contracts_pdf_draft.php',
];
foreach ($PDF_LIB_PATHS as $p) {
    if (is_file($p)) { require_once $p; break; }
}

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

/* =========================================================================
   Auth/contextes : client réel / admin réel / vues forcées via query
   -------------------------------------------------------------------------
   - ?admin=1 : forcer VUE ADMIN (si session admin existe)
   - ?as=client : forcer VUE CLIENT (lecture seule si pas de session client)
   Règles :
   - is_admin_context => session admin + admin=1 + pas as=client
   - is_client_context => as=client OU session client
   - contrôle appartenance du contrat UNIQUEMENT si session client réelle
   - signature autorisée UNIQUEMENT si session client réelle
   ========================================================================= */
$forceClient = isset($_GET['as']) && $_GET['as'] === 'client';
$forceAdmin  = isset($_GET['admin']) && $_GET['admin'] === '1';

$hasAdminSession  = !empty($_SESSION['admin_id']);
$hasClientSession = !empty($_SESSION['user_id']);

$is_admin_context  = ($hasAdminSession && $forceAdmin && !$forceClient);
$is_client_context = ($forceClient || $hasClientSession);

// Si aucune vue ni session, on renvoie vers login client par défaut
if (!$is_admin_context && !$is_client_context) {
    header('Location: /login.php');
    exit();
}
$session_user_id = (int)($_SESSION['user_id'] ?? 0);

// ===== Récup paramètres
$contract_id = isset($_GET['contract_id']) ? (int)$_GET['contract_id'] : (int)($_POST['contract_id'] ?? 0);
if ($contract_id <= 0) {
    http_response_code(400);
    die("Contrat invalide.");
}

// ===== Charger le contrat (et vérifier l’appartenance si client connecté réellement)
try {
    $st = $pdo->prepare("SELECT id, user_id, date_souscription FROM contrats WHERE id = ? LIMIT 1");
    $st->execute([$contract_id]);
    $contrat = $st->fetch(PDO::FETCH_ASSOC);
    if (!$contrat) {
        http_response_code(404);
        die("Contrat introuvable.");
    }

    // Vérif d’appartenance UNIQUEMENT si session client réelle
    if ($hasClientSession && (int)$contrat['user_id'] !== $session_user_id) {
        http_response_code(403);
        die("Vous n’êtes pas autorisé(e) à signer ce contrat depuis ce compte.");
    }
} catch (Throwable $e) {
    http_response_code(500);
    die("Erreur de chargement du contrat.");
}

// ===== Charger le document « contrat » le plus récent
function load_latest_contract_doc(PDO $pdo, int $contract_id, bool $onlyVisible): ?array {
    $sql = "
        SELECT id, filename, file_path, status, is_visible,
               client_signed_at, admin_signed_at, upload_date
        FROM documents
        WHERE contract_id = ?
          AND LOWER(category) IN ('contrat','contrats','contract','contracts')
    ";
    if ($onlyVisible) {
        $sql .= " AND is_visible = 1 ";
    }
    $sql .= " ORDER BY id DESC LIMIT 1";
    $q = $pdo->prepare($sql);
    $q->execute([$contract_id]);
    $row = $q->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

/*
 Pour la vue "client" (réelle ou forcée), on ne montre que les PDF visibles.
 Pour la vue admin (réelle), on peut voir même si pas encore visible.
*/
$doc = load_latest_contract_doc($pdo, $contract_id, $is_client_context);

// ===== Gestion POST : signature client uniquement (exige session client réelle)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'client_sign') {
    try {
        // Signature UNIQUEMENT si session client réelle
        if (!$hasClientSession) {
            throw new RuntimeException("Seul le client authentifié peut signer ce contrat depuis cette page.");
        }

        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new RuntimeException("Jeton CSRF invalide.");
        }

        if (!$doc) {
            throw new RuntimeException("Aucun PDF de contrat n’est disponible.");
        }
        if ((int)$doc['is_visible'] !== 1) {
            throw new RuntimeException("Le PDF de ce contrat n’est pas encore disponible à la signature.");
        }

        // Data URL PNG
        $data_url = (string)($_POST['signature_data_url'] ?? '');
        if (strpos($data_url, 'data:image/png;base64,') !== 0) {
            throw new RuntimeException("Signature invalide.");
        }

        // Sauvegarde de l'image
        $baseAbs = realpath(__DIR__);
        if ($baseAbs === false) throw new RuntimeException("Chemin base invalide.");
        $sigDir  = $baseAbs . '/documents/signatures';
        if (!is_dir($sigDir)) @mkdir($sigDir, 0775, true);
        if (!is_writable($sigDir)) throw new RuntimeException("Dossier non inscriptible: $sigDir");

        $png = base64_decode(substr($data_url, strlen('data:image/png;base64,')));
        if ($png === false || strlen($png) < 200) throw new RuntimeException("Données signature corrompues.");

        $sigAbs = $sigDir . "/contract-{$contract_id}-client.png";
        file_put_contents($sigAbs, $png);

        // Pose la date de signature côté client sur le document lié
        $upd = $pdo->prepare("UPDATE documents SET client_signed_at = NOW() WHERE id = ?");
        $upd->execute([(int)$doc['id']]);

        // Régénère le PDF final pour y injecter l'image + la date
        if (!function_exists('regenerate_contract_pdf_final')) {
            throw new RuntimeException("Fonction de régénération PDF non disponible.");
        }
        regenerate_contract_pdf_final($pdo, $contract_id, (int)$doc['id']);

        // Redirige avec succès
        header('Location: /sign_contract.php?contract_id='.(int)$contract_id.'&done=1');
        exit;
    } catch (Throwable $e) {
        header('Location: /sign_contract.php?contract_id='.(int)$contract_id.'&err='.urlencode($e->getMessage()));
        exit;
    }
}

// ===== Préparer l’affichage
$err  = isset($_GET['err']) ? (string)$_GET['err'] : '';
$done = isset($_GET['done']) ? (int)$_GET['done'] : 0;

$clientSignedAtTxt = '';
if ($doc && !empty($doc['client_signed_at'])) {
    $clientSignedAtTxt = date('d/m/Y H:i', strtotime($doc['client_signed_at']));
}

// URL du PDF pour iframe
$pdfPublicUrl = ($doc && !empty($doc['file_path'])) ? $doc['file_path'] : '';

// Bouton retour
$backHref  = $is_admin_context ? '/admin/gestion_documents.php' : '/mes_documents.php';
$backLabel = $is_admin_context ? '← Retour admin' : '← Retour à mes documents';

?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Signature du contrat #<?= (int)$contract_id ?> — Mon Plant Fraise</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style>
    :root {
      --primary:#2E7D32; --bd:#e5e7eb; --muted:#6b7280;
      --ok:#e8f5e9; --okbd:#c8e6c9; --err:#fdecea; --errbd:#f5c6cb;
      --card:#fff; --bg:#f7f7f7;
    }
    *{ box-sizing: border-box; }
    body{ margin:0; font-family: system-ui, -apple-system, Roboto, Arial, sans-serif; background:var(--bg); color:#111; }
    .wrap{ max-width:1200px; margin:0 auto; padding:18px; }

    .header{ display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:12px; flex-wrap:wrap; }
    .title{ font-size:22px; font-weight:800; margin:0; }
    .muted{ color:var(--muted); }

    .card{ background:var(--card); border:1px solid var(--bd); border-radius:12px; box-shadow:0 1px 2px rgba(0,0,0,.04); }
    .card-body{ padding:14px; }

    .grid{
      display:grid;
      grid-template-columns: 1.3fr 0.7fr;
      gap:14px;
    }

    .btn{ display:inline-flex; align-items:center; gap:8px; background:var(--primary); color:#fff; border:none; border-radius:10px; padding:10px 14px; cursor:pointer; font-weight:700; text-decoration:none; }
    .btn.secondary{ background:#374151; }
    .btn.ghost{ background:#fff; color:#111; border:1px solid var(--bd); }

    .alert-ok{ background:var(--ok); border:1px solid var(--okbd); padding:10px 12px; border-radius:10px; margin:10px 0; }
    .alert-err{ background:var(--err); border:1px solid var(--errbd); padding:10px 12px; border-radius:10px; margin:10px 0; }
    .alert-admin{ background:#fff7e6; border:1px solid #ffe0b2; padding:10px 12px; border-radius:10px; margin:10px 0; }

    .row{ display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
    .small{ font-size:12px; color:var(--muted); }

    .pdf-frame{ width:100%; height:80vh; border:0; background:#222; border-radius:10px; }
    .box{ border:1px dashed var(--bd); border-radius:10px; padding:12px; background:#fafafa; }
    .sig-canvas{ width:100%; height:220px; background:#fff; border:1px solid var(--bd); border-radius:10px; touch-action: none; }
    .actions{ display:flex; gap:8px; margin-top:10px; }

    @media (max-width: 1024px) {
      .grid{ grid-template-columns: 1fr; }
      .pdf-frame{ height:70vh; }
    }
    @media (max-width: 600px) {
      .pdf-frame{ height:60vh; }
    }
  </style>
</head>
<body>
<div class="wrap">

  <div class="header">
    <div>
      <h1 class="title">Signature du contrat #<?= (int)$contract_id ?></h1>
      <?php if ($is_admin_context): ?>
        <div class="muted">Mode administrateur — aperçu du PDF et lien de signature (pas de signature admin ici).</div>
      <?php elseif ($is_client_context): ?>
        <div class="muted">Signez votre contrat en toute sécurité ci-dessous.</div>
      <?php endif; ?>
    </div>
    <div class="row">
      <a class="btn ghost" href="<?= h($backHref) ?>"><?= h($backLabel) ?></a>
    </div>
  </div>

  <?php if ($is_admin_context): ?>
    <div class="alert-admin">
      Vous êtes connecté en tant qu’<strong>administrateur</strong>. Cette page permet de visualiser le contrat et de copier le
      <em>lien de signature</em> à transmettre au client. Vous ne pouvez pas signer à sa place depuis ici.
    </div>
  <?php endif; ?>

  <?php if ($err): ?>
    <div class="alert-err"><?= h($err) ?></div>
  <?php endif; ?>

  <?php if ($done): ?>
    <div class="alert-ok">La signature a été enregistrée et le contrat a été mis à jour.</div>
  <?php endif; ?>

  <div class="grid">
    <!-- Colonne PDF -->
    <div class="card">
      <div class="card-body">
        <div class="row" style="justify-content:space-between;">
          <div class="small">
            <?php if ($doc): ?>
              Document #<?= (int)$doc['id'] ?> — <?= h($doc['filename'] ?? '') ?>
              <?php if (!empty($doc['upload_date'])): ?>
                · Généré le <?= date('d/m/Y H:i', strtotime($doc['upload_date'])) ?>
              <?php endif; ?>
              <?php if ($is_client_context): ?>
                · <?= ((int)$doc['is_visible'] === 1) ? 'Disponible' : 'Non disponible' ?>
              <?php endif; ?>
            <?php else: ?>
              <span class="muted">Aucun PDF de contrat n’est disponible.</span>
            <?php endif; ?>
          </div>
          <?php if ($doc): ?>
            <div class="row">
              <a class="btn secondary" href="/download.php?id=<?= (int)$doc['id'] ?>">Télécharger</a>
              <?php if ($pdfPublicUrl): ?>
                <a class="btn ghost" href="<?= h($pdfPublicUrl) ?>" target="_blank" rel="noopener">Ouvrir dans un onglet</a>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>

        <div style="margin-top:10px;">
          <?php if ($pdfPublicUrl): ?>
            <iframe class="pdf-frame" src="<?= h($pdfPublicUrl) ?>" title="Contrat PDF"></iframe>
          <?php else: ?>
            <div class="alert-err">Aucun PDF de contrat n’est disponible.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Colonne de droite -->
    <div class="card">
      <div class="card-body">
        <?php if ($is_admin_context): ?>
          <div class="box">
            <div class="small" style="margin-bottom:6px;">Lien de signature à transmettre au client :</div>
            <div class="row" style="gap:6px;">
              <?php
                // IMPORTANT : forcer une vue client côté destinataire
                $link = '/sign_contract.php?contract_id='.(int)$contract_id.'&as=client';
              ?>
              <input type="text" id="shareLink" value="<?= h($link) ?>" style="flex:1; padding:10px; border:1px solid var(--bd); border-radius:8px" readonly>
              <button class="btn" type="button" id="copyBtn">Copier</button>
            </div>
            <div class="small" style="margin-top:8px;">Le client doit être connecté à son compte pour signer.</div>
          </div>
        <?php else: ?>
          <?php if (!$doc): ?>
            <div class="alert-err">Aucun PDF n’est encore disponible pour ce contrat. Réessayez plus tard.</div>
          <?php elseif ((int)$doc['is_visible'] !== 1): ?>
            <div class="alert-err">Le PDF n’est pas encore disponible à la signature. Merci de réessayer plus tard.</div>
          <?php elseif (!empty($doc['client_signed_at'])): ?>
            <div class="alert-ok">✅ Déjà signé par vous le <?= h($clientSignedAtTxt) ?>.</div>
            <div class="small">Si la signature n’apparaît pas, rechargez la page ; le PDF est régénéré automatiquement.</div>
          <?php else: ?>
            <div class="box">
              <div class="small" style="margin-bottom:6px;">Signez ci-dessous (au doigt ou à la souris) :</div>
              <canvas id="sig" class="sig-canvas"></canvas>
              <div class="actions">
                <button class="btn ghost" type="button" id="clearBtn">Effacer</button>
                <form id="signForm" method="POST" style="margin-left:auto;">
                  <input type="hidden" name="action" value="client_sign">
                  <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
                  <input type="hidden" name="contract_id" value="<?= (int)$contract_id ?>">
                  <input type="hidden" name="signature_data_url" id="signature_data_url">
                  <button class="btn" type="submit">Signer</button>
                </form>
              </div>
              <div class="small" style="margin-top:6px;">Votre signature sera annexée au PDF et datée automatiquement.</div>
            </div>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // Copie du lien (admin)
  const copyBtn = document.getElementById('copyBtn');
  const shareInput = document.getElementById('shareLink');
  if (copyBtn && shareInput) {
    copyBtn.addEventListener('click', async function(){
      try {
        shareInput.select();
        shareInput.setSelectionRange(0, 99999);
        await navigator.clipboard.writeText(shareInput.value);
        copyBtn.textContent = 'Copié !';
        setTimeout(()=>copyBtn.textContent='Copier', 1200);
      } catch(e) {
        alert('Impossible de copier le lien automatiquement.');
      }
    });
  }

  // Signature (client)
  const canvas = document.getElementById('sig');
  const form   = document.getElementById('signForm');
  const clearB = document.getElementById('clearBtn');
  const hidden = document.getElementById('signature_data_url');

  if (!canvas || !form || !hidden) return;

  const ctx = canvas.getContext('2d');
  let drawing = false;
  let last = null;

  function resizeCanvas(){
    const ratio = Math.max(window.devicePixelRatio || 1, 1);
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    canvas.width  = cssW * ratio;
    canvas.height = cssH * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    // fond blanc
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, cssW, cssH);
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap  = 'round';
    ctx.strokeStyle = '#111';
  }

  function pos(evt){
    const rect = canvas.getBoundingClientRect();
    if (evt.touches && evt.touches[0]) {
      return { x: evt.touches[0].clientX - rect.left, y: evt.touches[0].clientY - rect.top };
    }
    return { x: evt.clientX - rect.left, y: evt.clientY - rect.top };
  }

  function begin(e){
    e.preventDefault();
    drawing = true;
    last = pos(e);
  }
  function move(e){
    if (!drawing) return;
    e.preventDefault();
    const p = pos(e);
    ctx.beginPath();
    ctx.moveTo(last.x, last.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last = p;
  }
  function end(e){
    if (!drawing) return;
    e.preventDefault();
    drawing = false;
  }

  // Souris
  canvas.addEventListener('mousedown', begin);
  canvas.addEventListener('mousemove', move);
  canvas.addEventListener('mouseup', end);
  canvas.addEventListener('mouseleave', end);
  // Tactile
  canvas.addEventListener('touchstart', begin, {passive:false});
  canvas.addEventListener('touchmove',  move,  {passive:false});
  canvas.addEventListener('touchend',   end,   {passive:false});
  canvas.addEventListener('touchcancel',end,   {passive:false});

  window.addEventListener('resize', resizeCanvas);
  // init
  resizeCanvas();

  if (clearB) clearB.addEventListener('click', function(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    resizeCanvas();
  });

  form.addEventListener('submit', function(){
    // Export PNG
    const data = canvas.toDataURL('image/png');
    hidden.value = data;
  });
})();
</script>
</body>
</html>


