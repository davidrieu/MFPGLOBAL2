<?php
// Fichier : db_connection.php

// ----- Clé Stripe (source unique) -----
// Mets ta VRAIE clé (sk_live_... ou sk_test_...) ici.
// Tu pourras la déplacer en variable d’environnement plus tard si besoin.
if (!defined('STRIPE_SECRET_KEY')) {
    define('STRIPE_SECRET_KEY', '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');
}


$host_name = 'mpfgloqamo.mysql.db';
$database  = 'mpfgloqamo'; // Utilisation du nouveau nom de base de données
$user_name = 'mpfgloqamo';
$password  = '24021993Ab';
$port = '35917';

try {
    // Création de l'objet PDO pour la connexion
    $pdo = new PDO("mysql:host=$host_name;dbname=$database;charset=utf8mb4", $user_name, $password);
    
    // Configuration des options pour la gestion des erreurs
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // En cas d'échec, on arrête tout et on affiche l'erreur
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Si vous arrivez ici, la variable $pdo est prête à être utilisée.
// Il n'est pas nécessaire d'afficher un message de succès sur un site en production.
?>