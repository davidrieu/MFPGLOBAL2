<?php
// htdocs/download.php — Téléchargement/affichage d'un document PDF

declare(strict_types=1);
session_start();

// (optionnel en prod)
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/db_connection.php';

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function deny($code=403, $msg='Accès refusé'){ http_response_code($code); exit($msg); }

// --- Auth minimal : client connecté OU admin connecté
$isUser  = isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] > 0;
$isAdmin = isset($_SESSION['admin_id']) && (int)$_SESSION['admin_id'] > 0;
if (!$isUser && !$isAdmin) {
    // rediriger vers login si besoin
    header('Location: /login.php');
    exit();
}

$doc_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($doc_id <= 0) deny(400, 'Paramètre manquant.');

try {
    // On récupère le doc (visible pour le client ; tout pour l’admin)
    if ($isAdmin) {
        $stmt = $pdo->prepare("SELECT id, user_id, filename, file_path, category, is_visible FROM documents WHERE id = ?");
        $stmt->execute([$doc_id]);
    } else {
        $stmt = $pdo->prepare("SELECT id, user_id, filename, file_path, category, is_visible FROM documents WHERE id = ? AND is_visible = 1");
        $stmt->execute([$doc_id]);
    }
    $doc = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$doc) deny(404, 'Document introuvable.');

    // Contrôle d’accès : le client ne peut télécharger que ses propres docs visibles
    if ($isUser && (int)$doc['user_id'] !== (int)$_SESSION['user_id']) {
        deny(403, 'Ce document ne vous appartient pas.');
    }

    // Résolution du chemin physique
    $filePathDb = trim((string)$doc['file_path'] ?: '');
    if ($filePathDb === '') deny(404, 'Chemin de fichier vide.');
    // Les enregistrements précédents utilisent des chemins web du type /documents/contrats/xxx.pdf
    // On reconstruit le chemin absolu sur disque :
    $absBase = realpath(__DIR__);
    if ($absBase === false) deny(500, 'Base path invalide.');
    // Normaliser : retirer d’éventuels `./`
    if (strpos($filePathDb, './') === 0) $filePathDb = '/' . ltrim(substr($filePathDb, 2), '/');
    if ($filePathDb[0] !== '/') $filePathDb = '/' . $filePathDb;

    $abs = $absBase . $filePathDb;

    // Fallback : si realpath échoue plus bas (env d’hébergement), on tente aussi le dossier UPLOAD utilisé côté lib
    if (!is_file($abs)) {
        $alt = realpath(__DIR__ . '/documents/contrats/');
        if ($alt) {
            $candidate = rtrim($alt, '/').'/'.basename($filePathDb);
            if (is_file($candidate)) $abs = $candidate;
        }
    }
    if (!is_file($abs)) deny(404, 'Fichier non trouvé sur le disque.');

    // En-têtes HTTP
    $filename = trim((string)$doc['filename']) ?: ('document_'.$doc_id.'.pdf');
    $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename);

    $inline = (isset($_GET['view']) && (int)$_GET['view'] === 1); // ?view=1 pour affichage dans le navigateur
    header('Content-Type: application/pdf');
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="'.$safeName.'"');
    header('Content-Length: ' . filesize($abs));
    header('X-Content-Type-Options: nosniff');

    // Nettoyage des buffers pour éviter la corruption du PDF
    while (ob_get_level()) { ob_end_clean(); }

    // Lecture du fichier
    $fp = fopen($abs, 'rb');
    if ($fp === false) deny(500, 'Erreur ouverture fichier.');
    fpassthru($fp);
    fclose($fp);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    exit('Erreur interne.');
}
