<?php
// dashboardapporteur.php — Dashboard Apporteurs d’affaires (protégé & complet)
// ---------------------------------------------------------------------------------
// • Lien d’affiliation visible : https://mpf-global.com/loginap.php?parrain=CODE&discount=KIND:VALUE
// • Règle visible : "Règle : reduction:20" ou "Règle : bonus:20"
// • Graphique des commissions (Chart.js)
// • Tables : clients, investissements, commissions, dossier de paiement N-1
// • Tolérance si promo_kind/promo_value manquent en BDD (fallback reduction:0)
//
// Sécurité & session
session_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Redirection si non connecté (attend $_SESSION['apporteur_id'])
if (empty($_SESSION['apporteur_id'])) {
    $next = urlencode($_SERVER['REQUEST_URI'] ?? 'dashboardapporteur.php');
    header("Location: loginapporteur.php?next={$next}");
    exit;
}

// Connexion BDD
require_once __DIR__ . '/db_connection.php'; // doit définir $pdo (PDO)
if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit("db_connection.php doit définir \$pdo (PDO).");
}
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Stripe (optionnel)
$stripeSecret = defined('STRIPE_SECRET_KEY')
    ? STRIPE_SECRET_KEY
    : (getenv('STRIPE_SECRET_KEY') ?: ($_SERVER['STRIPE_SECRET_KEY'] ?? null));
$stripeReady = !empty($stripeSecret);
if ($stripeReady) {
    require_once __DIR__ . '/vendor/autoload.php';
    \Stripe\Stripe::setApiKey($stripeSecret);
}

// ---------------------------------------------------------------------------------
// Helpers
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function euro0($n){ return number_format((float)$n, 0, ',', ' ') . ' €'; }
function euro2($n){ return number_format((float)$n, 2, ',', ' ') . ' €'; }
function trunc2($x){ return floor(((float)$x)*100)/100; }
function labelTypePaiement(?string $t): string {
    $t = strtolower((string)$t);
    if (in_array($t, ['abonnement','12x','mensuel','subscription','monthly'], true)) {
        return 'Abonnement (12x)';
    }
    return 'Paiement unique';
}
function badgeTypePaiement(?string $t): string {
    $t = strtolower((string)$t);
    if (in_array($t, ['abonnement','12x','mensuel','subscription','monthly'], true)) {
        return '<span class="badge blue">Abonnement (12x)</span>';
    }
    return '<span class="badge">Paiement unique</span>';
}
function periodPrevMonth(): string { // YYYY-MM du mois précédent
    $tz = new DateTimeZone('Europe/Paris');
    $d  = new DateTime('first day of last month 00:00:00', $tz);
    return $d->format('Y-m');
}
function monthHumanFR(string $ym): string {
    $dt = DateTime::createFromFormat('Y-m', $ym, new DateTimeZone('Europe/Paris'));
    if (!$dt) return $ym;
    $mois = [1=>'janv.',2=>'févr.',3=>'mars',4=>'avr.',5=>'mai',6=>'juin',7=>'juil.',8=>'août',9=>'sept.',10=>'oct.',11=>'nov.',12=>'déc.'];
    return ($mois[(int)$dt->format('n')] ?? $dt->format('m')) . ' ' . $dt->format('Y');
}
function startEndTimestampsOfYm(string $ym): array { // [tsStart, tsEndExcl]
    $tz = new DateTimeZone('Europe/Paris');
    $d1 = DateTime::createFromFormat('Y-m-d H:i:s', $ym.'-01 00:00:00', $tz) ?: new DateTime('first day of this month', $tz);
    $d2 = (clone $d1)->modify('first day of next month');
    return [$d1->getTimestamp(), $d2->getTimestamp()];
}

// ---------------------------------------------------------------------------------
// Récup infos apporteur (code + règle d’avantage)
// Table attendue : apporteurs_login
$apporteurId = (int)$_SESSION['apporteur_id'];

// Detecter si les colonnes promo existent (pour éviter un 500 si pas encore ajoutées)
$hasPromoKind  = false;
$hasPromoValue = false;
try {
    $cols = $pdo->query("SHOW COLUMNS FROM apporteurs_login")->fetchAll(PDO::FETCH_COLUMN, 0);
    if (is_array($cols)) {
        $colsLower = array_map('strtolower', $cols);
        $hasPromoKind  = in_array('promo_kind', $colsLower, true);
        $hasPromoValue = in_array('promo_value', $colsLower, true);
    }
} catch (\Throwable $e) {
    // on ignore, fallback par défaut
}

// Récup sponsorship_code + promo_kind/promo_value si dispo
if ($hasPromoKind && $hasPromoValue) {
    $st = $pdo->prepare("SELECT sponsorship_code, promo_kind, promo_value FROM apporteurs_login WHERE id = :id LIMIT 1");
} else {
    $st = $pdo->prepare("SELECT sponsorship_code FROM apporteurs_login WHERE id = :id LIMIT 1");
}
$st->execute([':id'=>$apporteurId]);
$rowAp = $st->fetch(PDO::FETCH_ASSOC);
$apporteurCode = trim((string)($rowAp['sponsorship_code'] ?? ''));
if ($apporteurCode === '') {
    http_response_code(403);
    exit("Aucun sponsorship_code n'est associé à cet apporteur.");
}

// Règle d’affiliation (fallback reduction:0)
$promoKind  = $hasPromoKind  ? strtolower((string)($rowAp['promo_kind']  ?? 'reduction')) : 'reduction';
$promoValue = $hasPromoValue ? (float)($rowAp['promo_value'] ?? 0) : 0.0;
if (!in_array($promoKind, ['reduction','bonus'], true)) $promoKind = 'reduction';
if ($promoValue < 0) $promoValue = 0.0;

// Lien d’affiliation demandé
$discountParam = $promoKind . ':' . (string)(0 + $promoValue); // ex "reduction:20" ou "bonus:20"
$affLink = "https://mpf-global.com/loginap.php?parrain=" . rawurlencode($apporteurCode) . "&discount=" . rawurlencode($discountParam);

// ---------------------------------------------------------------------------------
// Assure les tables workflow
function ensureWorkflowTables(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS commission_validations (
            apporteur_id BIGINT NOT NULL,
            period_month CHAR(7) NOT NULL,
            status ENUM('en_attente','valide','paye') NOT NULL DEFAULT 'en_attente',
            validated_at DATETIME NULL,
            paid_at DATETIME NULL,
            PRIMARY KEY (apporteur_id, period_month)
        )
    ");
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS commission_issues (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            apporteur_id BIGINT NOT NULL,
            period_month CHAR(7) NOT NULL,
            message TEXT NOT NULL,
            status ENUM('open','resolved','dismissed') DEFAULT 'open',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            resolved_at DATETIME NULL,
            INDEX idx_issue_lookup (apporteur_id, period_month, status)
        )
    ");
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS payout_folders (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            apporteur_id BIGINT NOT NULL,
            period_month CHAR(7) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_folder (apporteur_id, period_month)
        )
    ");
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS payout_folder_items (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            folder_id BIGINT NOT NULL,
            user_id BIGINT NOT NULL,
            contrat_id BIGINT NULL,
            paid_at DATETIME NULL,
            paid_amount DECIMAL(12,2) DEFAULT 0,
            currency CHAR(3) DEFAULT 'EUR',
            contract_amount DECIMAL(12,2) DEFAULT 0,
            payment_type VARCHAR(32) NOT NULL,
            stripe_receipt_url TEXT NULL,
            stripe_pi VARCHAR(64) NULL,
            stripe_charge VARCHAR(64) NULL,
            stripe_invoice VARCHAR(64) NULL,
            INDEX idx_folder (folder_id),
            INDEX idx_folder_user (folder_id, user_id),
            INDEX idx_folder_contrat (folder_id, contrat_id)
        )
    ");
}
ensureWorkflowTables($pdo);

// Création du dossier N-1 si manquant + population de base
function getOrCreateFolder(PDO $pdo, int $apporteurId, string $periodMonth): int {
    $st = $pdo->prepare("SELECT id FROM payout_folders WHERE apporteur_id=? AND period_month=?");
    $st->execute([$apporteurId, $periodMonth]);
    $id = (int)$st->fetchColumn();
    if ($id) return $id;
    $ins = $pdo->prepare("INSERT INTO payout_folders (apporteur_id, period_month) VALUES (?, ?)");
    $ins->execute([$apporteurId, $periodMonth]);
    return (int)$pdo->lastInsertId();
}

// Stripe helpers
function findStripeReceiptsForUserMonth(int $userId, string $ym, bool $stripeReady): array {
    if (!$stripeReady) return [];
    try {
        [$tsStart, $tsEnd] = startEndTimestampsOfYm($ym);
        $out = [];

        // Charges
        $charges = \Stripe\Charge::all([
            'limit' => 100,
            'created' => ['gte'=>$tsStart,'lt'=>$tsEnd],
        ]);
        foreach ($charges->autoPagingIterator() as $ch) {
            $meta = $ch->metadata ?? new \Stripe\StripeObject();
            $uidMeta = isset($meta['user_id']) ? (int)$meta['user_id'] : null;
            if ($uidMeta !== $userId) continue;
            $out[] = [
                'paid_at'      => date('Y-m-d H:i:s', $ch->created),
                'amount'       => isset($ch->amount_captured) ? $ch->amount_captured/100 : ($ch->amount/100),
                'currency'     => strtoupper($ch->currency ?? 'EUR'),
                'receipt_url'  => $ch->receipt_url ?? null,
                'pi'           => $ch->payment_intent ?? null,
                'charge'       => $ch->id ?? null,
                'invoice'      => $ch->invoice ?? null,
            ];
        }

        // Invoices
        $invoices = \Stripe\Invoice::all([
            'limit' => 100,
            'created' => ['gte'=>$tsStart,'lt'=>$tsEnd],
        ]);
        foreach ($invoices->autoPagingIterator() as $inv) {
            $meta = $inv->metadata ?? new \Stripe\StripeObject();
            $uidMeta = isset($meta['user_id']) ? (int)$meta['user_id'] : null;
            if ($uidMeta !== $userId) continue;

            $chargeId = is_string($inv->charge ?? null) ? $inv->charge : null;
            $receiptUrl = null; $pi = null;
            if ($chargeId) {
                $ch = \Stripe\Charge::retrieve($chargeId);
                $receiptUrl = $ch->receipt_url ?? null;
                $pi = $ch->payment_intent ?? null;
            }
            $paidAtTs = $inv->status_transitions->paid_at ?? $inv->created ?? time();
            $out[] = [
                'paid_at'      => date('Y-m-d H:i:s', $paidAtTs),
                'amount'       => isset($inv->amount_paid) ? $inv->amount_paid/100 : (isset($inv->total) ? $inv->total/100 : 0),
                'currency'     => strtoupper($inv->currency ?? 'EUR'),
                'receipt_url'  => $receiptUrl,
                'pi'           => $pi,
                'charge'       => $chargeId,
                'invoice'      => $inv->id ?? null,
            ];
        }

        return $out;
    } catch (\Throwable $e) {
        error_log("Stripe receipts fetch error: ".$e->getMessage());
        return [];
    }
}

function ensurePayoutFolderItems(PDO $pdo, int $folderId, int $apporteurId, string $apporteurCode, string $ym, bool $stripeReady): void {
    // si déjà peuplé -> ne rien faire
    $has = $pdo->prepare("SELECT 1 FROM payout_folder_items WHERE folder_id=? LIMIT 1");
    $has->execute([$folderId]);
    if ($has->fetchColumn()) return;

    // Clients rattachés à cet apporteur (users.parrain = code)
    $stUsers = $pdo->prepare("SELECT id FROM users WHERE parrain = ?");
    $stUsers->execute([$apporteurCode]);
    $users = $stUsers->fetchAll(PDO::FETCH_ASSOC);
    if (empty($users)) return;

    [$tsStart, $tsEnd] = startEndTimestampsOfYm($ym);
    $dStart = (new DateTime('@'.$tsStart))->setTimezone(new DateTimeZone('Europe/Paris'))->format('Y-m-d H:i:s');
    $dEnd   = (new DateTime('@'.$tsEnd  ))->setTimezone(new DateTimeZone('Europe/Paris'))->format('Y-m-d H:i:s');

    $stCmd = $pdo->prepare("
        SELECT id, user_id, montant_total, date_commande AS paid_at, stripe_session_id
        FROM commandes
        WHERE user_id=? AND date_commande>=? AND date_commande<?
    ");
    $insItem = $pdo->prepare("
        INSERT INTO payout_folder_items
            (folder_id, user_id, contrat_id, paid_at, paid_amount, currency, contract_amount, payment_type, stripe_receipt_url, stripe_pi, stripe_charge, stripe_invoice)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    ");

    foreach ($users as $u) {
        $uid = (int)$u['id'];

        // Commandes du mois
        $stCmd->execute([$uid, $dStart, $dEnd]);
        while ($cmd = $stCmd->fetch(PDO::FETCH_ASSOC)) {
            $insItem->execute([
                $folderId, $uid, null,
                $cmd['paid_at'] ?? null,
                (float)$cmd['montant_total'], 'EUR',
                0, 'Paiement initial',
                null, null, null, null
            ]);
        }

        // Reçus Stripe
        $receipts = findStripeReceiptsForUserMonth($uid, $ym, $stripeReady);
        foreach ($receipts as $r) {
            $insItem->execute([
                $folderId, $uid, null,
                $r['paid_at'], trunc2($r['amount']), $r['currency'] ?? 'EUR',
                0, 'Stripe',
                $r['receipt_url'], $r['pi'], $r['charge'], $r['invoice']
            ]);
        }
    }

    // Enrichir contract_amount & payment_type via contrats
    $upd = $pdo->prepare("
        UPDATE payout_folder_items i
        JOIN contrats k ON k.user_id = i.user_id
        SET i.contract_amount = k.montant,
            i.payment_type = CASE
                WHEN LOWER(k.type_paiement) IN ('abonnement','12x','mensuel','subscription','monthly') THEN 'Abonnement (12x)'
                ELSE 'Paiement unique'
            END
        WHERE i.folder_id = ?
          AND (i.contract_amount IS NULL OR i.contract_amount = 0)
    ");
    $upd->execute([$folderId]);
}

// ---------------------------------------------------------------------------------
// Données de page
$COMM_RATE = 0.20; // 20 %
$tab      = $_GET['tab'] ?? 'overview';
$search   = trim($_GET['q'] ?? '');
$sortInv  = $_GET['sort_inv'] ?? 'date';
$dirInv   = strtolower($_GET['dir_inv'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
$sortCli  = $_GET['sort_cli'] ?? 'name';
$dirCli   = strtolower($_GET['dir_cli'] ?? 'asc') === 'desc' ? 'DESC' : 'ASC';

$prevYm    = periodPrevMonth();
$folderId  = getOrCreateFolder($pdo, $apporteurId, $prevYm);
ensurePayoutFolderItems($pdo, $folderId, $apporteurId, $apporteurCode, $prevYm, $stripeReady);

// Investissements
$orderInv = "k.date_souscription $dirInv";
if ($sortInv === 'name')   $orderInv = "client_name $dirInv";
if ($sortInv === 'amount') $orderInv = "k.montant $dirInv";
$sqlInv = "
    SELECT
        k.id AS contrat_id,
        CONCAT(u.name, ' ', u.prenom) AS client_name,
        k.date_souscription, k.montant, k.apport,
        (k.apport * :rate_inv) AS commission,
        k.type_paiement, k.mensualites_payees
    FROM contrats k
    JOIN users u ON u.id = k.user_id
    WHERE u.parrain = :code
";
$paramsInv = [':code'=>$apporteurCode, ':rate_inv'=>$COMM_RATE];
if ($search !== '') { $sqlInv .= " AND (CONCAT(u.name, ' ', u.prenom) LIKE :q OR k.id LIKE :q)"; $paramsInv[':q'] = '%'.$search.'%'; }
$sqlInv .= " ORDER BY $orderInv";
$st = $pdo->prepare($sqlInv); $st->execute($paramsInv);
$investissements = $st->fetchAll(PDO::FETCH_ASSOC);

// Clients (agrégats)
$orderCli = "client_name $dirCli";
if ($sortCli === 'amount') $orderCli = "total_invest $dirCli";
if ($sortCli === 'date')   $orderCli = "first_subscription_date $dirCli";
$sqlCli = "
    SELECT
        u.id,
        CONCAT(u.name, ' ', u.prenom) AS client_name,
        MIN(k.date_souscription) AS first_subscription_date,
        COUNT(k.id) AS nb_contrats,
        COALESCE(SUM(k.montant),0) AS total_invest,
        COALESCE(SUM(k.apport),0)  AS total_apport,
        COALESCE(SUM(k.apport * :rate_cli),0) AS total_commissions
    FROM users u
    LEFT JOIN contrats k ON k.user_id = u.id
    WHERE u.parrain = :code
";
$paramsCli = [':code'=>$apporteurCode, ':rate_cli'=>$COMM_RATE];
if ($search !== '') { $sqlCli .= " AND (CONCAT(u.name, ' ', u.prenom) LIKE :q)"; $paramsCli[':q'] = '%'.$search.'%'; }
$sqlCli .= " GROUP BY u.id ORDER BY $orderCli";
$st = $pdo->prepare($sqlCli); $st->execute($paramsCli);
$clients = $st->fetchAll(PDO::FETCH_ASSOC);

// Contrats détaillés par user
$st = $pdo->prepare("
    SELECT k.id, k.user_id, k.date_souscription, k.montant, k.apport, k.type_paiement, k.mensualites_payees
    FROM contrats k
    JOIN users u ON u.id = k.user_id
    WHERE u.parrain = :code
    ORDER BY k.user_id, k.date_souscription DESC, k.id DESC
");
$st->execute([':code'=>$apporteurCode]);
$rowsContracts = $st->fetchAll(PDO::FETCH_ASSOC);
$contractsByUser = [];
foreach ($rowsContracts as $rc) { $contractsByUser[(int)$rc['user_id']][] = $rc; }

// Commissions mensuelles
$st = $pdo->prepare("
    SELECT
        DATE_FORMAT(k.date_souscription, '%Y-%m') AS period_month,
        SUM(k.apport * :rate_comm) AS total_amount
    FROM contrats k
    JOIN users u ON u.id = k.user_id
    WHERE u.parrain = :code
    GROUP BY DATE_FORMAT(k.date_souscription, '%Y-%m')
    ORDER BY 1
");
$st->execute([':code'=>$apporteurCode, ':rate_comm'=>$COMM_RATE]);
$commissions = $st->fetchAll(PDO::FETCH_ASSOC);

// Statuts validations/paiements
$st = $pdo->prepare("SELECT period_month, status, validated_at, paid_at FROM commission_validations WHERE apporteur_id=?");
$st->execute([$apporteurId]);
$mapVal = [];
while ($v = $st->fetch(PDO::FETCH_ASSOC)) { $mapVal[$v['period_month']] = $v; }

// Kpis + chart
$totalInvest = array_sum(array_column($investissements, 'montant'));
$totalClients = count($clients);
$currentMonthKey = date('Y-m');
$commThisMonth = 0.0;
foreach ($commissions as $c) if ($c['period_month'] === $currentMonthKey) { $commThisMonth = (float)$c['total_amount']; break; }
$chartLabels = []; $chartValues = [];
foreach ($commissions as $c) {
    $chartLabels[] = monthHumanFR($c['period_month']);
    $chartValues[] = (float)$c['total_amount'];
}

// Dossier N-1
$st = $pdo->prepare("SELECT id FROM payout_folders WHERE apporteur_id=? AND period_month=?");
$st->execute([$apporteurId, $prevYm]);
$prevFolderId = (int)$st->fetchColumn();
$folderItems = [];
if ($prevFolderId) {
    $stI = $pdo->prepare("
        SELECT i.*, CONCAT(u.name,' ',u.prenom) as client_name
        FROM payout_folder_items i
        JOIN users u ON u.id = i.user_id
        WHERE i.folder_id=?
        ORDER BY i.paid_at, i.id
    ");
    $stI->execute([$prevFolderId]);
    $folderItems = $stI->fetchAll(PDO::FETCH_ASSOC);
}

?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<title>Dashboard Apporteurs d’affaires</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
  *, *::before, *::after { box-sizing: border-box; }
  :root{
    --primary-color:#2E7D32; --primary-gradient:linear-gradient(135deg,#4CAF50,#2E7D32);
    --bg:#F4F6F8; --card:#ffffff; --muted:#6b7280; --text:#212121; --ring: rgba(76,175,80,.25);
    --radius:12px; --shadow: 0 10px 30px rgba(0,0,0,.08);
  }
  body{ margin:0; font-family:'Roboto',sans-serif; background:
        radial-gradient(1200px 320px at 20% 0%, rgba(76,175,80,.08), transparent 60%),
        linear-gradient(180deg, #ffffff, var(--bg) 40%, #f8fafc 100%); color:var(--text); }
  .container{max-width:1120px;margin:0 auto;padding:24px}
  h1{font-size:30px;line-height:1.15;font-weight:750;margin:0 0 4px 0;letter-spacing:-.01em; font-family:'Poppins',sans-serif;}
  .sub{color:var(--muted);margin:4px 0 0}
  .row{display:flex;gap:12px;align-items:center}
  .row.wrap{flex-wrap:wrap}.sp-between{justify-content:space-between}
  .card{background:var(--card);border:1px solid #e9ecef;border-radius:var(--radius);box-shadow:var(--shadow);position:relative;overflow:hidden;transition:.25s;margin-bottom:14px}
  .card:before{content:"";position:absolute;inset:-1px -1px auto -1px;height:6px;background:var(--primary-gradient);opacity:.35}
  .card:hover{transform:translateY(-2px);box-shadow:0 16px 48px rgba(0,0,0,.10);border-color:#e0e7e4}
  .card .head{padding:16px 20px;border-bottom:1px solid #f2f2f2;background:linear-gradient(180deg, rgba(248,250,252,.8), rgba(255,255,255,1))}
  .card .body{padding:16px 20px}.card h3{margin:0;font-size:18px;font-family:'Poppins',sans-serif}
  .kpis{display:grid;grid-template-columns:repeat(1,minmax(0,1fr));gap:12px;margin:12px 0}
  @media(min-width:920px){.kpis{grid-template-columns:repeat(4,1fr)}}
  .kpi{background:#fff;border:1px solid #eef0f4;border-radius:var(--radius);padding:12px 14px}
  .kpi .lbl{font-size:13px;color:var(--muted)} .kpi .val{font-size:20px;font-weight:750}
  .btn{display:inline-flex;align-items:center;gap:8px;border:1px solid #e5e7eb;border-radius:12px;padding:9px 14px;background:#fff;color:#111;cursor:pointer;transition:.2s;text-decoration:none}
  .btn.primary{background:var(--primary-gradient);color:#fff;border-color:#2E7D32;box-shadow:0 12px 26px rgba(46,125,50,.24)}
  .btn.small{padding:6px 10px;border-radius:10px;font-size:12px}
  .input, select, textarea{border:1px solid #e5e7eb;border-radius:10px;padding:10px 12px;min-width:220px;background:#fff}
  .tabs{display:flex;flex-wrap:wrap;gap:8px;border:1px solid #e5e7eb;padding:5px;border-radius:12px;background:#fff;box-shadow:0 4px 16px rgba(2,6,23,.05);position:sticky;top:10px;z-index:10}
  .tab{border:none;background:none;padding:9px 14px;border-radius:10px;cursor:pointer;text-decoration:none;color:#111;font-weight:500;}
  .tab.active{background:var(--primary-gradient);color:#fff;box-shadow:0 10px 22px rgba(17,24,39,.15)}
  .badge{display:inline-block;border-radius:9999px;background:#f1f5f9;padding:4px 10px;font-size:12px;font-weight:500;}
  .badge.green{background:rgba(16,185,129,.14);color:#065f46;border:1px solid rgba(16,185,129,.25)}
  .badge.blue{background:rgba(37,99,235,.14);color:#1e3a8a;border:1px solid rgba(37,99,235,.25)}
  table{width:100%;border-collapse:separate;border-spacing:0}
  thead th{color:#6b7280;font-weight:600;font-size:13px;background:#f9fafb;position:sticky;top:0;z-index:1;border-bottom:1px solid #eef0f4;text-align:left;padding:12px 14px;}
  td{padding:12px 14px;border-bottom:1px solid #eef0f4;text-align:left}
  tbody tr:nth-child(even){background:#fbfbfd} tbody tr:hover{background:#f6f7fb}
  .muted{color:#6b7280}
  .hidden{display:none}
  .subrow{background:#fcfdfc}
  .pill{display:inline-flex;align-items:center;gap:10px;border:1px dashed #cbd5e1;border-radius:12px;padding:10px 12px;background:#fff}
  .pill .k{font-weight:700}
  .aff-box{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
  .code{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;background:#0b1020;color:#e8f0ff;padding:10px 12px;border-radius:10px;font-size:12px}
</style>
</head>
<body>
<div class="container">
  <div class="row sp-between wrap" style="margin-bottom:12px;align-items:flex-start;">
    <div>
      <h1>Dashboard Apporteurs d’affaires</h1>
      <p class="sub">Suivi en temps réel des clients, investissements, commissions et dossiers de paiement.</p>
    </div>
    <div class="row">
      <a class="btn" href="loginapporteur.php?logout=1">Déconnexion</a>
    </div>
  </div>

  <!-- Encadré AFFILIATION -->
  <div class="card">
    <div class="head"><h3>Votre lien d’affiliation</h3><div class="sub">Partagez ce lien — les achats seront rattachés à votre code.</div></div>
    <div class="body">
      <div class="aff-box">
        <span class="pill"><span class="k">Code :</span> <strong><?= h($apporteurCode) ?></strong></span>
        <span class="pill"><span class="k">Règle :</span> <strong><?= h($promoKind . ':' . (0 + $promoValue)) ?></strong></span>
        <a class="btn primary" target="_blank" rel="noopener" href="<?= h($affLink) ?>">Ouvrir le lien</a>
      </div>
      <div style="margin-top:10px">
        <div class="code"><?= h($affLink) ?></div>
        <p class="muted" style="margin:8px 0 0;font-size:12px">
          Destination : <code>mpf-global.com/loginap.php</code> — paramètres : <code>parrain=<?= h($apporteurCode) ?></code>, <code>discount=<?= h($discountParam) ?></code>
        </p>
      </div>
    </div>
  </div>

  <!-- KPIs -->
  <div class="kpis">
    <div class="kpi"><div class="lbl">Total investissements</div><div class="val"><?= euro0($totalInvest) ?></div></div>
    <div class="kpi"><div class="lbl">Clients actifs</div><div class="val"><?= (int)$totalClients ?></div></div>
    <div class="kpi"><div class="lbl">Commissions du mois</div><div class="val"><?= euro2(trunc2($commThisMonth)) ?></div></div>
    <div class="kpi"><div class="lbl">Prochain paiement</div><div class="val"><?= h((new DateTime('first day of next month', new DateTimeZone('Europe/Paris')))->format('d/m/Y')) ?></div></div>
  </div>

  <!-- TABS -->
  <div class="tabs" style="margin-bottom:12px">
    <a class="tab <?= $tab==='overview'?'active':'' ?>" href="?<?= http_build_query(array_merge($_GET, ['tab'=>'overview'])) ?>">Vue d’ensemble</a>
    <a class="tab <?= $tab==='clients'?'active':'' ?>" href="?<?= http_build_query(array_merge($_GET, ['tab'=>'clients'])) ?>">Clients</a>
    <a class="tab <?= $tab==='invests'?'active':'' ?>" href="?<?= http_build_query(array_merge($_GET, ['tab'=>'invests'])) ?>">Investissements</a>
    <a class="tab <?= $tab==='commissions'?'active':'' ?>" href="?<?= http_build_query(array_merge($_GET, ['tab'=>'commissions'])) ?>">Commissions</a>
    <a class="tab <?= $tab==='payouts'?'active':'' ?>" href="?<?= http_build_query(array_merge($_GET, ['tab'=>'payouts'])) ?>">Dossiers de paiement</a>
  </div>

  <!-- OVERVIEW -->
  <div id="tab-overview" class="<?= $tab==='overview'?'':'hidden' ?>">
    <div class="card">
      <div class="head"><h3>Commissions par mois</h3><div class="sub">Historique illimité, paiement le 01 de chaque mois.</div></div>
      <div class="body"><canvas id="chartCommissions" height="96"></canvas></div>
    </div>
  </div>

  <!-- CLIENTS -->
  <div id="tab-clients" class="<?= $tab==='clients'?'':'hidden' ?>">
    <div class="card">
      <div class="head"><h3>Liste des clients</h3><div class="sub">Cliquez sur “Détails” pour voir les contrats de chaque client.</div></div>
      <div class="body" style="overflow-x:auto;">
        <table>
          <thead><tr><th>Client</th><th>1ère souscription</th><th>Contrats</th><th>Montant cumulé</th><th>Apport total</th><th>Commissions totales</th><th></th></tr></thead>
          <tbody>
          <?php if (empty($clients)): ?>
            <tr><td colspan="7" class="muted" style="text-align:center;padding:16px">Aucun client trouvé.</td></tr>
          <?php else: foreach ($clients as $cl):
            $uid   = (int)$cl['id'];
            $first = $cl['first_subscription_date'] ? (new DateTime($cl['first_subscription_date']))->format('d/m/Y') : '—';
            $cid   = "contracts-of-{$uid}";
          ?>
            <tr>
              <td><strong><?= h($cl['client_name']) ?></strong></td>
              <td><?= h($first) ?></td>
              <td><?= (int)$cl['nb_contrats'] ?></td>
              <td><?= euro0($cl['total_invest']) ?></td>
              <td><?= euro2($cl['total_apport']) ?></td>
              <td><strong><?= euro2(trunc2($cl['total_commissions'])) ?></strong></td>
              <td><button class="btn" type="button" onclick="toggleRow('<?= h($cid) ?>')">Détails</button></td>
            </tr>
            <tr id="<?= h($cid) ?>" class="subrow hidden">
              <td colspan="7">
                <?php $list = $contractsByUser[$uid] ?? []; ?>
                <?php if (empty($list)): ?>
                  <div class="muted">Aucun contrat pour ce client.</div>
                <?php else: ?>
                <div style="overflow-x:auto;">
                  <table>
                    <thead>
                      <tr>
                        <th>Contrat</th><th>Date souscription</th><th>Montant</th><th>Apport</th><th>Commission (20%)</th><th>Type de paiement</th><th>Mensualités</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($list as $k): ?>
                      <tr>
                        <td><strong>#<?= (int)$k['id'] ?></strong></td>
                        <td><?= h((new DateTime($k['date_souscription']))->format('d/m/Y')) ?></td>
                        <td><?= euro0($k['montant']) ?></td>
                        <td><?= euro2($k['apport']) ?></td>
                        <td><strong><?= euro2(trunc2((float)$k['apport'] * 0.20)) ?></strong></td>
                        <td><?= badgeTypePaiement($k['type_paiement']) ?> <div class="muted" style="font-size:12px"><?= h(labelTypePaiement($k['type_paiement'])) ?></div></td>
                        <td>
                          <?php
                          $tp = strtolower((string)$k['type_paiement']);
                          if (in_array($tp, ['abonnement','12x','mensuel','subscription','monthly'], true)) {
                              echo '<strong>'.(int)($k['mensualites_payees'] ?? 0).'</strong> / 12';
                          } else {
                              echo '<span class="muted">—</span>';
                          }
                          ?>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- INVESTS -->
  <div id="tab-invests" class="<?= $tab==='invests'?'':'hidden' ?>">
    <div class="card">
      <div class="head"><h3>Investissements rattachés</h3><div class="sub">Avec modalité de paiement indiquée.</div></div>
      <div class="body" style="overflow-x:auto;">
        <table>
          <thead><tr><th>Contrat</th><th>Client</th><th>Date</th><th>Montant</th><th>Apport</th><th>Commission (20%)</th><th>Type de paiement</th><th>Mensualités</th></tr></thead>
          <tbody>
          <?php if (empty($investissements)): ?>
            <tr><td colspan="8" class="muted" style="text-align:center;padding:16px">Aucun investissement trouvé.</td></tr>
          <?php else: foreach ($investissements as $iv): ?>
            <tr>
              <td><strong>#<?= h($iv['contrat_id']) ?></strong></td>
              <td><?= h($iv['client_name']) ?></td>
              <td><?= h((new DateTime($iv['date_souscription']))->format('d/m/Y')) ?></td>
              <td><?= euro0($iv['montant']) ?></td>
              <td><?= euro2($iv['apport']) ?></td>
              <td><strong><?= euro2(trunc2($iv['commission'])) ?></strong></td>
              <td><?= badgeTypePaiement($iv['type_paiement']) ?> <div class="muted" style="font-size:12px"><?= h(labelTypePaiement($iv['type_paiement'])) ?></div></td>
              <td>
                <?php
                $tp = strtolower((string)$iv['type_paiement']);
                if (in_array($tp, ['abonnement','12x','mensuel','subscription','monthly'], true)) {
                    echo '<strong>'.(int)($iv['mensualites_payees'] ?? 0).'</strong> / 12';
                } else {
                    echo '<span class="muted">—</span>';
                }
                ?>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- COMMISSIONS -->
  <div id="tab-commissions" class="<?= $tab==='commissions'?'':'hidden' ?>">
    <div class="card">
      <div class="head"><h3>Historique des commissions</h3></div>
      <div class="body" style="overflow-x:auto;">
        <table>
          <thead><tr><th>Mois</th><th>Montant (estimé)</th><th>Statut</th></tr></thead>
          <tbody>
          <?php if (empty($commissions)): ?>
            <tr><td colspan="3" class="muted" style="text-align:center;padding:16px">Aucune commission trouvée.</td></tr>
          <?php else: foreach ($commissions as $c):
              $ym = $c['period_month']; $status = $mapVal[$ym]['status'] ?? 'en_attente'; ?>
            <tr>
              <td><strong><?= h(monthHumanFR($ym)) ?></strong></td>
              <td><?= euro2(trunc2($c['total_amount'])) ?></td>
              <td>
                <?php if ($status==='paye'): ?>
                  <span class="badge green">Payé</span>
                <?php elseif ($status==='valide'): ?>
                  <span class="badge blue">Validé</span>
                <?php else: ?>
                  <span class="badge">En attente</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- PAYOUTS -->
  <div id="tab-payouts" class="<?= $tab==='payouts'?'':'hidden' ?>">
    <div class="card">
      <div class="head">
        <h3>Dossier de paiement — <?= h(monthHumanFR($prevYm)) ?></h3>
        <div class="sub">Un dossier est créé automatiquement pour chaque mois terminé (N-1).</div>
      </div>
      <div class="body" style="overflow-x:auto;">
        <div class="row" style="justify-content:flex-end;margin-bottom:10px">
          <a class="btn" href="?action=export_payout_csv&ym=<?= h($prevYm) ?>">Exporter CSV</a>
        </div>
        <table>
          <thead>
            <tr>
              <th>Payé le</th><th>Client</th><th>Contrat</th><th>Montant payé</th>
              <th>Montant contrat</th><th>Type de paiement</th><th>Reçu Stripe</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($folderItems)): ?>
            <tr><td colspan="7" class="muted" style="text-align:center;padding:16px">Aucune transaction enregistrée pour <?= h(monthHumanFR($prevYm)) ?>.</td></tr>
          <?php else: foreach ($folderItems as $it): ?>
            <tr>
              <td><?= h($it['paid_at'] ? (new DateTime($it['paid_at']))->format('d/m/Y H:i') : '—') ?></td>
              <td><strong><?= h($it['client_name']) ?></strong> <span class="muted" style="font-size:12px">#<?= (int)$it['user_id'] ?></span></td>
              <td><?= $it['contrat_id'] ? ('#'.(int)$it['contrat_id']) : '<span class="muted">—</span>' ?></td>
              <td><?= euro2($it['paid_amount']) ?> <span class="muted" style="font-size:11px"><?= h(strtoupper($it['currency'] ?? 'EUR')) ?></span></td>
              <td><?= euro2($it['contract_amount']) ?></td>
              <td><?= h($it['payment_type'] ?: '—') ?></td>
              <td>
                <?php if (!empty($it['stripe_receipt_url'])): ?>
                  <a class="btn small" href="<?= h($it['stripe_receipt_url']) ?>" target="_blank" rel="noopener">Voir reçu</a>
                <?php else: ?>
                  <span class="muted">Non disponible</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

<script>
(function(){
  // tab init
  const current = new URL(location.href).searchParams.get('tab') || 'overview';
  document.querySelectorAll('[id^="tab-"]').forEach(el => {
    el.classList.toggle('hidden', el.id !== `tab-${current}`);
  });
})();
(function(){
  // chart
  const labels = <?= json_encode($chartLabels, JSON_UNESCAPED_UNICODE) ?>;
  const values = <?= json_encode($chartValues, JSON_UNESCAPED_UNICODE) ?>;
  const ctx = document.getElementById('chartCommissions');
  if (!ctx || values.length === 0) return;
  new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [{
      label: 'Commissions', data: values, tension:.35, fill:true,
      borderColor:'#2E7D32', backgroundColor:'rgba(76,175,80,.10)', borderWidth:2, pointRadius:2
    }]},
    options: {
      responsive:true,
      plugins:{ legend:{ display:false },
        tooltip:{ callbacks:{ label:(c)=> (Math.floor(c.parsed.y*100)/100).toLocaleString('fr-FR',{style:'currency',currency:'EUR'}) } } },
      scales:{ y:{ beginAtZero:true, ticks:{ callback:(v)=> (Math.floor(v*100)/100).toLocaleString('fr-FR',{style:'currency',currency:'EUR'}) } } }
    }
  });
})();
function toggleRow(id){
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle('hidden');
}
</script>
</body>
</html>

