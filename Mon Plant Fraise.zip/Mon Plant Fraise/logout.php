<?php
// On démarre la session pour pouvoir y accéder
session_start();

// On supprime toutes les variables de session
$_SESSION = [];

// On détruit la session
session_destroy();

// On redirige l'utilisateur vers la page de connexion
header('Location: login.php');
exit();
?>