<?php
// -----------------------------------------------------------------------------
// investclient.php — Investissement libre + Panier/Produits
// -----------------------------------------------------------------------------

// --- BLOC DE DÉBOGAGE (Désactivé pour la production) ---
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// 1) Session & Auth
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 2) CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 3) DB & Badge
require_once 'db_connection.php';
require_once 'badge_sentinel.php';

// ... (Le reste de votre code PHP initial reste identique jusqu'au HTML) ...

$crypto_rates = [];
try {
    $api_url = 'https://api.coingecko.com/api/v3/simple/price?ids=tether,usd-coin&vs_currencies=eur';
    $json_data = @file_get_contents($api_url);
    if ($json_data) {
        $rates = json_decode($json_data, true);
        $crypto_rates['USDT'] = $rates['tether']['eur'] ?? 0;
        $crypto_rates['USDC'] = $rates['usd-coin']['eur'] ?? 0;
    }
} catch (Exception $e) {
    error_log("Erreur API CoinGecko : " . $e->getMessage());
}

$prenom = $_SESSION['user_prenom'] ?? '';
$user_id = (int)($_SESSION['user_id'] ?? 0);

$crypto_wallets = [
    'USDT' => '0xf128fa3aa6da0e406250e131362100c2e6ccc84a',
    'USDC' => '0xf128fa3aa6da0e406250e131362100c2e6ccc84a'
];
$iban_mon_plant_fraise = 'FR76 1695 8000 0156 0179 2941 361';
$bic_mon_plant_fraise = 'QNTOFRP1XXX';
$banque_nom_adresse = 'QONTO (OLINDA SAS), 18 rue de Navarin 75009 Paris, France';
$nom_compte = 'Mon Plant Fraise';
$adresse_compte = '27 avenue de la tour de fer, 74490 St Jeoire';

$promo_codes_for_js = [];
$referral_codes_for_js = [];
try {
    $codes_stmt = $pdo->prepare("SELECT code, discount_percent, montant_reduction, cumulable FROM promo_codes WHERE is_active = 1 AND (usage_limit IS NULL OR usage_count < usage_limit) AND (starts_at IS NULL OR starts_at <= NOW()) AND (ends_at IS NULL OR ends_at >= NOW()) AND (user_id IS NULL OR user_id = :uid)");
    $codes_stmt->execute([':uid' => $user_id]);
    foreach ($codes_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $type = null; $val = 0;
        if (!empty($row['discount_percent'])) { $type = 'percent'; $val = (float)$row['discount_percent']; }
        elseif (!empty($row['montant_reduction'])) { $type = 'amount'; $val = (float)$row['montant_reduction']; }
        if ($type) { $promo_codes_for_js[strtoupper($row['code'])] = ['valid' => true, 'type' => $type, 'value' => $val, 'label' => htmlspecialchars($row['code']), 'stackable' => (bool)$row['cumulable']]; }
    }
    $refStmt = $pdo->query("SELECT DISTINCT UPPER(parrain) AS code FROM users WHERE parrain IS NOT NULL AND parrain <> ''");
    while ($r = $refStmt->fetch(PDO::FETCH_ASSOC)) {
        $code = strtoupper(trim($r['code']));
        $referral_codes_for_js[$code] = ['valid' => true, 'type' => 'none', 'value' => 0, 'label' => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'), 'stackable' => true];
    }
} catch (Throwable $e) { error_log("INVEST PROMO/REF LOAD ERROR: ".$e->getMessage()); }

$referral_prefill = '';
try {
    if ($user_id > 0) {
        $pref = $pdo->prepare("SELECT UPPER(parrain) AS code FROM users WHERE id = :uid LIMIT 1");
        $pref->execute([':uid' => $user_id]);
        $referral_prefill = (string)($pref->fetchColumn() ?: '');
    }
} catch (Throwable $e) { error_log('REFERRAL PREFILL (users.parrain) ERROR: '.$e->getMessage()); }

$available_products = [];
try {
    $products_sql = "SELECT id, name, descriptif, prix, duree_mois, taux, image_url, is_active, stock_restant, paiement_mensuel_disponible FROM produits WHERE is_active = 1 ORDER BY stock_restant DESC, name ASC";
    $products_stmt = $pdo->query($products_sql);
    $available_products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { error_log("INVEST PRODUCTS ERROR: ".$e->getMessage()); }

$free_invest = null;
try {
    $stmt = $pdo->prepare("SELECT id, name, image_url FROM produits WHERE is_active = 1 AND name = 'Investissement libre' LIMIT 1");
    $stmt->execute();
    $free_invest = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { error_log("INVEST CUSTOM PRODUCT ERROR: ".$e->getMessage()); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booster ma récolte - Mon Plant Fraise</title>
    <meta name="csrf-token" content="<?= htmlspecialchars($_SESSION['csrf_token']); ?>">
    
    <script src="https://js.stripe.com/v3/"></script> <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <style>
        *, *::before, *::after { box-sizing: border-box; }
        :root{
            --primary-color:#2E7D32; --primary-color-dark:#1B5E20;
            --primary-gradient:linear-gradient(135deg,#4CAF50,#2E7D32);
            --text-color:#212121; --text-color-light:#757575;
            --background-color:#F4F6F8; --card-background-color:#FAFAFA;
            --border-radius:12px; --box-shadow:0 4px 12px rgba(0,0,0,.08);
            --warning:#d32f2f; --card-h: 540px; --img-h: 200px;
        }
        body{background-color:var(--background-color);font-family:'Roboto',Arial,sans-serif;margin:0;display:flex;color:var(--text-color);}
        
        /* --- CSS DU MENU CORRIGÉ (identique à espace-client.php) --- */
        .sidebar{background-color:var(--card-background-color);width:260px;height:100vh;padding:20px;position:fixed;top:0;left:0;box-shadow:0 2px 10px rgba(0,0,0,.1);display:flex;flex-direction:column;z-index:1000;transition:transform 0.3s ease-in-out;}
        .sidebar-header{margin-bottom:30px;text-align:center;}
        .sidebar-header a img{max-width:80%;height:auto;}
        .sidebar ul{list-style:none;padding:0;margin:0;}
        .sidebar ul li a{display:flex;align-items:center;padding:12px 10px;margin-bottom:8px;text-decoration:none;color:var(--text-color-light);border-radius:var(--border-radius);font-weight:500;transition:background-color .2s ease,color .2s ease;}
        .sidebar ul li a .material-symbols-outlined{margin-right:15px;font-size:22px;}
        .sidebar ul li a:hover{background-color:#eee;}
        .sidebar ul li a[href="investclient.php"]{background-color:var(--primary-color);color:#fff;}
        .toggle-btn { display: none; }
        
        .container{margin-left:260px;padding:30px;width:calc(100% - 260px);}
        
        @media (max-width: 900px){
            .sidebar{transform:translateX(-100%);}
            .sidebar.open {transform: translateX(0);}
            .container{margin-left:0;width:100%;padding:16px;}
            .toggle-btn { display: flex; align-items: center; justify-content: center; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size:24px; }
            .main-header{padding-top:60px;}
            .row{grid-template-columns:1fr;}
            .alloc-grid{grid-template-columns:1fr;}
        }
        /* --- FIN DU CSS DU MENU --- */

        .main-header{font-family:'Poppins',sans-serif;font-size:28px;font-weight:700;margin:0 0 6px;}
        .subheader{color:var(--text-color-light);margin-bottom:18px;}
        .toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:10px;}
        .product-filters{display:flex;flex-wrap:wrap;gap:10px;margin:6px 0 22px;}
        .product-filters button{padding:10px 18px;border-radius:20px;border:1px solid #ddd;background:var(--card-background-color);color:var(--text-color-light);cursor:pointer;font-weight:500;}
        .product-filters button.active{background:var(--primary-gradient);color:#fff;border-color:transparent;box-shadow:0 2px 8px rgba(46,125,50,.3);}
        .products-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:22px;align-items:stretch;}
        .card{background:var(--card-background-color);box-shadow:var(--box-shadow);border-radius:var(--border-radius);display:flex;flex-direction:column;overflow:hidden;transition:transform .2s ease, box-shadow .2s ease;position:relative;height:var(--card-h);}
        .card:hover{transform:translateY(-5px);box-shadow:0 8px 16px rgba(0,0,0,.1);}
        .card-image{width:100%;height:var(--img-h);object-fit:cover;flex:0 0 auto;aspect-ratio:auto;}
        .card-content{padding:18px;display:flex;flex-direction:column;gap:10px;flex:1 1 auto;}
        .card h3{margin:0 0 6px 0;font-size:20px;font-family:'Poppins';min-height:2.6em;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
        .desc{font-size:14px;color:var(--text-color-light);line-height:1.4;min-height:calc(1.4em * 3);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;}
        .stats{display:flex;gap:16px;justify-content:space-between;border-top:1px solid #eee;padding-top:10px;min-height:56px;align-items:center;}
        .stat b{display:block;color:var(--text-color);font-size:16px;}
        .price{font-family:'Poppins';font-size:22px;font-weight:700;color:#2E7D32;}
        .stock{font-size:12px;color:var(--text-color-light);text-align:right;margin-top:4px;min-height:18px;}
        .btn{display:inline-flex;justify-content:center;align-items:center;padding:10px 16px;border-radius:10px;border:1px solid transparent;background:var(--primary-gradient);color:#fff;font-weight:700;cursor:pointer;text-decoration:none;}
        .btn:disabled{background:#bdbdbd;cursor:not-allowed;}
        .btn-outline{background:#fff;color:#2E7D32;border:1px solid #A5D6A7;}
        .actions-area{margin-top:auto !important;}
        .readonly{background:#f5f5f5;color:#666;cursor:not-allowed;}
        .popup-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);display:none;justify-content:center;align-items:center;z-index:2000;}
        .popup{background:#fff;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.25);width:min(970px,95vw);max-height:90vh;overflow:auto;padding:18px 18px 22px;}
        .popup h2{font-family:'Poppins';margin:0 0 6px 0;color:#2E7D32;}
        .popup .subtitle{color:#666;margin-bottom:12px;}
        .calc-panel{margin-top:12px;padding:14px;border:1px solid #eee;border-radius:8px;background:#fafafa;}
        .calc-panel h4{margin:0 0 8px 0;font-family:'Poppins';}
        .row{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
        .field{margin-top:10px;}
        .field label{display:block;font-size:14px;margin-bottom:4px;color:#333;}
        .field input[type="text"], .field input[type="number"]{width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;}
        .muted{color:#666;font-size:12px;margin-top:6px;line-height:1.35;}
        .payment-toggle{display:flex;gap:10px;justify-content:center;margin-top:6px;}
        .payment-btn{padding:10px 14px;border-radius:999px;border:1px solid #ddd;background:#fff;font-weight:700;cursor:pointer;min-width:200px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);}
        .payment-btn.active{background:var(--primary-gradient);color:#fff;border-color:transparent;box-shadow:0 8px 18px rgba(46,125,50,.35);}
        .totals{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px;}
        .box{background:#f7f7f7;border-radius:8px;padding:10px;text-align:center;}
        .box small{display:block;color:#888;}
        .box strong{font-size:20px;color:#2E7D32;}
        .actions{display:flex;gap:10px;justify-content:flex-end;margin-top:16px;}
        .crypto-divider{display:flex;align-items:center;gap:10px;margin:18px 0;}
        .crypto-divider span{color:#666;font-weight:700;}
        .crypto-divider hr{flex:1;border:none;border-top:1px solid #e5e5e5;}
        .crypto-choices{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;}
        .crypto-btn{padding:10px 14px;border-radius:12px;border:1px solid #ddd;background:#fff;font-weight:700;cursor:pointer;min-width:120px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06);}
        .crypto-btn.active{background:#1f2937;color:#fff;border-color:#1f2937;box-shadow:0 8px 18px rgba(0,0,0,.25);}
        .crypto-address{display:none;margin-top:10px;padding:12px;border:1px dashed #bbb;border-radius:10px;background:#fff;}
        .crypto-address .row{grid-template-columns:1fr auto;}
        .crypto-address code{word-break:break-all;font-size:13px;background:#f7f7f7;border-radius:6px;padding:6px 8px;display:block;}
        .copy-btn{padding:8px 10px;border-radius:8px;border:1px solid #ddd;background:#fff;cursor:pointer;}
        .crypto-check{margin-top:8px;display:flex;align-items:center;gap:8px;color:#333;}
        .crypto-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:12px;}
        .alloc-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;}
        .product-list,.cart{border:1px solid #eee;border-radius:8px;padding:10px;max-height:330px;overflow:auto;background:#fff;}
        .prod-row{display:flex;justify-content:space-between;align-items:center;padding:8px 6px;border-bottom:1px solid #f3f3f3;}
        .prod-row:last-child{border-bottom:none;}
        .qty-box{display:inline-flex;gap:6px;align-items:center;}
        .qty-btn{width:26px;height:26px;border:1px solid #ccc;background:#f7f7f7;border-radius:6px;cursor:pointer;}
        .cart-row{display:flex;justify-content:space-between;align-items:center;padding:8px 6px;border-bottom:1px solid #f3f3f3;}
        .cart-row:last-child{border-bottom:none;}
        @supports not (object-fit: cover) { .card-image{ height: var(--img-h); } }

        /* --- CSS Panier flottant --- */
        .floating-cart {
            position: fixed;
            bottom: 90px;
            right: 30px;
            background: var(--primary-gradient);
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 5px 15px rgba(0,0,0,0.25);
            z-index: 999;
            transition: transform 0.2s ease-in-out, opacity 0.2s ease-in-out;
            opacity: 1;
        }
        .floating-cart:hover {
            transform: scale(1.1);
        }
        .floating-cart .material-symbols-outlined {
            font-size: 28px;
        }
        .cart-item-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--warning);
            color: white;
            font-size: 12px;
            font-weight: bold;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 2px solid white;
        }

        /* --- CSS Responsif pour les Popups --- */
        @media (max-width: 768px) {
            .popup {
                width: 95vw;
                padding: 16px;
                max-height: 95vh;
            }
            .popup .row,
            .popup .alloc-grid,
            .popup .totals {
                grid-template-columns: 1fr;
            }
            .payment-toggle {
                flex-direction: column;
                gap: 8px;
            }
            .payment-btn {
                min-width: unset;
                width: 100%;
            }
            .actions, .crypto-actions {
                flex-direction: column;
                gap: 8px;
            }
            .actions .btn, .actions form, .crypto-actions .btn, .crypto-actions form {
                width: 100%;
                margin: 0;
            }
            .actions form .btn, .crypto-actions form .btn {
                width: 100%;
            }
            .crypto-address .row {
                grid-template-columns: 1fr;
                gap: 8px;
            }
            .crypto-address .row > div:last-child {
                justify-content: flex-start;
            }
            .alloc-grid {
                gap: 12px;
            }
            .product-list, .cart {
                max-height: 250px; /* Hauteur ajustée pour mobile */
            }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Bonjour <?= htmlspecialchars($prenom) ?> 👋</h1>
    <div class="subheader">Investissez un montant libre ou ajoutez des plants à votre panier. Aucun rendement n’est garanti.</div>

    <div class="toolbar">
        <div id="product-filters" class="product-filters">
            <button type="button" data-filter="all">Tous les plants</button>
            <button type="button" class="active" data-filter="instock">Disponibles</button>
            <button type="button" data-filter="outofstock">Épuisés</button>
        </div>
    </div>

    <div class="products-grid" id="grid">
        <?php if (!empty($free_invest)): ?>
            <div class="card" data-id="<?= (int)$free_invest['id']; ?>" data-custom="1">
                <img src="<?= htmlspecialchars($free_invest['image_url'] ?? '/images/invest-libre.jpg'); ?>" class="card-image" alt="Investissement libre">
                <div class="card-content">
                    <h3>Investissement libre</h3>
                    <div class="desc">
                        Choisissez un montant libre. Le taux objectif est fixé à 40% (environ).
                        Les plants et variétés seront sélectionnés pour vous par Mon Plant Fraise.
                        Durée indicative : 12 mois.
                    </div>
                    <div class="stats">
                        <div class="stat"><small>12x</small><b>Disponible</b></div>
                        <div class="stat"><small>Montant</small><b>Libre</b></div>
                        <div class="stat"><small>Taux Moyen</small><b>40%</b></div>
                    </div>
                    <div class="actions-area">
                        <button type="button" class="btn btn-outline btn-custom-open">
                            <span class="material-symbols-outlined" style="margin-right:6px;">savings</span>
                            Choisir mon montant
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if (empty($available_products)): ?>
            <p>Aucun produit n'est disponible pour le moment.</p>
        <?php else: ?>
            <?php foreach ($available_products as $p): ?>
                <?php
                    $oos = ((int)$p['stock_restant'] <= 0);
                    $prix = (float)($p['prix'] ?? 0);
                    $pay12 = !empty($p['paiement_mensuel_disponible']);
                    $isFree = (isset($free_invest['id']) && (int)$free_invest['id'] === (int)$p['id']);
                    if ($isFree) continue; // Skip rendering 'Investissement Libre' here if it's in the products list
                ?>
                <div class="card <?= $oos ? 'out-of-stock':''; ?>"
                     data-id="<?= (int)$p['id']; ?>"
                     data-name="<?= htmlspecialchars($p['name']); ?>"
                     data-price="<?= number_format($prix, 2, '.', ''); ?>"
                     data-stock="<?= (int)$p['stock_restant']; ?>"
                     data-12x="<?= $pay12 ? '1':'0'; ?>">
                    <?php if ($oos): ?><div class="overlay-oos" style="position:absolute;inset:0;background:rgba(0,0,0,.45);color:#fff;display:flex;align-items:center;justify-content:center;font-family:'Poppins';font-size:28px;font-weight:800;">ÉPUISÉ</div><?php endif; ?>
                    <img src="<?= htmlspecialchars($p['image_url'] ?? ''); ?>" class="card-image" alt="<?= htmlspecialchars($p['name']); ?>">
                    <div class="card-content">
                        <h3><?= htmlspecialchars($p['name']); ?></h3>
                        <div class="desc"><?= nl2br(htmlspecialchars($p['descriptif'] ?? '')); ?></div>
                        <div class="stats">
                            <div class="stat"><small>Durée</small><b><?= (int)$p['duree_mois']; ?> mois</b></div>
                            <div class="stat"><small>Taux moyen</small><b><?= number_format((float)$p['taux'], 2, ',', ' '); ?> %</b></div>
                            <div class="stat"><small>Prix</small><b class="price"><?= number_format($prix, 2, ',', ' '); ?> €</b></div>
                        </div>
                        <div class="stock">Stock : <?= (int)$p['stock_restant']; ?> restant(s)</div>
                        <div class="actions-area">
                            <button type="button" class="btn btn-add" <?= $oos ? 'disabled':''; ?>>Ajouter au panier</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<div class="popup-overlay" id="popup-overlay">
    <div class="popup">
        <h2>Votre investissement</h2>
        <div class="subtitle">Saisissez un montant libre, appliquez vos codes (si éligibles), choisissez le paiement puis validez. Durée indicative : 12 mois.</div>
        <div class="calc-panel" id="custom-invest-panel">
            <h4>Investissement libre</h4>
            <div class="row">
                <div class="field">
                    <label for="custom-amount">Montant (en €)</label>
                    <input type="number" id="custom-amount" min="1" step="1" placeholder="Ex : 1000" inputmode="decimal" />
                </div>
                <div class="field">
                    <label for="custom-rate">Taux objectif (%) <span class="muted">(fixe, environ)</span></label>
                    <input type="number" id="custom-rate" min="40" max="40" step="1" value="40" readonly class="readonly" />
                    <small class="muted">Le taux est fixé à 40% pour les investissements libres.</small>
                </div>
            </div>
            <div class="totals" style="margin-top: 10px;">
                <div class="box">
                    <small>Montant saisi</small>
                    <strong id="custom-amount-view">0,00 €</strong>
                </div>
                <div class="box">
                    <small>Valeur investie (bonus inclus)</small>
                    <strong id="custom-invested-value">0,00 €</strong>
                </div>
            </div>
            <div class="totals" style="margin-top: 10px;">
                <div class="box">
                    <small>Projection indic. (non garantie)</small>
                    <strong id="custom-projection">—</strong>
                </div>
            </div>
            <div class="field" style="margin-top: 8px;">
                <label>
                    <input type="checkbox" id="custom-accept" />
                    J’accepte que <strong>les plants et variétés soient sélectionnés pour moi par Mon Plant Fraise</strong> et je comprends qu’<strong>il n’y a aucune garantie de rendement</strong>.
                </label>
            </div>
        </div>
        <div class="calc-panel">
            <div class="field">
                <label for="promo-code-input">Code promo <span id="promo-status-icon"></span></label>
                <input type="text" id="promo-code-input" placeholder="EX: BIENVENUE20" style="text-transform: uppercase;" />
                <small id="promo-feedback" class="form-feedback"></small>
            </div>
            <div class="field">
                <label for="referral-code-input">Code parrain <span id="referral-status-icon"></span></label>
                <input type="text" id="referral-code-input" value="<?= htmlspecialchars($referral_prefill) ?>" readonly class="readonly" style="text-transform: uppercase;" />
                <small id="referral-feedback" class="form-feedback"></small>
            </div>
            <div class="field" style="margin-top: 8px;">
                <label>Mode de paiement (carte)</label>
                <div class="payment-toggle" id="payment-toggle">
                    <button type="button" class="payment-btn" data-value="full" aria-pressed="true">Paiement comptant</button>
                    <button type="button" class="payment-btn" data-value="12x" aria-pressed="false" id="btn-12x">12 mensualités</button>
                </div>
            </div>
            <div class="totals" style="margin-top: 10px;">
                <div class="box">
                    <small>À régler aujourd’hui</small>
                    <strong id="pay-now">0,00 €</strong>
                </div>
                <div class="box">
                    <small>Si 12 mensualités</small>
                    <strong id="monthly-12x">0,00 € / mois</strong>
                </div>
            </div>
        </div>
        <div class="actions">
            <button class="btn btn-outline" id="close-popup" type="button">Fermer</button>
            <button class="btn btn-outline" id="open-crypto-popup" type="button" style="background: #fff; color: #1f2937; border: 1px solid #cbd5e1;">
                Payer en cryptomonnaie
            </button>
            <button class="btn btn-outline" id="show-virement-free" type="button">
                Payer par virement
            </button>
            <form id="checkout-form" action="create-checkout-session.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>" />
                <input type="hidden" name="payment_plan" id="payment-plan" value="full" />
                <input type="hidden" name="promo_code" id="hidden-promo" value="" />
                <input type="hidden" name="referral_code" id="hidden-referral" value="<?= htmlspecialchars($referral_prefill) ?>" />
                <input type="hidden" name="top_up_after_discount" id="hidden-topup" value="0" />
                <input type="hidden" name="monthly_12x" id="hidden-monthly" value="0" />
                <input type="hidden" name="custom_amount" id="hidden-custom-amount" value="0" />
                <input type="hidden" name="custom_rate" id="hidden-custom-rate" value="40" />
                <input type="hidden" name="custom_accept" id="hidden-custom-accept" value="0" />
                <?php if (!empty($free_invest)): ?>
                <input type="hidden" name="new_products[0][id]" value="<?= (int)$free_invest['id'] ?>" />
                <input type="hidden" name="new_products[0][quantity]" value="1" />
                <?php endif; ?>
                <button class="btn" type="submit" id="checkout-submit" disabled>Je confirme et je paie</button>
            </form>
        </div>
    </div>
</div>

<div class="popup-overlay" id="popup-virement" style="display: none;">
    <div class="popup">
        <h2>Paiement par virement bancaire</h2>
        <div id="virement-details-free" style="margin-top: 15px; padding: 15px; border: 1px dashed #2e7d32; border-radius: 8px; background-color: #f8fbf8;">
            <p>Veuillez effectuer le virement vers le compte suivant en utilisant votre numéro de commande (qui sera généré après validation) comme référence de paiement.</p>
            <div style="background: #fff; padding: 10px; border-radius: 6px; margin-bottom: 12px;">
                <strong>IBAN :</strong> <code><?= htmlspecialchars($iban_mon_plant_fraise); ?></code><br />
                <strong>BIC :</strong> <code><?= htmlspecialchars($bic_mon_plant_fraise); ?></code><br />
                <strong>Banque :</strong> QONTO (OLINDA SAS), 18 rue de Navarin 75009 Paris, France<br />
                <strong>Nom du compte :</strong> Mon Plant Fraise<br />
                <strong>Adresse du compte :</strong> 27 avenue de la tour de fer, 74490 St Jeoire
            </div>
            <label style="display: flex; align-items: flex-start; gap: 8px; font-size: 14px; color: #333;">
                <input type="checkbox" id="virement-accept-free" style="margin-top: 2px;" />
                <span>Je comprends que si sous 72h ouvrés mes fonds ne sont pas réceptionnés par la société, mon contrat souscrit ce jour sera résilié.</span>
            </label>
            <div class="actions" style="margin-top: 15px;">
                <button class="btn btn-outline" id="back-to-payment-choice-free" type="button">Retour</button>
                <form id="virement-form-free" action="create-checkout-session.php" method="POST" style="margin: 0;"></form>
    <input type="hidden" name="is_manual_payment" value="1">
</form>
            </div>
        </div>
    </div>
</div>

<div class="popup-overlay" id="popup-crypto" style="display: none;">
    <div class="popup">
        <h2>Paiement en cryptomonnaie</h2>
        <div class="subtitle">Choisissez votre crypto, copiez l’adresse, envoyez le montant puis validez votre commande.</div>
        <div class="calc-panel">
            <div class="totals" style="margin-top: 0;">
                <div class="box">
                    <small>Montant saisi</small>
                    <strong id="crypto-amount-view">0,00 €</strong>
                </div>
                <div class="box">
                    <small>Valeur investie (bonus inclus)</small>
                    <strong id="crypto-invested-view">0,00 €</strong>
                </div>
            </div>
            <small class="muted">Les codes promo influent sur le <em>à payer</em> en carte. En crypto, envoyez le montant total que vous avez saisi.</small>
        </div>
        <div class="calc-panel" id="crypto-panel">
            <div class="crypto-choices" id="crypto-choices">
                <button type="button" class="crypto-btn" data-coin="USDT">Tether (USDT - ERC20)</button>
                <button type="button" class="crypto-btn" data-coin="USDC">USD Coin (USDC - ERC20)</button>
            </div>
            <div id="crypto-amount-to-send-wrapper" style="display: none; text-align: center; margin-top: 20px;">
                <div style="font-weight: bold; font-size: 1.1em; color: #333;">Montant à envoyer :</div>
                <div id="crypto-amount-to-send" style="font-size: 1.5em; color: var(--primary-color); font-weight: bold; margin-top: 5px;"></div>
                <small class="muted">Ce montant inclut une majoration pour couvrir les frais de réseau et de traitement.</small>
            </div>
            <div class="crypto-address" id="crypto-address-box">
                <div class="row">
                    <div>
                        <div style="font-weight: 700; margin-bottom: 6px;">Adresse <span id="crypto-coin-label"></span> de Mon Plant Fraise</div>
                        <code id="crypto-address-code"></code>
                        <small class="muted"
                            >Envoyez exactement le montant saisi dans la popup précédente. La projection reste basée sur la valeur investie (bonus inclus si code parrain MPF102569).</small
                        >
                    </div>
                    <div style="display: flex; align-items: flex-start;">
                        <button class="copy-btn" id="copy-crypto-address" type="button">Copier</button>
                    </div>
                </div>
                <label class="crypto-check">
                    <input type="checkbox" id="crypto-sent-check" />
                    J’ai bien envoyé le paiement à cette adresse.
                </label>
            </div>
        </div>
        <div class="crypto-actions">
            <button class="btn btn-outline" id="close-popup-crypto" type="button">Retour</button>
            <form id="crypto-form" action="create-checkout-session.php" method="POST">
                <input type="hidden" name="is_manual_payment" value="1">                 <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>" />
    <input type="hidden" name="is_manual_payment" value="1">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>" />
                <input type="hidden" name="payment_method" value="crypto" />
                <input type="hidden" name="crypto_coin" id="crypto-coin-field" value="" />
                <input type="hidden" name="crypto_address" id="crypto-address-field" value="" />
                <?php if (!empty($free_invest)): ?>
                <input type="hidden" name="new_products[0][id]" value="<?= (int)$free_invest['id'] ?>" />
                <input type="hidden" name="new_products[0][quantity]" value="1" />
                <?php endif; ?>
                <input type="hidden" name="custom_amount" id="crypto-custom-amount" value="0" />
                <input type="hidden" name="custom_rate" value="40" />
                <input type="hidden" name="custom_accept" id="crypto-custom-accept" value="0" />
                <input type="hidden" name="promo_code" id="crypto-hidden-promo" value="" />
                <input type="hidden" name="referral_code" id="crypto-hidden-referral" value="<?= htmlspecialchars($referral_prefill) ?>" />
                <input type="hidden" name="payment_plan" id="crypto-payment-plan" value="full" />
                <input type="hidden" name="monthly_12x" id="crypto-monthly-12x" value="0" />
                <input type="hidden" name="note" value="Paiement crypto manuel — adresse affichée et confirmée côté client." />
                <button class="btn" id="crypto-submit" type="submit" disabled>Je valide ma commande</button>
            </form>
        </div>
    </div>
</div>

<div class="popup-overlay" id="popup-cart" style="display: none;">
    <div class="popup">
        <h2>Votre panier</h2>
        <div class="subtitle">Ajustez les quantités, ajoutez vos codes, choisissez votre mode de paiement puis validez.</div>
        <div class="alloc-grid">
            <div>
                <h3 style="margin: 6px 0;">Produits</h3>
                <div class="product-list" id="product-list"></div>
            </div>
            <div>
                <h3 style="margin: 6px 0;">Panier</h3>
                <div class="cart" id="cart">
                    <p id="cart-empty" style="color: #999; text-align: center; margin: 8px 0;">Votre panier est vide.</p>
                </div>
                <div class="totals">
                    <div class="box">
                        <small>Total avant remises</small>
                        <strong id="gross-total">0,00 €</strong>
                    </div>
                    <div class="box">
                        <small>Total remises</small>
                        <strong id="discount-total">0,00 €</strong>
                    </div>
                </div>
                <div class="calc-panel">
                    <div class="field">
                        <label for="promo-code-input-cart">Code promo <span id="promo-status-icon-cart"></span></label>
                        <input type="text" id="promo-code-input-cart" placeholder="EX: BIENVENUE20" style="text-transform: uppercase;" />
                        <small id="promo-feedback-cart" class="form-feedback"></small>
                    </div>
                    <div class="field">
                        <label for="referral-code-input-cart">Code parrain <span id="referral-status-icon-cart"></span></label>
                        <input type="text" id="referral-code-input-cart" value="<?= htmlspecialchars($referral_prefill) ?>" readonly class="readonly" style="text-transform: uppercase;" />
                        <small id="referral-feedback-cart" class="form-feedback"></small>
                    </div>
                    <div class="field" style="margin-top: 8px;">
                        <label>Mode de paiement</label>
                        <div class="payment-toggle" id="payment-toggle-cart">
                            <button type="button" class="payment-btn" data-value="full" aria-pressed="true">Paiement comptant</button>
                            <button type="button" class="payment-btn" data-value="12x" aria-pressed="false" id="btn-12x-cart">12 mensualités</button>
                        </div>
                        <small id="plan-warning-cart" style="display: none; color: #d32f2f;">Le 12x n’est pas disponible pour au moins un produit de votre panier.</small>
                    </div>
                    <div class="totals" style="margin-top: 10px;">
                        <div class="box">
                            <small>À régler aujourd’hui</small>
                            <strong id="pay-now-cart">0,00 €</strong>
                        </div>
                        <div class="box">
                            <small>Si 12 mensualités</small>
                            <strong id="monthly-12x-cart">0,00 € / mois</strong>
                        </div>
                    </div>
                </div>
                <div class="actions">
                    <button class="btn btn-outline" id="close-popup-cart" type="button">Fermer</button>
                    <button class="btn btn-outline" id="show-virement-cart" type="button">
                        Payer par virement
                    </button>
                    <form id="checkout-form-cart" action="create-checkout-session.php" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>" />
                        <input type="hidden" name="payment_plan" id="payment-plan-cart" value="full" />
                        <input type="hidden" name="promo_code" id="hidden-promo-cart" value="" />
                        <input type="hidden" name="referral_code" id="hidden-referral-cart" value="<?= htmlspecialchars($referral_prefill) ?>" />
                        <input type="hidden" name="top_up_after_discount" id="hidden-topup-cart" value="0" />
                        <input type="hidden" name="monthly_12x" id="hidden-monthly-cart" value="0" />
                        <div id="hidden-products"></div>
                        <button class="btn" type="submit" id="checkout-submit-cart" disabled>Je confirme et je paie</button>
                    </form>
                </div>
                <div id="virement-details-cart" style="display: none; margin-top: 15px; padding: 15px; border: 1px dashed #2e7d32; border-radius: 8px; background-color: #f8fbf8;">
                    <h4>Paiement par virement bancaire</h4>
                    <p>Veuillez effectuer le virement vers le compte suivant en utilisant votre numéro de commande (qui sera généré après validation) comme référence de paiement.</p>
                    <div style="background: #fff; padding: 10px; border-radius: 6px; margin-bottom: 12px;">
                        <strong>IBAN :</strong> <code><?= htmlspecialchars($iban_mon_plant_fraise); ?></code><br />
                        <strong>BIC :</strong> <code><?= htmlspecialchars($bic_mon_plant_fraise); ?></code><br />
                        <strong>Banque :</strong> QONTO (OLINDA SAS), 18 rue de Navarin 75009 Paris, France<br />
                        <strong>Nom du compte :</strong> Mon Plant Fraise<br />
                        <strong>Adresse du compte :</strong> 27 avenue de la tour de fer, 74490 St Jeoire
                    </div>
                    <label style="display: flex; align-items: flex-start; gap: 8px; font-size: 14px; color: #333;">
                        <input type="checkbox" id="virement-accept-cart" style="margin-top: 2px;" />
                        <span>Je comprends que si sous 72h ouvrés mes fonds ne sont pas réceptionnés par la société, mon contrat souscrit ce jour sera résilié.</span>
                    </label>
                    <div class="actions" style="margin-top: 15px;">
                        <button class="btn btn-outline" id="back-to-payment-choice-cart" type="button">Retour</button>
                        <form id="virement-form-cart" action="create-checkout-session.php" method="POST" style="margin: 0;"></form>
    <input type="hidden" name="is_manual_payment" value="1">
</form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="floating-cart" class="floating-cart" style="display: none;">
    <span class="material-symbols-outlined">shopping_cart</span>
    <span id="cart-item-count" class="cart-item-count">0</span>
</div>

<button id="scrollTopBtn" title="Haut de page" style="position: fixed; bottom: 20px; right: 30px; border: none; background: #2e7d32; color: #fff; cursor: pointer; padding: 10px; border-radius: 50%; width: 50px; height: 50px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); display: none; align-items: center; justify-content: center;">
    <span class="material-symbols-outlined" style="font-size: 2rem;">expand_less</span>
</button>

<script>
    /* ===========================
    Initialisation Stripe
    =========================== */
    // !! REMPLACEZ CI-DESSOUS PAR VOTRE VRAIE CLÉ PUBLIQUE STRIPE !!
    const stripe = Stripe('pk_live_51PDuReFqpvBWmr4W62leB8lDWPsuvo1tOApDh9WTLY0tkYzzbWLYGqSyaAJx2yHZ4JbzFds4DipK7H9DVTZPQckL00gKu6kipN');

    /* ===========================
    Données serveur -> front
    =========================== */
    const serverCodes = <?= json_encode($promo_codes_for_js); ?>;
    const referralCodes = <?= json_encode($referral_codes_for_js); ?>;
    const FREE_INVEST_ID = <?= isset($free_invest['id']) ? (int)$free_invest['id'] : 0 ?>;
    const REFERRAL_PREFILL = '<?= addslashes(strtoupper($referral_prefill)) ?>';
    const CRYPTO_WALLETS = <?= json_encode($crypto_wallets, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
    const CRYPTO_RATES = <?= json_encode($crypto_rates); ?>;

    const catalogue = <?= json_encode(array_map(function($p){
        return [
            'id'    => (int)$p['id'],
            'name'  => $p['name'],
            'price' => (float)$p['prix'],
            'stock' => (int)$p['stock_restant'],
            'm12'   => (int)!empty($p['paiement_mensuel_disponible']),
        ];
    }, $available_products)); ?>;

    /* ===========================
    État commun
    =========================== */
    let currentPlan = 'full'; // 'full' | '12x'
    let currentPayMethod = 'card'; // 'card' | 'crypto' (uniquement pour Invest libre)
    let codeInfo = { promo: null, referral: null };
    let customInv = { amount: 0, desiredRate: 40, accepted: false };
    let cryptoState = { coin: '', address: '', copied: false, sent: false };

    /* ===========================
    PANIER (état + helpers)
    =========================== */
    let cart = []; // {id, name, qty}
    function findProduct(id) {
        return catalogue.find(p => p.id === id);
    }

    function updateFloatingCart() {
        const fab = document.getElementById('floating-cart');
        const badge = document.getElementById('cart-item-count');
        if (!fab || !badge) return;

        const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);

        if (totalItems > 0) {
            badge.textContent = totalItems;
            fab.style.display = 'flex';
        } else {
            fab.style.display = 'none';
        }
    }

    function upsertCart(id, delta) {
        const p = findProduct(id);
        if (!p) return;
        let it = cart.find(x => x.id === id);
        if (!it) {
            if (delta > 0) cart.push({ id: id, name: p.name, qty: 1 });
        } else {
            it.qty += delta;
            if (it.qty <= 0) cart = cart.filter(x => x.id !== id);
        }
        it = cart.find(x => x.id === id);
        if (it && it.qty > p.stock) {
            it.qty = p.stock;
        }
        renderCart();
    }
    function setQty(id, qty) {
        const p = findProduct(id);
        if (!p) return;
        qty = Math.max(0, Math.min(p.stock, parseInt(qty || 0, 10)));
        const it = cart.find(x => x.id === id);
        if (!it && qty > 0) cart.push({ id: id, name: p.name, qty });
        else if (it) {
            it.qty = qty;
            if (it.qty <= 0) cart = cart.filter(x => x.id !== id);
        }
        renderCart();
    }
    function cartAllows12x() {
        if (cart.length === 0) return true;
        return cart.every(it => {
            const p = findProduct(it.id);
            return p && p.m12 === 1;
        });
    }
    function buildHiddenProducts() {
        const holder = document.getElementById('hidden-products');
        if (!holder) return;
        holder.innerHTML = '';
        cart.forEach((it, idx) => {
            holder.insertAdjacentHTML('beforeend', `
    <input type="hidden" name="new_products[${idx}][id]" value="${it.id}">
    <input type="hidden" name="new_products[${idx}][quantity]" value="${it.qty}">
    `);
        });
    }
    function renderCatalogueList() {
        const list = document.getElementById('product-list');
        if (!list) return;
        list.innerHTML = '';
        catalogue.forEach(p => {
            if (p.id === FREE_INVEST_ID) return;
            const row = document.createElement('div');
            row.className = 'prod-row';
            row.innerHTML = `
    <div>
        <div><strong>${p.name}</strong></div>
        <small>${fmt(p.price)} — Stock: ${p.stock} — ${p.m12 ? '12x OK' : '12x non dispo'}</small>
    </div>
    <div class="qty-box">
        <button type="button" class="qty-btn" data-add="${p.id}">Ajouter</button>
    </div>
    `;
            list.appendChild(row);
        });
    }
    function renderCart() {
        const cartEl = document.getElementById('cart');
        const emptyEl = document.getElementById('cart-empty');
        if (!cartEl) return;

        Array.from(cartEl.querySelectorAll('.cart-row')).forEach(n => n.remove());
        if (cart.length === 0) {
            if (emptyEl) emptyEl.style.display = 'block';
        } else {
            if (emptyEl) emptyEl.style.display = 'none';
            cart.forEach(item => {
                const p = findProduct(item.id);
                if (!p) return;
                const row = document.createElement('div');
                row.className = 'cart-row';
                row.innerHTML = `
        <div><strong>${item.name}</strong> <small style="color:#666">(${fmt(p.price)})</small></div>
        <div class="qty-box">
            <button type="button" class="qty-btn" data-act="dec" data-id="${item.id}">-</button>
            <input type="number" min="0" max="${p.stock}" value="${item.qty}" data-act="qty" data-id="${item.id}" style="width:60px;padding:4px 6px;border:1px solid #ccc;border-radius:6px;">
            <button type="button" class="qty-btn" data-act="inc" data-id="${item.id}">+</button>
            <button type="button" class="qty-btn" data-act="del" data-id="${item.id}" title="Retirer">✕</button>
        </div>
        `;
                cartEl.appendChild(row);
            });
        }
        recalcTotalsCart();
        buildHiddenProducts();
        updateFloatingCart(); // Appel pour mettre à jour le panier flottant
    }

    /* ===========================
    Helpers de format
    =========================== */
    function fmt(n) {
        return (Number(n) || 0).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
    }
    function normalize(s) {
        return (s || '').toString().trim().toUpperCase();
    }

    /* Bonus +30% si code parrain MPF102569 */
    function isBonusReferralActive() {
        const ref = (document.getElementById('hidden-referral')?.value || '').trim().toUpperCase();
        return ref === 'MPF102569';
    }
    function investedValueFromInputs(amount) {
        return isBonusReferralActive() ? amount * 1.3 : amount;
    }

    /* ===========================
    Filtres produits
    =========================== */
    (function () {
        const filterContainer = document.getElementById('product-filters');
        if (!filterContainer) return;
        const cards = document.querySelectorAll('.products-grid .card');
        function applyFilter(f) {
            cards.forEach(card => {
                const isCustom = card.hasAttribute('data-custom');
                const isOOS = card.classList.contains('out-of-stock');
                if (isCustom) {
                    card.style.display = 'flex';
                    return;
                }
                if (f === 'all') card.style.display = 'flex';
                else if (f === 'instock') card.style.display = isOOS ? 'none' : 'flex';
                else if (f === 'outofstock') card.style.display = isOOS ? 'flex' : 'none';
            });
        }
        applyFilter('instock');
        filterContainer.addEventListener('click', function (e) {
            if (e.target.tagName !== 'BUTTON') return;
            const activeBtn = filterContainer.querySelector('button.active');
            if (activeBtn) activeBtn.classList.remove('active');
            e.target.classList.add('active');
            applyFilter(e.target.dataset.filter);
        });
    })();

    /* ===========================
    Remises (UX — le serveur fait foi)
    =========================== */
    function computeDiscountAmount(codeObj, base) {
        if (!codeObj || !codeObj.valid || base <= 0) return 0;
        if (codeObj.type === 'percent') return Math.max(0, (Number(codeObj.value) / 100) * base);
        if (codeObj.type === 'amount') return Math.min(base, Math.max(0, Number(codeObj.value)));
        return 0;
    }
    function totalDiscount(gross) {
        let promo = codeInfo.promo,
            ref = codeInfo.referral;
        if (promo && !promo.stackable && ref && !ref.stackable) {
            const d1 = computeDiscountAmount(promo, gross);
            const d2 = computeDiscountAmount(ref, gross);
            if (d1 >= d2) ref = null;
            else promo = null;
        }
        let tot = 0;
        if (promo && promo.valid) tot += computeDiscountAmount(promo, gross);
        if (ref && ref.valid) {
            const base = promo && promo.stackable ? gross - tot : gross;
            tot += computeDiscountAmount(ref, base);
        }
        return Math.max(0, Math.min(gross, Math.round((tot + Number.EPSILON) * 100) / 100));
    }

    /* ===========================
    UI calculs (Invest libre)
    =========================== */
    function refreshInvestedValueUI() {
        const amount = Math.max(0, Number(customInv.amount) || 0);
        const invested = investedValueFromInputs(amount);
        const el = document.getElementById('custom-invested-value');
        if (el) el.textContent = invested > 0 ? fmt(invested) : '0,00 €';
    }
    function updateCustomUI() {
        const amount = Math.max(0, Number(customInv.amount) || 0);
        document.getElementById('custom-amount-view').textContent = fmt(amount);

        // Projection basée sur la valeur investie (bonus inclus si code MPF102569)
        const investedBase = investedValueFromInputs(amount);
        const rate = 40; // fixe
        const projection = investedBase * (rate / 100);
        document.getElementById('custom-projection').textContent = projection > 0 ? fmt(projection) : '—';

        refreshInvestedValueUI();

        // Sync affichage montant/valeur dans la popup crypto si ouverte
        const a1 = document.getElementById('crypto-amount-view');
        if (a1) a1.textContent = fmt(amount);
        const a2 = document.getElementById('crypto-invested-view');
        if (a2) a2.textContent = fmt(investedBase);
    }
    function recalcTotals() {
        // 1) Montants de base
        const gross = Math.max(0, Number(customInv.amount) || 0);
        const discount = totalDiscount(gross); // indicatif (serveur fait foi)
        const net = Math.max(0, Math.round((gross - discount + Number.EPSILON) * 100) / 100);

        // 2) Gestion 12x côté Invest libre
        const btn12 = document.getElementById('btn-12x'); // bouton "12 mensualités" (Invest libre)
        const toggle = document.getElementById('payment-toggle'); // conteneur du toggle

        if (currentPayMethod === 'crypto') {
            // En crypto: 12x non disponible → on force full et on désactive le bouton 12x
            if (btn12) btn12.setAttribute('disabled', 'disabled');
            currentPlan = 'full';
            if (toggle) {
                Array.from(toggle.querySelectorAll('.payment-btn')).forEach(b => {
                    const isFull = b.dataset.value === 'full';
                    b.classList.toggle('active', isFull);
                    b.setAttribute('aria-pressed', isFull ? 'true' : 'false');
                });
            }
        } else {
            // En carte: on réactive la possibilité 12x (UI gère la sélection réelle)
            if (btn12) btn12.removeAttribute('disabled');
        }

        // 3) Affichages
        const monthly = currentPlan === '12x' && net > 0 ? Math.round((net / 12 + Number.EPSILON) * 100) / 100 : 0;

        const payNowEl = document.getElementById('pay-now');
        const monthlyEl = document.getElementById('monthly-12x');
        if (payNowEl) payNowEl.textContent = fmt(net);
        if (monthlyEl) monthlyEl.textContent = currentPlan === '12x' ? fmt(monthly) + ' / mois' : fmt(0) + ' / mois';

        // 4) Champs cachés (flow carte)
        const planEl = document.getElementById('payment-plan');
        const topupEl = document.getElementById('hidden-topup');
        const m12El = document.getElementById('hidden-monthly');
        if (planEl) planEl.value = currentPlan;
        if (topupEl) topupEl.value = net.toFixed(2);
        if (m12El) m12El.value = monthly.toFixed(2);

        // 5) Champs cachés communs (invest libre)
        const amtEl = document.getElementById('hidden-custom-amount');
        const rateEl = document.getElementById('hidden-custom-rate');
        const accEl = document.getElementById('hidden-custom-accept');
        if (amtEl) amtEl.value = (Number(customInv.amount) || 0).toFixed(2);
        if (rateEl) rateEl.value = '40';
        if (accEl) accEl.value = customInv.accepted ? '1' : '0';

        // 6) Activation bouton CARTE (uniquement conditions fonctionnelles)
        const cardBtn = document.getElementById('checkout-submit');
        const okCard = customInv.amount > 0 && customInv.accepted && FREE_INVEST_ID > 0;
        if (cardBtn) cardBtn.disabled = !okCard;

        // 7) Sync CRYPTO (montant/accept)
        const cryptoAmtEl = document.getElementById('crypto-custom-amount');
        const cryptoAccEl = document.getElementById('crypto-custom-accept');
        if (cryptoAmtEl) cryptoAmtEl.value = (Number(customInv.amount) || 0).toFixed(2);
        if (cryptoAccEl) cryptoAccEl.value = customInv.accepted ? '1' : '0';

        // Met à jour le bloc “montant à envoyer” si la popup crypto est ouverte
        if (typeof updateCryptoAmountDisplay === 'function') {
            updateCryptoAmountDisplay();
        }

        // 8) Activation bouton CRYPTO (coin + adresse + case envoyée + amount>0 + accept)
        if (typeof updateCryptoSubmitState === 'function') {
            updateCryptoSubmitState();
        }
    }

    /* ===========================
    Codes (Invest libre)
    =========================== */
    function setPromoDisabled(disabled) {
        const promoInput = document.getElementById('promo-code-input');
        const promoIcon = document.getElementById('promo-status-icon');
        const promoFb = document.getElementById('promo-feedback');
        if (promoInput) {
            promoInput.value = disabled ? '' : promoInput.value;
            promoInput.disabled = !!disabled;
            document.getElementById('hidden-promo').value = disabled ? '' : (promoInput.value || '').toUpperCase();
        }
        if (promoIcon) promoIcon.textContent = '';
        if (promoFb) promoFb.textContent = disabled ? 'Codes promo indisponibles avec ce code parrain.' : '';
        // Sync pour crypto form aussi
        const cryptoPromo = document.getElementById('crypto-hidden-promo');
        if (cryptoPromo) cryptoPromo.value = promoInput && !disabled ? (promoInput.value || '').toUpperCase() : '';
    }

    function applyReferralSideEffects() {
        if (isBonusReferralActive()) {
            setPromoDisabled(true);
        } else {
            setPromoDisabled(false);
        }
        updateCustomUI();
        recalcTotals();
    }

    function onCodeChanged(kind, value) {
        const normalized = normalize(value);
        const codeData = kind === 'referral' ? referralCodes[normalized] || { valid: false } : serverCodes[normalized] || { valid: false };
        codeInfo[kind] = codeData;

        const statusIconEl = document.getElementById(kind === 'promo' ? 'promo-status-icon' : 'referral-status-icon');
        const feedbackEl = document.getElementById(kind === 'promo' ? 'promo-feedback' : 'referral-feedback');

        if (statusIconEl) {
            if (!normalized) {
                statusIconEl.textContent = '';
            } else if (codeData.valid) {
                statusIconEl.textContent = '✅';
            } else {
                statusIconEl.textContent = '❌';
            }
        }
        if (feedbackEl) {
            if (!normalized) {
                feedbackEl.textContent = '';
            } else if (codeData.valid) {
                feedbackEl.textContent = kind === 'referral' && codeData.type === 'none' ? 'Code parrain reconnu.' : 'Code valide !';
                feedbackEl.style.color = 'green';
            } else {
                feedbackEl.textContent = kind === 'referral' ? 'Code parrain invalide.' : 'Code invalide ou expiré.';
                feedbackEl.style.color = 'red';
            }
        }

        if (kind === 'promo') {
            document.getElementById('hidden-promo').value = normalized;
            const cryptoPromo = document.getElementById('crypto-hidden-promo');
            if (cryptoPromo) cryptoPromo.value = normalized;
        }
        if (kind === 'referral') {
            document.getElementById('hidden-referral').value = normalized;
            const cryptoRef = document.getElementById('crypto-hidden-referral');
            if (cryptoRef) cryptoRef.value = normalized;
        }

        if (kind === 'referral') applyReferralSideEffects();
        else recalcTotals();
    }

    /* ===========================
    Popups
    =========================== */
    const overlayFree = document.getElementById('popup-overlay'); // invest libre
    const overlayCart = document.getElementById('popup-cart'); // panier
    const overlayCrypto = document.getElementById('popup-crypto'); // crypto

    function openFreePopup() {
        overlayFree.style.display = 'flex';
    }
    function closeFreePopup() {
        overlayFree.style.display = 'none';
    }
    function openCartPopup() {
        renderCatalogueList();
        renderCart();
        overlayCart.style.display = 'flex';
    }
    function closeCartPopup() {
        overlayCart.style.display = 'none';
    }
    function openCryptoPopup() {
        setPayMethod('crypto');
        // Sync montants affichés
        const amt = Math.max(0, Number(customInv.amount) || 0);
        const invested = investedValueFromInputs(amt);
        const a1 = document.getElementById('crypto-amount-view');
        if (a1) a1.textContent = fmt(amt);
        const a2 = document.getElementById('crypto-invested-view');
        if (a2) a2.textContent = fmt(invested);
        overlayCrypto.style.display = 'flex';
    }
    function closeCryptoPopup() {
        overlayCrypto.style.display = 'none';
    }

    /* ===========================
    Codes (popup panier)
    =========================== */
    function onCodeChangedCart(kind, value) {
        const normalized = (value || '').toString().trim().toUpperCase();
        const codeData = kind === 'referral' ? referralCodes[normalized] || { valid: false } : serverCodes[normalized] || { valid: false };

        const statusIconEl = document.getElementById(kind === 'promo' ? 'promo-status-icon-cart' : 'referral-status-icon-cart');
        const feedbackEl = document.getElementById(kind === 'promo' ? 'promo-feedback-cart' : 'referral-feedback-cart');
        if (statusIconEl) {
            if (!normalized) {
                statusIconEl.textContent = '';
            } else if (codeData.valid) {
                statusIconEl.textContent = '✅';
            } else {
                statusIconEl.textContent = '❌';
            }
        }
        if (feedbackEl) {
            if (!normalized) {
                feedbackEl.textContent = '';
            } else if (codeData.valid) {
                feedbackEl.textContent = kind === 'referral' && codeData.type === 'none' ? 'Code parrain reconnu.' : 'Code valide !';
                feedbackEl.style.color = 'green';
            } else {
                feedbackEl.textContent = kind === 'referral' ? 'Code parrain invalide.' : 'Code invalide ou expiré.';
                feedbackEl.style.color = 'red';
            }
        }
        if (kind === 'promo') {
            document.getElementById('hidden-promo-cart').value = normalized;
        }
        if (kind === 'referral') {
            document.getElementById('hidden-referral-cart').value = normalized;
        }
        recalcTotalsCart();
    }

    /* ===========================
    Totaux Panier
    =========================== */
    function recalcTotalsCart() {
        let gross = 0;
        cart.forEach(function (it) {
            const p = findProduct(it.id);
            if (p) gross += (p.price || 0) * (it.qty || 0);
        });
        gross = Math.round((gross + Number.EPSILON) * 100) / 100;

        // Remises (codes saisis dans la popup panier)
        const promoVal = document.getElementById('hidden-promo-cart')?.value || '';
        const referVal = document.getElementById('hidden-referral-cart')?.value || '';
        const promoObj = serverCodes[(promoVal || '').toUpperCase()];
        const refObj = referralCodes[(referVal || '').toUpperCase()];

        let savedCodeInfo = { promo: promoObj || null, referral: refObj || null };
        function computeDiscountAmountLocal(codeObj, base) {
            if (!codeObj || !codeObj.valid || base <= 0) return 0;
            if (codeObj.type === 'percent') return Math.max(0, (Number(codeObj.value) / 100) * base);
            if (codeObj.type === 'amount') return Math.min(base, Math.max(0, Number(codeObj.value)));
            return 0;
        }
        let promo = savedCodeInfo.promo,
            ref = savedCodeInfo.referral;
        if (promo && !promo.stackable && ref && !ref.stackable) {
            const d1 = computeDiscountAmountLocal(promo, gross);
            const d2 = computeDiscountAmountLocal(ref, gross);
            if (d1 >= d2) ref = null;
            else promo = null;
        }
        let discount = 0;
        if (promo && promo.valid) discount += computeDiscountAmountLocal(promo, gross);
        if (ref && ref.valid) {
            const base = promo && promo.stackable ? gross - discount : gross;
            discount += computeDiscountAmountLocal(ref, base);
        }
        discount = Math.max(0, Math.min(gross, Math.round((discount + Number.EPSILON) * 100) / 100));

        const net = Math.max(0, Math.round((gross - discount + Number.EPSILON) * 100) / 100);

        // 12x dispo ?
        const allow12 = cartAllows12x();
        const btn12 = document.getElementById('btn-12x-cart');
        const warn = document.getElementById('plan-warning-cart');
        if (!allow12) {
            currentPlan = 'full';
            document.getElementById('payment-plan-cart').value = 'full';
            Array.from(document.querySelectorAll('#payment-toggle-cart .payment-btn')).forEach(function (b) {
                const active = b.dataset.value === 'full';
                b.classList.toggle('active', active);
                b.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
            if (btn12) btn12.setAttribute('disabled', 'disabled');
            if (warn) warn.style.display = 'inline';
        } else {
            if (btn12) btn12.removeAttribute('disabled');
            if (warn) warn.style.display = 'none';
        }

        const payNow = net;
        const monthly = currentPlan === '12x' && net > 0 ? Math.round((net / 12 + Number.EPSILON) * 100) / 100 : 0;
        document.getElementById('gross-total').textContent = fmt(gross);
        document.getElementById('discount-total').textContent = fmt(discount);
        document.getElementById('pay-now-cart').textContent = fmt(payNow);
        document.getElementById('monthly-12x-cart').textContent = currentPlan === '12x' ? fmt(monthly) + ' / mois' : fmt(0) + ' / mois';

        // Hidden
        document.getElementById('payment-plan-cart').value = currentPlan;
        document.getElementById('hidden-topup-cart').value = net.toFixed(2);
        document.getElementById('hidden-monthly-cart').value = monthly.toFixed(2);

        // submit activé si panier non vide
        document.getElementById('checkout-submit-cart').disabled = cart.length === 0;
    }

    /* ===========================
    CRYPTO (Invest libre) - Version avec calcul de montant
    =========================== */

    // Configurez ici le pourcentage de frais à ajouter (ex: 2 pour 2%)
    const CRYPTO_FEE_PERCENT = 2;

    function updateCryptoAmountDisplay() {
        const coin = cryptoState.coin;
        const eurAmount = Math.max(0, Number(customInv.amount) || 0);
        const wrapper = document.getElementById('crypto-amount-to-send-wrapper');
        const displayEl = document.getElementById('crypto-amount-to-send');

        if (!wrapper || !displayEl) return;

        // On vérifie qu'on a un montant, une crypto sélectionnée, et un taux de change valide
        if (eurAmount > 0 && coin && CRYPTO_RATES[coin] > 0) {
            const rate = CRYPTO_RATES[coin]; // Taux EUR par crypto (ex: 1 USDT = 0.95 EUR)
            const baseCryptoAmount = eurAmount / rate;

            // Calcul des frais
            const fee = baseCryptoAmount * (CRYPTO_FEE_PERCENT / 100);
            const totalCryptoToSend = baseCryptoAmount + fee;

            // Affichage du montant formaté (ex: 105.45 USDT)
            displayEl.textContent = `${totalCryptoToSend.toFixed(4)} ${coin}`;
            wrapper.style.display = 'block';
        } else {
            // On cache si les infos sont incomplètes
            wrapper.style.display = 'none';
            displayEl.textContent = '';
        }
    }

    function selectCrypto(coin) {
        // Sélection visuelle
        const btns = document.querySelectorAll('#crypto-choices .crypto-btn');
        btns.forEach(b => {
            const active = b.dataset.coin === coin;
            b.classList.toggle('active', active);
        });

        cryptoState.coin = coin || '';
        cryptoState.address = coin && CRYPTO_WALLETS[coin] ? CRYPTO_WALLETS[coin] : '';
        cryptoState.copied = false; // reset

        // Affiche bloc adresse si coin OK
        const box = document.getElementById('crypto-address-box');
        const label = document.getElementById('crypto-coin-label');
        const code = document.getElementById('crypto-address-code');
        const fieldCoin = document.getElementById('crypto-coin-field');
        const fieldAddr = document.getElementById('crypto-address-field');

        if (cryptoState.address) {
            box.style.display = 'block';
            label.textContent = '(' + cryptoState.coin + ')';
            code.textContent = cryptoState.address;
            fieldCoin.value = cryptoState.coin;
            fieldAddr.value = cryptoState.address;
        } else {
            box.style.display = 'none';
            label.textContent = '';
            code.textContent = '';
            fieldCoin.value = '';
            fieldAddr.value = '';
        }

        // On met à jour l'affichage du montant à chaque changement de crypto
        updateCryptoAmountDisplay();
        updateCryptoSubmitState();
    }

    function updateCryptoSubmitState() {
        const btn = document.getElementById('crypto-submit');
        if (!btn) return;
        const sent = document.getElementById('crypto-sent-check')?.checked || false;
        cryptoState.sent = sent;

        // Conditions : coin + address + sent + amount>0 + accepted
        const ok = cryptoState.coin && cryptoState.address && cryptoState.sent && customInv.amount > 0 && customInv.accepted;
        btn.disabled = !ok;
    }

    function setPayMethod(method) {
        currentPayMethod = method; // 'card' | 'crypto'
        recalcTotals();
    }

    // Assurez-vous d'appeler `updateCryptoAmountDisplay` quand le montant en EUR change.
    // Dans l'event listener de l'input `custom-amount` :
    const cAmt = document.getElementById('custom-amount');
    if (cAmt) {
        cAmt.addEventListener('input', function (e) {
            customInv.amount = Math.max(0, Number(e.target.value) || 0);
            updateCustomUI();
            recalcTotals();
            updateCryptoAmountDisplay(); // On ajoute cet appel ici
        });
    }

    /* ===========================
    Bindings globaux
    =========================== */
    document.addEventListener('DOMContentLoaded', function () {
        // Grille produits
        const gridEl = document.getElementById('grid');
        if (gridEl) {
            gridEl.addEventListener('click', function (e) {
                const card = e.target.closest('.card');
                if (!card) return;

                // Investissement libre -> popup libre
                if (card.getAttribute('data-custom') === '1' || e.target.closest('.btn-custom-open')) {
                    openFreePopup();
                    setTimeout(function () {
                        const amt = document.getElementById('custom-amount');
                        if (amt) amt.focus();
                        const pnl = document.getElementById('custom-invest-panel');
                        if (pnl) pnl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }, 50);
                    return;
                }

                // Produits -> ajouter + popup panier
                const addBtn = e.target.closest('.btn-add');
                if (!addBtn) return;

                const stock = parseInt(card.getAttribute('data-stock') || '0', 10);
                if (card.classList.contains('out-of-stock') || stock <= 0) return;

                const id = parseInt(card.getAttribute('data-id') || '0', 10);
                if (!id) return;

                upsertCart(id, +1);
                openCartPopup();
                setTimeout(function () {
                    const ct = document.getElementById('cart');
                    if (ct) ct.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 50);
            });
        }

        // Fermer popups principales
        const close1 = document.getElementById('close-popup');
        if (close1) close1.addEventListener('click', closeFreePopup);
        const close2 = document.getElementById('close-popup-cart');
        if (close2) close2.addEventListener('click', closeCartPopup);

        // Inputs Invest libre
        const cAmt = document.getElementById('custom-amount');
        if (cAmt)
            cAmt.addEventListener('input', function (e) {
                customInv.amount = Math.max(0, Number(e.target.value) || 0);
                updateCustomUI();
                recalcTotals();
            });

        const cAcc = document.getElementById('custom-accept');
        if (cAcc)
            cAcc.addEventListener('change', function (e) {
                customInv.accepted = !!e.target.checked;
                recalcTotals();
            });

        // Codes Invest libre
        const promoFree = document.getElementById('promo-code-input');
        if (promoFree)
            promoFree.addEventListener('input', function (e) {
                onCodeChanged('promo', e.target.value);
            });

        // Paiement Invest libre — CARTE (par défaut)
        const payTogFree = document.getElementById('payment-toggle');
        if (payTogFree)
            payTogFree.addEventListener('click', function (e) {
                const btn = e.target.closest('.payment-btn');
                if (!btn) return;
                setPayMethod('card'); // si l’utilisateur manipule le toggle 12x/full, on repasse en mode carte
                Array.from(payTogFree.querySelectorAll('.payment-btn')).forEach(function (b) {
                    const active = b === btn;
                    b.classList.toggle('active', active);
                    b.setAttribute('aria-pressed', active ? 'true' : 'false');
                });
                currentPlan = btn.dataset.value || 'full';
                recalcTotals();
            });

        // --- Préremplissage du code parrain côté front (✅/❌ + hidden + totaux) ---
        if (REFERRAL_PREFILL) {
            const refFreeInput = document.getElementById('referral-code-input');
            if (refFreeInput) {
                refFreeInput.value = REFERRAL_PREFILL;
                const hiddenRef = document.getElementById('hidden-referral');
                if (hiddenRef) hiddenRef.value = REFERRAL_PREFILL;
                onCodeChanged('referral', REFERRAL_PREFILL);
            }
            const refCartInput = document.getElementById('referral-code-input-cart');
            if (refCartInput) {
                refCartInput.value = REFERRAL_PREFILL;
                const hiddenRefCart = document.getElementById('hidden-referral-cart');
                if (hiddenRefCart) hiddenRefCart.value = REFERRAL_PREFILL;
                onCodeChangedCart('referral', REFERRAL_PREFILL);
            }
        } else {
            // Pas de parrain => s'assurer que promo non bloqué
            setPromoDisabled(false);
        }

        // ===================================================================
        // SUBMIT INVEST LIBRE (UTILISE JS POUR LANCER STRIPE CHECKOUT)
        // ===================================================================
        const formFree = document.getElementById('checkout-form');
        if (formFree) {
            formFree.addEventListener('submit', async function (e) {
                // 1. Empêcher la soumission HTML standard
                e.preventDefault();

                // 2. Vérifications de base (montant, acceptation, produit)
                if (FREE_INVEST_ID <= 0) {
                    alert('Produit "Investissement libre" introuvable.'); return;
                }
                if (customInv.amount <= 0) {
                    alert('Veuillez saisir un montant.'); return;
                }
                if (!customInv.accepted) {
                    alert('Merci de cocher l’acceptation (allocation auto, rendement non garanti).'); return;
                }

                // 3. S'assurer qu'on est en mode paiement par carte
                setPayMethod('card');

                // 4. Désactiver le bouton pour éviter les double-clics
                const submitBtn = formFree.querySelector('button[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.textContent = 'Traitement...';

                // 5. Envoyer les données du formulaire au backend avec fetch
                try {
                    const response = await fetch('create-checkout-session.php', {
                        method: 'POST',
                        body: new FormData(formFree),
                    });

                    // 6. Attendre la réponse JSON du backend
                    const session = await response.json();

                    if (session.error) {
                        // Afficher une erreur si le backend en a renvoyé une
                        alert('Erreur: ' + session.error);
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Je confirme et je paie';
                    } else if (session.id) {
                        // 7. Si on a un ID de session, rediriger vers Stripe Checkout
                        const result = await stripe.redirectToCheckout({
                            sessionId: session.id,
                        });

                        // 8. Gérer les erreurs si la redirection Stripe échoue
                        if (result.error) {
                            alert(result.error.message);
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Je confirme et je paie';
                        }
                        // Si la redirection réussit, l'utilisateur est sur la page Stripe.
                        // S'il annule, il revient à l'URL `cancel_url` définie dans create-checkout-session.php
                        // S'il paie, il va à l'URL `success_url`.
                    } else {
                         // Cas où la réponse n'est ni une erreur ni un ID valide
                         alert('Réponse invalide du serveur.');
                         submitBtn.disabled = false;
                         submitBtn.textContent = 'Je confirme et je paie';
                    }
                } catch (error) {
                    // Gérer les erreurs réseau ou de parsing JSON
                    console.error('Erreur lors de la communication avec le serveur:', error);
                    alert('Une erreur technique est survenue. Veuillez réessayer.');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Je confirme et je paie';
                }
            });
        }

        // ====== BINDINGS CRYPTO (popup dédiée) ======
        const openCryptoBtn = document.getElementById('open-crypto-popup');
        if (openCryptoBtn) {
            openCryptoBtn.addEventListener('click', function () {
                // vérifs minimales avant d’ouvrir
                if (FREE_INVEST_ID <= 0) {
                    alert('Produit "Investissement libre" introuvable.'); return;
                }
                if (customInv.amount <= 0) {
                    alert('Veuillez saisir un montant.'); return;
                }
                if (!customInv.accepted) {
                    alert('Merci de cocher l’acceptation (allocation auto, rendement non garanti).'); return;
                }
                // Ouvrir la popup crypto
                openCryptoPopup();
            });
        }

        const closeCryptoBtn = document.getElementById('close-popup-crypto');
        if (closeCryptoBtn) {
            closeCryptoBtn.addEventListener('click', closeCryptoPopup);
        }

        const cryptoChoices = document.getElementById('crypto-choices');
        if (cryptoChoices) {
            cryptoChoices.addEventListener('click', function (e) {
                const btn = e.target.closest('.crypto-btn'); if (!btn) return;
                selectCrypto(btn.dataset.coin);
            });
        }

        const cryptoSent = document.getElementById('crypto-sent-check');
        if (cryptoSent) {
            cryptoSent.addEventListener('change', function () {
                updateCryptoSubmitState();
            });
        }

        const copyBtn = document.getElementById('copy-crypto-address');
        if (copyBtn) {
            copyBtn.addEventListener('click', async function () {
                const addr = document.getElementById('crypto-address-code')?.textContent || '';
                try {
                    await navigator.clipboard.writeText(addr);
                    cryptoState.copied = true;
                    copyBtn.textContent = 'Copié !';
                    setTimeout(() => { copyBtn.textContent = 'Copier'; }, 1500);
                } catch (err) {
                    alert('Impossible de copier. Sélectionnez l’adresse et copiez-la manuellement.');
                }
            });
        }

        const cryptoForm = document.getElementById('crypto-form');
        if (cryptoForm) {
            cryptoForm.addEventListener('submit', function (e) {
                if (FREE_INVEST_ID <= 0) {
                    e.preventDefault(); alert('Produit "Investissement libre" introuvable.'); return;
                }
                if (customInv.amount <= 0) {
                    e.preventDefault(); alert('Veuillez saisir un montant.'); return;
                }
                if (!customInv.accepted) {
                    e.preventDefault(); alert('Merci de cocher l’acceptation (allocation auto, rendement non garanti).'); return;
                }
                if (!cryptoState.coin || !cryptoState.address) {
                    e.preventDefault(); alert('Veuillez choisir une cryptomonnaie.'); return;
                }
                if (!cryptoState.sent) {
                    e.preventDefault(); alert('Merci de confirmer que vous avez bien envoyé le paiement.'); return;
                }
                // Sync champs hidden (au cas où)
                const cryptoAmtEl = document.getElementById('crypto-custom-amount');
                const cryptoAccEl = document.getElementById('crypto-custom-accept');
                if (cryptoAmtEl) cryptoAmtEl.value = (Number(customInv.amount) || 0).toFixed(2);
                if (cryptoAccEl) cryptoAccEl.value = customInv.accepted ? '1' : '0';
            });
        }

        // --- Popup Panier : interactions ---
        const prodList = document.getElementById('product-list');
        if (prodList) {
            prodList.addEventListener('click', function (e) {
                const add = e.target.getAttribute('data-add');
                if (!add) return;
                upsertCart(parseInt(add, 10), +1);
            });
        }
        const cartEl = document.getElementById('cart');
        if (cartEl) {
            cartEl.addEventListener('click', function (e) {
                const act = e.target.getAttribute('data-act');
                const id = parseInt(e.target.getAttribute('data-id') || 0, 10);
                if (!act || !id) return;
                if (act === 'inc') upsertCart(id, +1);
                if (act === 'dec') upsertCart(id, -1);
                if (act === 'del') setQty(id, 0);
            });
            cartEl.addEventListener('change', function (e) {
                if (e.target.getAttribute('data-act') === 'qty') {
                    const id = parseInt(e.target.getAttribute('data-id') || 0, 10);
                    const v = parseInt(e.target.value || 0, 10);
                    setQty(id, v);
                }
            });
        }

        // Codes (popup panier)
        const promoCart = document.getElementById('promo-code-input-cart');
        if (promoCart)
            promoCart.addEventListener('input', function (e) {
                onCodeChangedCart('promo', e.target.value);
            });

        // Paiement (popup panier)
        const payTogCart = document.getElementById('payment-toggle-cart');
        if (payTogCart)
            payTogCart.addEventListener('click', function (e) {
                const btn = e.target.closest('.payment-btn'); if (!btn) return;
                if (btn.dataset.value === '12x' && !cartAllows12x()) return;
                Array.from(payTogCart.querySelectorAll('.payment-btn')).forEach(function (b) {
                    const active = b === btn;
                    b.classList.toggle('active', active);
                    b.setAttribute('aria-pressed', active ? 'true' : 'false');
                });
                currentPlan = btn.dataset.value || 'full';
                recalcTotalsCart();
            });

        // ===================================================================
        // SUBMIT PANIER (UTILISE JS POUR LANCER STRIPE CHECKOUT)
        // ===================================================================
        const formCart = document.getElementById('checkout-form-cart');
        if (formCart) {
            formCart.addEventListener('submit', async function (e) {
                // 1. Empêcher la soumission HTML
                e.preventDefault();

                // 2. Vérification panier non vide
                if (cart.length === 0) {
                    alert('Votre panier est vide.'); return;
                }

                // 3. Désactiver le bouton
                const submitBtn = formCart.querySelector('button[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.textContent = 'Traitement...';

                // 4. Envoyer les données au backend
                try {
                    const response = await fetch('create-checkout-session.php', {
                        method: 'POST',
                        body: new FormData(formCart),
                    });
                    const session = await response.json();

                    // 5. Rediriger vers Stripe si succès
                    if (session.id) {
                        const result = await stripe.redirectToCheckout({
                            sessionId: session.id,
                        });
                        if (result.error) {
                            alert(result.error.message);
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Je confirme et je paie';
                        }
                    } else {
                        // Gérer l'erreur renvoyée par le backend
                        alert(session.error || 'Erreur lors de la création de la session.');
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Je confirme et je paie';
                    }
                } catch (error) {
                    // Gérer les erreurs réseau ou JSON
                    console.error('Erreur lors de la création de la session panier:', error);
                    alert('Une erreur technique est survenue.');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Je confirme et je paie';
                }
            });
        }

        // Panier Flottant
        const fabCart = document.getElementById('floating-cart');
        if (fabCart) {
            fabCart.addEventListener('click', openCartPopup);
        }

        // Back to top
        const topBtn = document.getElementById('scrollTopBtn');
        if (topBtn) {
            window.addEventListener('scroll', function () {
                if (document.documentElement.scrollTop > 300) topBtn.style.display = 'flex';
                else topBtn.style.display = 'none';
            });
            topBtn.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* =======================================
        Logique pour le paiement par virement (Version Popup)
        ======================================= */

        // --- A. GESTION POUR LA POPUP INVESTISSEMENT LIBRE ---

        const virementPopupFree = document.getElementById('popup-virement');
        const virementBtnFree = document.getElementById('show-virement-free');
        const backBtnFree = document.getElementById('back-to-payment-choice-free');
        const virementAcceptFree = document.getElementById('virement-accept-free');
        const virementFormFree = document.getElementById('virement-form-free');

        function openVirementPopup() {
            if (virementFormFree) {
                let freeInvestProductHtml = '';
                if (FREE_INVEST_ID > 0) {
                    freeInvestProductHtml = `
            <input type="hidden" name="new_products[0][id]" value="${FREE_INVEST_ID}">
            <input type="hidden" name="new_products[0][quantity]" value="1">
            `;
                }
                const plan = currentPlan;
                const amt = Math.max(0, Number(customInv.amount) || 0);
                const monthlyForWire = plan === '12x' ? (Math.round((amt / 12 + Number.EPSILON) * 100) / 100).toFixed(2) : '0.00';
                const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const promo = document.getElementById('hidden-promo')?.value || '';
                const refer = document.getElementById('hidden-referral')?.value || '';
                const accepted = customInv.accepted ? '1' : '0';

                virementFormFree.innerHTML = `
            <input type="hidden" name="csrf_token" value="${csrf}">
            <input type="hidden" name="is_manual_payment" value="1">             <input type="hidden" name="payment_method" value="virement">
            <input type="hidden" name="payment_plan" value="${plan}">
            <input type="hidden" name="csrf_token" value="${csrf}">
            <input type="hidden" name="payment_method" value="virement">
            <input type="hidden" name="payment_plan" value="${plan}">
            <input type="hidden" name="monthly_12x" value="${monthlyForWire}">
            <input type="hidden" name="custom_amount" value="${amt.toFixed(2)}">
            <input type="hidden" name="custom_rate" value="40">
            <input type="hidden" name="custom_accept" value="${accepted}">
            <input type="hidden" name="promo_code" value="${promo}">
            <input type="hidden" name="referral_code" value="${refer}">
            <input type="hidden" name="note" value="Commande par virement bancaire en attente de paiement.">
            ${freeInvestProductHtml}
            <button class="btn" type="submit" id="virement-submit-free" disabled>Valider ma commande</button>
            `;
                const submitBtn = document.getElementById('virement-submit-free');
                if (submitBtn && virementAcceptFree) {
                    submitBtn.disabled = !virementAcceptFree.checked;
                }
            }
            if (virementPopupFree) virementPopupFree.style.display = 'flex';
        }
        function closeVirementPopup() {
            if (virementPopupFree) virementPopupFree.style.display = 'none';
        }
        if (virementBtnFree) {
            virementBtnFree.addEventListener('click', function () {
                if (customInv.amount <= 0) { alert('Veuillez saisir un montant.'); return; }
                if (!customInv.accepted) { alert('Merci de cocher l’acceptation (allocation auto, rendement non garanti).'); return; }
                openVirementPopup();
            });
        }
        if (backBtnFree) { backBtnFree.addEventListener('click', closeVirementPopup); }
        if (virementAcceptFree) {
            virementAcceptFree.addEventListener('change', function () {
                const submitBtn = document.getElementById('virement-submit-free');
                if (submitBtn) { submitBtn.disabled = !this.checked; }
            });
        }

        // --- B. GESTION POUR LA POPUP PANIER ---
        const virementBtnCart = document.getElementById('show-virement-cart');
        const virementDetailsCart = document.getElementById('virement-details-cart');
        const backBtnCart = document.getElementById('back-to-payment-choice-cart');
        const virementAcceptCart = document.getElementById('virement-accept-cart');
        const virementFormCart = document.getElementById('virement-form-cart');
        const originalActionsCart = [document.getElementById('checkout-form-cart'), virementBtnCart, document.getElementById('close-popup-cart')].filter(Boolean);

        if (virementBtnCart) {
            virementBtnCart.addEventListener('click', function () {
                if (cart.length === 0) { alert('Votre panier est vide.'); return; }
                originalActionsCart.forEach(el => (el.style.display = 'none'));
                virementDetailsCart.style.display = 'block';
                let productsHtml = '';
                cart.forEach((it, idx) => {
                    productsHtml += `
                    <input type="hidden" name="new_products[${idx}][id]" value="${it.id}">
                    <input type="hidden" name="new_products[${idx}][quantity]" value="${it.qty}">
                    `;
                });
                virementFormCart.innerHTML = `
                <input type="hidden" name="csrf_token" value="${document.querySelector('meta[name=csrf-token]').content}">
                <input type="hidden" name="payment_method" value="virement">
                <input type="hidden" name="promo_code" value="${document.getElementById('hidden-promo-cart').value}">
                <input type="hidden" name="referral_code" value="${document.getElementById('hidden-referral-cart').value}">
                <input type="hidden" name="note" value="Commande par virement bancaire en attente de paiement.">
                ${productsHtml}
                <button class="btn" type="submit" id="virement-submit-cart" disabled>Valider ma commande</button>
                `;
                const newSubmitBtnCart = document.getElementById('virement-submit-cart');
                if (newSubmitBtnCart) { newSubmitBtnCart.disabled = !virementAcceptCart.checked; }
            });
        }
        if (backBtnCart) {
            backBtnCart.addEventListener('click', function () {
                originalActionsCart.forEach(el => (el.style.display = 'inline-flex'));
                virementDetailsCart.style.display = 'none';
            });
        }
        if (virementAcceptCart) {
            virementAcceptCart.addEventListener('change', function () {
                const submitBtn = document.getElementById('virement-submit-cart');
                if (submitBtn) { submitBtn.disabled = !this.checked; }
            });
        }

        // Init
        renderCatalogueList();
        renderCart();
        updateCustomUI();
        recalcTotals();
    });
</script>

</body>
</html>