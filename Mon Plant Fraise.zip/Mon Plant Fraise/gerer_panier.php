<?php
// gerer_panier.php - VERSION CORRIGÉE POUR GÉRER LE PAIEMENT MENSUEL

session_start();
header('Content-Type: application/json');

// --- Vérification de la connexion de l'utilisateur ---
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté.']);
    exit();
}

// --- Initialisation du panier en session s'il n'existe pas ---
if (!isset($_SESSION['investment_cart'])) {
    $_SESSION['investment_cart'] = [];
}

// --- Récupération des données envoyées par le client (JavaScript) ---
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? null;
$data = $input['data'] ?? null;

if (!$action) {
    echo json_encode(['success' => false, 'error' => 'Action non spécifiée.']);
    exit();
}

// Pour des raisons de sécurité, il est fortement recommandé de récupérer les détails
// du produit (prix, nom) depuis la BDD ici, plutôt que de faire confiance au client.

switch ($action) {
    case 'ajouter':
        if (isset($data['id'])) {
            $productId = $data['id'];
            $paymentMode = $data['paymentMode'] ?? 'unique';
            
            // On crée une clé unique pour le panier en combinant l'ID et le mode de paiement.
            // Exemples: "1_unique", "1_mensuel", "2_unique", etc.
            $cartKey = $productId . '_' . $paymentMode;

            if (isset($_SESSION['investment_cart'][$cartKey])) {
                // Si l'article (avec ce mode de paiement) existe déjà, on augmente sa quantité.
                $_SESSION['investment_cart'][$cartKey]['quantity']++;
            } else {
                // Sinon, on l'ajoute au panier.
                $_SESSION['investment_cart'][$cartKey] = [
                    'id' => $productId,
                    'name' => $data['nom'],
                    'price' => (float)$data['prix'],
                    'rendement' => (float)$data['rendement'],
                    'quantity' => 1,
                    'paymentMode' => $paymentMode,
                    'cartKey' => $cartKey // On stocke la clé pour la retrouver facilement côté client.
                ];
            }
        }
        break;

    case 'augmenter':
        // On reçoit directement la clé unique de l'article à modifier.
        if (isset($data['cartKey']) && isset($_SESSION['investment_cart'][$data['cartKey']])) {
            $_SESSION['investment_cart'][$data['cartKey']]['quantity']++;
        }
        break;

    case 'diminuer':
        // On reçoit directement la clé unique de l'article à modifier.
        if (isset($data['cartKey']) && isset($_SESSION['investment_cart'][$data['cartKey']])) {
            $_SESSION['investment_cart'][$data['cartKey']]['quantity']--;
            // Si la quantité tombe à zéro, on supprime l'article du panier.
            if ($_SESSION['investment_cart'][$data['cartKey']]['quantity'] <= 0) {
                unset($_SESSION['investment_cart'][$data['cartKey']]);
            }
        }
        break;

    case 'recuperer':
        // Aucune action nécessaire, on renvoie simplement le panier en fin de script.
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Action inconnue.']);
        exit();
}

// On renvoie une réponse de succès avec le contenu du panier.
// array_values() transforme le tableau associatif en tableau simple, plus facile à gérer en JavaScript.
echo json_encode(['success' => true, 'cart' => array_values($_SESSION['investment_cart'])]);