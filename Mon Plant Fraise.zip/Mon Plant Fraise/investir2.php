<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investir chez Mon Plant Fraise</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* Styles Généraux */
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            color: #333;
            line-height: 1.6;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px 0;
        }

        /* En-tête */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 5%;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            position: relative;
            z-index: 1001;
        }
        .logo {
            display: flex;
            align-items: center;
            font-weight: 700;
            font-size: 1.2rem;
            text-decoration: none;
            color: #333;
        }
        .logo img {
            height: 60px;
            margin-right: 10px;
        }
        .main-menu a {
            text-decoration: none;
            color: #555;
            margin-left: 25px;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .main-menu a:hover {
            color: #6B8E23;
        }
        
        #menu-toggle, .hamburger-menu { 
            display: none; 
        }

        /* Bannière */
        .banner {
            background-image: url('images/banniere-investir.png');
            background-size: cover;
            background-position: center;
            height: 350px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            text-align: center;
            position: relative;
        }
        .banner::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0,0,0,0.3);
            z-index: 1;
        }
        .banner h1 {
            font-size: 3rem;
            font-weight: 700;
            z-index: 2;
        }
        
        /* Section Avantages */
        .advantages {
            display: flex;
            justify-content: space-around;
            padding: 50px 0;
            text-align: center;
        }
        .advantage-item {
            flex: 1;
            padding: 0 20px;
        }
        .advantage-item img {
            height: 200px; /* CORRIGÉ : Valeur initiale restaurée */
            margin-bottom: 10px; /* CORRIGÉ : Valeur initiale restaurée */
        }
        .advantage-item h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: #6B8E23;
        }
        .advantage-item p {
            font-size: 0.95rem;
            color: #666;
        }

        /* NOUVELLE SECTION : Investissement Anticipé */
        .early-investment-section {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            text-align: center;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .early-investment-section h2 {
            font-size: 1.8rem;
            color: #333;
            margin-bottom: 15px;
        }
        .early-investment-section p {
            font-size: 1rem;
            color: #555;
            max-width: 800px;
            margin: 0 auto 25px auto;
        }
        .early-investment-section .cta-button {
            background-color: #6B8E23;
            color: #fff;
            padding: 15px 35px;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .early-investment-section .cta-button:hover {
            background-color: #5A7C1F;
        }
        .early-investment-section .reassurance {
            font-size: 0.85rem;
            color: #777;
            margin-top: 15px;
        }

        /* Section Prise de Rendez-vous */
        .appointment-section {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 60px 0;
            gap: 40px;
        }
        .explanation-text, .appointment-module {
            flex: 1;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        .explanation-text { text-align: left; }
        .appointment-module { text-align: center; }
        .explanation-text h2, .appointment-module h2 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 20px;
        }
        .explanation-text p {
            color: #555;
            font-size: 1rem;
            line-height: 1.8;
        }

        /* Calendrier & Créneaux (styles inchangés) */
        .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; margin-bottom: 20px; font-size: 0.9rem; color: #777; }
        .calendar-grid div { padding: 8px 5px; border-radius: 4px; }
        .day-name { font-weight: 700; color: #333; }
        .date { background-color: #eee; cursor: pointer; transition: background-color 0.2s ease; }
        .date:hover { background-color: #ddd; }
        .date.selected { background-color: #6B8E23; color: #fff; }
        .date.available { background-color: #D4EDDA; color: #333; font-weight: 600; }
        .date.available.selected { background-color: #6B8E23; color: #fff; }
        .time-slots { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 30px; }
        .time-slot { padding: 10px; border: 1px solid #ddd; border-radius: 5px; cursor: pointer; transition: background-color 0.2s ease, border-color 0.2s ease; font-size: 0.95rem; color: #555; }
        .time-slot.available { background-color: #E6F3E6; border-color: #C6E0B1; }
        .time-slot.available:hover { background-color: #C6E0B1; }
        .time-slot.selected { background-color: #6B8E23; color: #fff; border-color: #6B8E23; }

        /* Formulaire */
        .appointment-form input[type="text"], .appointment-form input[type="email"], .appointment-form input[type="tel"] { width: calc(100% - 24px); padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 1rem; }
        .appointment-form button { background-color: #6B8E23; color: #fff; padding: 15px 30px; border: none; border-radius: 5px; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: background-color 0.3s ease; width: 100%; }
        .appointment-form button:hover { background-color: #5A7C1F; }

        /* Responsive */
        @media (max-width: 992px) {
            .banner h1 { font-size: 2.5rem; }
            .advantages { flex-direction: column; padding: 30px 0; }
            .advantage-item { margin-bottom: 30px; }
            .appointment-section { flex-direction: column; align-items: center; }
            .explanation-text, .appointment-module, .early-investment-section { width: 90%; margin-bottom: 30px; }
        }

        @media (max-width: 768px) {
            .hamburger-menu { display: block; cursor: pointer; z-index: 1001; }
            .hamburger-menu span { display: block; width: 25px; height: 3px; background-color: #333; margin: 5px 0; transition: 0.3s; }
            .main-menu { display: none; flex-direction: column; position: absolute; top: 80px; left: 0; width: 100%; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 10px 0; z-index: 1000; }
            .main-menu a { margin: 10px 0; text-align: center; width: 100%; padding: 10px 0; }
            #menu-toggle:checked ~ .main-menu { display: flex; }
            .banner { height: 250px; }
            .banner h1 { font-size: 2rem; }
            .advantage-item img {
                height: 50px; /* CORRIGÉ : Valeur initiale restaurée */
            }
            .advantage-item h3 { font-size: 1.1rem; }
            .explanation-text h2, .appointment-module h2, .early-investment-section h2 { font-size: 1.5rem; }
            .calendar-grid { font-size: 0.8rem; }
            .time-slots { grid-template-columns: 1fr; }
        }

        /* CSS POUR LA POPUP (inchangé) */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.6); display: none; justify-content: center; align-items: center; z-index: 2000; }
        .modal-content { background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); text-align: center; max-width: 500px; width: 90%; position: relative; }
        .modal-content h2 { color: #6B8E23; margin-top: 0; }
        .modal-close { position: absolute; top: 10px; right: 15px; font-size: 28px; font-weight: bold; cursor: pointer; color: #aaa; }
        .modal-close:hover { color: #333; }
    </style>
</head>
<body>
    <header>
        <a href="/" class="logo">
            <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise">
        </a>
        
        <div class="nav-container">
            <input type="checkbox" id="menu-toggle" style="display: none;"/>
            <label for="menu-toggle" class="hamburger-menu">
                <span></span><span></span><span></span>
            </label>
            <nav class="main-menu">
                <a href="index.php">Accueil</a>
                <a href="commander.php">Commander mes fraises</a>
                <a href="espace-client.php">Espace Client</a>
            </nav>
        </div>
    </header>

    <div class="banner">
        <h1>Faites fructifier votre épargne</h1>
    </div>

    <div class="container advantages">
        <div class="advantage-item">
            <img src="/images/icone-rendement2.png" alt="Haut Rendement"> <h3>Haut Rendement</h3>
            <p>Profitez d'un modèle économique éprouvé et d'un marché en croissance.</p>
        </div>
        <div class="advantage-item">
            <img src="/images/icone-durable.png" alt="Projet Durable"> <h3>Projet Durable</h3>
            <p>Investissez dans une agriculture locale et respectueuse de l'environnement.</p>
        </div>
        <div class="advantage-item">
            <img src="/images/icone-securite.png" alt="Sécurité"> <h3>Sécurité & Suivi</h3>
            <p>Bénéficiez d'un suivi transparent de votre investissement et de l'expertise de nos équipes.</p>
        </div>
    </div>

    <div class="container">
        <div class="early-investment-section">
            <h2>🚀 Prenez une longueur d'avance !</h2>
            <p>
                Vous êtes prêt à nous rejoindre ? Créez votre compte dès maintenant et effectuez un premier investissement.
                Votre placement sera <strong>plafonné à 3000€</strong> jusqu'à la validation de votre profil lors de l'appel de sélection.
            </p>
            <p>
                <strong>Votre garantie :</strong> Si votre candidature n'est pas retenue, vous serez <strong>intégralement remboursé, sans aucun frais.</strong>
            </p>
            <a href="creer-compte.php" class="cta-button">Créer mon compte et investir</a>
            <p class="reassurance">La planification de votre appel de sélection restera une étape nécessaire pour finaliser votre dossier.</p>
        </div>
    </div>
    <div class="container appointment-section" id="appointment-module">
        <div class="explanation-text">
            <h2>Pourquoi un appel de sélection ?</h2>
            <p>Notre engagement est de construire des partenariats durables et fructueux. L'appel de sélection nous permet de comprendre vos objectifs d'investissement et de nous assurer que notre modèle correspond parfaitement à vos attentes. C'est l'occasion d'échanger en toute transparence, de répondre à toutes vos questions et de vous présenter les détails de notre projet d'investissement.</p>
            <p>Cette étape est essentielle pour garantir une adéquation mutuelle et pour que vous puissiez investir en toute confiance dans un projet qui vous ressemble.</p>
        </div>
        <div class="appointment-module">
            <h2>Planifiez votre appel</h2>

            <?php
            if (isset($_GET['status']) && $_GET['status'] == 'error') {
                echo '<p style="color: red; font-weight: bold;">Une erreur est survenue. Veuillez réessayer.</p>';
            }
            ?>

            <div class="calendar-grid">
                 <div class="day-name">Lun</div>
                 <div class="day-name">Mar</div>
                 <div class="day-name">Mer</div>
                 <div class="day-name">Jeu</div>
                 <div class="day-name">Ven</div>
                 <div class="day-name">Sam</div>
                 <div class="day-name">Dim</div>
                 <div class="date available" data-date="2025-09-08">8</div>
                 <div class="date available" data-date="2025-09-09">9</div>
                 <div class="date available" data-date="2025-09-10">10</div>
                 <div class="date available" data-date="2025-09-11">11</div>
                 <div class="date available" data-date="2025-09-12">12</div>
                 <div class="date">13</div>
                 <div class="date">14</div>
                 <div class="date available" data-date="2025-09-15">15</div>
                 <div class="date available" data-date="2025-09-16">16</div>
                 <div class="date available" data-date="2025-09-17">17</div>
                 <div class="date available" data-date="2025-09-18">18</div>
                 <div class="date available" data-date="2025-09-19">19</div>
                 <div class="date">20</div>
                 <div class="date">21</div>
                 <div class="date available" data-date="2025-09-22">22</div>
                 <div class="date available" data-date="2025-09-23">23</div>
                 <div class="date available" data-date="2025-09-24">24</div>
                 <div class="date available" data-date="2025-09-25">25</div>
                 <div class="date available" data-date="2025-09-26">26</div>
                 <div class="date">27</div>
                 <div class="date">28</div>
            </div>

            <h3>Créneaux disponibles le <span id="selected-date-display"></span></h3>
            <div class="time-slots">
                <div class="time-slot available">9h00</div>
                <div class="time-slot available">10h30</div>
                <div class="time-slot available">14h00</div>
                <div class="time-slot available">15h30</div>
            </div>
            
            <form class="appointment-form" action="process_rdv.php" method="POST">
                <input type="hidden" name="date_rdv" id="hidden-date" required>
                <input type="hidden" name="heure_rdv" id="hidden-time" required>
                <input type="text" name="nom_complet" placeholder="Nom Complet" required>
                <input type="tel" name="telephone" placeholder="Numéro de Téléphone" required>
                <input type="email" name="email" placeholder="Adresse E-mail" required>
                <button type="submit">Planifier mon appel</button>
            </form>
        </div>
    </div>

    <div id="confirmationModal" class="modal-overlay">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal()">&times;</span>
            <h2>Demande Envoyée !</h2>
            <p>Votre demande de rendez-vous a bien été enregistrée.</p>
            <p>Un email de confirmation vient de vous être envoyé à l'adresse que vous avez renseignée. Pensez à vérifier vos spams.</p>
        </div>
    </div>

    <script>
        function closeModal() {
            const modal = document.getElementById('confirmationModal');
            modal.style.display = 'none';
            window.history.pushState({}, document.title, window.location.pathname + window.location.hash);
        }

        document.addEventListener('DOMContentLoaded', function() {
            const dates = document.querySelectorAll('.calendar-grid .date.available');
            const timeSlots = document.querySelectorAll('.time-slots .time-slot.available');
            const selectedDateDisplay = document.getElementById('selected-date-display');
            const hiddenDateInput = document.getElementById('hidden-date');
            const hiddenTimeInput = document.getElementById('hidden-time');
            const monthNames = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
            
            dates.forEach(date => {
                date.addEventListener('click', function() {
                    dates.forEach(d => d.classList.remove('selected'));
                    this.classList.add('selected');
                    const fullDate = this.getAttribute('data-date');
                    hiddenDateInput.value = fullDate;
                    const dateObj = new Date(fullDate + 'T00:00:00');
                    selectedDateDisplay.textContent = `${dateObj.getDate()} ${monthNames[dateObj.getMonth()]} ${dateObj.getFullYear()}`;
                });
            });

            timeSlots.forEach(slot => {
                slot.addEventListener('click', function() {
                    timeSlots.forEach(s => s.classList.remove('selected'));
                    this.classList.add('selected');
                    hiddenTimeInput.value = this.textContent;
                });
            });
            
            if (dates.length > 0) { dates[0].click(); }
            if (timeSlots.length > 0) { timeSlots[0].click(); }

            document.querySelector('.appointment-form').addEventListener('submit', function(event) {
                if (!hiddenDateInput.value || !hiddenTimeInput.value) {
                    alert('Veuillez sélectionner une date et un créneau horaire.');
                    event.preventDefault();
                }
            });
            
            const modal = document.getElementById('confirmationModal');
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('status') && urlParams.get('status') === 'success') {
                modal.style.display = 'flex';
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    closeModal();
                }
            }
        });
    </script>
</body>
</html>