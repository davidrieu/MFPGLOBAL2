<?php
// loginap.php — Inscription filleul (style login.php)
// - Préremplit le code parrain (défaut MPF102569), readonly si lock=1
// - Propage discount & UTM vers login.php
// - Inscrit l'utilisateur dans `users`, puis redirige vers login.php
// - DEBUG PERSISTANT : ?debug=1 (GET/POST) + mémorisation session
// - ÉVITE l’INSERT dans users.code_parrain si cette colonne est UNIQUE (réservée au code unique DU COMPTE)

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/db_connection.php';

// ---------- DEBUG PERSISTANT ----------
$debug_get  = isset($_GET['debug'])  && $_GET['debug'] === '1';
$debug_post = isset($_POST['debug']) && $_POST['debug'] === '1';
if ($debug_get) { $_SESSION['debug_loginap'] = 1; }
$__DEBUG = $debug_get || $debug_post || (!empty($_SESSION['debug_loginap']));

if ($__DEBUG) {
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
  $logDir = __DIR__ . '/logs';
  if (!is_dir($logDir)) { @mkdir($logDir, 0775, true); }
  @ini_set('error_log', $logDir . '/php-error.log');
  if (isset($pdo) && $pdo instanceof PDO) {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
  }
  function dd(...$vars) {
    echo "<pre style='background:#0b1020;color:#c5f467;padding:10px;border-radius:8px;white-space:pre-wrap'>";
    foreach ($vars as $v) { var_dump($v); }
    echo "</pre>";
  }
}

// Helpers schéma
function tableHasColumn(PDO $pdo, string $table, string $col): bool {
  $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE :c");
  $stmt->execute([':c' => $col]);
  return (bool)$stmt->fetch();
}
function columnIsUnique(PDO $pdo, string $table, string $col): bool {
  $stmt = $pdo->prepare("SHOW INDEX FROM `$table` WHERE Column_name = :c AND Non_unique = 0");
  $stmt->execute([':c' => $col]);
  return (bool)$stmt->fetch();
}

// Si déjà connecté -> espace client
if (isset($_SESSION['user_id'])) {
  header('Location: espace-client.php');
  exit();
}

// --------- Paramètres GET ---------
$parrain  = strtoupper(trim($_GET['parrain'] ?? 'MPF102569'));
$lock     = ($_GET['lock'] ?? '1') === '1';
$discount = trim($_GET['discount'] ?? '30');
$utm = [
  'utm_source'   => $_GET['utm_source']   ?? 'dashboard',
  'utm_medium'   => $_GET['utm_medium']   ?? 'affiliate',
  'utm_campaign' => $_GET['utm_campaign'] ?? ''
];

// Mémorisation funnel
$_SESSION['aff_parrain']  = $parrain;
$_SESSION['aff_locked']   = $lock ? 1 : 0;
$_SESSION['aff_discount'] = $discount;
$_SESSION['aff_utm']      = $utm;

// Lien vers login.php avec propagation (et debug si actif)
$qLogin = [
  'parrain'  => $parrain,
  'lock'     => $lock ? '1' : '0',
  'discount' => $discount
] + array_filter($utm, fn($v) => $v !== '');
if ($__DEBUG) { $qLogin['debug'] = '1'; }
$loginHref = 'login.php?' . http_build_query($qLogin);

// CSRF
if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error_message = '';

// ==========================
//   TRAITEMENT INSCRIPTION
// ==========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    // CSRF
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
      throw new Exception('CSRF token invalide.');
    }

    // Inputs
    $prenom       = trim($_POST['prenom']   ?? '');
    $nom          = trim($_POST['nom']      ?? '');
    $email        = trim($_POST['email']    ?? '');
    $password_raw = (string)($_POST['password']  ?? '');
    $password2    = (string)($_POST['password2'] ?? '');
    $accept       = isset($_POST['accept']) || isset($_POST['accept_cgu']); // selon nom

    // Code parrain issu du GET/hidden; si lock=1 on ignore toute modif visuelle
    $parrain_post  = strtoupper(trim($_POST['parrain'] ?? $parrain));
    $lock_post     = ($_POST['lock'] ?? ($lock ? '1' : '0')) === '1';
    if ($lock_post) { $parrain_post = $parrain; } // sécurité

    $discount_post = trim($_POST['discount'] ?? $discount);
    $utm_post = [
      'utm_source'   => $_POST['utm_source']   ?? $utm['utm_source'],
      'utm_medium'   => $_POST['utm_medium']   ?? $utm['utm_medium'],
      'utm_campaign' => $_POST['utm_campaign'] ?? $utm['utm_campaign'],
    ];

    if ($__DEBUG) {
      error_log('[loginap] POST fields: ' . json_encode([
        'prenom'=>$prenom, 'nom'=>$nom, 'email'=>$email,
        'parrain'=>$parrain_post, 'lock'=>$lock_post, 'discount'=>$discount_post,
        'utm'=>$utm_post
      ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }

    // Validations simples
    if ($prenom === '' || $nom === '' || $email === '' || $password_raw === '' || $password2 === '') {
      throw new Exception('Veuillez remplir tous les champs requis.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      throw new Exception('Adresse email invalide.');
    }
    if (strlen($password_raw) < 8) {
      throw new Exception('Le mot de passe doit contenir au moins 8 caractères.');
    }
    if ($password_raw !== $password2) {
      throw new Exception('Les mots de passe ne correspondent pas.');
    }
    if (!$accept) {
      throw new Exception('Merci d’accepter les CGU.');
    }

    // Vérifie doublon email
    $st = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
    $st->execute([':email' => $email]);
    if ($st->fetchColumn()) {
      throw new Exception("Un compte existe déjà avec cet email.");
    }

    // --- Détection du schéma `users` ---
    $hasPrenom       = tableHasColumn($pdo, 'users', 'prenom');
    $hasName         = tableHasColumn($pdo, 'users', 'name');
    $hasNom          = tableHasColumn($pdo, 'users', 'nom');
    $hasEmail        = tableHasColumn($pdo, 'users', 'email');
    $hasPwd          = tableHasColumn($pdo, 'users', 'password');
    $hasPwdHash      = tableHasColumn($pdo, 'users', 'password_hash');
    $hasCodeParrain  = tableHasColumn($pdo, 'users', 'code_parrain'); // ATTENTION: peut être UNIQUE
    $isUniqueCodePar = $hasCodeParrain ? columnIsUnique($pdo, 'users', 'code_parrain') : false;

    // Colonnes possibles pour stocker le code du *parrain* utilisé (non unique)
    $possibleSponsorCodeCols = [
      'parrain_code', 'code_parrain_utilise', 'code_parrain_parent', 'parrain', 'sponsor_code'
    ];
    $sponsorCodeCol = null;
    foreach ($possibleSponsorCodeCols as $c) {
      if (tableHasColumn($pdo, 'users', $c)) { $sponsorCodeCol = $c; break; }
    }

    // Parfois on a un lien par id -> parrain_id
    $hasParrainId = tableHasColumn($pdo, 'users', 'parrain_id');
    $parrain_user_id = null;
    if ($hasParrainId) {
      $st = $pdo->prepare("SELECT id FROM users WHERE code_parrain = :cp LIMIT 1");
      $st->execute([':cp' => $parrain_post]);
      $parrain_user_id = $st->fetchColumn() ?: null;
    }

    $hasCreatedAt    = tableHasColumn($pdo, 'users', 'created_at');

    if (!$hasEmail) {
      throw new Exception("La colonne 'email' est absente de la table users.");
    }
    if (!$hasPwd && !$hasPwdHash) {
      throw new Exception("Aucune colonne mot de passe trouvée (attendue: 'password' ou 'password_hash').");
    }

    // Hash pwd
    $pwd_h = password_hash($password_raw, PASSWORD_DEFAULT);

    // Construction dynamique INSERT
    $fields = [];
    $placeholders = [];
    $params = [];

    if ($hasPrenom)        { $fields[] = 'prenom';       $placeholders[]=':prenom';     $params[':prenom'] = $prenom; }
    if ($hasName)          { $fields[] = 'name';         $placeholders[]=':name';       $params[':name']   = $nom; } // nom de famille dans 'name' si pas de 'nom'
    if ($hasNom)           { $fields[] = 'nom';          $placeholders[]=':nom';        $params[':nom']    = $nom; }
    if ($hasEmail)         { $fields[] = 'email';        $placeholders[]=':email';      $params[':email']  = $email; }
    if ($hasPwd)           { $fields[] = 'password';     $placeholders[]=':pwd';        $params[':pwd']    = $pwd_h; }
    if (!$hasPwd && $hasPwdHash) { $fields[] = 'password_hash'; $placeholders[]=':pwd'; $params[':pwd']    = $pwd_h; }

    // NE PAS toucher à users.code_parrain si c'est UNIQUE (cette colonne est le code unique DU COMPTE)
    if ($hasCodeParrain && !$isUniqueCodePar) {
      // seulement si non unique -> on peut y stocker le code du parrain utilisé
      $fields[] = 'code_parrain';
      $placeholders[]=':cp_used';
      $params[':cp_used'] = $parrain_post;
    }

    // Stockage “propre” du code parrain utilisé
    if ($sponsorCodeCol) {
      $fields[] = $sponsorCodeCol;
      $placeholders[] = ':parrain_code_used';
      $params[':parrain_code_used'] = $parrain_post;
    }

    // Lien par ID si dispo
    if ($hasParrainId && $parrain_user_id) {
      $fields[] = 'parrain_id';
      $placeholders[]=':parrain_id';
      $params[':parrain_id'] = $parrain_user_id;
    }

    if ($hasCreatedAt)     { $fields[] = 'created_at';   $placeholders[]=':created_at'; $params[':created_at'] = date('Y-m-d H:i:s'); }

    if (empty($fields)) {
      throw new Exception("Impossible de construire l’insertion : aucune colonne compatible trouvée.");
    }

    if ($__DEBUG) {
      dd('SCHEMA CHECK', [
        'hasCodeParrain' => $hasCodeParrain,
        'isUniqueCodePar'=> $isUniqueCodePar,
        'sponsorCodeCol' => $sponsorCodeCol,
        'hasParrainId'   => $hasParrainId,
        'parrain_user_id'=> $parrain_user_id
      ]);
    }

    $sql = "INSERT INTO users (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
    if ($__DEBUG) { error_log('[loginap] SQL='.$sql.' params='.json_encode($params)); }
    $ins = $pdo->prepare($sql);
    $ins->execute($params);

    if ($__DEBUG) { dd('INSERT OK', ['sql'=>$sql, 'params'=>$params]); }

    // Redirection vers login.php (avec les paramètres)
    header('Location: ' . $loginHref);
    exit();

  } catch (PDOException $e) {
    error_log('[loginap] PDO ERROR code='.$e->getCode().' msg='.$e->getMessage());
    if ($__DEBUG) {
      dd('PDOException', [
        'code' => (string)$e->getCode(),
        'message' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
      ]);
    }
    // Erreur doublon connue -> message plus clair
    if ((string)$e->getCode() === '23000' && stripos($e->getMessage(), 'Duplicate entry') !== false) {
      $error_message = "Impossible d’utiliser ce champ pour le code parrain : contrainte d’unicité. (Le code du parrain est bien pris en compte ailleurs.)";
    } else {
      $error_message = "Erreur technique. Veuillez réessayer plus tard.";
    }
  } catch (Throwable $e) {
    error_log('[loginap] ERROR '.$e->getMessage());
    if ($__DEBUG) {
      dd('Throwable', [
        'message' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
        'POST'   => $_POST,
      ]);
    }
    $error_message = $__DEBUG ? $e->getMessage() : "Erreur technique. Veuillez réessayer plus tard.";
  }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>Inscription - Mon Plant Fraise</title>

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

  <style>
    *, *::before, *::after { box-sizing: border-box; }
    :root{
      --primary-color:#2E7D32;
      --primary-gradient:linear-gradient(135deg,#4CAF50,#2E7D32);
      --background-color:#F4F6F8;
      --card-background-color:#ffffff;
      --text-color:#212121;
      --text-color-light:#757575;
      --error-color:#c62828;
      --error-bg-color:#ffebee;
      --border-radius:12px;
      --input-h: 48px;
    }
    html, body { height: 100%; }
    body{
      font-family:'Roboto',sans-serif;
      background-color:var(--background-color);
      margin:0;
      display:flex;
      justify-content:center;
      align-items:flex-start;
      padding:24px 12px;
    }
    .login-wrapper{
      display:grid;
      grid-template-columns:1fr 1fr;
      width:100%;
      max-width:900px;
      background-color:var(--card-background-color);
      border-radius:var(--border-radius);
      box-shadow:0 10px 30px rgba(0,0,0,0.1);
      overflow:hidden;
    }
    .branding-panel{
      background:var(--primary-gradient);
      color:#fff;
      display:flex; flex-direction:column; justify-content:center; align-items:center;
      padding:40px; text-align:center;
    }
    .branding-panel h1{ font-family:'Poppins',sans-serif; font-size:24px; margin-bottom:10px; }
    .branding-panel p{ font-size:16px; opacity:.9; }
    .form-panel{
      padding:32px 40px;
      display:flex; flex-direction:column; justify-content:flex-start;
      max-height: calc(100vh - 48px);
      overflow-y:auto;
      scrollbar-gutter: stable both-edges;
      background:#fff;
    }
    .form-logo-container{ text-align:center; margin-bottom:16px; }
    .form-logo-container img{ max-width:200px; height:auto; }
    h2{ font-family:'Poppins',sans-serif; font-size:28px; color:var(--text-color); margin:0 0 16px 0; text-align:center; }
    .form-group{ margin-bottom:14px; }
    .form-group label{ display:block; margin-bottom:8px; color:var(--text-color); font-weight:500; white-space: nowrap; }
    .input-wrapper{ position:relative; }
    .input-wrapper .material-symbols-outlined{
      position:absolute; left:14px; top:50%; transform:translateY(-50%);
      color:var(--text-color-light);
      pointer-events:none;
    }
    .form-group input, .form-group select{
      width:100%; height:var(--input-h);
      padding:0 44px 0 44px;
      border:1px solid #ddd; border-radius:var(--border-radius);
      font-size:16px; background:#fff; transition:border-color .2s, box-shadow .2s; line-height: var(--input-h);
    }
    .form-group input:focus, .form-group select:focus{
      outline:none; border-color:var(--primary-color);
      box-shadow:0 0 0 3px rgba(76,175,80,.15);
    }
    .toggle-visibility{
      position:absolute; right:10px; top:50%; transform:translateY(-50%);
      width:32px; height:32px; border-radius:8px; border:1px solid transparent;
      display:flex; align-items:center; justify-content:center;
      background:#fff; cursor:pointer;
    }
    .toggle-visibility:hover{ background:#f7faf7; border-color:#e5f0e5; }
    .toggle-visibility .material-symbols-outlined{ color:#6b7280; pointer-events:none; }
    .readonly{ background:#f5f5f5; color:#666; cursor:not-allowed; }
    .row-2{ display:grid; grid-template-columns:1fr 1fr; gap:12px; }
    @media (max-width: 560px){ .row-2{ grid-template-columns:1fr; } }
    .btn-submit{
      width:100%; height:50px; background:var(--primary-gradient); color:#fff;
      border:none; border-radius:var(--border-radius); font-size:16px; font-weight:700; cursor:pointer; transition:all .2s ease;
    }
    .btn-submit:hover{ box-shadow:0 4px 12px rgba(46,125,50,.4); transform:translateY(-2px); }
    .btn-outline{
      display:inline-block; width:100%; padding:12px; background:#fff; color:var(--primary-color);
      border:1px solid #A5D6A7; border-radius:var(--border-radius); font-size:15px; font-weight:700;
      text-align:center; text-decoration:none; transition:all .2s ease; white-space:nowrap;
    }
    .btn-outline:hover{ box-shadow:0 4px 12px rgba(46,125,50,.15); transform:translateY(-1px); }
    .btn-cgv{
      display:inline-flex; align-items:center; justify-content:center;
      padding:6px 10px; border-radius:999px; border:1px solid #A5D6A7;
      background:#fff; color:var(--primary-color); font-size:12px; font-weight:700; line-height:1; white-space:nowrap; cursor:pointer; text-decoration:none;
    }
    .btn-cgv:hover{ background:#f8fffa; }
    .error-message{
      display:flex; align-items:center; gap:10px; background:var(--error-bg-color); color:var(--error-color);
      padding:12px; border-radius:var(--border-radius); margin-bottom:14px; border:1px solid var(--error-color);
    }
    .links{ text-align:center; margin-top:12px; font-size:14px; }
    .links a{ color:var(--primary-color); text-decoration:none; font-weight:500; }
    .links a:hover{ text-decoration:underline; }
    @media (max-width: 900px){
      body{ padding:16px 10px; }
      .login-wrapper{ grid-template-columns:1fr; max-width:520px; }
      .branding-panel{ display:none; }
      .form-panel{ padding:24px; max-height: calc(100vh - 32px); }
    }
    @media (max-height: 740px){
      .form-panel{ max-height: calc(100vh - 28px); }
    }
  </style>
</head>
<body>
  <div class="login-wrapper">
    <div class="branding-panel">
      <h1>Bienvenue chez Mon Plant Fraise</h1>
      <p>Créez votre compte pour profiter de l’avantage filleul.</p>
    </div>

    <div class="form-panel">
      <div class="form-logo-container">
        <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise" />
      </div>

      <h2>Inscription</h2>

      <?php if (!empty($error_message)): ?>
        <div class="error-message">
          <span class="material-symbols-outlined">warning</span>
          <span><?php echo htmlspecialchars($error_message); ?></span>
        </div>
      <?php endif; ?>

      <!-- Formulaire d'inscription -->
      <form action="<?php
          $qs = $_GET;
          if ($__DEBUG) $qs['debug'] = '1';
          $self = $_SERVER['PHP_SELF'] . (empty($qs) ? '' : '?' . http_build_query($qs));
          echo htmlspecialchars($self);
        ?>" method="post" id="register-form" novalidate>
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>" />
        <?php if ($__DEBUG): ?><input type="hidden" name="debug" value="1"><?php endif; ?>

        <!-- on propage parrain / lock / discount / utm -->
        <input type="hidden" name="parrain"  value="<?php echo htmlspecialchars($parrain); ?>" />
        <input type="hidden" name="lock"     value="<?php echo $lock ? '1' : '0'; ?>" />
        <input type="hidden" name="discount" value="<?php echo htmlspecialchars($discount); ?>" />
        <?php foreach ($utm as $k=>$v): if($v!==''): ?>
          <input type="hidden" name="<?php echo htmlspecialchars($k); ?>" value="<?php echo htmlspecialchars($v); ?>" />
        <?php endif; endforeach; ?>

        <!-- Code parrain (affiché, readonly si lock=1) -->
        <div class="form-group">
          <label for="code_parrain">Code parrain</label>
          <div class="input-wrapper">
            <span class="material-symbols-outlined">group_add</span>
            <input
              type="text"
              id="code_parrain"
              value="<?php echo htmlspecialchars($parrain); ?>"
              <?php echo $lock ? 'readonly class="readonly"' : ''; ?>
              aria-readonly="<?php echo $lock ? 'true' : 'false'; ?>"
            />
          </div>
          <div style="color: var(--text-color-light); font-size: 12px; margin-top: 6px;">
            Ce code sera appliqué à votre compte. <?php echo $lock ? "Il ne peut pas être modifié." : "Vous pouvez le modifier avant validation."; ?>
          </div>
        </div>

        <!-- Identité -->
        <div class="row-2">
          <div class="form-group">
            <label for="prenom">Prénom</label>
            <div class="input-wrapper">
              <span class="material-symbols-outlined">badge</span>
              <input type="text" name="prenom" id="prenom" required />
            </div>
          </div>
          <div class="form-group">
            <label for="nom">Nom</label>
            <div class="input-wrapper">
              <span class="material-symbols-outlined">badge</span>
              <input type="text" name="nom" id="nom" required />
            </div>
          </div>
        </div>

        <!-- Email -->
        <div class="form-group">
          <label for="email">Adresse Email</label>
          <div class="input-wrapper">
            <span class="material-symbols-outlined">mail</span>
            <input type="email" name="email" id="email" required autocomplete="email" />
          </div>
        </div>

        <!-- Mots de passe -->
        <div class="row-2">
          <div class="form-group">
            <label for="password">Mot de passe</label>
            <div class="input-wrapper">
              <span class="material-symbols-outlined">lock</span>
              <input type="password" name="password" id="password" minlength="8" required autocomplete="new-password" />
              <button type="button" class="toggle-visibility" data-target="password" aria-label="Afficher le mot de passe">
                <span class="material-symbols-outlined">visibility</span>
              </button>
            </div>
          </div>
          <div class="form-group">
            <label for="password2">Confirmer le mot de passe</label>
            <div class="input-wrapper">
              <span class="material-symbols-outlined">lock</span>
              <input type="password" name="password2" id="password2" minlength="8" required autocomplete="new-password" />
              <button type="button" class="toggle-visibility" data-target="password2" aria-label="Afficher le mot de passe">
                <span class="material-symbols-outlined">visibility</span>
              </button>
            </div>
          </div>
        </div>

        <!-- CGU + CGV -->
        <div class="form-group" style="margin-top: 4px;">
          <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
            <label style="display:flex; align-items:center; gap:8px; margin:0;">
              <input type="checkbox" id="accept" name="accept" required />
              <span style="color: var(--text-color-light); white-space:nowrap;">J’accepte les CGU et la politique de confidentialité.</span>
            </label>
            <a class="btn-cgv" href="cgv.php" target="_blank" rel="noopener">CGV</a>
          </div>
        </div>

        <!-- Avantage -->
        <div style="color: var(--text-color-light); font-size: 13px; margin: 6px 0 12px;">
          Avantage filleul : <strong>-<?php echo htmlspecialchars($discount); ?>%</strong> appliqué en permanence grâce à la team Sentinel.
        </div>

        <div class="form-group" style="margin-top:6px;">
          <button type="submit" class="btn-submit">Créer mon compte</button>
        </div>
      </form>

      <div class="links" style="margin-bottom:4px;">
        Déjà inscrit ?<br />
        <a class="btn-outline" style="display:inline-block; margin-top:10px;" href="<?php echo htmlspecialchars($loginHref); ?>">
          Se connecter
        </a>
      </div>
    </div>
  </div>

  <script>
    // Validation minimale côté client
    (function(){
      const form = document.getElementById('register-form');
      const p1 = document.getElementById('password');
      const p2 = document.getElementById('password2');
      const accept = document.getElementById('accept');
      form.addEventListener('submit', function(e){
        if (p1.value.length < 8 || p2.value.length < 8) { e.preventDefault(); alert('Le mot de passe doit contenir au moins 8 caractères.'); return; }
        if (p1.value !== p2.value) { e.preventDefault(); alert('Les mots de passe ne correspondent pas.'); return; }
        if (!accept.checked) { e.preventDefault(); alert('Merci d’accepter les CGU.'); return; }
      });
    })();

    // Toggle visibilité des mots de passe
    (function(){
      document.querySelectorAll('.toggle-visibility').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-target');
          const input = document.getElementById(id);
          if (!input) return;
          const isPwd = input.getAttribute('type') === 'password';
          input.setAttribute('type', isPwd ? 'text' : 'password');
          btn.querySelector('.material-symbols-outlined').textContent = isPwd ? 'visibility_off' : 'visibility';
          btn.setAttribute('aria-label', isPwd ? 'Masquer le mot de passe' : 'Afficher le mot de passe');
        });
      });
    })();
  </script>
</body>
</html>



