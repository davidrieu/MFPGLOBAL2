<style>
    /* Superposition qui assombrit le reste de la page */
    .cart-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 998;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    /* Styles pour le panneau de panier lui-même */
    .cart-panel {
        position: fixed;
        top: 0;
        right: 0;
        width: 100%;
        max-width: 400px; /* Largeur maximale du panier */
        height: 100%;
        background-color: #fff;
        box-shadow: -5px 0 15px rgba(0,0,0,0.15);
        z-index: 999;
        display: flex;
        flex-direction: column;
        transform: translateX(100%); /* Position initiale, caché à droite */
        transition: transform 0.3s ease-in-out;
    }

    /* Classe 'open' pour afficher le panier et l'overlay */
    .cart-panel.open, .cart-overlay.open {
        transform: translateX(0);
        opacity: 1;
        visibility: visible;
    }

    /* En-tête du panier */
    .cart-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        border-bottom: 1px solid #eee;
    }
    .cart-header h2 {
        margin: 0;
        font-size: 1.5rem;
    }
    .close-cart-btn {
        background: none;
        border: none;
        font-size: 2rem;
        cursor: pointer;
        color: #888;
        line-height: 1;
    }

    /* Corps du panier (liste des produits) */
    .cart-body {
        flex-grow: 1;
        overflow-y: auto; /* Permet de scroller si beaucoup d'articles */
        padding: 20px;
    }
    .cart-item {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
        gap: 15px;
    }
    .cart-item img {
        width: 70px;
        height: 70px;
        object-fit: cover;
    }
    .item-details {
        flex-grow: 1;
    }
    .item-details h3 {
        margin: 0 0 5px 0;
        font-size: 1rem;
    }
    .item-details .price {
        color: #6B8E23;
        font-weight: 600;
    }
    .item-quantity {
        display: flex;
        align-items: center;
    }
    .item-quantity input {
        width: 30px;
        text-align: center;
        border: 1px solid #ccc;
        padding: 5px 0;
        border-radius: 0;
    }
    .item-remove {
        color: #aaa;
        text-decoration: none;
        font-size: 0.9rem;
        margin-top: 5px;
        display: block;
    }
    .item-remove:hover {
        color: #d9534f;
    }

    /* Pied de page du panier */
    .cart-footer {
        padding: 20px;
        border-top: 1px solid #eee;
        background-color: #f8f8f8;
    }
    .cart-subtotal {
        display: flex;
        justify-content: space-between;
        font-size: 1.2rem;
        font-weight: 600;
        margin-bottom: 20px;
    }
    .checkout-btn {
        display: block;
        width: 100%;
        background-color: #6B8E23;
        color: #fff;
        text-align: center;
        padding: 15px 0;
        text-decoration: none;
        font-size: 1.1rem;
        font-weight: 600;
        border: none;
        border-radius: 0; /* Bouton carré */
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    .checkout-btn:hover {
        background-color: #5A7C1F;
    }

    /* Icône/Bulle flottante du panier */
    .cart-bubble {
        position: fixed;
        bottom: 25px;
        right: 25px;
        width: 60px;
        height: 60px;
        background-color: #6B8E23;
        color: white;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        z-index: 997;
        font-size: 1.8rem; /* Taille de l'icône SVG */
    }
    .cart-item-count {
        position: absolute;
        top: -5px;
        right: -5px;
        background-color: #D9534F; /* Rouge pour le badge */
        color: white;
        border-radius: 50%;
        width: 24px;
        height: 24px;
        font-size: 0.8rem;
        font-weight: 700;
        display: flex;
        justify-content: center;
        align-items: center;
        border: 2px solid #fff;
    }
</style>

<div class="cart-overlay"></div>

<aside class="cart-panel">
    <header class="cart-header">
        <h2>Votre Panier</h2>
        <button class="close-cart-btn" aria-label="Fermer le panier">&times;</button>
    </header>
    <div class="cart-body">
        <div class="cart-item">
            <img src="images/barquette-500g.jpg" alt="Barquette de fraises">
            <div class="item-details">
                <h3>Barquette Découverte (500g)</h3>
                <span class="price">9,90€</span>
                <a href="#" class="item-remove">Retirer</a>
            </div>
            <div class="item-quantity">
                <input type="number" value="1" min="1">
            </div>
        </div>
        
        <div class="cart-item">
            <img src="images/cagette-2kg.jpg" alt="Cagette de fraises">
            <div class="item-details">
                <h3>Cagette Famille (2Kg)</h3>
                <span class="price">34,90€</span>
                <a href="#" class="item-remove">Retirer</a>
            </div>
            <div class="item-quantity">
                <input type="number" value="1" min="1">
            </div>
        </div>
        
    </div>
    <footer class="cart-footer">
        <div class="cart-subtotal">
            <span>Sous-total :</span>
            <span>44,80€</span> </div>
        <a href="checkout.php" class="checkout-btn">Valider et Payer</a> </footer>
</aside>

<div class="cart-bubble">
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" class="bi bi-cart3" viewBox="0 0 16 16">
        <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.74 14H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
    </svg>
    <div class="cart-item-count">2</div> </div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const cartPanel = document.querySelector('.cart-panel');
        const cartOverlay = document.querySelector('.cart-overlay');
        const openCartBtn = document.querySelector('.cart-bubble');
        const closeCartBtn = document.querySelector('.close-cart-btn');

        function openCart() {
            cartPanel.classList.add('open');
            cartOverlay.classList.add('open');
        }

        function closeCart() {
            cartPanel.classList.remove('open');
            cartOverlay.classList.remove('open');
        }

        openCartBtn.addEventListener('click', openCart);
        closeCartBtn.addEventListener('click', closeCart);
        cartOverlay.addEventListener('click', closeCart);
    });
</script>