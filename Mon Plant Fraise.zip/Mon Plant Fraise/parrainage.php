<?php
// VERSION COMPLÈTE ET CORRIGÉE

// Débogage (à commenter ou retirer en production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Démarrer la session et vérifier la connexion de l'utilisateur
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 2. Connexion à la base de données
require_once 'db_connection.php';

require_once 'badge_sentinel.php';

// 3. Initialisation des variables
$user_id = $_SESSION['user_id'];
$mon_code_parrain = null;
$ma_cagnotte = 0.00;
$filleuls = [];
$codes_promo_disponibles = [];
$message_cagnotte = '';
$message_general = '';

// --- GESTION DE LA GÉNÉRATION D'UN NOUVEAU CODE PARRAIN ---
if (isset($_POST['generer_mon_code'])) {
    try {
        // Avant de générer, on récupère la liste complète des codes existants pour garantir l'unicité
        $stmt_old = $pdo->query("SELECT DISTINCT code_parrain FROM parrainage WHERE code_parrain IS NOT NULL");
        $old_codes = $stmt_old->fetchAll(PDO::FETCH_COLUMN);
        
        $stmt_new = $pdo->query("SELECT code_parrain FROM users WHERE code_parrain IS NOT NULL");
        $new_codes = $stmt_new->fetchAll(PDO::FETCH_COLUMN);
        
        $all_existing_codes = array_unique(array_merge($old_codes, $new_codes));

        // Boucle de génération
        $nouveau_code = '';
        do {
            $prefix = ['FRAISE', 'PLANT', 'RECOLTE', 'SOLEIL'][array_rand(['FRAISE', 'PLANT', 'RECOLTE', 'SOLEIL'])];
            $nombre_aleatoire = random_int(1000, 9999);
            $nouveau_code_potentiel = $prefix . $nombre_aleatoire;
        } while (in_array($nouveau_code_potentiel, $all_existing_codes));
        $nouveau_code = $nouveau_code_potentiel;

        // On enregistre le nouveau code DANS LA TABLE USERS
        $stmt_update = $pdo->prepare("UPDATE users SET code_parrain = :code WHERE id = :user_id");
        $stmt_update->execute(['code' => $nouveau_code, 'user_id' => $user_id]);
        
        header('Location: parrainage.php?code_genere=1');
        exit();

    } catch (PDOException $e) {
        $message_general = "Une erreur technique est survenue. Impossible de générer le code.";
    }
}


if (isset($_GET['code_genere']) && $_GET['code_genere'] == 1) {
    $message_general = "Votre code de parrainage a été généré avec succès !";
}

// --- GESTION DE L'UTILISATION DE LA CAGNOTTE ---
if (isset($_POST['utiliser_cagnotte'])) {
    $stmt_cagnotte_check = $pdo->prepare("SELECT cagnotte FROM users WHERE id = :user_id");
    $stmt_cagnotte_check->execute(['user_id' => $user_id]);
    $cagnotte_actuelle = $stmt_cagnotte_check->fetchColumn();

    $pourcentage = filter_input(INPUT_POST, 'pourcentage_cagnotte', FILTER_VALIDATE_INT);

    if ($pourcentage && in_array($pourcentage, [20, 50, 100])) {
        $montant_a_utiliser = round(($cagnotte_actuelle * $pourcentage) / 100, 2);

        if ($montant_a_utiliser > 0 && $montant_a_utiliser <= $cagnotte_actuelle) {
            
            $pdo->beginTransaction();
            try {
                // Étape A : Générer un code promo unique
                $code_promo_genere = '';
                do {
                    $code_promo_potentiel = 'CAGNOTTE-' . strtoupper(bin2hex(random_bytes(4)));
                    $stmt_exist = $pdo->prepare("SELECT id FROM promo_codes WHERE code = :code");
                    $stmt_exist->execute(['code' => $code_promo_potentiel]);
                } while ($stmt_exist->fetch());
                $code_promo_genere = $code_promo_potentiel;

                // Étape B : Insérer le code promo dans la nouvelle table
                $stmt_insert_code = $pdo->prepare(
                    "INSERT INTO promo_codes (user_id, code, montant_reduction) VALUES (:user_id, :code, :montant)"
                );
                $stmt_insert_code->execute([
                    'user_id' => $user_id,
                    'code' => $code_promo_genere,
                    'montant' => $montant_a_utiliser
                ]);

                // Étape C : Débiter la cagnotte de l'utilisateur
                $stmt_debit_cagnotte = $pdo->prepare("UPDATE users SET cagnotte = cagnotte - :montant WHERE id = :user_id");
                $stmt_debit_cagnotte->execute(['montant' => $montant_a_utiliser, 'user_id' => $user_id]);

                $pdo->commit();
                $message_cagnotte = "Félicitations ! Votre code de réduction '<strong>" . htmlspecialchars($code_promo_genere) . "</strong>' d'une valeur de " . number_format($montant_a_utiliser, 2, ',', ' ') . " € a été créé.";

            } catch (PDOException $e) {
                $pdo->rollBack();
                $message_cagnotte = "Une erreur technique est survenue. Votre cagnotte n'a pas été modifiée. Veuillez réessayer.";
            }
        } else {
            $message_cagnotte = "Le montant demandé est invalide ou supérieur à votre cagnotte.";
        }
    } else {
        $message_cagnotte = "Veuillez sélectionner un pourcentage valide.";
    }
}


// --- LOGIQUE PRINCIPALE D'AFFICHAGE ET DE RÉCUPÉRATION DES DONNÉES ---
try {
    // Récupération du code parrain
    $stmt_parrainage = $pdo->prepare("SELECT code_parrain FROM parrainage WHERE parrain_id = :user_id LIMIT 1");
    $stmt_parrainage->execute(['user_id' => $user_id]);
    $result_parrainage = $stmt_parrainage->fetch(PDO::FETCH_ASSOC);
    if ($result_parrainage && !empty($result_parrainage['code_parrain'])) {
        $mon_code_parrain = $result_parrainage['code_parrain'];
    } else {
        $stmt_users = $pdo->prepare("SELECT code_parrain FROM users WHERE id = :user_id");
        $stmt_users->execute(['user_id' => $user_id]);
        $result_users = $stmt_users->fetch(PDO::FETCH_ASSOC);
        if ($result_users && !empty($result_users['code_parrain'])) {
            $mon_code_parrain = $result_users['code_parrain'];
        }
    }

    // Récupérer la cagnotte de l'utilisateur
    $stmt_cagnotte = $pdo->prepare("SELECT cagnotte FROM users WHERE id = :user_id");
    $stmt_cagnotte->execute(['user_id' => $user_id]);
    $ma_cagnotte = $stmt_cagnotte->fetchColumn() ?: 0.00;

    // Récupérer la liste des filleuls
    $stmt_filleuls = $pdo->prepare("SELECT email_utilisateur, gain_parrain, date_demande FROM parrainage WHERE parrain_id = :parrain_id AND statut_demande = 'approuvé' ORDER BY date_demande DESC");
    $stmt_filleuls->execute(['parrain_id' => $user_id]);
    $filleuls = $stmt_filleuls->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les codes promo non utilisés de l'utilisateur
    $stmt_promo_codes = $pdo->prepare("SELECT code, montant_reduction, date_creation FROM promo_codes WHERE user_id = :user_id AND est_utilise = FALSE ORDER BY date_creation DESC");
    $stmt_promo_codes->execute(['user_id' => $user_id]);
    $codes_promo_disponibles = $stmt_promo_codes->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("ERREUR TECHNIQUE : Impossible de récupérer les informations de parrainage. " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parrainage - Mon Plant Fraise</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <style>
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --primary-color: #2E7D32;
            --primary-color-dark: #1B5E20;
            --primary-color-light: #C8E6C9;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --text-color: #212121;
            --text-color-light: #757575;
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; transition: transform 0.3s ease-in-out; }
        .sidebar-header { margin-bottom: 30px; text-align: center; }
        .sidebar-header a img { max-width: 80%; height: auto; }
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover { background-color: #eeeeee; }
        .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 260px; padding: 30px; width: calc(100% - 260px); }
        .main-header { font-family: 'Poppins', sans-serif; font-size: 28px; font-weight: 700; margin-bottom: 25px; }
        .card { background-color: var(--card-background-color); padding: 25px; margin-bottom: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .card h2 { font-family: 'Poppins', sans-serif; color: var(--text-color); margin-top: 0; font-size: 20px; font-weight: 600; margin-bottom: 20px; }
        .message-feedback { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: var(--primary-color-light); color: var(--primary-color-dark); border: 1px solid var(--primary-color); }
        .text-center { text-align: center; }

        .sponsorship-code-container { text-align: center; }
        .sponsorship-code { background-color: #e8f5e9; border: 2px dashed var(--primary-color); color: var(--primary-color-dark); padding: 15px 20px; font-size: 1.5rem; font-family: 'Poppins', sans-serif; font-weight: 700; letter-spacing: 2px; display: inline-block; border-radius: var(--border-radius); margin: 10px 0; }
        .total-earnings { font-size: 1.2rem; font-weight: 500; }
        .total-earnings span { font-family: 'Poppins', sans-serif; color: var(--primary-color); font-weight: 700; }

        .btn { padding: 12px 28px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 16px; font-weight: 700; text-decoration: none; display: inline-block; transition: all 0.2s ease; }
        .btn-primary { background: var(--primary-gradient); color: white; }
        .btn-primary:hover { box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4); transform: translateY(-2px); }
        .btn-primary:disabled { background: #BDBDBD; cursor: not-allowed; box-shadow: none; transform: none; }

        .cagnotte-options { display: flex; flex-direction: column; gap: 15px; margin-top: 15px; margin-bottom: 20px; }
        .cagnotte-options label { display: flex; align-items: center; background-color: #f9f9f9; padding: 15px; border-radius: var(--border-radius); border: 1px solid #eee; cursor: pointer; transition: border-color 0.2s, background-color 0.2s; }
        .cagnotte-options label:has(input:checked) { border-color: var(--primary-color); background-color: var(--primary-color-light); }
        .cagnotte-options input[type="radio"] { appearance: none; -webkit-appearance: none; width: 20px; height: 20px; border: 2px solid #ccc; border-radius: 50%; margin-right: 15px; transition: border-color 0.2s; }
        .cagnotte-options input[type="radio"]:checked { border-color: var(--primary-color); background-color: var(--primary-color); box-shadow: inset 0 0 0 3px white; }
        
        .responsive-list .list-item { display: flex; justify-content: space-between; align-items: center; padding: 15px; background-color: #F9F9F9; border-radius: var(--border-radius); margin-bottom: 10px; }
        .list-item .item-details { flex-grow: 1; }
        .list-item .item-details .main-info { font-weight: 500; color: var(--text-color); }
        .list-item .item-details .sub-info { font-size: 14px; color: var(--text-color-light); }
        .list-item .item-value { font-family: 'Poppins', sans-serif; font-size: 16px; font-weight: 600; color: var(--primary-color); }
        .responsive-list-footer { margin-top: 20px; padding-top: 15px; border-top: 2px solid var(--primary-color-light); text-align: right; font-size: 18px; font-weight: 600; }
        .responsive-list-footer .total-value { font-family: 'Poppins', sans-serif; color: var(--primary-color); }
        
        /* AJOUT : Styles pour les cartes repliables */
        .card.collapsible > h2 {
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            user-select: none; /* Empêche la sélection du texte du titre */
        }
        .card.collapsible > h2 .indicator {
            transition: transform 0.3s ease-in-out;
        }
        .card-content {
            overflow: hidden;
            max-height: 2000px; /* Assez grand pour tout contenu */
            opacity: 1;
            transition: max-height 0.4s ease-in-out, padding 0.4s ease-in-out, opacity 0.3s ease-in-out, margin 0.4s ease-in-out;
        }
        .card.collapsed .card-content {
            max-height: 0;
            padding-top: 0;
            padding-bottom: 0;
            margin-top: 0;
            margin-bottom: 0;
            opacity: 0;
        }
        .card.collapsed > h2 {
           margin-bottom: 0; /* Enlève la marge du h2 quand replié */
        }
        .card.collapsed > h2 .indicator {
            transform: rotate(-90deg);
        }
        
        .toggle-btn { display: none; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .container { margin-left: 0; padding: 15px; width: 100%; }
            .toggle-btn { display: block; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size: 24px; display: flex; align-items: center; justify-content: center; }
            .main-header { margin-top: 70px; font-size: 24px; }
            .card { padding: 20px; }
            .sponsorship-code { font-size: 1.2rem; }
            .responsive-list .list-item { flex-direction: column; align-items: flex-start; gap: 8px; }
            .responsive-list .item-value { width: 100%; text-align: left; }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php" class="active"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Parrainage</h1>

    <?php if (!empty($message_general)): ?>
        <div class="message-feedback"><?php echo htmlspecialchars($message_general); ?></div>
    <?php endif; ?>

    <div class="card">
        <h2>Mon Code & Cagnotte</h2>
        <div class="card-content">
            <?php if (empty($mon_code_parrain)): ?>
                <div class="text-center">
                    <p>Générez votre code personnel pour commencer à parrainer vos amis !</p>
                    <form method="post" action="parrainage.php" style="margin-top: 15px;">
                        <button type="submit" name="generer_mon_code" class="btn btn-primary">Générer mon code</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="sponsorship-code-container">
                    <p>Partagez ce code avec vos amis :</p>
                    <div class="sponsorship-code"><?php echo htmlspecialchars($mon_code_parrain); ?></div>
                    <p class="total-earnings">Cagnotte disponible : <span><?php echo number_format($ma_cagnotte, 2, ',', ' '); ?> €</span></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="card collapsible">
        <h2>
            <span>Utiliser ma Cagnotte</span>
            <span class="material-symbols-outlined indicator">expand_more</span>
        </h2>
        <div class="card-content">
            <?php if (!empty($message_cagnotte)): ?>
                <div class="message-feedback"><?php echo $message_cagnotte; ?></div>
            <?php endif; ?>
            <p>Convertissez une partie de votre cagnotte en code de réduction à utiliser sur votre prochaine commande.</p>
            <form method="post" action="parrainage.php">
                    <div class="cagnotte-options">
                        <?php
                        $options = [20, 50, 100];
                        $options_disponibles = false;
                        foreach ($options as $p) {
                            $montant_option = round(($ma_cagnotte * $p) / 100, 2);
                            if ($montant_option >= 0.01) {
                                $options_disponibles = true;
                                echo '<label>';
                                echo '<input type="radio" name="pourcentage_cagnotte" value="' . $p . '" required>';
                                echo '<span>' . $p . '% (' . number_format($montant_option, 2, ',', ' ') . ' €)</span>';
                                echo '</label>';
                            }
                        }
                        if (!$options_disponibles) {
                            echo "<p>Votre cagnotte est insuffisante pour générer un code.</p>";
                        }
                        ?>
                    </div>
                <button type="submit" name="utiliser_cagnotte" class="btn btn-primary" <?php if (!$options_disponibles) echo 'disabled'; ?>>Générer un code de réduction</button>
            </form>
        </div>
    </div>
    
    <div class="card collapsible">
        <h2>
            <span>Mes Réductions Disponibles</span>
            <span class="material-symbols-outlined indicator">expand_more</span>
        </h2>
        <div class="card-content">
            <?php if (empty($codes_promo_disponibles)): ?>
                <p>Vous n'avez pas de code de réduction disponible pour le moment.</p>
            <?php else: ?>
                <div class="responsive-list">
                    <?php foreach ($codes_promo_disponibles as $promo_code): ?>
                    <div class="list-item">
                        <div class="item-details">
                            <div class="main-info"><?php echo htmlspecialchars($promo_code['code']); ?></div>
                            <div class="sub-info">Créé le <?php echo date('d/m/Y', strtotime($promo_code['date_creation'])); ?></div>
                        </div>
                        <div class="item-value"><?php echo number_format($promo_code['montant_reduction'], 2, ',', ' '); ?> €</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card collapsible">
        <h2>
            <span>Historique de mes Parrainages</span>
            <span class="material-symbols-outlined indicator">expand_more</span>
        </h2>
        <div class="card-content">
            <?php if (empty($filleuls)): ?>
                <p>Vous n'avez pas encore de filleuls.</p>
            <?php else: ?>
                <div class="responsive-list">
                    <?php
                    $total_gains = 0;
                    foreach ($filleuls as $filleul):
                        $total_gains += $filleul['gain_parrain'];
                    ?>
                    <div class="list-item">
                         <div class="item-details">
                            <div class="main-info"><?php echo htmlspecialchars($filleul['email_utilisateur']); ?></div>
                            <div class="sub-info">Inscrit le <?php echo date('d/m/Y', strtotime($filleul['date_demande'])); ?></div>
                        </div>
                        <div class="item-value">+ <?php echo number_format($filleul['gain_parrain'], 2, ',', ' '); ?> €</div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="responsive-list-footer">
                    Total des gains : <span class="total-value"><?php echo number_format($total_gains, 2, ',', ' '); ?> €</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('open');
    }

    // AJOUT : Script pour gérer les cartes repliables
    document.addEventListener('DOMContentLoaded', () => {
        const collapsibleCards = document.querySelectorAll('.card.collapsible');

        collapsibleCards.forEach(card => {
            const header = card.querySelector('h2');
            if (header) {
                header.addEventListener('click', () => {
                    card.classList.toggle('collapsed');
                });
            }
        });
    });
</script>

</body>
</html>