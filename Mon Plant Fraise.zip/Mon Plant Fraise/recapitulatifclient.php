<?php
session_start();
require_once 'db_connection.php'; // Votre connexion à la BDD

// Vérifie la connexion et l'existence du panier d'investissement
if (!isset($_SESSION['user_id']) || !isset($_SESSION['investment_cart']) || empty($_SESSION['investment_cart'])) {
    header('Location: investclient.php');
    exit();
}

$panier = $_SESSION['investment_cart'];
$total = 0;
$totalAujourdhui = 0;
$totalMensualitesRestantes = 0;
$hasMonthlyPayment = false;
$rendementMoyenPondere = 0;
$quantiteTotale = 0;
$discount = 0;
$promo_message = '';
$user_id = $_SESSION['user_id'];

// --- Logique pour le code promo et parrainage ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['promo_code'])) {
    $promo_code = trim($_POST['promo_code']);
    
    // On nettoie les anciennes données de promo de la session avant de vérifier le nouveau code
    unset($_SESSION['promo_code'], $_SESSION['discount_percent'], $_SESSION['discount_amount'], $_SESSION['parrain_id'], $_SESSION['gain_parrain_percent']);

    if (!empty($promo_code)) {
        try {
            // 1. On cherche d'abord dans la table des codes promos classiques
            $stmt = $pdo->prepare("SELECT * FROM promo_codes WHERE code = :code AND is_active = 1");
            $stmt->execute(['code' => $promo_code]);
            $promo = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($promo) {
                // C'est un code promo standard
                $now = new DateTime();
                $starts_at = new DateTime($promo['starts_at']);
                $ends_at = $promo['ends_at'] ? new DateTime($promo['ends_at']) : null;
                
                if ($promo['est_utilise'] == 1) {
                    $promo_message = 'Ce code promo a déjà été utilisé.';
                } elseif ($now < $starts_at) {
                    $promo_message = 'Ce code promo n\'est pas encore actif.';
                } elseif ($ends_at && $now > $ends_at) {
                    $promo_message = 'Ce code promo a expiré.';
                } elseif ($promo['usage_limit'] > 0 && $promo['usage_count'] >= $promo['usage_limit']) {
                    $promo_message = 'La limite d\'utilisation pour ce code a été atteinte.';
                } else {
                    $_SESSION['promo_code'] = $promo['code'];
                    if ($promo['discount_percent'] > 0) {
                        $_SESSION['discount_percent'] = $promo['discount_percent'];
                    } elseif ($promo['montant_reduction'] > 0) {
                        $_SESSION['discount_amount'] = $promo['montant_reduction'];
                    }
                    $promo_message = 'Code promo appliqué avec succès !';
                }
            } else {
                // 2. Si non trouvé, on cherche dans la table de parrainage.

                // Nouvelle vérification : Un utilisateur ne peut être parrainé qu'une seule fois.
                $stmt_check_filleul = $pdo->prepare("SELECT COUNT(*) FROM parrainage WHERE filleul_id = :user_id");
                $stmt_check_filleul->execute(['user_id' => $user_id]);
                $is_already_filleul = $stmt_check_filleul->fetchColumn();

                if ($is_already_filleul > 0) {
                    $promo_message = 'Vous avez déjà bénéficié d\'une offre de parrainage.';
                } else {
                    // On vérifie la validité du code de parrainage.
                    // On prend n'importe quelle ligne correspondant au code pour vérifier les détails.
                    $stmt_parrain = $pdo->prepare("SELECT * FROM parrainage WHERE code_parrain = :code LIMIT 1");
                    $stmt_parrain->execute(['code' => $promo_code]);
                    $parrainage = $stmt_parrain->fetch(PDO::FETCH_ASSOC);

                    if (!$parrainage) {
                        $promo_message = 'Code de parrainage invalide.';
                    } elseif ($parrainage['parrain_id'] == $user_id) {
                        $promo_message = 'Vous ne pouvez pas utiliser votre propre code de parrainage.';
                    } elseif ($parrainage['statut_demande'] !== 'approuve') {
                        $promo_message = 'Ce code de parrainage n\'est pas encore approuvé.';
                    } elseif ($parrainage['remise_filleul'] <= 0) {
                        $promo_message = 'Ce code de parrainage est valide, mais n\'offre pas de remise.';
                    } else {
                        // Le code est valide et l'utilisateur peut être parrainé.
                        $_SESSION['promo_code'] = $parrainage['code_parrain'];
                        $_SESSION['discount_percent'] = $parrainage['remise_filleul'];
                        
                        // On stocke les informations du parrain pour lui créditer son gain après le paiement
                        $_SESSION['parrain_id'] = $parrainage['parrain_id'];
                        $_SESSION['gain_parrain_percent'] = $parrainage['gain_parrain'];

                        $promo_message = 'Code de parrainage appliqué avec succès !';
                    }
                }
            }
        } catch (PDOException $e) {
            $promo_message = 'Erreur lors de la validation du code.';
            // error_log('PDO Error: ' . $e->getMessage());
        }
    }
}


// --- Nouvelle logique de calcul des totaux et des réductions ---

// 1. Calculer la valeur totale du panier AVANT toute réduction.
$total = 0;
foreach ($panier as $item) {
    $total += $item['price'] * $item['quantity'];
}

// 2. Calculer le montant de la réduction sur cette valeur totale.
$discount = 0;
if (isset($_SESSION['promo_code'])) {
    if (isset($_SESSION['discount_percent'])) {
        $discount = ($total * $_SESSION['discount_percent']) / 100;
    } elseif (isset($_SESSION['discount_amount'])) {
        $discount = $_SESSION['discount_amount'];
    }
}
// S'assurer que la réduction ne peut pas être supérieure au total.
$discount = min($total, $discount);

// 3. Calculer les montants à payer en appliquant la réduction au prorata sur chaque item.
foreach ($panier as $item) {
    $itemTotalValue = $item['price'] * $item['quantity'];
    $quantiteTotale += $item['quantity'];
    $rendementMoyenPondere += ($item['rendement'] ?? 0) * $item['quantity'];

    // On calcule la valeur de l'item après application de sa part de réduction
    // Le facteur de réduction est (1 - (remise_totale / total_brut))
    $reductionFactor = ($total > 0) ? (1 - ($discount / $total)) : 1;
    $valeurReduiteItem = $itemTotalValue * $reductionFactor;

    if (isset($item['paymentMode']) && $item['paymentMode'] === 'mensuel') {
        $hasMonthlyPayment = true;
        // Le paiement d'aujourd'hui et les mensualités sont basés sur la NOUVELLE valeur réduite
        $totalAujourdhui += ($valeurReduiteItem / 12);
        $totalMensualitesRestantes += ($valeurReduiteItem * 11 / 12);
    } else {
        // Pour les paiements uniques, le total d'aujourd'hui est la valeur réduite
        $totalAujourdhui += $valeurReduiteItem;
    }
}

// Les totaux finaux sont maintenant correctement calculés.
// $total reste la valeur avant réduction pour l'affichage.
$totalFinalAujourdhui = $totalAujourdhui;
$rendementMoyenFinal = $quantiteTotale > 0 ? ($rendementMoyenPondere / $quantiteTotale) : 0;

// ==============================================================================
// POINT CRUCIAL : Le montant final est stocké ici.
// Votre page de paiement (create-checkout-session.php) DOIT utiliser
// $_SESSION['final_total'] pour obtenir le montant à facturer.
// ==============================================================================
$_SESSION['final_total'] = $totalFinalAujourdhui;
$_SESSION['order_total_value'] = $total; // On stocke aussi la valeur totale pour le calcul du gain parrain

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Récapitulatif de votre investissement - Mon Plant Fraise</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    <style>
        :root {
            --primary-color: #2E7D32;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --text-color: #212121;
            --text-color-light: #757575;
            --background-color: #FFFFFF; /* Fond blanc */
            --card-background-color: #F9FAFB; /* Gris très clair pour les cartes */
            --border-color: #E5E7EB;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        
        body {
            background-color: var(--background-color);
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            color: var(--text-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 1100px;
            margin: 0 auto;
        }

        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-container img {
            max-width: 180px; /* Logo plus grand */
            height: auto;
        }
        
        .main-header {
            font-family: 'Poppins', sans-serif;
            font-size: 32px; /* Titre plus impactant */
            font-weight: 700;
            margin-bottom: 30px;
            text-align: center;
        }

        .recap-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            align-items: flex-start;
        }

        .card {
            background-color: var(--card-background-color);
            box-shadow: var(--box-shadow);
            border-radius: var(--border-radius);
            padding: 30px; /* Plus d'espace intérieur */
            border: 1px solid var(--border-color); /* Bordure subtile */
        }
        
        .card h2 {
            font-family: 'Poppins', sans-serif;
            font-size: 22px;
            margin-top: 0;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }

        .recap-table {
            width: 100%;
            border-collapse: collapse;
        }
        .recap-table th, .recap-table td {
            padding: 15px 0; /* Plus d'espacement vertical */
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .recap-table th { font-weight: 500; color: var(--text-color-light); font-size: 14px; }
        .recap-table td { font-weight: 500; }
        .recap-table tr:last-child td { border: none; }
        .text-right { text-align: right; }
        .item-name { font-weight: 700; }
        .item-name small { font-weight: 400; color: var(--primary-color); display: block; font-size: 12px; margin-top: 2px;}

        .summary-table { width: 100%; }
        .summary-table tr td {
            padding: 12px 0;
            font-size: 16px;
        }
        .summary-table tr.total-row td {
            border-top: 2px solid #ddd;
            padding-top: 15px;
            font-size: 22px; /* Total plus visible */
        }
        .summary-table strong {
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
        }
        .discount-row { color: var(--primary-color); }

        .promo-form {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .promo-form input {
            flex-grow: 1;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
        }
        .promo-message {
            margin-top: 10px;
            font-size: 14px;
            font-weight: 500;
        }
        
        .actions { margin-top: 25px; }
        .btn-primary {
            display: block;
            width: 100%;
            padding: 16px; /* Bouton plus grand */
            background: var(--primary-gradient);
            color: white;
            text-decoration: none;
            border-radius: var(--border-radius);
            font-weight: 700;
            transition: all 0.2s ease;
            text-align: center;
            border: none;
            cursor: pointer;
            font-size: 18px; /* Texte plus grand */
            letter-spacing: 0.5px;
        }
        .btn-primary:hover {
            box-shadow: 0 6px 15px rgba(46, 125, 50, 0.4);
            transform: translateY(-3px);
        }
        .btn-primary:disabled {
            background: #BDBDBD;
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }
        .btn-secondary {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: var(--text-color-light);
            text-decoration: none;
            font-weight: 500;
        }
        
        .monthly-details {
            background-color: #FFFFFF;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-top: 20px;
            border: 1px solid var(--border-color);
        }
        .monthly-details h3 {
            margin-top: 0;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
        }
        .monthly-details p { margin: 5px 0 0 0; font-size: 14px; }

        .engagement-check {
            margin: 20px 0 10px 0;
            display: flex;
            align-items: flex-start;
        }
        .engagement-check input {
            margin-right: 10px;
            margin-top: 4px;
        }
        .engagement-check label {
            font-size: 14px;
            color: var(--text-color-light);
            cursor: pointer;
        }

        @media (max-width: 992px) {
            .recap-grid { grid-template-columns: 1fr; }
            body { align-items: flex-start; }
        }

    </style>
</head>
<body>

<div class="container">
    <div class="logo-container">
        <!-- Assurez-vous que le chemin vers votre logo est correct -->
        <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise">
    </div>
    <h1 class="main-header">Finalisez votre investissement</h1>

    <div class="recap-grid">
        <div class="card">
            <h2>Détail de mon panier</h2>
            <table class="recap-table">
                <thead>
                    <tr>
                        <th>Produit</th>
                        <th class="text-right">Rendement</th>
                        <th class="text-right">Quantité</th>
                        <th class="text-right">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($panier as $item): ?>
                        <tr>
                            <td class="item-name">
                                <?php echo htmlspecialchars($item['name']); ?>
                                <?php if(isset($item['paymentMode']) && $item['paymentMode'] === 'mensuel'): ?>
                                    <small>Paiement mensuel</small>
                                <?php endif; ?>
                            </td>
                            <td class="text-right"><?php echo htmlspecialchars($item['rendement'] ?? '0'); ?>%</td>
                            <td class="text-right"><?php echo $item['quantity']; ?></td>
                            <td class="text-right"><?php echo number_format($item['price'] * $item['quantity'], 2, ',', ' '); ?> €</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h2>Résumé du paiement</h2>
            
            <table class="summary-table">
                <tr>
                    <td>Valeur totale du panier</td>
                    <td class="text-right"><?php echo number_format($total, 2, ',', ' '); ?> €</td>
                </tr>
                <?php if ($discount > 0): ?>
                <tr class="discount-row">
                    <td>
                        Réduction 
                        <?php 
                        if (isset($_SESSION['discount_percent'])) {
                            echo "({$_SESSION['discount_percent']}%)";
                        }
                        ?>
                    </td>
                    <td class="text-right">- <?php echo number_format($discount, 2, ',', ' '); ?> €</td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td>Rendement moyen</td>
                    <td class="text-right"><?php echo number_format($rendementMoyenFinal, 2, ',', ' '); ?>%</td>
                </tr>
                <tr class="total-row">
                    <td><strong>À payer aujourd'hui</strong></td>
                    <td class="text-right"><strong><?php echo number_format($totalFinalAujourdhui, 2, ',', ' '); ?> €</strong></td>
                </tr>
            </table>

            <?php if ($hasMonthlyPayment): ?>
                <div class="monthly-details">
                    <h3>Prochaines mensualités</h3>
                    <p>
                        Il vous restera <strong>11 mensualités</strong> de 
                        <strong><?php echo number_format($totalMensualitesRestantes / 11, 2, ',', ' '); ?> €</strong>
                        chacune.
                    </p>
                </div>
            <?php endif; ?>

            <div class="promo-section">
                <form method="POST" action="recapitulatifclient.php">
                    <label for="promo_code" style="font-weight: 500; font-size: 14px; display:block; margin-bottom:8px;">Code promo ou parrain</label>
                    <div class="promo-form">
                        <input type="text" id="promo_code" name="promo_code" placeholder="Entrez votre code" value="<?php echo isset($_SESSION['promo_code']) ? htmlspecialchars($_SESSION['promo_code']) : ''; ?>">
                        <button type="submit" class="btn-primary" style="padding: 12px 18px; width: auto; font-size: 16px;">Appliquer</button>
                    </div>
                     <?php if (!empty($promo_message)): ?>
                        <p class="promo-message" style="color: <?php echo (isset($_SESSION['promo_code']) && ($_SESSION['promo_code'] !== 'Code invalide ou déjà utilisé.' && $_SESSION['promo_code'] !== 'Erreur lors de la validation du code.' && $_SESSION['promo_code'] !== 'Vous ne pouvez pas utiliser votre propre code de parrainage.')) ? 'var(--primary-color)' : 'red'; ?>;">
                            <?php echo $promo_message; ?>
                        </p>
                    <?php endif; ?>
                </form>
            </div>

            <div class="actions">
                <?php if ($hasMonthlyPayment): ?>
                    <div class="engagement-check">
                        <input type="checkbox" id="engagement-mensuel">
                        <label for="engagement-mensuel">Je comprends et je m'engage à payer les 11 mensualités restantes.</label>
                    </div>
                <?php endif; ?>

                <a href="create-checkout-session.php" class="btn-primary" id="payment-btn">Procéder au paiement</a>
                <a href="investclient.php" class="btn-secondary">Modifier mon investissement</a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const engagementCheckbox = document.getElementById('engagement-mensuel');
    const paymentButton = document.getElementById('payment-btn');

    const updatePaymentButtonState = () => {
        if (engagementCheckbox && !engagementCheckbox.checked) {
            paymentButton.style.background = '#BDBDBD';
            paymentButton.style.cursor = 'not-allowed';
            paymentButton.href = 'javascript:void(0)';
        } else {
            paymentButton.style.background = ''; // Revient au style CSS
            paymentButton.style.cursor = 'pointer';
            paymentButton.href = 'create-checkout-session.php';
        }
    };

    if (engagementCheckbox) {
        engagementCheckbox.addEventListener('change', updatePaymentButtonState);
    }
    
    // Initial check on page load
    updatePaymentButtonState();
});
</script>

</body>
</html>





