<?php
echo "PHP fonctionne !";
?>