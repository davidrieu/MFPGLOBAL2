<button id="scrollTopBtn" title="Retour en haut">
    <span class="material-symbols-outlined">keyboard_arrow_up</span>
</button>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const scrollTopBtn = document.getElementById('scrollTopBtn');

    if (scrollTopBtn) {
        // Affiche ou masque le bouton en fonction du défilement
        window.onscroll = function() {
            if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
                scrollTopBtn.style.display = "block";
            } else {
                scrollTopBtn.style.display = "none";
            }
        };

        // Gère le clic sur le bouton pour remonter en haut de la page
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({top: 0, behavior: 'smooth'});
        });
    }
});
</script>