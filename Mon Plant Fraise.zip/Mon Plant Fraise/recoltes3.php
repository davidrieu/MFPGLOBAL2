<?php
// Débogage (à retirer en production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. SÉCURITÉ : Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// SÉCURITÉ : Générer un jeton CSRF pour les formulaires de renouvellement
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// 3. CONNEXION À LA BASE DE DONNÉES
require_once 'db_connection.php';

// 4. Initialisation des variables
$prenom = $_SESSION['user_prenom'] ?? '';
$contrats_en_cours = [];
$contrats_en_attente_renouvellement = [];
$contrats_clotures = [];
$montant_total_investi = 0;
$somme_ponderee_rendements = 0;
$somme_montants_pour_ponderation = 0;
$rendement_moyen_pondere = 0;
$somme_contrats_en_cours = 0;
$somme_rendements_actuels = 0;
$available_products = [];
$promo_codes_for_js = [];

try {
    $user_id = $_SESSION['user_id'];
    
    // --- LECTURE DES CODES PROMO (avec gestion de la cumulabilité) ---
    $codes_sql = "
        SELECT 
            code, discount_percent, montant_reduction, 'Code promo' as description, cumulable
        FROM promo_codes 
        WHERE 
            is_active = 1 
            AND (usage_limit IS NULL OR usage_count < usage_limit)
            AND (starts_at IS NULL OR starts_at <= NOW())
            AND (ends_at IS NULL OR ends_at >= NOW())
            AND (user_id IS NULL OR user_id = :user_id)
    ";

    $codes_stmt = $pdo->prepare($codes_sql);
    $codes_stmt->execute(['user_id' => $user_id]);
    $codes_from_db = $codes_stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($codes_from_db as $code_row) {
        $type = null;
        $valeur = 0;
        if (isset($code_row['discount_percent']) && $code_row['discount_percent'] > 0) {
            $type = 'percent';
            $valeur = $code_row['discount_percent'];
        } elseif (isset($code_row['montant_reduction']) && $code_row['montant_reduction'] > 0) {
            $type = 'amount';
            $valeur = $code_row['montant_reduction'];
        }

        if ($type) {
            $promo_codes_for_js[strtoupper($code_row['code'])] = [
                'valid' => true,
                'type' => $type,
                'value' => (float)$valeur,
                'label' => htmlspecialchars($code_row['code']),
                'stackable' => (bool)$code_row['cumulable']
            ];
        }
    }

    // --- LECTURE DES CODES PARRAIN (depuis users.code_parrain) ---
    $referral_codes_for_js = [];
    try {
        $refStmt = $pdo->query("
            SELECT UPPER(code_parrain) AS code
            FROM users
            WHERE code_parrain IS NOT NULL AND code_parrain <> ''
        ");
        while ($r = $refStmt->fetch(PDO::FETCH_ASSOC)) {
            $code = $r['code'];
            $referral_codes_for_js[$code] = [
                'valid'     => true,
                'type'      => 'percent', // suivi parrain, pas de remise
                'value'     => 5,
                'label'     => htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
                'stackable' => true
            ];
        }
    } catch (Exception $e) {
        $referral_codes_for_js = [];
    }
    
    // --- Requête SQL optimisée qui calcule statuts et dates ---
    $sql = "
        SELECT 
            c.id, c.user_prenom, c.date_souscription, c.montant, c.apport, c.taux_moyen, 
            c.statut AS statut_contrat_db,
            p.id AS produit_id, p.name AS produit_name, p.descriptif, p.duree_mois,
            dr.statut AS statut_retrait, dr.montant AS montant_retrait,

            DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH) AS date_fin_calculee,
            DATE_ADD(DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH), INTERVAL 30 DAY) AS deadline_renouvellement,

            CASE
                WHEN dr.statut = 'En attente' THEN 'en_attente_paiement'
                WHEN c.statut IN ('Clôturé', 'Renouvelé') THEN 'cloture'
                WHEN NOW() < DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH) THEN 'en_cours'
                WHEN NOW() BETWEEN DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH) AND DATE_ADD(DATE_ADD(c.date_souscription, INTERVAL p.duree_mois MONTH), INTERVAL 30 DAY) THEN 'en_attente_renouvellement'
                ELSE 'cloture'
            END AS statut_calcule
        FROM contrats AS c
        JOIN produits AS p ON c.produit_id = p.id
        LEFT JOIN demandes_retrait AS dr ON c.id = dr.contrat_id AND dr.user_id = c.user_id
        WHERE c.user_id = :user_id
        ORDER BY 
            CASE statut_calcule
                WHEN 'en_attente_renouvellement' THEN 1
                WHEN 'en_cours' THEN 2
                WHEN 'en_attente_paiement' THEN 3
                ELSE 4
            END,
            c.date_souscription DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $user_id]);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $statut = $row['statut_calcule'];
        $date_souscription = new DateTime($row['date_souscription']);
        $date_fin = new DateTime($row['date_fin_calculee']);
        $deadline_renouvellement = new DateTime($row['deadline_renouvellement']);
        $aujourdhui = new DateTime();
        
        $statut_class = '';
        $pourcentage_temps_ecoule = 0;

        switch ($statut) {
            case 'en_cours':
                $statut_class = 'status-en-cours';
                if ($date_fin > $date_souscription) {
                   $pourcentage_temps_ecoule = (($aujourdhui->getTimestamp() - $date_souscription->getTimestamp()) / ($date_fin->getTimestamp() - $date_souscription->getTimestamp())) * 100;
                }
                $somme_ponderee_rendements += $row['montant'] * $row['taux_moyen'];
                $somme_montants_pour_ponderation += $row['montant'];
                break;
            case 'en_attente_renouvellement':
                $statut_class = 'status-en-attente';
                $pourcentage_temps_ecoule = 100;
                break;
            case 'en_attente_paiement':
                $statut_class = 'status-paiement-attente';
                $pourcentage_temps_ecoule = 100;
                break;
            default: // 'cloture'
                $statut = 'cloture';
                $statut_class = 'status-cloture';
                $pourcentage_temps_ecoule = 100;
                break;
        }

        if ($statut === 'en_cours') {
            $montant_total_investi += $row['apport'];
        }
        
        $pourcentage_temps_ecoule = max(0, min(100, $pourcentage_temps_ecoule));
        
        // Calcul du rendement basé sur 'montant' pour la clarté
        $rendement_total_contrat = $row['montant'] * ($row['taux_moyen'] / 100);
        $rendement_actuel = $rendement_total_contrat * ($pourcentage_temps_ecoule / 100);

        $contrat_data = [
            'id' => $row['id'],
            'date_souscription' => $row['date_souscription'],
            'montant' => $row['montant'],
            'apport' => $row['apport'],
            'taux_moyen' => $row['taux_moyen'],
            'rendement_total_contrat' => $rendement_total_contrat,
            'rendement_actuel' => $rendement_actuel,
            'pourcentage_temps_ecoule' => $pourcentage_temps_ecoule,
            'produit_id' => $row['produit_id'],
            'produit_name' => $row['produit_name'],
            'produit_descriptif' => $row['descriptif'],
            'duree_mois' => (int)$row['duree_mois'],
            'statut' => $statut,
            'statut_class' => $statut_class,
            'temps_restant_renouvellement' => $deadline_renouvellement->getTimestamp(),
            'date_fin' => $date_fin->format('d/m/Y'),
            'montant_retrait' => $row['montant_retrait'],
            'db_statut' => $row['statut_contrat_db']
        ];
        
        if ($statut === 'en_cours') {
            $contrats_en_cours[] = $contrat_data;
        } elseif ($statut === 'en_attente_renouvellement') {
            $contrats_en_attente_renouvellement[] = $contrat_data;
        } else {
            $contrats_clotures[] = $contrat_data;
        }
    }
    
    foreach ($contrats_en_cours as $contrat) {
    // La valeur actuelle d'un contrat est sa valeur de base (`montant`) + ses gains actuels
    $somme_contrats_en_cours += $contrat['montant'] + $contrat['rendement_actuel'];
    
    // On continue de sommer les gains séparément pour l'affichage "Gains Actuels"
    $somme_rendements_actuels += $contrat['rendement_actuel'];
}

    if ($somme_montants_pour_ponderation > 0) {
        $rendement_moyen_pondere = $somme_ponderee_rendements / $somme_montants_pour_ponderation;
    }
    
    $products_sql = "SELECT id, name, descriptif, prix, duree_mois, taux FROM produits WHERE is_active = 1";
    $products_stmt = $pdo->query($products_sql);
    $available_products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("ERREUR TECHNIQUE : " . $e->getMessage());
} finally {
    $pdo = null;
}

if (isset($_SESSION['error_message'])) {
    echo '<div id="global-error-banner" style="position:sticky;top:0;z-index:9999;background:#fdecea;color:#b71c1c;padding:12px 15px;text-align:center;font-weight:600;border-bottom:1px solid #f5c2c7;">'
        . htmlspecialchars($_SESSION['error_message']) .
        '</div>';
    unset($_SESSION['error_message']);
}
$FORM_ERRORS = $_SESSION['form_errors'] ?? [];
unset($_SESSION['form_errors']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Récoltes - Mon Plant Fraise</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <style>
      :root{--primary-color:#2E7D32;--primary-color-light:#C8E6C9;--primary-gradient:linear-gradient(135deg, #4CAF50, #2E7D32);--warning-color:#FFA000;--info-color:#2196F3;--text-color:#212121;--text-color-light:#757575;--background-color:#F4F6F8;--card-background-color:#ffffff;--border-radius:12px;--box-shadow:0 4px 12px rgba(0,0,0,0.08);}
      body{background-color:var(--background-color);font-family:'Roboto',sans-serif;margin:0;display:flex;color:var(--text-color);}
      .sidebar{background-color:var(--card-background-color);width:260px;height:100vh;padding:20px;position:fixed;top:0;left:0;box-shadow:0 2px 10px rgba(0, 0, 0, 0.1);display:flex;flex-direction:column;z-index:1000;transition:transform 0.3s ease-in-out;}
      .sidebar-header{margin-bottom:30px;}
      .sidebar-header a img{max-width:80%;height:auto;display:block;margin:0 auto;}
      .sidebar ul{list-style-type:none;padding:0;margin:0;}
      .sidebar ul li a{display:flex;align-items:center;padding:12px 10px;margin-bottom:8px;text-decoration:none;color:var(--text-color-light);border-radius:var(--border-radius);font-weight:500;transition:background-color 0.2s ease, color 0.2s ease;}
      .sidebar ul li a .material-symbols-outlined{margin-right:15px;font-size:22px;}
      .sidebar ul li a:hover{background-color:#eeeeee;}
      .sidebar ul li a[href="recoltes.php"]{background-color:var(--primary-color);color:white;}
      .container{margin-left:280px;padding:30px;width:calc(100% - 280px);transition:margin-left 0.3s ease-in-out;}
      .main-header{font-family:'Poppins',sans-serif;font-size:28px;font-weight:700;margin-bottom:20px;}
      .summary-card{background:var(--primary-gradient);color:white;padding:20px;border-radius:var(--border-radius);margin-bottom:25px;box-shadow:0 6px 15px rgba(46,125,50,0.4);}
      .summary-card h3{margin-top:0;font-size:16px;font-weight:400;opacity:0.9;}
      .summary-card .summary-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px;margin-top:15px;}
      .summary-card .summary-item{font-size:14px;}
      .summary-card .summary-item strong{display:block;font-family:'Poppins',sans-serif;font-size:22px;font-weight:700;}
      .contracts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:25px;}
      .card{background-color:var(--card-background-color);border-radius:var(--border-radius);box-shadow:var(--box-shadow);margin-bottom:15px;overflow:hidden;padding:0;position:relative;}
      .card-header{padding:12px 18px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #eee;}
      .card-header h3{margin:0;font-size:18px;font-weight:500;}
      .card-content{padding:18px;}
      .status-en-cours .card-header{background-color:var(--primary-color-light);}
      .status-en-attente .card-header{background-color:#FFF3E0;}
      .status-cloture .card-header{background-color:#E0E0E0;color:var(--text-color-light);}
      .status-badge{font-size:12px;font-weight:500;padding:4px 10px;border-radius:16px;color:white;}
      .status-cloture .status-badge{background-color:#757575;}
      .status-en-attente .status-badge{background-color:var(--warning-color);}
      .info-item{display:flex;align-items:center;margin-bottom:12px;font-size:15px;color:var(--text-color-light);}
      .info-item .material-symbols-outlined{font-size:20px;margin-right:12px;color:var(--primary-color);}
      .info-item strong{color:var(--text-color);font-weight:500;margin-left:5px;}
      .rendement-actuel{color:var(--primary-color)!important;font-weight:700!important;}
      .progress-bar-container{background-color:#e0e0e0;border-radius:20px;overflow:hidden;margin-top:15px;}
      .progress-bar{height:10px;border-radius:20px;transition:width 0.5s;background:var(--primary-gradient);}
      .btn-renew, .quick-action-btn{display:inline-block;flex-grow:1;box-sizing:border-box;padding:12px;background-color:var(--warning-color);color:white;text-decoration:none;border:none;border-radius:8px;font-weight:700;cursor:pointer;transition:background-color 0.2s ease;font-size:14px;text-align:center;}
      .btn-renew:hover, .quick-action-btn:hover{background-color:#FB8C00;}
      .btn-renew { width: 100%; margin-top: 10px; background-color: var(--primary-color); }
      .quick-action-btn { background-color: #f0f0f0; color: #333; display:flex; align-items:center; justify-content:center; gap:8px; border: 1px solid #ddd; }
      .quick-actions { display:flex; gap:10px; }
      .no-contracts-message{background-color:#fff;padding:20px;border-radius:var(--border-radius);text-align:center;color:var(--text-color-light);}
      .final-yield-summary{background-color:var(--primary-color-light);border:1px solid var(--primary-color);color:var(--primary-color);padding:15px;margin-bottom:20px;border-radius:8px;text-align:center;}
      .final-yield-summary small{display:block;font-size:14px;}
      .final-yield-summary strong{display:block;font-family:'Poppins',sans-serif;font-size:24px;margin:5px 0;color:#212121;}
      .final-yield-summary span{font-size:13px;opacity:0.8;}
      .popup-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(0,0,0,0.7);display:none;justify-content:center;align-items:center;z-index:2000;}
      #renewal-popup-overlay .popup-content { max-width: 800px; }
      #details-popup-overlay .popup-content { max-width: 650px; }
      .popup-content{background-color:#fff;padding:25px;border-radius:var(--border-radius);box-shadow:0 5px 15px rgba(0,0,0,0.3);width:100%;position:relative;max-height:90vh;overflow-y:auto;box-sizing: border-box;}
      .popup-close-btn{position:absolute;top:10px;right:15px;font-size:28px;font-weight:bold;color:#aaa;cursor:pointer;}
      .popup-content h2{font-family:'Poppins',sans-serif;margin-top:0;color:var(--primary-color);text-align:center;}
      .popup-header-summary{text-align:center;margin-bottom:20px;}
      .popup-header-summary strong{font-family:'Poppins';font-size:32px;color:#212121;}
      .popup-header-summary span{color:var(--text-color-light);}
      .slider-container{padding:10px 0;}
      .slider{-webkit-appearance:none;width:100%;height:8px;background:#ddd;border-radius:5px;outline:none;}
      .slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:24px;height:24px;background:var(--primary-color);border-radius:50%;cursor:pointer;border:3px solid #fff;box-shadow:0 0 5px rgba(0,0,0,0.2);}
      .slider::-moz-range-thumb{width:24px;height:24px;background:var(--primary-color);border-radius:50%;cursor:pointer;border:3px solid #fff;box-shadow:0 0 5px rgba(0,0,0,0.2);}
      .slider-labels{display:flex;justify-content:space-between;font-size:12px;color:var(--text-color-light);padding:0 5px;}
      .preset-buttons { display: flex; justify-content: space-around; margin-bottom: 15px; gap: 10px; }
      .preset-btn { padding: 8px 12px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 20px; cursor: pointer; font-size: 13px; }
      .preset-btn:hover { background-color: #eee; }
      .calculation-results{display:flex;flex-direction:column;gap:10px;margin-top:20px;background-color:#f7f7f7;padding:15px;border-radius:8px;}
      .calculation-box{width:100%;text-align:center;}
      .calculation-box small{color:var(--text-color-light);}
      .calculation-box strong{font-size:20px;display:block;color:var(--primary-color);}
      .iban-section{margin-top:15px;}
      .iban-section label{display:block;margin-bottom:5px;font-size:14px;}
      .iban-section input{width:100%;box-sizing:border-box;padding:10px;border-radius:5px;border:1px solid #ccc;}
      .iban-section input.input-error {
  border-color: #d32f2f !important;
  box-shadow: 0 0 0 2px rgba(211,47,47,.15);
}
.form-feedback.error { color:#d32f2f; font-weight:600; }
      .popup-actions{display:flex;flex-direction:column;gap:10px;margin-top:25px;}
      .popup-btn{width:100%;padding:12px 24px;border:none;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer;box-sizing:border-box;}
      .popup-btn.primary{background-color:var(--primary-color);color:white;order:1;}
      .popup-btn.secondary{background-color:#eee;color:#333;order:2;}
      .hidden{display:none!important;}
      .allocation-section h3{font-family:'Poppins',sans-serif;font-size:16px;text-align:left;margin-bottom:10px; border-bottom: 2px solid var(--primary-color-light); padding-bottom: 5px;}
      .allocation-progress{margin-bottom:20px;}
      .progress-bar-track{background-color:#e0e0e0;border-radius:20px;height:12px;overflow:hidden;}
      .progress-bar-fill{background:var(--primary-gradient);height:100%;width:0%;border-radius:20px;transition:width 0.5s ease;}
      .progress-bar-fill.is-over { background: var(--warning-color); }
      .progress-text{font-size:14px;color:var(--text-color-light);margin-top:8px;text-align:center;}
      .product-item{display:flex;flex-direction:column;align-items:flex-start;gap:10px;padding:10px;border-bottom:1px solid #f0f0f0;}
      .product-item:last-child{border-bottom:none;}
      .product-item-info strong{display:block;}
      .product-item-info span{font-size:12px;color:var(--text-color-light);}
      .add-product-btn{padding:5px 15px;background-color:var(--primary-color-light);color:var(--primary-color);border:1px solid var(--primary-color);cursor:pointer;border-radius:20px;font-weight:bold;align-self:flex-end;}
      .add-product-btn:hover{background-color:var(--primary-color);color:white;}
      #reinvestment-cart .cart-item{display:flex;justify-content:space-between;align-items:center;background-color:#f9f9f9;padding:8px 12px;border-radius:5px;margin-bottom:5px;font-size:14px;}
      .remove-item-btn{cursor:pointer;color:#cc0000;font-weight:bold;}
      .toast-notification{position:fixed;top:-100px;right:20px;background-color:var(--primary-color);color:white;padding:15px 25px;border-radius:8px;z-index:3000;font-size:16px;box-shadow:0 3px 10px rgba(0,0,0,0.2);opacity:0;transition:opacity 0.5s, top 0.5s;}
      .countdown-timer{font-size:14px;font-weight:500;margin-top:10px;text-align:center;}
      #top-up-section{margin-top:15px;padding:15px;background-color:#fff8e1;border:1px solid #ffecb3;border-radius:8px;text-align:center;}
      #top-up-section label{font-size:14px;font-weight:500;color:#6d4c41;}
      .accordion-item{background-color:var(--card-background-color);border-radius:var(--border-radius);box-shadow:var(--box-shadow);margin-bottom:20px;overflow:hidden;}
      .accordion-header{display:flex;justify-content:space-between;align-items:center;padding:15px 20px;cursor:pointer;border-bottom:1px solid transparent;transition:border-color 0.3s ease;}
      .accordion-header h2{margin:0;font-family:'Poppins',sans-serif;font-size:20px;}
      .accordion-header .material-symbols-outlined{font-size:28px;transition:transform 0.3s ease-in-out;}
      .accordion-item:not(.is-open) .accordion-header{border-color:#eee;}
      .accordion-item.is-open .accordion-header .material-symbols-outlined{transform:rotate(180deg);}
      .accordion-content{padding:0 20px;max-height:0;overflow:hidden;transition:max-height 0.5s ease-in-out, padding 0.5s ease-in-out;}
      .accordion-content .contracts-grid, .accordion-content .no-contracts-message{padding-top:20px;padding-bottom:20px;}
      .card[data-details]{cursor:pointer;transition:transform 0.2s ease, box-shadow 0.2s ease;}
      .card[data-details]:hover{transform:translateY(-5px);box-shadow:0 8px 20px rgba(0,0,0,0.12);}
      .status-paiement-attente .card-header { background-color: #E3F2FD; }
      .status-paiement-attente .status-badge { background-color: var(--info-color); color: white; }
      .info-item.retrait-info .material-symbols-outlined { color: var(--info-color); }
      .toggle-btn { display: none; }
      .card-content.is-grayed-out { opacity: 0.3; filter: grayscale(90%); transition: opacity 0.3s ease, filter 0.3s ease; }
      .card-overlay { position: absolute; top: 51px; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; z-index: 2; }
      .overlay-message { background-color: rgba(46, 125, 50, 0.85); color: white; padding: 10px 20px; border-radius: 25px; font-weight: 700; font-size: 1.1em; box-shadow: 0 2px 8px rgba(0,0,0,0.3); }
      .payment-options { display: flex; gap: 16px; flex-wrap: wrap; }
      .allocation-columns { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
      .product-list { border: 1px solid #eee; padding: 10px; border-radius: 8px; margin-bottom: 15px; max-height: 280px; overflow-y: auto; }
      .product-list::-webkit-scrollbar { -webkit-appearance: none; width: 7px; }
      .product-list::-webkit-scrollbar-thumb { border-radius: 4px; background-color: rgba(0, 0, 0, .5); }
      .form-feedback { font-size: 12px; margin-top: 4px; display: block; }

      /* --- Payment toggle buttons (NOUVEAU) --- */
      .payment-toggle {
        display: flex; justify-content: center; gap: 12px; width: 100%; margin-top: 6px;
      }
      .payment-btn {
        padding: 12px 16px; border-radius: 999px; border: 1px solid #ddd; background: #fff;
        font-weight: 700; cursor: pointer; min-width: 220px; text-align: center;
        transition: transform .06s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease;
        box-shadow: 0 2px 8px rgba(0,0,0,.06);
      }
      .payment-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 14px rgba(0,0,0,.10); border-color: #ccc; }
      .payment-btn.active { background: var(--primary-gradient); color: #fff; border-color: transparent; box-shadow: 0 8px 18px rgba(46,125,50,.35); }
      .payment-btn:focus { outline: 2px solid #a5d6a7; outline-offset: 2px; }

      /* Radios cachées mais accessibles */
      .visually-hidden {
        position: absolute !important;
        width: 1px !important; height: 1px !important;
        padding: 0 !important; margin: -1px !important; overflow: hidden !important;
        clip: rect(0, 0, 0, 0) !important; white-space: nowrap !important; border: 0 !important;
      }

      @media (max-width: 992px) {
        .sidebar { transform: translateX(-100%); }
        .sidebar.open { transform: translateX(0); }
        .container { margin-left: 0; width: 100%; padding: 15px; box-sizing: border-box; }
        .toggle-btn { display: flex; align-items: center; justify-content: center; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); }
        .main-header { padding-top: 60px; }
      }
      @media (max-width: 768px) {
        .main-header { font-size: 24px; }
        .summary-card .summary-grid { grid-template-columns: 1fr; gap: 15px; }
        .contracts-grid { grid-template-columns: 1fr; }
        .accordion-header h2 { font-size: 18px; }
        .popup-header-summary strong { font-size: 28px; }
        .calculation-box strong { font-size: 18px; }
        .popup-content { width: 95%; padding: 20px 15px; }
        .allocation-columns { grid-template-columns: 1fr; gap: 20px; } /* définition initiale */
        .product-list { max-height: 25vh; }
        #confirm-codes-and-payment > div[style*="grid"] { grid-template-columns: 1fr !important; gap: 15px !important; }
        .payment-options { flex-direction: column; align-items: flex-start; gap: 12px; }
        .payment-btn { min-width: 0; width: 100%; }
        .payment-toggle { flex-direction: column; align-items: stretch; }
      }

      /* --- OVERRIDES pour garder le panier à côté + sticky, et plus haut --- */
      .allocation-columns {
        grid-template-columns: 1fr 1fr; /* côte à côte */
        align-items: start;
      }
      .cart-column {
        position: sticky;
        top: 20px;
        align-self: start;
      }
      .product-list {
        max-height: 60vh; /* plus haut pour scroller confortablement */
      }
      @media (max-width: 768px) {
        .allocation-columns { grid-template-columns: 1fr 1fr; gap: 12px; } /* côte à côte aussi en mobile */
        .product-list { max-height: 45vh; }
      }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['error_message'])) {
    echo '<div style="position: sticky; top: 0; z-index: 9999; background-color: #f8d7da; color: #721c24; padding: 15px; text-align: center; font-weight: bold;"><strong>Erreur :</strong> ' . htmlspecialchars($_SESSION['error_message']) . '</div>';
    unset($_SESSION['error_message']);
}
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    echo "<script>document.addEventListener('DOMContentLoaded', function() { showSuccessToast(" . json_encode($success_message) . "); });</script>";
    unset($_SESSION['success_message']);
}
?>

<button class="toggle-btn" id="menu-toggle">
    <span class="material-symbols-outlined">menu</span>
</button>
  
<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Mes Récoltes & Contrats</h1>
  
    <div class="summary-card">
        <h3>Bonjour <strong><?php echo htmlspecialchars($prenom); ?></strong> ! Votre portefeuille en un clin d'œil :</h3>
        <div class="summary-grid">
            <div class="summary-item">
                Valeur Actuelle (Contrats en cours)
                <strong><?php echo number_format($somme_contrats_en_cours, 2, ',', ' '); ?> €</strong>
            </div>
            <div class="summary-item">
                Gains Actuels (Contrats en cours)
                <strong>+ <?php echo number_format($somme_rendements_actuels, 2, ',', ' '); ?> €</strong>
            </div>
            <div class="summary-item">
                Montant Total Investi (Actif)
                <strong><?php echo number_format($montant_total_investi, 2, ',', ' '); ?> €</strong>
            </div>
            <div class="summary-item">
                Rendement Moyen Pondéré
                <strong><?php echo number_format($rendement_moyen_pondere, 2, ',', ' '); ?> %</strong>
            </div>
        </div>
    </div>
  
    <div class="contracts-section">
        <div class="accordion-item">
            <div class="accordion-header">
                <h2>En cours (<?php echo count($contrats_en_cours); ?>)</h2>
                <span class="material-symbols-outlined">expand_less</span>
            </div>
            <div class="accordion-content">
                <?php if (!empty($contrats_en_cours)) : ?>
                    <div class="contracts-grid">
                        <?php foreach ($contrats_en_cours as $contrat) : ?>
                            <div class="card <?php echo $contrat['statut_class']; ?>" data-details='<?php echo htmlspecialchars(json_encode($contrat), ENT_QUOTES, 'UTF-8'); ?>'>
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($contrat['produit_name']) . ' - ' . number_format($contrat['montant'], 0, ' ', ' ') . ' €'; ?></h3>
                                </div>
                                <div class="card-content">
                                    <div class="info-item"><span class="material-symbols-outlined">calendar_month</span> Souscrit le: <strong><?php echo date('d/m/Y', strtotime($contrat['date_souscription'])); ?></strong></div>
                                    <div class="info-item"><span class="material-symbols-outlined">account_balance_wallet</span> Investi: <strong><?php echo number_format($contrat['apport'], 2, ',', ' '); ?> €</strong></div>
                                    <div class="info-item"><span class="material-symbols-outlined">trending_up</span> Rend. actuel: <strong class="rendement-actuel"><?php echo number_format($contrat['rendement_actuel'], 2, ',', ' '); ?> €</strong></div>
                                    <div class="info-item"><span class="material-symbols-outlined">emoji_events</span> Rend. final estimé: <strong><?php echo number_format($contrat['rendement_total_contrat'], 2, ',', ' '); ?> €</strong></div>
                                    <div class="progress-bar-container"><div class="progress-bar" style="width: <?php echo $contrat['pourcentage_temps_ecoule']; ?>%;"></div></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="no-contracts-message">Vous n'avez aucun contrat en cours de récolte.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="accordion-item">
            <div class="accordion-header">
                <h2>En attente de renouvellement (<?php echo count($contrats_en_attente_renouvellement); ?>)</h2>
                <span class="material-symbols-outlined">expand_less</span>
            </div>
            <div class="accordion-content">
                <?php if (!empty($contrats_en_attente_renouvellement)) : ?>
                    <div class="contracts-grid">
                        <?php foreach ($contrats_en_attente_renouvellement as $contrat) : ?>
                            <div class="card <?php echo $contrat['statut_class']; ?>">
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($contrat['produit_name']) . ' - ' . number_format($contrat['montant'], 0, ' ', ' ') . ' €'; ?></h3>
                                    <span class="status-badge">À renouveler</span>
                                </div>
                                <div class="card-content">
                                    <?php $total_disponible = $contrat['montant'] + $contrat['rendement_total_contrat']; ?>
                                    <div class="final-yield-summary">
                                        <small>Félicitations ! Votre capital est disponible :</small>
                                        <strong><?php echo number_format($total_disponible, 2, ',', ' '); ?> €</strong>
                                        <span>(Capital de <?php echo number_format($contrat['montant'], 2, ',', ' '); ?> € + Gains de <?php echo number_format($contrat['rendement_total_contrat'], 2, ',', ' '); ?> €)</span>
                                    </div>
                                    
                                    <div class="quick-actions">
                                        <button class="quick-action-btn" onclick="quickAction('reinvest_all', <?php echo $contrat['id']; ?>, '<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>')">
                                            <span class="material-symbols-outlined">refresh</span> Tout Réinvestir
                                        </button>
                                        <button class="quick-action-btn" onclick="quickAction('withdraw_all', <?php echo $contrat['id']; ?>, '<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>')">
                                            <span class="material-symbols-outlined">savings</span> Tout Retirer
                                        </button>
                                    </div>
                                    
                                    <button class="btn-renew js-no-details" onclick="openRenewalPopup(<?php echo htmlspecialchars(json_encode($contrat), ENT_QUOTES, 'UTF-8'); ?>)">Gérer (Personnalisé)</button>
                                    <div class="countdown-timer" data-deadline="<?php echo $contrat['temps_restant_renouvellement']; ?>">Calcul...</div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="no-contracts-message">Vous n'avez aucun contrat en attente de renouvellement.</p>
                <?php endif; ?>
            </div>
        </div>
      
        <div class="accordion-item">
            <div class="accordion-header">
                <h2>Historique (<?php echo count($contrats_clotures); ?>)</h2>
                <span class="material-symbols-outlined">expand_more</span>
            </div>
            <div class="accordion-content">
                <?php if (!empty($contrats_clotures)) : ?>
                    <div class="contracts-grid">
                        <?php foreach ($contrats_clotures as $contrat) : ?>
                            <?php 
                                $is_finalized = ($contrat['statut'] !== 'en_attente_paiement');
                                $overlay_message = '';
                                if ($is_finalized) {
                                    $overlay_message = (trim($contrat['db_statut']) === 'Renouvelé') ? 'Renouvelé' : 'Fonds récupérés';
                                }
                            ?>
                            <div class="card <?php echo $contrat['statut_class']; ?>" data-details='<?php echo htmlspecialchars(json_encode($contrat), ENT_QUOTES, 'UTF-8'); ?>'>
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($contrat['produit_name']) . ' - ' . number_format($contrat['montant'], 0, ' ', ' ') . ' €'; ?></h3>
                                    <?php if ($contrat['statut'] === 'en_attente_paiement'): ?>
                                        <span class="status-badge">Paiement en attente</span>
                                    <?php else: ?>
                                        <span class="status-badge">Clôturé</span>
                                    <?php endif; ?>
                                </div>
                                 <div class="card-content <?php echo $is_finalized ? 'is-grayed-out' : ''; ?>">
                                    <div class="info-item"><span class="material-symbols-outlined">calendar_month</span> Souscrit le: <strong><?php echo date('d/m/Y', strtotime($contrat['date_souscription'])); ?></strong></div>
                                    <?php if ($contrat['statut'] === 'en_attente_paiement'): ?>
                                        <div class="info-item retrait-info">
                                            <span class="material-symbols-outlined">hourglass_top</span>
                                            Retrait demandé: <strong><?php echo number_format($contrat['montant_retrait'] ?? 0, 2, ',', ' '); ?> €</strong>
                                        </div>
                                        <div class="info-item retrait-info">
                                            <span class="material-symbols-outlined">info</span>
                                            <span>Votre demande est en cours de traitement.</span>
                                        </div>
                                    <?php else: ?>
                                        <div class="info-item"><span class="material-symbols-outlined">account_balance_wallet</span> Investi: <strong><?php echo number_format($contrat['apport'], 2, ',', ' '); ?> €</strong></div>
                                        <div class="info-item"><span class="material-symbols-outlined">emoji_events</span> Rendement final atteint: <strong><?php echo number_format($contrat['rendement_total_contrat'], 2, ',', ' '); ?> €</strong></div>
                                    <?php endif; ?>
                                </div>
                                <?php if ($is_finalized): ?>
                                <div class="card-overlay">
                                    <span class="overlay-message"><?php echo $overlay_message; ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="no-contracts-message">Vous n'avez aucun contrat dans votre historique.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="renewal-popup-overlay" class="popup-overlay">
    <div class="popup-content">
        <span class="popup-close-btn" onclick="closeRenewalPopup()">&times;</span>

        <div id="popup-step-choice">
            <h2>Que souhaitez-vous faire ?</h2>
            <div class="popup-header-summary">
                <strong id="popup-total-amount">0,00 €</strong>
                <span id="popup-amount-details" style="display:block;"></span>
            </div>
            
            <div class="preset-buttons">
                <button class="preset-btn" data-value="0">Retrait Total</button>
                <button class="preset-btn" data-value="gains">Réinvestir les Gains</button>
                <button class="preset-btn" data-value="100">Réinvestir le Total</button>
            </div>

            <div class="slider-container">
                <input type="range" min="0" max="100" value="100" step="1" class="slider" id="reinvest-slider">
                <div class="slider-labels"><span>Retrait</span><span>Réinvestir</span></div>
            </div>
            <div class="calculation-results">
                <div class="calculation-box"><small>Montant à réinvestir</small><strong id="amount-reinvest">0,00 €</strong></div>
                <div class="calculation-box"><small>Montant à virer</small><strong id="amount-withdraw">0,00 €</strong></div>
            </div>
            <div id="iban-section" class="iban-section hidden">
                <label for="iban-input">Votre IBAN pour le virement</label>
                <input type="text" id="iban-input" placeholder="FR76...">
            </div>
            <div class="popup-actions">
                <button id="popup-cta-choice" class="popup-btn primary">Étape suivante</button>
            </div>
        </div>

        <div id="popup-step-allocate" class="hidden">
            <h2>Allouez votre réinvestissement</h2>
            <div class="allocation-progress">
                <div class="progress-bar-track"><div class="progress-bar-fill" id="allocation-bar-fill"></div></div>
                <div class="progress-text">Alloué : <strong id="allocated-amount">0,00 €</strong> / <strong id="total-to-allocate">0,00 €</strong><span id="top-up-warning"></span></div>
            </div>
            
            <div class="allocation-section">
                <div class="allocation-columns">
                    <div class="product-column">
                        <h3>1. Choisissez vos produits</h3>
                        <div id="product-list" class="product-list"></div>
                    </div>
                    <div class="cart-column">
                        <h3>2. Votre panier</h3>
                        <div id="reinvestment-cart" class="product-list">
                            <p id="cart-empty-msg" style="color:#999;text-align:center;">Votre panier est vide.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="top-up-section" class="hidden">
                <input type="checkbox" id="top-up-checkbox" name="accept_top_up">
                <label for="top-up-checkbox">Oui, je souhaite compléter par un versement de <strong id="top-up-amount">0,00 €</strong>.</label>
            </div>
            <div class="popup-actions">
                <button type="button" class="popup-btn secondary" id="popup-back-to-choice-btn">Retour</button>
                <button id="popup-cta-allocate" class="popup-btn primary">Étape suivante</button>
            </div>
        </div>

        <div id="popup-step-confirm" class="hidden">
            <h2>Récapitulatif de votre choix</h2>
            <div class="calculation-results">
                <div class="calculation-box"><small>Valeur des nouveaux contrats</small><strong id="confirm-reinvest">0,00 €</strong></div>
                <div class="calculation-box"><small>Montant viré (retrait)</small><strong id="confirm-withdraw">0,00 €</strong></div>
            </div>

            <div id="confirm-codes-and-payment" style="margin-top:16px;padding:14px;border:1px solid #eee;border-radius:8px;background:#fafafa;">
                <h3 style="margin:0 0 10px 0;font-family:'Poppins',sans-serif;font-size:18px;color:#212121;">Codes & paiement</h3>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                    <div class="iban-section">
                        <label for="promo-code-input">Code promo <span id="promo-status-icon"></span></label>
                        <input type="text" id="promo-code-input" placeholder="EX: BIENVENUE20" style="text-transform:uppercase;">
                        <small id="promo-feedback" class="form-feedback"></small>
                    </div>
                    <div class="iban-section">
                        <label for="referral-code-input">Code parrain <span id="referral-status-icon"></span></label>
                        <input type="text" id="referral-code-input" placeholder="EX: PARRAIN123" style="text-transform:uppercase;">
                        <small id="referral-feedback" class="form-feedback"></small>
                    </div>
                </div>

                <!-- NOUVELLE zone “Mode de paiement” en boutons -->
                <div class="iban-section" style="margin-top:6px;">
                    <label style="display:block;margin-bottom:6px;">Mode de paiement</label>

                    <!-- Boutons centrés -->
                    <div class="payment-toggle" id="payment-toggle">
                        <button type="button" class="payment-btn" data-value="full" aria-pressed="true">
                            Paiement comptant
                        </button>
                        <button type="button" class="payment-btn" data-value="12x" aria-pressed="false">
                            12 mensualités
                        </button>
                    </div>

                    <!-- Radios conservées (cachées) pour compatibilité -->
                    <input type="radio" name="payment_plan_choice" value="full" id="payment-choice-full" class="visually-hidden" checked>
                    <input type="radio" name="payment_plan_choice" value="12x" id="payment-choice-12x" class="visually-hidden">
                </div>
            </div>

            <div id="discount-live-panel" class="calculation-results" style="margin-top:12px;">
                <div class="calculation-box" style="width:100%;">
                    <small>Détails des remises</small>
                    <div id="discount-lines" style="font-size:14px;color:#444;margin-top:6px;">
                        <em>Aucune remise appliquée pour le moment.</em>
                    </div>
                </div>
            </div>

            <div id="payable-live-panel" class="calculation-results" style="margin-top:12px;background:#eef7ee;">
                <div class="calculation-box"><small>À régler aujourd’hui</small><strong id="confirm-top-up-after-discount">0,00 €</strong></div>
                <div class="calculation-box"><small>Si 12 mensualités</small><strong id="confirm-monthly-12x">0,00 € / mois</strong></div>
            </div>

            <div id="confirm-iban-section" class="iban-section hidden">
                <label>Sur le compte IBAN :</label>
                <input type="text" id="confirm-iban" readonly style="background:#f0f0f0;border:1px solid #ddd;">
            </div>

            <form id="renewal-form" action="create-checkout-session.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" id="popup-contract-id" name="contract_id">
                <input type="hidden" id="popup-withdraw-amount" name="withdraw_amount">
                <input type="hidden" id="popup-iban-value" name="iban">
                <input type="hidden" id="popup-top-up-amount" name="top_up_amount" value="0">
                <input type="hidden" id="popup-promo-code" name="promo_code" value="">
                <input type="hidden" id="popup-referral-code" name="referral_code" value="">
                <input type="hidden" id="popup-payment-plan" name="payment_plan" value="full">
                <input type="hidden" id="popup-top-up-after-discount" name="top_up_after_discount" value="0">
                <input type="hidden" id="popup-monthly-12x" name="monthly_12x" value="0">
                <input type="hidden" id="popup-contract-discount" name="contract_discount_total" value="0">
                <div id="new-contracts-inputs"></div>
                <div class="popup-actions">
                    <button type="button" class="popup-btn secondary" id="popup-back-btn">Retour</button>
                    <button type="submit" class="popup-btn primary">Je confirme et je finalise</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="details-popup-overlay" class="popup-overlay">
    <div class="popup-content popup-details-card" style="padding:0;border-top:5px solid var(--primary-color);overflow:hidden;">
        <span class="popup-close-btn" id="close-details-popup">&times;</span>
        <div class="popup-header-details" style="display:flex;align-items:center;background-color:#f9f9f9;padding:20px 25px;border-bottom:1px solid #eee;">
            <div class="header-icon-container" style="background-color:var(--primary-color-light);color:var(--primary-color);border-radius:50%;width:50px;height:50px;display:flex;align-items:center;justify-content:center;margin-right:20px;">
                <span class="material-symbols-outlined" id="details-icon">grass</span>
            </div>
            <div>
                <h2 id="details-popup-title" style="margin:0 0 5px 0;font-size:22px;color:var(--text-color);text-align:left;">Détails du contrat</h2>
                <span class="status-badge" id="details-status-badge"></span>
            </div>
        </div>
        <div class="popup-kpi-section" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:20px 25px;background-color:#fff;">
            <div class="kpi-box" style="background-color:#f7f9fc;border-radius:var(--border-radius);padding:15px;text-align:center;border:1px solid #eef;">
                <span style="font-size:14px;color:var(--text-color-light);">Investissement Initial</span>
                <strong id="details-apport" style="display:block;font-size:24px;font-family:'Poppins',sans-serif;color:var(--primary-color);margin-top:5px;">0,00 €</strong>
            </div>
            <div class="kpi-box" style="background-color:#f7f9fc;border-radius:var(--border-radius);padding:15px;text-align:center;border:1px solid #eef;">
                <span style="font-size:14px;color:var(--text-color-light);">Gain Final Estimé</span>
                <strong id="details-rendement-final" style="display:block;font-size:24px;font-family:'Poppins',sans-serif;color:var(--primary-color);margin-top:5px;">0,00 €</strong>
            </div>
        </div>
        <div class="popup-details-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:20px 25px;border-top:1px solid #eee;">
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">calendar_today</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Date de souscription</span><strong id="details-date-souscription" style="font-size:16px;color:var(--text-color);font-weight:500;">--/--/----</strong></div></div>
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">event_available</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Date de fin du contrat</span><strong id="details-date-fin" style="font-size:16px;color:var(--text-color);font-weight:500;">--/--/----</strong></div></div>
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">hourglass_top</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Durée</span><strong id="details-duree" style="font-size:16px;color:var(--text-color);font-weight:500;">-- mois</strong></div></div>
            <div class="details-grid-item" style="display:flex;align-items:center;"><span class="material-symbols-outlined" style="font-size:24px;color:var(--primary-color);margin-right:15px;">percent</span><div><span style="display:block;font-size:13px;color:var(--text-color-light);">Taux annuel moyen</span><strong id="details-taux" style="font-size:16px;color:var(--text-color);font-weight:500;">-- %</strong></div></div>
        </div>
        <div class="popup-progress-section" style="padding:20px 25px;border-top:1px solid #eee;">
            <h4 style="margin:0 0 10px 0;font-size:16px;font-weight:500;text-align:center;">Progression du contrat</h4>
            <div class="progress-bar-container"><div class="progress-bar" id="details-progress-bar" style="width: 0%;"></div></div>
            <div class="progress-labels" style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-color-light);margin-top:8px;"><span id="details-progress-start">--/--/----</span><span id="details-progress-end">--/--/----</span></div>
        </div>
        <div class="details-description" style="background-color:#f9f9f9;padding:20px 25px;border-top:1px solid #eee;">
            <h4 style="margin:0 0 8px 0;font-size:16px;font-weight:500;">Descriptif du produit</h4>
            <p id="details-descriptif" style="margin:0;font-size:14px;line-height:1.6;color:var(--text-color-light);"></p>
        </div>
    </div>
</div>
<div id="toast-notification" class="toast-notification"></div>

<form id="quick-action-form" action="create-checkout-session.php" method="POST" style="display:none;">
    <input type="hidden" name="csrf_token" id="quick-action-csrf">
    <input type="hidden" name="contract_id" id="quick-action-contract-id">
    <input type="hidden" name="action_type" id="quick-action-type">
    <input type="hidden" name="iban" id="quick-action-iban">
</form>

<script>
    const serverCodes = <?php echo json_encode($promo_codes_for_js); ?>;
    const availableProducts = <?php echo json_encode($available_products); ?>;
    const referralCodes = <?php echo json_encode($referral_codes_for_js); ?>; // NEW: codes parrains (users.code_parrain)
</script>
<script>
// ---------- Helpers UI ----------
function showSuccessToast(message) {
    const toast = document.getElementById('toast-notification');
    if (toast) {
        toast.textContent = message;
        toast.style.top = '20px';
        toast.style.opacity = '1';
        setTimeout(() => {
            toast.style.top = '-100px';
            toast.style.opacity = '0';
        }, 4000);
    }
}
function formatCurrency(value) {
    const n = Number(value || 0);
    return n.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
}
function normalizeCode(val) {
    return (val || "").toString().trim().toUpperCase();
}

// ---------- Global state ----------
let currentContractData = {};
let totalToAllocate = 0;
let reinvestmentCart = [];
let codeInfo = { promo: null, referral: null };

// ---------- Logique des actions rapides ----------
function quickAction(type, contractId, csrfToken) {
    const form = document.getElementById('quick-action-form');
    form.querySelector('#quick-action-csrf').value = csrfToken;
    form.querySelector('#quick-action-contract-id').value = contractId;
    form.querySelector('#quick-action-type').value = type;

    if (type === 'withdraw_all') {
        const userIban = prompt("Veuillez confirmer votre IBAN pour le virement complet :");
        if (userIban) { 
            form.querySelector('#quick-action-iban').value = userIban;
            form.submit();
        }
    } else if (type === 'reinvest_all') {
        const confirmReinvest = confirm("Confirmez-vous le réinvestissement de la totalité du capital et des gains dans le même produit ?");
        if (confirmReinvest) {
            form.submit();
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    const popupOverlay = document.getElementById('renewal-popup-overlay');
    const stepChoice = document.getElementById('popup-step-choice');
    const stepAllocate = document.getElementById('popup-step-allocate');
    const stepConfirm = document.getElementById('popup-step-confirm');
    const slider = document.getElementById('reinvest-slider');
    const renewalForm = document.getElementById('renewal-form');
    const promoCodeInput = document.getElementById('promo-code-input');
    const referralCodeInput = document.getElementById('referral-code-input');
    const hiddenPromo = document.getElementById('popup-promo-code');
    const hiddenReferral = document.getElementById('popup-referral-code');
    const ibanInput = document.getElementById('iban-input');
    const choiceCtaBtn = document.getElementById('popup-cta-choice');

    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    }

        document.querySelectorAll('.countdown-timer').forEach(timer => {
        const deadline = parseInt(timer.getAttribute('data-deadline'), 10) * 1000;
        if (isNaN(deadline) || deadline <= 0) {
            timer.style.display = 'none';
            return;
        }
        const interval = setInterval(() => {
            const distance = deadline - Date.now();
            if (distance < 0) {
                timer.textContent = "Délai expiré";
                clearInterval(interval);
                return;
            }
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            timer.textContent = `Temps restant : ${days}j ${hours}h ${minutes}m ${seconds}s`;
        }, 1000);
    });

    // Accordéons
    document.querySelectorAll('.accordion-item').forEach(item => {
        const header = item.querySelector('.accordion-header');
        const content = item.querySelector('.accordion-content');
        if (!header || !content) return;

        if (item.classList.contains('is-open')) {
            content.style.maxHeight = content.scrollHeight + 40 + 'px';
        }

        header.addEventListener('click', () => {
            item.classList.toggle('is-open');
            const icon = header.querySelector('.material-symbols-outlined');
            if (item.classList.contains('is-open')) {
                content.style.maxHeight = content.scrollHeight + 40 + 'px';
                if (icon) icon.textContent = 'expand_less';
            } else {
                content.style.maxHeight = '0px';
                if (icon) icon.textContent = 'expand_more';
            }
        });
    });

    // ---------- ÉTAPE 1 : Choix ----------
    stepChoice.addEventListener('click', function(e) {
        if (!e.target.classList.contains('preset-btn')) return;

        const action = e.target.dataset.value;
        const totalAmount = (currentContractData.montant || 0) + (currentContractData.rendement_total_contrat || 0);
        let percentage = 100;

        if (action === '0') percentage = 0;
        else if (action === '100') percentage = 100;
        else if (action === 'gains') {
            const gains = currentContractData.rendement_total_contrat || 0;
            percentage = totalAmount > 0 ? (gains / totalAmount) * 100 : 0;
        }

        slider.value = percentage;
        slider.dispatchEvent(new Event('input'));
    });

    // Ouverture popup de renouvellement
   window.openRenewalPopup = function (contractData) {
  currentContractData = contractData || {};

  // Casts explicites pour éviter la concaténation de chaînes
  const capital = Number(currentContractData.montant) || 0;
  const gains   = Number(currentContractData.rendement_total_contrat) || 0;
  const totalAmount = capital + gains;

  document.getElementById('popup-contract-id').value = currentContractData.id || '';

  // Montant total correct (ex: 55,00 €)
  document.getElementById('popup-total-amount').textContent = formatCurrency(totalAmount);

  // Détail capital + gains correct
  document.getElementById('popup-amount-details').textContent =
    `(Capital de ${formatCurrency(capital)} + Gains de ${formatCurrency(gains)})`;

  // Le reste inchangé
  slider.value = 100;
  reinvestmentCart = [];
  updateSliderAmounts(100);

  stepChoice.classList.remove('hidden');
  stepAllocate.classList.add('hidden');
  stepConfirm.classList.add('hidden');

  if (promoCodeInput) promoCodeInput.value = "";
  if (referralCodeInput) referralCodeInput.value = "";
  onCodeChanged('promo', '');
  onCodeChanged('referral', '');
  codeInfo = { promo: null, referral: null };

  popupOverlay.style.display = 'flex';
};

window.closeRenewalPopup = function () {
  popupOverlay.style.display = 'none';
};

    function updateSliderAmounts(percentage) {
  // Sécurise le pourcentage
  let pct = Number.isFinite(percentage) ? Number(percentage) : 0;
  pct = Math.min(100, Math.max(0, pct));

  const totalAmount = (Number(currentContractData.montant) || 0) + (Number(currentContractData.rendement_total_contrat) || 0);
  const reinvestAmountRaw = totalAmount * (pct / 100);
  const withdrawAmountRaw = totalAmount - reinvestAmountRaw;

  // Arrondi 2 décimales (évite -0.00)
  const round2 = v => Math.round((v + Number.EPSILON) * 100) / 100;
  const reinvestAmount = round2(Math.max(0, reinvestAmountRaw));
  const withdrawAmount = round2(Math.max(0, withdrawAmountRaw));

  // UI montants
  document.getElementById('amount-reinvest').textContent = formatCurrency(reinvestAmount);
  document.getElementById('amount-withdraw').textContent = formatCurrency(withdrawAmount);

  // IBAN visible seulement si retrait > ~0
  const needIban = withdrawAmount >= 0.01;
  const ibanSection = document.getElementById('iban-section');
  const ibanInput   = document.getElementById('iban-input');
  ibanSection.classList.toggle('hidden', !needIban);

  // Si pas besoin d’IBAN, on nettoie le champ et les erreurs visuelles
  if (!needIban && ibanInput) {
    ibanInput.value = '';
    ibanInput.classList.remove('input-error');
    const fb = ibanInput.parentElement.querySelector('.form-feedback');
    if (fb) fb.textContent = '';
  }

  // Libellé CTA : si réinvestissement = 0 => c'est un retrait total
  choiceCtaBtn.textContent = (reinvestAmount > 0.01) ? 'Étape suivante' : 'Confirmer le retrait total';
}

// Listener
slider.addEventListener('input', (e) => updateSliderAmounts(Number(e.target.value || 0)));


    // ---------- ÉTAPE 2 : Allocation ----------
    function updateAllocationProgress() {
        const cartEl = document.getElementById('reinvestment-cart');
        const emptyMsgEl = document.getElementById('cart-empty-msg');
        const allocatedAmountEl = document.getElementById('allocated-amount');
        const totalToAllocateEl = document.getElementById('total-to-allocate');
        const topUpWarningEl = document.getElementById('top-up-warning');
        const allocationBar = document.getElementById('allocation-bar-fill');

        if (!cartEl || !emptyMsgEl || !allocatedAmountEl || !totalToAllocateEl || !topUpWarningEl || !allocationBar) {
            console.error("Éléments manquants pour l'allocation.");
            return;
        }

        // Nettoyage des items visibles (laisse le message vide en place)
        cartEl.querySelectorAll('.cart-item').forEach(el => el.remove());
        emptyMsgEl.style.display = reinvestmentCart.length > 0 ? 'none' : 'block';

        let currentAllocated = 0;
        reinvestmentCart.forEach((item, index) => {
            const price = parseFloat(item.prix || 0);
            currentAllocated += price;
            const plantTypeText = item.plantType === 'mature' ? 'Plants matures' : 'Jeunes pousses';
            cartEl.insertAdjacentHTML(
                'beforeend',
                `<div class="cart-item">
                    <span>${item.name} (${plantTypeText}) - ${formatCurrency(price)}</span>
                    <span class="remove-item-btn" data-index="${index}">&times;</span>
                </div>`
            );
        });

        allocatedAmountEl.textContent = formatCurrency(currentAllocated);
        totalToAllocateEl.textContent = formatCurrency(totalToAllocate);

        if (currentAllocated > totalToAllocate) {
            allocationBar.style.width = '100%';
            allocationBar.classList.add('is-over');
            const topUpAmount = currentAllocated - totalToAllocate;
            topUpWarningEl.innerHTML = `<br><span style="color:var(--warning-color);">(Versement complémentaire : ${formatCurrency(topUpAmount)})</span>`;
            document.getElementById('top-up-amount').textContent = formatCurrency(topUpAmount);
            document.getElementById('top-up-section').classList.remove('hidden');
        } else {
            allocationBar.classList.remove('is-over');
            const displayPercentage = totalToAllocate > 0 ? (currentAllocated / totalToAllocate) * 100 : 0;
            allocationBar.style.width = `${displayPercentage}%`;
            topUpWarningEl.innerHTML = '';
            document.getElementById('top-up-section').classList.add('hidden');
            document.getElementById('top-up-checkbox').checked = false;
        }

        document.getElementById('popup-cta-allocate').disabled = reinvestmentCart.length === 0;
    }

    choiceCtaBtn.addEventListener('click', function() {
        totalToAllocate = parseFloat(
            (document.getElementById('amount-reinvest').textContent || '0')
            .replace(/[^\d,.-]/g, '')
            .replace(',', '.')
        ) || 0;

        if (totalToAllocate < 0.01) {
            reinvestmentCart = [];
            goToConfirmStep();
            return;
        }

        stepChoice.classList.add('hidden');
        stepAllocate.classList.remove('hidden');
        document.getElementById('total-to-allocate').textContent = formatCurrency(totalToAllocate);

        const productListEl = document.getElementById('product-list');
        productListEl.innerHTML = '';

        availableProducts.forEach((p, index) => {
            const productHtml = `
                <div class="product-item">
                    <div class="product-item-info">
                        <strong>${p.name} - ${formatCurrency(parseFloat(p.prix || 0))}</strong>
                        <span>Durée: ${p.duree_mois} mois</span>
                        <div class="plant-choice-toggle" style="margin-top:8px; font-size: 13px;">
                            <label><input type="radio" name="plant_type_${p.id}" value="new" checked> Jeunes Pousses</label>
                            <label style="margin-left:10px;"><input type="radio" name="plant_type_${p.id}" value="mature"> Garder mes plants</label>
                        </div>
                    </div>
                    <button class="add-product-btn" data-index="${index}">Ajouter</button>
                </div>`;
            productListEl.insertAdjacentHTML('beforeend', productHtml);
        });

        // Appliquer la règle "Garder mes plants" uniquement si même produit
        enforcePlantTypeRules();

        updateAllocationProgress();
    });

    document.getElementById('product-list').addEventListener('click', (e) => {
        const btn = e.target.closest('.add-product-btn');
        if (!btn) return;

        // anti double-clic (guard 300ms)
        const now = Date.now();
        if (now - lastAddTs < 300) return;
        lastAddTs = now;

        const productIndex = btn.dataset.index;
        const productToAdd = { ...availableProducts[productIndex] };
        const plantTypeChoice = document.querySelector(`input[name="plant_type_${productToAdd.id}"]:checked`);
        productToAdd.plantType = plantTypeChoice ? plantTypeChoice.value : 'new';

        reinvestmentCart.push(productToAdd);

        // Nettoyage de doublons (même produit + même type de plant)
        sanitizeCartDuplicates();

        updateAllocationProgress();
    });

    document.getElementById('reinvestment-cart').addEventListener('click', (e) => {
        if (!e.target.matches('.remove-item-btn')) return;
        const idx = Number(e.target.dataset.index);
        if (!Number.isNaN(idx)) {
            reinvestmentCart.splice(idx, 1);
            updateAllocationProgress();
        }
    });

    // ---------- Codes : promos & parrain ----------
    function getCodeInfo(code) {
        const normalized = normalizeCode(code);
        if (!normalized) return null;
        return serverCodes[normalized] || { valid: false };
    }

    function getReferralInfo(code) {
        const normalized = normalizeCode(code);
        if (!normalized) return null;
        return referralCodes[normalized] || { valid: false };
    }

    function computeDiscountAmount(codeObj, base) {
        if (!codeObj || !codeObj.valid || base <= 0) return 0;
        if (codeObj.type === 'percent') {
            return Math.max(0, (Number(codeObj.value) / 100) * base);
        } else if (codeObj.type === 'amount') {
            return Math.min(base, Math.max(0, Number(codeObj.value)));
        } else if (codeObj.type === 'none') {
            return 0; // suivi parrain, pas de remise
        }
        return 0;
    }

    function renderDiscountLines(base, promoObj, referralObj) {
        let html = '';
        let totalDiscount = 0;

        // Si les deux ne sont pas cumulables, on garde le plus avantageux
        if (promoObj && !promoObj.stackable && referralObj && !referralObj.stackable) {
            const promoD = computeDiscountAmount(promoObj, base);
            const refD = computeDiscountAmount(referralObj, base);
            if (promoD >= refD) referralObj = null;
            else promoObj = null;
        }

        if (promoObj && promoObj.valid) {
            const d = computeDiscountAmount(promoObj, base);
            totalDiscount += d;
            html += `<div>• ${promoObj.label || 'Code promo'}: -${formatCurrency(d)}</div>`;
        }

        if (referralObj && referralObj.valid) {
            const remainingBase = (promoObj && promoObj.stackable) ? base - totalDiscount : base;
            const d = computeDiscountAmount(referralObj, remainingBase);
            totalDiscount += d;
            if (referralObj.type === 'none') {
                html += `<div>• Code Parrain reconnu : ${referralObj.label || ''} (pas de remise, suivi parrain)</div>`;
            } else {
                html += `<div>• Code Parrain: -${formatCurrency(d)}</div>`;
            }
        }

        if (!html) {
            html = `<em>Aucune remise appliquée pour le moment.</em>`;
        } else {
            html += `<div style="margin-top:6px;font-weight:700;">Total remises : -${formatCurrency(totalDiscount)}</div>`;
        }

        document.getElementById('discount-lines').innerHTML = html;
        return totalDiscount;
    }

    function recalcDiscountsAndTotals() {
  // Helper d’arrondi (2 décimales)
  const round2 = v => Math.round((Number(v) + Number.EPSILON) * 100) / 100;

  // --- PARTIE 1 : Calculs initiaux ---
  const grossContractValue = reinvestmentCart.reduce(
    (s, item) => s + (Number(item.prix) || 0),
    0
  );

  const totalDiscount = renderDiscountLines(
    grossContractValue,
    codeInfo.promo,
    codeInfo.referral
  );

  const netContractValue = Math.max(0, round2(grossContractValue - totalDiscount));

  // ✅ Cast explicites (important)
  const totalAvailable =
    (Number(currentContractData.montant) || 0) +
    (Number(currentContractData.rendement_total_contrat) || 0);

  // Montant choisi pour réinvestir (depuis l’étape 1)
  const useFromAvailable = Math.min(netContractValue, Number(totalToAllocate) || 0);

  // --- PARTIE 2 : Compensation retrait / paiement ---
  const provisionalWithdraw = round2(totalAvailable - useFromAvailable);
  const provisionalTopUp   = Math.max(0, round2(netContractValue - (Number(totalToAllocate) || 0)));

  let finalWithdraw = 0;
  let finalTopUp    = 0;

  if (provisionalWithdraw >= provisionalTopUp) {
    // Le retrait couvre tout ou partie du complément
    finalWithdraw = round2(provisionalWithdraw - provisionalTopUp);
    finalTopUp    = 0;
  } else {
    // L’utilisateur doit payer la différence
    finalTopUp    = round2(provisionalTopUp - provisionalWithdraw);
    finalWithdraw = 0;
  }

  // --- PARTIE 3 : UI + champs cachés ---
  document.getElementById('confirm-reinvest').textContent             = formatCurrency(grossContractValue);
  document.getElementById('confirm-withdraw').textContent              = formatCurrency(finalWithdraw);
  document.getElementById('confirm-top-up-after-discount').textContent = formatCurrency(finalTopUp);

  const plan = (document.querySelector('input[name="payment_plan_choice"]:checked') || {}).value || 'full';
  const monthly = (plan === '12x' && finalTopUp > 0) ? round2(finalTopUp / 12) : 0;
  document.getElementById('confirm-monthly-12x').textContent =
    (plan === '12x' && finalTopUp > 0) ? `${formatCurrency(monthly)} / mois` : `${formatCurrency(0)} / mois`;

  // Champs envoyés au serveur
  document.getElementById('popup-withdraw-amount').value       = finalWithdraw.toFixed(2);

  // Brut (avant remises et compensation) – utile à l’UX uniquement
  const topUpBrut = Math.max(0, round2(grossContractValue - (Number(totalToAllocate) || 0)));
  document.getElementById('popup-top-up-amount').value         = topUpBrut.toFixed(2);

  // ✅ Montant réellement à payer (à utiliser côté serveur pour Stripe)
  document.getElementById('popup-top-up-after-discount').value = finalTopUp.toFixed(2);
  document.getElementById('popup-monthly-12x').value           = monthly.toFixed(2);
  document.getElementById('popup-contract-discount').value     = round2(totalDiscount).toFixed(2);
}

function onCodeChanged(kind, value) {
  const normalized = normalizeCode(value);
  const codeData = (kind === 'referral') ? getReferralInfo(normalized) : getCodeInfo(normalized);
  codeInfo[kind] = codeData;

  const statusIconEl = document.getElementById(`${kind}-status-icon`);
  const feedbackEl   = document.getElementById(`${kind}-feedback`);

  if (statusIconEl && feedbackEl) {
    if (!normalized) {
      statusIconEl.textContent = '';
      feedbackEl.textContent = '';
    } else if (codeData && codeData.valid) {
      statusIconEl.textContent = '✅';
      feedbackEl.textContent = (kind === 'referral' && codeData.type === 'none')
        ? 'Code parrain reconnu (pas de remise).'
        : 'Code valide !';
      feedbackEl.style.color = 'green';
    } else {
      statusIconEl.textContent = '❌';
      feedbackEl.textContent = (kind === 'referral') ? 'Code parrain invalide.' : 'Code invalide ou expiré.';
      feedbackEl.style.color = 'red';
    }
  }

  if (kind === 'promo')    hiddenPromo.value    = normalized;
  if (kind === 'referral') hiddenReferral.value = normalized;

  recalcDiscountsAndTotals();
}

if (promoCodeInput)    promoCodeInput.addEventListener('input', e => onCodeChanged('promo', e.target.value));
if (referralCodeInput) referralCodeInput.addEventListener('input', e => onCodeChanged('referral', e.target.value));

// Paiement toggle (boutons + radios cachées)
function setPaymentPlan(val) {
  document.getElementById('popup-payment-plan').value = val;
  document.getElementById('payment-choice-full').checked = (val === 'full');
  document.getElementById('payment-choice-12x').checked  = (val === '12x');

  document.querySelectorAll('.payment-btn').forEach(btn => {
    const active = (btn.dataset.value === val);
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-pressed', active ? 'true' : 'false');
  });

  recalcDiscountsAndTotals();
}

const paymentToggle = document.getElementById('payment-toggle');
if (paymentToggle) {
  paymentToggle.addEventListener('click', (e) => {
    const btn = e.target.closest('.payment-btn');
    if (!btn) return;
    setPaymentPlan(btn.dataset.value);
  });

  const initialPlan = (document.querySelector('input[name="payment_plan_choice"]:checked') || {}).value || 'full';
  setPaymentPlan(initialPlan);
}

// ---------- ÉTAPE 3 : Confirmation ----------
function goToConfirmStep() {
  stepAllocate.classList.add('hidden');
  stepChoice.classList.add('hidden');
  stepConfirm.classList.remove('hidden');

  const withdraw = parseFloat(
    (document.getElementById('amount-withdraw').textContent || '0')
      .replace(/[^\d,.-]/g, '')
      .replace(',', '.')
  ) || 0;

  const showIban = withdraw > 0.01;
  document.getElementById('confirm-iban-section').classList.toggle('hidden', !showIban);
  if (showIban) document.getElementById('confirm-iban').value = ibanInput.value || '';
  document.getElementById('popup-iban-value').value = ibanInput.value || '';

  // Génère les inputs cachés pour les nouveaux contrats
  const newContractsInputsContainer = document.getElementById('new-contracts-inputs');
  newContractsInputsContainer.innerHTML = '';
  reinvestmentCart.forEach((item, index) => {
    newContractsInputsContainer.insertAdjacentHTML('beforeend', `
      <input type="hidden" name="new_products[${index}][id]" value="${item.id}">
      <input type="hidden" name="new_products[${index}][plant_type]" value="${item.plantType}">
    `);
  });

  // Synchronise les codes (au cas où)
  onCodeChanged('promo',    promoCodeInput ? promoCodeInput.value : '');
  onCodeChanged('referral', referralCodeInput ? referralCodeInput.value : '');

  recalcDiscountsAndTotals();
}

document.getElementById('popup-cta-allocate').addEventListener('click', goToConfirmStep);

document.getElementById('popup-back-to-choice-btn').addEventListener('click', () => {
  stepAllocate.classList.add('hidden');
  stepChoice.classList.remove('hidden');
});

document.getElementById('popup-back-btn').addEventListener('click', () => {
  stepConfirm.classList.add('hidden');
  if (totalToAllocate > 0.01) stepAllocate.classList.remove('hidden');
  else                        stepChoice.classList.remove('hidden');
});

// Soumission formulaire final
renewalForm.addEventListener('submit', function (e) {
  e.preventDefault();        // vérifs côté client
  recalcDiscountsAndTotals(); // s’assure que les champs hidden sont à jour

  const withdrawAmount  = parseFloat(document.getElementById('popup-withdraw-amount').value || '0');
  const ibanHiddenInput = document.getElementById('popup-iban-value');
  const topUpBrut       = parseFloat(document.getElementById('popup-top-up-amount').value || '0');

  // Validation IBAN si retrait
  if (withdrawAmount > 0 && (!ibanHiddenInput.value || ibanHiddenInput.value.trim().length < 10)) {
    alert("Veuillez renseigner un IBAN valide pour le virement.");
    return;
  }

  // Confirmation du versement complémentaire brut (UX)
  if (topUpBrut > 0 && !document.getElementById('top-up-checkbox').checked) {
    const proceed = confirm("Vous avez un versement complémentaire à régler, mais la case de confirmation n'est pas cochée. Souhaitez-vous continuer quand même ?");
    if (!proceed) return;
  }

  // Nettoyage IBAN si pas de retrait
  if (withdrawAmount <= 0) {
    ibanHiddenInput.value   = '';
    ibanHiddenInput.disabled = true;
  } else {
    ibanHiddenInput.disabled = false;
  }

  this.submit();
});


    // ---------- POPUP DÉTAILS ----------
    const detailsPopup = document.getElementById('details-popup-overlay');
    const closeDetailsBtn = document.getElementById('close-details-popup');

    document.querySelectorAll('.card[data-details]').forEach(card => {
        card.addEventListener('click', (e) => {
            if (e.target.closest('.js-no-details')) return;

            try {
                const data = JSON.parse(card.dataset.details);
                const statutInfo = {
                    'en_cours': { text: 'En cours', class: 'status-en-cours' },
                    'cloture': { text: 'Clôturé', class: 'status-cloture' },
                    'en_attente_renouvellement': { text: 'À renouveler', class: 'status-en-attente' },
                    'en_attente_paiement': { text: 'Paiement en attente', class: 'status-paiement-attente' }
                };
                const currentStatus = statutInfo[data.statut] || { text: data.statut, class: '' };
                const dateSouscription = new Date(data.date_souscription);

                document.getElementById('details-popup-title').textContent = `${data.produit_name} - ${formatCurrency(data.montant)}`;
                const statusBadge = document.getElementById('details-status-badge');
                statusBadge.textContent = currentStatus.text;
                statusBadge.className = `status-badge ${currentStatus.class.replace('status-', '')}`;
                document.getElementById('details-apport').textContent = formatCurrency(data.apport);
                document.getElementById('details-rendement-final').textContent = formatCurrency(data.rendement_total_contrat);
                document.getElementById('details-date-souscription').textContent = dateSouscription.toLocaleDateString('fr-FR');
                document.getElementById('details-date-fin').textContent = data.date_fin;
                document.getElementById('details-duree').textContent = `${data.duree_mois} mois`;
                document.getElementById('details-taux').textContent = `${parseFloat(data.taux_moyen).toFixed(2)} %`;
                document.getElementById('details-progress-bar').style.width = `${data.pourcentage_temps_ecoule}%`;
                document.getElementById('details-progress-start').textContent = dateSouscription.toLocaleDateString('fr-FR');
                document.getElementById('details-progress-end').textContent = data.date_fin;
                document.getElementById('details-descriptif').textContent = data.produit_descriptif;

                detailsPopup.style.display = 'flex';
            } catch (err) {
                console.error("Erreur lors de la lecture des détails du contrat :", err);
            }
        });
    });

    const closeDetailsPopup = () => { detailsPopup.style.display = 'none'; };
    if (closeDetailsBtn) closeDetailsBtn.addEventListener('click', closeDetailsPopup);
    if (detailsPopup) {
        detailsPopup.addEventListener('click', (e) => {
            if (e.target === detailsPopup) closeDetailsPopup();
        });
    }

    // ---------- RÈGLES : "Garder mes plants" & anti-doublons ----------
    function enforcePlantTypeRules() {
        const list = document.getElementById('product-list');
        if (!list || !currentContractData || !currentContractData.produit_id) return;

        list.querySelectorAll('.product-item').forEach(item => {
            const btn = item.querySelector('.add-product-btn');
            if (!btn) return;

            const index = btn.getAttribute('data-index');
            const p = availableProducts[index];
            if (!p) return;

            const keepRadio = item.querySelector(`input[name="plant_type_${p.id}"][value="mature"]`);
            const keepLabel = keepRadio ? keepRadio.closest('label') : null;
            const allowed = Number(p.id) === Number(currentContractData.produit_id);

            if (keepRadio) {
                keepRadio.disabled = !allowed;
                if (!allowed) {
                    keepRadio.checked = false;
                    const newRadio = item.querySelector(`input[name="plant_type_${p.id}"][value="new"]`);
                    if (newRadio) newRadio.checked = true;

                    if (keepLabel) {
                        keepLabel.style.opacity = 0.4;
                        keepLabel.title = "Option disponible uniquement pour le même produit que le contrat en renouvellement.";
                    }
                } else {
                    if (keepLabel) {
                        keepLabel.style.opacity = 1;
                        keepLabel.title = "";
                    }
                }
            }
        });
    }

    // Observer les changements de la liste produits pour réappliquer la règle
    const productListObserverTarget = document.getElementById('product-list');
    if (productListObserverTarget) {
        const mo = new MutationObserver(() => enforcePlantTypeRules());
        mo.observe(productListObserverTarget, { childList: true, subtree: true });
    }

    function sanitizeCartDuplicates() {
        const seen = new Set();
        reinvestmentCart = reinvestmentCart.filter(item => {
            const key = `${item.id}::${item.plantType || 'new'}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    // Garde anti double-clic globale pour "Ajouter"
    let lastAddTs = 0;

}); // fin DOMContentLoaded
  (function(){
  const formErrors = <?php echo json_encode($FORM_ERRORS ?? []); ?>;
  if (!formErrors || !Object.keys(formErrors).length) return;

  function showFieldError(inputEl, msg) {
    if (!inputEl) return;
    inputEl.classList.add('input-error');
    let fb = inputEl.parentElement.querySelector('.form-feedback');
    if (!fb) {
      fb = document.createElement('small');
      fb.className = 'form-feedback error';
      inputEl.parentElement.appendChild(fb);
    } else {
      fb.classList.add('error');
    }
    fb.textContent = msg || 'Champ invalide.';
  }

  if (formErrors.iban) {
    const overlay = document.getElementById('renewal-popup-overlay');
    const stepChoice = document.getElementById('popup-step-choice');
    const stepAllocate = document.getElementById('popup-step-allocate');
    const stepConfirm = document.getElementById('popup-step-confirm');
    if (overlay && stepChoice && stepAllocate && stepConfirm) {
      overlay.style.display = 'flex';
      stepChoice.classList.remove('hidden');
      stepAllocate.classList.add('hidden');
      stepConfirm.classList.add('hidden');
      setTimeout(() => {
        const ibanInput = document.getElementById('iban-input');
        if (ibanInput) { showFieldError(ibanInput, formErrors.iban); ibanInput.focus(); }
      }, 50);
    }
  }
})();
</script>
</body>
</html>
