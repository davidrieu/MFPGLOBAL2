<?php
session_start();
require_once 'db_connection.php'; // Votre connexion à la BDD

// --- 1. SÉCURITÉ ET VÉRIFICATIONS ---

// Vérifie que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Récupère l'ID du contrat depuis l'URL et s'assure que c'est un nombre
$contrat_id_a_renouveler = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$contrat_id_a_renouveler) {
    header('Location: recoltes.php?error=invalid_id');
    exit();
}

$user_id = $_SESSION['user_id'];

// --- 2. VÉRIFICATION DU CONTRAT ET DE SON ÉLIGIBILITÉ ---

try {
    // Étape A : On récupère le contrat et la durée du produit associé
    // On vérifie que le contrat appartient bien à l'utilisateur connecté
    $stmt = $pdo->prepare(
        "SELECT c.produit_id, c.type_paiement, c.date_souscription, p.duree_mois
         FROM contrats AS c
         JOIN produits AS p ON c.produit_id = p.id
         WHERE c.id = :contrat_id AND c.user_id = :user_id
         LIMIT 1"
    );
    $stmt->execute([
        'contrat_id' => $contrat_id_a_renouveler,
        'user_id' => $user_id
    ]);
    $contrat = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$contrat) {
        // Le contrat n'existe pas ou n'appartient pas à l'utilisateur
        header('Location: recoltes.php?error=contrat_invalide');
        exit();
    }

    // Étape B : On recalcule son statut pour vérifier qu'il est bien renouvelable
    $date_souscription = new DateTime($contrat['date_souscription']);
    $duree_mois = (int)$contrat['duree_mois'];
    $aujourdhui = new DateTime();
    $date_fin = (clone $date_souscription)->add(new DateInterval("P{$duree_mois}M"));
    $date_limite_renouvellement = (clone $date_fin)->add(new DateInterval("P30D"));

    // Condition exacte de votre fichier recoltes.php
    $est_renouvelable = ($aujourdhui >= $date_fin && $aujourdhui <= $date_limite_renouvellement);

    if (!$est_renouvelable) {
        // Si le contrat n'est pas dans la période de renouvellement
        header('Location: recoltes.php?error=non_renouvelable');
        exit();
    }

    // Étape C : On récupère les informations actuelles du produit (le prix a peut-être changé)
    $produit_id = $contrat['produit_id'];
    $stmt_produit = $pdo->prepare("SELECT id, name, prix, taux FROM produits WHERE id = :produit_id LIMIT 1");
    $stmt_produit->execute(['produit_id' => $produit_id]);
    $produit = $stmt_produit->fetch(PDO::FETCH_ASSOC);

    if (!$produit) {
        // Si le produit d'origine n'existe plus dans le catalogue
        header('Location: recoltes.php?error=produit_inconnu');
        exit();
    }

} catch (PDOException $e) {
    // On commente les lignes originales pour le moment
    // error_log("Erreur renouvellement: " . $e->getMessage());
    // header('Location: recoltes.php?error=db_error');
    // exit();

    // On affiche l'erreur directement pour le débogage
    die("ERREUR SQL DANS renouveler.php : " . $e->getMessage());
}


// --- 3. PRÉPARATION DU PANIER DE RENOUVELLEMENT ---

// On vide le panier actuel pour éviter de mélanger un renouvellement avec d'autres achats
unset($_SESSION['investment_cart']);
$_SESSION['investment_cart'] = [];

// On prépare le produit à ajouter au panier
$item_a_renouveler = [
    'id' => $produit['id'],
    'name' => 'Renouvellement - ' . $produit['name'], // On peut ajouter un préfixe pour plus de clarté
    'price' => $produit['prix'],
    'quantity' => 1, // Un renouvellement concerne 1 contrat
    'rendement' => $produit['taux'],
    'paymentMode' => $contrat['type_paiement'] // On reprend le même mode de paiement
];

// On ajoute l'article au panier de la session
$_SESSION['investment_cart'][$produit['id']] = $item_a_renouveler;

// --- 4. REDIRECTION VERS LE TUNNEL DE PAIEMENT ---

// Le panier est prêt, on redirige vers la page de récapitulatif
header('Location: recapitulatifclient.php');
exit();

?>