<?php
// process_rdv.php
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Inclusion de la connexion BDD et des fonctions email
    require 'db_connection.php';
    require 'mail_functions.php'; // S'ASSURER QUE CE FICHIER EST BIEN INCLUS

    // 1. Récupérer et nettoyer les données du formulaire
    $nom_complet = trim(htmlspecialchars($_POST['nom_complet']));
	$telephone = trim(htmlspecialchars($_POST['telephone']));
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL));
    $date_rdv = trim($_POST['date_rdv']);
    $heure_rdv = trim($_POST['heure_rdv']);

    // 2. Valider les données
    if (empty($nom_complet) || empty($telephone) || empty($email) || empty($date_rdv) || empty($heure_rdv) || $email === false) {
        header("Location: investir.php?status=error");
        exit();
    }

    try {
        // 3. Insérer les données dans la base de données
        $sql = "INSERT INTO rendez_vous (nom_complet, telephone, email, date_rdv, heure_rdv) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nom_complet, $telephone, $email, $date_rdv, $heure_rdv]);

        // 4. Préparer et envoyer l'email de confirmation de demande
        $subject = "Confirmation de votre demande de rendez-vous";
        $body = "
            <h2>Bonjour " . htmlspecialchars($nom_complet) . ",</h2>
            <p>Nous avons bien reçu votre demande de rendez-vous pour investir chez Mon Plant Fraise.</p>
            <p>Voici les détails de votre demande :</p>
            <ul>
                <li><strong>Date souhaitée :</strong> " . date('d/m/Y', strtotime($date_rdv)) . "</li>
                <li><strong>Heure souhaitée :</strong> " . htmlspecialchars($heure_rdv) . "</li>
            </ul>
            <p>Notre équipe va examiner votre demande et vous recevrez un <strong>nouvel email</strong> dès que le rendez-vous sera validé par nos soins.</p>
            <p>Cordialement,<br>L'équipe Mon Plant Fraise</p>
        ";
        
        // L'APPEL À LA FONCTION D'ENVOI D'EMAIL
        send_appointment_email($email, $subject, $body);

        // 5. Rediriger avec un statut de succès pour afficher la popup
        header("Location: investir.php?status=success#appointment-module");
        exit();

    } catch (Exception $e) {
        // En cas d'erreur, rediriger avec un message d'erreur
        error_log("Erreur lors du traitement du RDV : " . $e->getMessage());
        header("Location: investir.php?status=error");
        exit();
    }

} else {
    // Si la page est accédée directement, rediriger
    header("Location: investir.php");
    exit();
}
?>