<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Client - Mon Plant Fraise</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <style>
        /* --- Reset et Style Général --- */
        :root {
            --primary-color: #4CAF50; /* Vert principal */
            --primary-color-dark: #388E3C;
            --text-color: #333333;
            --text-color-light: #757575;
            --background-color: #f5f5f5;
            --card-background-color: #ffffff;
            --border-radius: 8px;
            --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }

        body {
            background-color: var(--background-color);
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            display: flex;
            color: var(--text-color);
        }

        /* --- Barre de Navigation Latérale (Sidebar) --- */
        .sidebar {
            background-color: var(--card-background-color);
            width: 260px;
            height: 100vh;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
        }

        .sidebar-header {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 30px;
            padding-left: 10px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar ul li a {
            display: flex;
            align-items: center;
            padding: 12px 10px;
            margin-bottom: 8px;
            text-decoration: none;
            color: var(--text-color-light);
            border-radius: var(--border-radius);
            font-weight: 500;
            transition: background-color 0.2s ease, color 0.2s ease;
        }

        .sidebar ul li a .material-symbols-outlined {
            margin-right: 15px;
            font-size: 22px;
        }

        .sidebar ul li a:hover {
            background-color: #eeeeee;
        }

        /* Style pour le lien actif */
        .sidebar ul li a.active {
            background-color: var(--primary-color);
            color: white;
        }

        /* --- Contenu Principal --- */
        .container {
            margin-left: 300px; /* 260px sidebar + 40px padding */
            padding: 20px;
            width: 100%;
            transition: margin-left 0.3s ease-in-out;
        }

        .main-header {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        /* --- Cartes de Contenu --- */
        .card {
            background-color: var(--card-background-color);
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: var(--box-shadow);
            border-radius: var(--border-radius);
        }

        .card h3 {
            color: var(--text-color);
            margin-top: 0;
            font-size: 20px;
            font-weight: 500;
        }
        
        .card p {
            line-height: 1.6;
            color: var(--text-color-light);
        }
        
        /* Style spécifique pour les infos financières */
        .financial-info span {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.1em;
        }

        /* --- Bouton Material --- */
        .material-button {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .material-button:hover {
            background-color: var(--primary-color-dark);
            box-shadow: 0 3px 6px rgba(0,0,0,0.25);
        }

        /* --- Responsive Design --- */
        .toggle-btn {
            display: none; /* Caché sur desktop */
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }
            
            .container {
                margin-left: 0;
                padding: 15px;
            }
            
            .toggle-btn {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                background-color: var(--primary-color);
                color: white;
                border: none;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                cursor: pointer;
                z-index: 1001;
                box-shadow: 0 2px 5px rgba(0,0,0,0.3);
                font-size: 24px;
            }

            .main-header {
                margin-top: 60px; /* Espace pour le bouton menu */
            }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar">
    <div class="sidebar-header">
        Mon Plant Fraise
    </div>
    <ul>
        <li><a href="#" class="active"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="#"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Tableau de bord</h1>

    <div class="card">
        <h3>
            Bienvenue, Marie Dupont !
        </h3>
        <p class="financial-info">Les informations financières sont en cours de chargement...</p>
    </div>

    <div class="card">
        <h3>Répartition de vos avoirs</h3>
        <div style="max-width: 350px; margin: 0 auto;">
            <canvas id="doughnutChart"></canvas>
        </div>
    </div>

    <div class="card">
        <h3>🎉 Nouveau : Le Parrainage est arrivé !</h3>
        <p>Partagez l’amour des fraises avec vos amis et gagnez des récompenses. En parrainant vos proches, recevez des plants de fraises gratuits pour chaque nouvel achat de leur part.</p>
        <p><strong>Parrainez dès aujourd'hui et commencez à récolter vos récompenses ! 🍓</strong></p>
        <a href="#" class="material-button">En savoir plus</a>
    </div>
</div>

<script>
    function toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('open');
    }

    // Cette fonction s'exécute quand le contenu de la page est prêt.
    document.addEventListener('DOMContentLoaded', function() {

        const staticData = {
            somme_contrats_en_cours: 5430.50,
            somme_rendements_actuels: 875.25
        };

        const financialInfo = document.querySelector('.financial-info');
        financialInfo.innerHTML = 
            `La somme totale de vos contrats en cours est de : <span>${new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(staticData.somme_contrats_en_cours)}</span><br>
            Vous avez actuellement un total de rendements d'environ : <span>${new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(staticData.somme_rendements_actuels)}</span>`;
        
        const doughnutCtx = document.getElementById('doughnutChart').getContext('2d');
        new Chart(doughnutCtx, {
            type: 'doughnut',
            data: {
                labels: ['Votre apport', 'Rendements actuels'],
                datasets: [{
                    data: [staticData.somme_contrats_en_cours, staticData.somme_rendements_actuels],
                    // --- MODIFICATION ICI ---
                    // Le vert clair a été remplacé par du rouge (#F44336)
                    backgroundColor: ['#4CAF50', '#F44336'], 
                    borderColor: 'var(--card-background-color)',
                    borderWidth: 4,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            color: '#333',
                            padding: 20
                        }
                    }
                }
            }
        });
    });
</script>

</body>
</html>
