<?php
// Démarrer la session pour stocker des messages
session_start();

// Inclure le fichier de connexion à la base de données
require_once 'db_connection.php'; 

$errors = [];

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Récupérer et nettoyer les données
    $prenom = trim($_POST['prenom'] ?? '');
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password_form = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $date_naissance = trim($_POST['date_naissance'] ?? '');
    $adresse = trim($_POST['adresse'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $code_parrain_saisi = trim($_POST['code_parrain'] ?? '');

    // 2. Valider les données
    if (empty($prenom) || empty($nom) || empty($email) || empty($password_form) || empty($date_naissance) || empty($adresse) || empty($telephone)) {
        $errors[] = "Tous les champs principaux sont obligatoires.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'adresse e-mail n'est pas valide.";
    }
    if ($password_form !== $password_confirm) {
        $errors[] = "Les mots de passe ne correspondent pas.";
    }
    if (strlen($password_form) < 8) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
    }
    // NOUVEAU : Vérifier si la case des conditions générales a été cochée
    if (!isset($_POST['terms'])) {
        $errors[] = "Vous devez accepter les conditions générales d'utilisation pour vous inscrire.";
    }

    // 3. Vérifier si l'email existe déjà
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "Cette adresse e-mail est déjà utilisée.";
        }
    }
    
    // ... Le reste de la logique PHP reste identique ...

    // 4. Traitement du code de parrainage
    $parrain_id = null;
    if (!empty($code_parrain_saisi) && empty($errors)) { // On vérifie seulement s'il n'y a pas déjà d'erreurs
        $stmt = $pdo->prepare("SELECT id FROM users WHERE sponsorship_code = ? AND verifie = 'oui'");
        $stmt->execute([$code_parrain_saisi]);
        $parrain = $stmt->fetch();
        if ($parrain) {
            $parrain_id = $parrain['id'];
        } else {
            $errors[] = "Le code de parrainage est invalide.";
        }
    }

    // 5. Si aucune erreur, procéder à l'insertion
    if (empty($errors)) {
        $hashed_password = password_hash($password_form, PASSWORD_BCRYPT);

        try {
            $sql = "INSERT INTO users (prenom, name, email, password, date_naissance, adresse, telephone, registration_date, statut, verifie, parrain) 
                    VALUES (:prenom, :nom, :email, :password, :date_naissance, :adresse, :telephone, NOW(), 'actif', 'non', :parrain)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':prenom'         => htmlspecialchars($prenom),
                ':nom'            => htmlspecialchars($nom),
                ':email'          => $email,
                ':password'       => $hashed_password,
                ':date_naissance' => $date_naissance,
                ':adresse'        => htmlspecialchars($adresse),
                ':telephone'      => htmlspecialchars($telephone),
                ':parrain'        => $parrain_id
            ]);
            header("Location: login.php?status=registered");
            exit();
        } catch (PDOException $e) {
            $errors[] = "Une erreur technique est survenue. Veuillez réessayer.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un compte - Mon Plant Fraise</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body, html { font-family: 'Montserrat', sans-serif; background-color: #f4f4f4; }
        .container { max-width: 600px; margin: 50px auto; padding: 40px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #6B8E23; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; }
        .form-group input[type="text"], input[type="email"], input[type="password"], input[type="date"], input[type="tel"] { width: calc(100% - 24px); padding: 12px; border: 1px solid #ccc; border-radius: 5px; }
        .form-row { display: flex; gap: 20px; }
        .form-row .form-group { flex: 1; }
        .submit-btn { width: 100%; padding: 15px; background-color: #6B8E23; color: #fff; border: none; border-radius: 5px; font-size: 1.1rem; cursor: pointer; }
        .login-link { text-align: center; margin-top: 20px; }
        .login-link a { color: #6B8E23; text-decoration: none; font-weight: 600; }
        .error-messages { padding: 15px; background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; border-radius: 5px; margin-bottom: 20px; }
        .error-messages ul { margin: 0; padding-left: 20px; }
        /* NOUVEAU : Style pour la case à cocher des CGU */
        .form-group.terms { display: flex; align-items: center; }
        .form-group.terms input[type="checkbox"] { margin-right: 10px; width: auto; }
        .form-group.terms label { margin-bottom: 0; font-weight: normal; }
        .form-group.terms a { color: #6B8E23; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Créer votre compte investisseur</h1>

        <?php if (!empty($errors)): ?>
            <div class="error-messages">
                <strong>Oups ! Une erreur est survenue :</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="creer-compte.php" method="POST">
            <div class="form-row">
                <div class="form-group"><label for="prenom">Prénom</label><input type="text" id="prenom" name="prenom" required value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>"></div>
                <div class="form-group"><label for="nom">Nom</label><input type="text" id="nom" name="nom" required value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>"></div>
            </div>
            <div class="form-group"><label for="email">Adresse E-mail</label><input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"></div>
            <div class="form-row">
                <div class="form-group"><label for="password">Mot de passe</label><input type="password" id="password" name="password" required></div>
                <div class="form-group"><label for="password_confirm">Confirmer</label><input type="password" id="password_confirm" name="password_confirm" required></div>
            </div>
            <div class="form-group"><label for="date_naissance">Date de naissance</label><input type="date" id="date_naissance" name="date_naissance" required value="<?php echo htmlspecialchars($_POST['date_naissance'] ?? ''); ?>"></div>
            <div class="form-group"><label for="adresse">Adresse complète</label><input type="text" id="adresse" name="adresse" required value="<?php echo htmlspecialchars($_POST['adresse'] ?? ''); ?>"></div>
            <div class="form-group"><label for="telephone">Numéro de téléphone</label><input type="tel" id="telephone" name="telephone" required value="<?php echo htmlspecialchars($_POST['telephone'] ?? ''); ?>"></div>
            <div class="form-group"><label for="code_parrain">Code de parrainage (Optionnel)</label><input type="text" id="code_parrain" name="code_parrain" value="<?php echo htmlspecialchars($_POST['code_parrain'] ?? ''); ?>"></div>

            <div class="form-group terms">
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">J'ai lu et j'accepte les <a href="/cgu.php" target="_blank">Conditions Générales d'Utilisation</a>.</label>
            </div>

            <button type="submit" class="submit-btn">Créer mon compte</button>
        </form>

        <p class="login-link">Vous avez déjà un compte ? <a href="login.php">Connectez-vous</a></p>
    </div>
</body>
</html>