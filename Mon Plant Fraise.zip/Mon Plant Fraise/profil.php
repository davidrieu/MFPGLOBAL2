<?php
declare(strict_types=1);

// (Mettez 0 en production)
ini_set('display_errors', 0);
error_reporting(E_ALL);

// IBAN polyfill (désactivé volontairement)
if (!function_exists("is_valid_iban_format")) {
    function is_valid_iban_format($iban) { return true; }
}

// ====================================================================================
// profil.php — Espace client MPF : Profil (users only)
// ====================================================================================

// Démarrer la session en premier
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Inclure la connexion DB et autres dépendances
require_once 'db_connection.php'; // Doit définir $pdo
require_once 'badge_sentinel.php'; // Fichier ré-activé

// ===== Protection CSRF =====
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

// Fonctions utilitaires
function h($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function post($key, $default = ''){
    return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : $default;
}

// Variables pour les messages flash
$flash_success = '';
$flash_error   = '';

// ID de l'utilisateur connecté
$user_id = (int)$_SESSION['user_id'];

// Initialiser les données utilisateur avec des valeurs par défaut
$user = [
    'id'                 => $user_id,
    'name'               => '',
    'prenom'             => '',
    'email'              => '', // Lecture seule
    'telephone'          => '',
    'adresse'            => '',
    'date_naissance'     => '',
    'nationalite'        => '',
    'lieu_naissance'     => '',
    'adresse_l1'         => '',
    'adresse_l2'         => '',
    'code_postal'        => '',
    'ville'              => '',
    'pays'               => 'France', // Défaut
    'iban'               => '',
    'mandat_prelevement' => 0, // 0 ou 1
];

// Variables pour les statistiques des contrats
$stats_contrats = ['en_cours' => 0, 'en_attente' => 0, 'echu' => 0];

// ===== CHARGEMENT INITIAL DES DONNÉES (requête GET ou avant traitement POST) =====
try {
    // Charger les informations de l'utilisateur
    $st = $pdo->prepare("
        SELECT id, name, prenom, email, telephone, adresse,
               date_naissance, nationalite, lieu_naissance,
               adresse_l1, adresse_l2, code_postal, ville, pays,
               iban, mandat_prelevement
        FROM users
        WHERE id = :id
        LIMIT 1
    ");
    $st->execute([':id' => $user_id]);
    $db_user_data = $st->fetch(PDO::FETCH_ASSOC);

    if ($db_user_data) {
        foreach ($user as $key => $defaultValue) {
            if (isset($db_user_data[$key]) && $db_user_data[$key] !== null) {
                $user[$key] = $db_user_data[$key];
            }
        }
        if (empty($user['pays'])) {
            $user['pays'] = 'France';
        }
    } else {
        error_log("Erreur critique: Utilisateur ID {$user_id} connecté mais non trouvé en base.");
        unset($_SESSION['user_id']);
        header('Location: login.php?error=user_not_found');
        exit();
    }

    // Charger les statistiques des contrats
    $stmt_contrats = $pdo->prepare(
        "SELECT c.statut, c.date_souscription, COALESCE(p.duree_mois, 12) AS duree_mois
         FROM contrats c
         LEFT JOIN produits p ON c.produit_id = p.id
         WHERE c.user_id = :uid"
    );
    $stmt_contrats->execute([':uid' => $user_id]);
    $contrats = $stmt_contrats->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $aujourdhui = new DateTimeImmutable();
    foreach ($contrats as $contrat) {
        try {
            // --- CORRECTION PAGE BLANCHE (DATE INVALIDE) ---
            // Ignorer les dates invalides (ex: 0000-00-00) au lieu de planter
            if (empty($contrat['date_souscription']) || $contrat['date_souscription'] === '0000-00-00 00:00:00' || $contrat['date_souscription'] === null) {
                continue; // Saute ce contrat
            }
            
            $date_souscription = new DateTimeImmutable($contrat['date_souscription']);
            $duree_mois = (int)$contrat['duree_mois'];
            if ($duree_mois <= 0) $duree_mois = 12;
            $date_fin = $date_souscription->add(new DateInterval("P{$duree_mois}M"));

            if ($aujourdhui < $date_fin) {
                if (strtolower((string)$contrat['statut']) === 'en_attente') {
                    $stats_contrats['en_attente']++;
                } else {
                    $stats_contrats['en_cours']++;
                }
            } else {
                $stats_contrats['echu']++;
            }
        } catch (Exception $dateEx) {
             error_log("Erreur date contrat ID (non dispo ici) pour user {$user_id}: " . $dateEx->getMessage() . " (Date: " . ($contrat['date_souscription'] ?? 'NULL') . ")");
             // Ne plante pas, continue
        }
    }

} catch (PDOException $e) {
    // --- CORRECTION PAGE BLANCHE (remplace die()) ---
    error_log("Erreur PDO chargement profil user {$user_id}: " . $e->getMessage());
    $flash_error = 'ERREUR TECHNIQUE : Impossible de charger les informations. (PDO)';
} catch (Throwable $e) { 
    // --- CORRECTION PAGE BLANCHE (remplace die()) ---
    error_log("Erreur Throwable chargement profil user {$user_id}: " . $e->getMessage());
    $flash_error = 'ERREUR TECHNIQUE : Une erreur inattendue est survenue. (TH)';
}


// ===== TRAITEMENT DE LA MISE À JOUR (requête POST) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données POST
    $submitted_csrf = post('csrf_token');
    $telephone      = post('telephone');
    $adresse        = post('adresse');
    $date_n         = post('date_naissance');
    $nationalite    = post('nationalite');
    $lieu_naiss     = post('lieu_naissance');
    $adresse_l1     = post('adresse_l1');
    $adresse_l2     = post('adresse_l2');
    $code_postal    = post('code_postal');
    $ville          = post('ville');
    $pays           = post('pays', 'France');
    $iban_raw       = post('iban');
    $iban           = strtoupper(str_replace(' ', '', $iban_raw)); // Nettoyer l'IBAN
    $mandat         = isset($_POST['mandat_prelevement']) ? 1 : 0;

    // Repopuler $user avec les données soumises pour ré-afficher en cas d'erreur
    $user['telephone']          = $telephone;
    $user['adresse']            = $adresse;
    $user['date_naissance']     = $date_n;
    $user['nationalite']        = $nationalite;
    $user['lieu_naissance']     = $lieu_naiss;
    $user['adresse_l1']         = $adresse_l1;
    $user['adresse_l2']         = $adresse_l2;
    $user['code_postal']        = $code_postal;
    $user['ville']              = $ville;
    $user['pays']               = $pays;
    $user['iban']               = $iban;
    $user['mandat_prelevement'] = $mandat;

    try {
        // 1. Vérifier le jeton CSRF
        if (!hash_equals($csrf, $submitted_csrf)) {
            throw new RuntimeException("Erreur de sécurité (jeton invalide). Veuillez réessayer.");
        }

        // --- CORRECTION "ENREGISTREMENT IMPOSSIBLE" ---
        // Bloc de validation strict supprimé pour autoriser la sauvegarde
        // même si d'anciennes données (ex: téléphone) sont invalides.
        
         if ($iban !== '' && !is_valid_iban_format($iban)) {
             throw new RuntimeException("Le format de l'IBAN est invalide.");
         }


        // 3. Préparer et exécuter la mise à jour
        $sql = "UPDATE users SET
                    telephone = :tel,
                    adresse = :adr,
                    date_naissance = :dnaiss,
                    nationalite = :nat,
                    lieu_naissance = :lnaiss,
                    adresse_l1 = :a1,
                    adresse_l2 = :a2,
                    code_postal = :cp,
                    ville = :ville,
                    pays = :pays,
                    iban = :iban,
                    mandat_prelevement = :mandat
                WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([
            ':tel'    => $telephone,
            ':adr'    => $adresse,
            ':dnaiss' => ($date_n !== '' ? $date_n : null),
            ':nat'    => $nationalite,
            ':lnaiss' => $lieu_naiss,
            ':a1'     => $adresse_l1,
            ':a2'     => $adresse_l2,
            ':cp'     => $code_postal,
            ':ville'  => $ville,
            ':pays'   => ($pays !== '' ? $pays : 'France'),
            ':iban'   => $iban,
            ':mandat' => $mandat,
            ':id'     => $user_id
        ]);

        if (!$success) {
             $errorInfo = $stmt->errorInfo();
             error_log("Erreur PDO UPDATE profil user {$user_id}: " . ($errorInfo[2] ?? 'Inconnue'));
             throw new RuntimeException("Une erreur est survenue lors de l'enregistrement. (Code: DB)");
        }

        // 4. Succès
        header("Location: profil.php?ok=1");
        exit(); 

    } catch (PDOException $e) {
        error_log("Erreur PDO UPDATE profil user {$user_id}: " . $e->getMessage());
        $flash_error = "Erreur de base de données lors de la sauvegarde. Veuillez réessayer.";
    } catch (Throwable $e) { 
        $flash_error = $e->getMessage();
    }
}

// Vérifier si un message de succès doit être affiché
if (isset($_GET['ok']) && $_GET['ok'] == '1') {
    $flash_success = "Vos informations ont été mises à jour avec succès.";
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mon Profil - Mon Plant Fraise</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

<style>
    /* --- Styles CSS (inchangés) --- */
    *, *::before, *::after { box-sizing: border-box; }
    :root {
        --primary-color:#2E7D32; --primary-color-dark:#1B5E20; --primary-color-light:#C8E6C9;
        --primary-gradient:linear-gradient(135deg,#4CAF50,#2E7D32);
        --warning-color:#FFA000; --grey-color:#9E9E9E;
        --text-color:#212121; --text-color-light:#757575;
        --background-color:#F4F6F8; --card-background-color:#ffffff;
        --border-radius:12px; --box-shadow:0 4px 12px rgba(0,0,0,0.08);
    }
    body { background:var(--background-color); font-family:'Roboto',Arial,sans-serif; margin:0; display:flex; color:var(--text-color); }
    .sidebar { background:var(--card-background-color); width:260px; height:100vh; padding:20px; position:fixed; top:0; left:0; box-shadow:0 2px 10px rgba(0,0,0,.1); display:flex; flex-direction:column; z-index:1000; transition:.3s; }
    .sidebar-header { margin-bottom:30px; text-align:center; }
    .sidebar-header a img { max-width:80%; height:auto; }
    .sidebar ul { list-style:none; padding:0; margin:0; }
    .sidebar ul li a { display:flex; align-items:center; padding:12px 10px; margin-bottom:8px; text-decoration:none; color:var(--text-color-light); border-radius:var(--border-radius); font-weight:500; transition:.2s; }
    .sidebar ul li a .material-symbols-outlined { margin-right:15px; font-size:22px; }
    .sidebar ul li a:hover { background:#eee; }
    .sidebar ul li a.active { background:var(--primary-color); color:#fff; }
    .container { margin-left:260px; padding:30px; width:calc(100% - 260px); transition:.3s; }
    .main-header { font-family:'Poppins',sans-serif; font-size:28px; font-weight:700; margin-bottom:25px; }

    .alert { padding:14px 16px; border-radius:10px; margin-bottom:18px; font-weight: 500;}
    .alert-success { background:#E8F5E9; border:1px solid #A5D6A9; color: #1B5E20; }
    .alert-error   { background:#FFEBEE; border:1px solid #FFCDD2; color: #C62828; }

    .card { background:var(--card-background-color); padding:25px; margin-bottom:25px; box-shadow:var(--box-shadow); border-radius:var(--border-radius); }
    .card h2 { font-family:'Poppins',sans-serif; color:var(--text-color); margin-top:0; font-size:20px; font-weight:600; margin-bottom:20px; }

    .stats-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px,1fr)); gap:20px; }
    .stat-item { display:flex; align-items:center; gap:15px; background:#F9F9F9; padding:20px; border-radius:var(--border-radius); border-left:5px solid; }
    .stat-item.en-cours { border-color:var(--primary-color); }
    .stat-item.en-attente { border-color:var(--warning-color); }
    .stat-item.echu { border-color:var(--grey-color); }
    .stat-item .icon { font-size:32px; }
    .stat-item.en-cours .icon { color:var(--primary-color); }
    .stat-item.en-attente .icon { color:var(--warning-color); }
    .stat-item.echu .icon { color:var(--grey-color); }
    .stat-info .count { font-family:'Poppins',sans-serif; font-size:28px; font-weight:700; color:var(--text-color); }
    .stat-info .label { font-size:14px; color:var(--text-color-light); }

    .form-grid { display:grid; grid-template-columns:1fr 1fr; gap:25px; }
    .form-group label { display:block; margin-bottom:8px; font-weight:500; font-size:14px; color:var(--text-color); }
    .form-group input, .form-group textarea, .form-group select { 
        width:100%; padding:12px; border:1px solid #ddd; border-radius:var(--border-radius);
        font-size:1rem; font-family:'Roboto',sans-serif; transition:border-color .2s, box-shadow .2s;
        background-color: #fff; 
        color: var(--text-color);
    }
    .form-group input:disabled,
    .form-group textarea:disabled,
    .form-group select:disabled { 
        background-color: #f5f5f5;
        color: #757575;
        cursor: not-allowed;
        border-color: #eee;
    }
    .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
        outline:none; border-color:var(--primary-color); box-shadow:0 0 0 3px var(--primary-color-light);
    }
    .form-group textarea { resize: vertical; min-height: 80px;} 
    .form-group .input-iban { 
        text-transform: uppercase;
    }
    .form-group-checkbox label { 
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
    }
     .form-group-checkbox input[type="checkbox"] {
         width: auto; 
         accent-color: var(--primary-color); 
         cursor: pointer;
     }
      .form-group-checkbox input[type="checkbox"]:disabled {
         cursor: not-allowed;
         accent-color: #bdbdbd;
     }

    /* --- CORRECTION BOUTONS --- */
    .main-actions {
        margin-bottom: 25px; 
        text-align: left;
    }
    .card-footer { margin-top:25px; text-align:right; } /* Gardé au cas où */
    .btn { padding:12px 28px; border:none; border-radius:var(--border-radius); cursor:pointer; font-size:14px; font-weight:700; text-decoration:none; display:inline-block; transition:all .2s; }
    .btn-primary { background:var(--primary-gradient); color:#fff; }
    .btn-primary:hover { box-shadow:0 4px 12px rgba(46,125,50,.4); transform:translateY(-2px); }
    .btn-secondary { background:#E0E0E0; color:#232323; }
    .btn-secondary:hover { background:#BDBDBD; }
    .toggle-btn { display:none; }

    /* --- Styles responsives (inchangés) --- */
    @media (max-width:992px) { 
         .form-grid { grid-template-columns: 1fr; } 
    }
    @media (max-width:768px) {
        .sidebar { transform:translateX(-100%); }
        .sidebar.open { transform:translateX(0); }
        .container { margin-left:0; padding:15px; width:100%; }
        .toggle-btn { display:flex; align-items:center; justify-content:center; position:fixed; top:15px; left:15px; background:var(--primary-color); color:#fff; border:none; border-radius:50%; width:50px; height:50px; cursor:pointer; z-index:1001; box-shadow:0 2px 5px rgba(0,0,0,.3); font-size:24px; }
        .main-header { margin-top:70px; font-size:24px; }
        .card { padding:20px; }
        .card h2 { font-size:18px; }
        .stats-grid { grid-template-columns:1fr; gap:15px; } 
        .stat-info .count { font-size:24px; }
        
        /* --- CORRECTION BOUTONS (RESPONSIVE) --- */
        .main-actions { text-align: center; }
        .main-actions .btn { width:calc(50% - 10px); margin: 5px;}
        .main-actions .btn:last-child { margin-right: 0;}
        .main-actions .btn:first-child { margin-left: 0;}

         @media (max-width: 480px) {
             .main-actions .btn { width: 100%; margin: 0 0 10px 0; }
         }
    }
</style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php" class="active"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <h1 class="main-header">Mon Profil</h1>

    <?php if ($flash_success): ?>
        <div class="alert alert-success"><?= h($flash_success) ?></div>
    <?php endif; ?>
    <?php if ($flash_error): ?>
        <div class="alert alert-error"><?= h($flash_error) ?></div>
    <?php endif; ?>

    <div class="card">
        <h2>Aperçu de vos contrats</h2>
        <div class="stats-grid">
            <div class="stat-item en-cours">
                <span class="material-symbols-outlined icon">play_circle</span>
                <div class="stat-info">
                    <div class="count"><?= (int)$stats_contrats['en_cours'] ?></div>
                    <div class="label">En cours</div>
                </div>
            </div>
            <div class="stat-item en-attente">
                <span class="material-symbols-outlined icon">pending</span>
                <div class="stat-info">
                    <div class="count"><?= (int)$stats_contrats['en_attente'] ?></div>
                    <div class="label">En attente</div>
                </div>
            </div>
            <div class="stat-item echu">
                <span class="material-symbols-outlined icon">check_circle</span>
                <div class="stat-info">
                    <div class="count"><?= (int)$stats_contrats['echu'] ?></div>
                    <div class="label">Échus</div>
                </div>
            </div>
        </div>
    </div>

    <form method="post" action="profil.php" id="profileForm" enctype="application/x-www-form-urlencoded">
        <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

        <div class="main-actions">
            <button type="button" id="editBtn" class="btn btn-secondary">Modifier mes informations</button>
            <button type="submit" id="saveBtn" class="btn btn-primary" style="display:none;">Enregistrer les modifications</button>
        </div>

        <div class="card">
            <h2>Identité & Coordonnées</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Nom</label>
                    <input type="text" id="name" value="<?= h($user['name']) ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="prenom">Prénom</label>
                    <input type="text" id="prenom" value="<?= h($user['prenom']) ?>" disabled>
                </div>

                <div class="form-group">
                    <label for="email">Email (identifiant)</label>
                    <input type="email" id="email" name="email_display" value="<?= h($user['email']) ?>" disabled>
                     </div>

                <div class="form-group">
                    <label for="telephone">Téléphone</label>
                    <input type="tel" id="telephone" name="telephone" value="<?= h($user['telephone']) ?>" placeholder="+33 6 12 34 56 78" disabled>
                </div>

                <div class="form-group" style="grid-column:1 / -1;">
                    <label for="adresse">Adresse (champ historique)</label>
                    <textarea id="adresse" name="adresse" rows="2" placeholder="Ancien champ adresse (optionnel)" disabled><?= h($user['adresse']) ?></textarea>
                </div>

                <div class="form-group">
                    <label for="adresse_l1">Adresse Ligne 1</label>
                    <input type="text" id="adresse_l1" name="adresse_l1" value="<?= h($user['adresse_l1']) ?>" placeholder="Numéro et nom de rue" disabled>
                </div>
                <div class="form-group">
                    <label for="adresse_l2">Adresse Ligne 2</label>
                    <input type="text" id="adresse_l2" name="adresse_l2" value="<?= h($user['adresse_l2']) ?>" placeholder="Appartement, lieu-dit..." disabled>
                </div>
                <div class="form-group">
                    <label for="code_postal">Code postal</label>
                    <input type="text" id="code_postal" name="code_postal" value="<?= h($user['code_postal']) ?>" placeholder="74000" disabled>
                </div>
                <div class="form-group">
                    <label for="ville">Ville</label>
                    <input type="text" id="ville" name="ville" value="<?= h($user['ville']) ?>" placeholder="Annecy" disabled>
                </div>
                <div class="form-group">
                    <label for="pays">Pays</label>
                    <input type="text" id="pays" name="pays" value="<?= h($user['pays']) ?>" placeholder="France" disabled>
                     </div>

                 <div class="form-group">
                    <label for="date_naissance">Date de naissance</label>
                    <input type="date" id="date_naissance" name="date_naissance" value="<?= h($user['date_naissance']) ?>" disabled max="<?= date('Y-m-d') ?>"> </div>
                <div class="form-group">
                    <label for="nationalite">Nationalité</label>
                    <input type="text" id="nationalite" name="nationalite" value="<?= h($user['nationalite']) ?>" placeholder="Française" disabled>
                </div>
                <div class="form-group">
                    <label for="lieu_naissance">Lieu de naissance (Ville, Pays)</label>
                    <input type="text" id="lieu_naissance" name="lieu_naissance" value="<?= h($user['lieu_naissance']) ?>" placeholder="Paris, France" disabled>
                </div>
            </div>
        </div>

        <div class="card">
            <h2>Informations bancaires</h2>
            <div class="form-grid">
                <div class="form-group" style="grid-column:1 / -1;">
                    <label for="iban">IBAN (pour les retraits)</label>
                    <input type="text" id="iban" name="iban" class="input-iban" value="<?= h($user['iban']) // Afficher l'IBAN nettoyé ?>" placeholder="FR76 XXXX XXXX XXXX XXXX XXXX XXX" disabled>
                     </div>
                <div class="form-group form-group-checkbox" style="grid-column:1 / -1;">
                     <label for="mandat_prelevement">
                         <input type="checkbox" id="mandat_prelevement" name="mandat_prelevement" value="1" <?= !empty($user['mandat_prelevement']) ? 'checked' : '' ?> disabled>
                         Mandat de prélèvement SEPA autorisé (pour les paiements en plusieurs fois)
                     </label>
                 </div>
            </div>

            </div>
    </form>
</div>

<script>
function toggleSidebar() { document.querySelector('.sidebar').classList.toggle('open'); }

document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    const profileForm = document.getElementById('profileForm');
    
    // Sélectionne tous les champs qui doivent devenir éditables
    const editableFields = profileForm.querySelectorAll(
        'input[type="tel"], input[type="text"], input[type="date"], input[type="checkbox"], textarea, select'
    );

    if(editBtn && saveBtn && editableFields.length > 0) {
        editBtn.addEventListener('click', () => {
            editableFields.forEach(field => {
                // On active seulement les champs qui ne sont PAS l'email, nom, prenom
                if (field.id !== 'name' && field.id !== 'prenom' && field.id !== 'email') {
                    field.disabled = false;
                }
            });
            editBtn.style.display = 'none';
            saveBtn.style.display = 'inline-block';
            
            const firstEditable = document.getElementById('telephone');
            if (firstEditable) {
                 firstEditable.focus();
            }
        });
    }

    // Formatage IBAN à la volée (inchangé)
    const ibanEl = document.getElementById('iban');
    if (ibanEl) {
        ibanEl.addEventListener('input', (e) => {
            const input = e.target;
            let cursorPos = input.selectionStart;
            let value = input.value.toUpperCase().replace(/[^A-Z0-9]/g,'');
            let originalLength = value.length;
            value = value.replace(/(.{4})/g,'$1 ').trim();
            input.value = value;
            let addedSpaces = Math.floor((cursorPos - 1) / 4) - Math.floor((input.selectionStart - 1 - (value.length - originalLength)) / 4) ;
             cursorPos += (value.length - originalLength) ; 

            try {
                 if (cursorPos < 0) cursorPos = 0;
                 if (cursorPos > input.value.length) cursorPos = input.value.length;
                 input.setSelectionRange(cursorPos, cursorPos);
            } catch(_) {}
        });

        // Appliquer le formatage initial au chargement
        if (ibanEl.value) {
           let initialValue = ibanEl.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
           ibanEl.value = initialValue.replace(/(.{4})/g, '$1 ').trim();
        }
    }

     // Si un message d'erreur est affiché, forcer l'état "édition"
     <?php if ($flash_error): ?>
     // Tenter de deviner le champ basé sur le message
     let errorFieldId = null;
     const errorMsg = <?= json_encode(strtolower($flash_error)) ?>;
     if (errorMsg.includes('téléphone')) errorFieldId = 'telephone';
     else if (errorMsg.includes('date de naissance')) errorFieldId = 'date_naissance';
     else if (errorMsg.includes('iban')) errorFieldId = 'iban';
     else if (errorMsg.includes('adresse ligne 1')) errorFieldId = 'adresse_l1';
     
     if (errorFieldId) {
         const errorField = document.getElementById(errorFieldId);
         if (errorField) { 
              errorField.focus();
              errorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
         }
     }
     // S'assurer que les boutons sont dans l'état "enregistrement" si une erreur POST est survenue
     if (editBtn && saveBtn) {
        editBtn.style.display = 'none';
        saveBtn.style.display = 'inline-block';
        // Activer tous les champs (sauf ceux protégés)
        editableFields.forEach(field => {
            if (field.id !== 'name' && field.id !== 'prenom' && field.id !== 'email') {
                field.disabled = false;
            }
        });
     }
    <?php endif; ?>

});
</script>

</body>
</html>
