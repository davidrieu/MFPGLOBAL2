<?php
// index.php - Pas de logique PHP serveur pour l'instant
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Plant Fraise - Accueil</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        /* Réinitialisation de base et styles du corps */
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            color: #333; /* Couleur par défaut pour le texte des sections */
            background-color: #f9f9f9; /* Un fond léger pour les sections */
            scroll-behavior: smooth; /* Ajout pour défilement doux */
        }

        /* Conteneur principal qui couvre toute la page avec l'image de fond */
        .hero-container {
            height: 100vh;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('/images/fond-fraises.png');
            background-size: cover;
            background-position: center;
            text-align: center;
            position: relative; /* Nécessaire pour positionner le logo et l'overlay */
            color: #fff; /* La couleur du texte est blanche uniquement pour cette section */
        }

        /* Superposition sombre pour améliorer la lisibilité du texte */
        .hero-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.4); /* Légèrement plus sombre */
            z-index: 1;
        }

        /* Style pour le lien "MPF-GROUP" en haut à gauche */
        .header-logo-link {
            position: absolute;
            top: 30px;
            left: 30px;
            z-index: 3; /* Pour être au-dessus de l'overlay (z-index: 1) et du contenu (z-index: 2) */
            background-color: transparent;
            border: 2px solid #fff;
            color: #fff;
            padding: 8px 16px;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            border-radius: 0; /* Angles carrés */
            font-family: 'Montserrat', sans-serif; /* Assurer la cohérence de la police */
        }

        .header-logo-link:hover {
            background-color: rgba(255, 255, 255, 0.9);
            color: #000;
        }

        /* Conteneur pour le titre et les boutons */
        .content-wrapper {
            position: relative;
            z-index: 2; /* Au-dessus de l'overlay */
            padding: 20px;
        }

        /* Style du titre principal */
        .main-title {
            font-size: 3rem; /* Ajusté pour lisibilité */
            font-weight: 700; /* Plus marqué */
            margin-bottom: 40px;
            letter-spacing: 1px; /* Espacement ajusté */
            text-shadow: 0 2px 4px rgba(0,0,0,0.5); /* Ombre portée pour lisibilité */
        }

        /* Conteneur pour la navigation/boutons */
        .main-nav {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap; /* Permet aux boutons de passer à la ligne si nécessaire */
        }

        /* Style des boutons transparents avec angles carrés */
        .nav-button {
            background-color: transparent;
            border: 2px solid #fff;
            color: #fff;
            padding: 12px 25px;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.2s ease;
            border-radius: 0; /* Angles carrés */
            text-transform: uppercase; /* Style plus affirmé */
            letter-spacing: 0.5px;
        }

        .nav-button:hover {
            background-color: rgba(255, 255, 255, 0.9);
            color: #000;
            transform: scale(1.05); /* Léger agrandissement au survol */
        }

        /* Section "Qui sommes-nous ?" */
        .about-section {
            padding: 80px 20px; /* Plus d'espace vertical, padding horizontal */
            background-color: #fff;
        }

        .container {
            width: 90%;
            max-width: 1100px;
            margin: 0 auto; /* Centre le contenu */
        }

        .about-content {
            display: flex;
            align-items: center;
            gap: 50px;
        }

        .about-video-wrapper {
            flex: 1.5; /* Ajustement proportion vidéo/texte */
            position: relative;
            /* Utilisation aspect-ratio pour une meilleure gestion */
            aspect-ratio: 16 / 9;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .about-video-wrapper video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .about-video-controls {
            position: absolute;
            bottom: 15px; /* Ajusté */
            right: 15px; /* Ajusté */
            z-index: 3;
        }

        .about-video-controls button {
            background-color: rgba(0, 0, 0, 0.6); /* Plus contrasté */
            color: #fff;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.2s ease;
        }

        .about-video-controls button:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        .about-text {
            flex: 1; /* Le texte prend le reste */
        }

        .about-text h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #6B8E23; /* Vert olive */
            margin-top: 0;
            margin-bottom: 25px; /* Augmenté */
        }

        .about-text p {
            font-size: 1rem;
            line-height: 1.7;
            margin-bottom: 20px; /* Augmenté */
            color: #555; /* Gris foncé pour le corps du texte */
        }
        .about-text p strong { /* Style pour le texte en gras */
             color: #333; /* Plus sombre pour le gras */
             font-weight: 600;
         }

        /* Section "Notre fonctionnement" */
        .how-it-works-section {
            padding: 80px 20px;
            background-color: #f9f9f9;
            text-align: center;
        }

        .how-it-works-section h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #6B8E23;
            margin-bottom: 60px; /* Augmenté */
        }

        .process-steps {
            display: grid; /* Utilisation de grid pour meilleure gestion */
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); /* Responsive */
            gap: 40px;
            max-width: 1200px; /* Limite largeur globale */
            margin: 0 auto; /* Centrage */
        }

        .step {
            background-color: #fff;
            padding: 30px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .step:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.12);
        }

        .step-icon {
            width: 100px; /* Réduit */
            height: 100px; /* Réduit */
            margin: 0 auto 25px;
            border-radius: 50%;
            background-color: #E6F0D5;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden; /* Assurer que l'img ne dépasse pas */
        }

        .step-icon img {
            width: 60px; /* Taille fixe pour icônes */
             height: 60px; /* Taille fixe pour icônes */
            object-fit: contain; /* S'assure que l'icône est visible */
        }

        .step h3 {
            font-size: 1.4rem; /* Ajusté */
            color: #6B8E23;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .step p {
            font-size: 0.95rem;
            line-height: 1.6;
            color: #555;
        }

        /* --- Adaptation pour les mobiles --- */
        @media (max-width: 992px) { /* Point de rupture tablette */
             .about-content {
                 flex-direction: column; /* Vidéo au-dessus du texte */
                 text-align: center;
                 gap: 40px;
             }
             .about-video-wrapper {
                 width: 100%;
                 max-width: 600px; /* Limite largeur vidéo sur tablette */
                 aspect-ratio: 16 / 9; /* S'assurer du ratio */
             }
             .about-text {
                 max-width: 600px; /* Limite largeur texte */
             }
        }

        @media (max-width: 768px) {
            .main-title {
                font-size: 2.2rem; /* Encore plus petit */
                margin-bottom: 30px;
            }

            .main-nav {
                flex-direction: column;
                align-items: center;
                gap: 15px;
            }

            .nav-button {
                width: 80%;
                max-width: 300px; /* Limite largeur boutons */
                padding: 15px 0;
                font-size: 0.9rem;
            }

            /* Ajustement mobile pour le logo */
            .header-logo-link {
                top: 20px;
                left: 20px;
                padding: 6px 12px;
                font-size: 0.9rem;
            }

            /* Sections */
            .about-section, .how-it-works-section {
                 padding: 60px 15px; /* Moins de padding */
            }

            .about-text h2, .how-it-works-section h2 {
                font-size: 2rem;
                margin-bottom: 40px;
            }

             .about-video-wrapper {
                 /* Les styles de tablette sont déjà bons, on peut affiner si besoin */
                  max-width: 100%; /* Pleine largeur sur mobile */
             }

            .process-steps {
                grid-template-columns: 1fr; /* Une seule colonne */
                gap: 30px;
            }

            .step {
                 width: 100%; /* Pleine largeur */
                 max-width: 400px; /* Limite largeur étape */
                 margin: 0 auto; /* Centrage si besoin */
            }
        }
    </style>

</head>
<body>

    <div class="hero-container">
        <a href="global.php" class="header-logo-link">MPF-GROUP</a>

        <div class="content-wrapper">
            <h1 class="main-title">MON PLANT FRAISE</h1>
            <nav class="main-nav">
                <a href="investir.php" class="nav-button">Parrainer</a> <a href="commander.php" class="nav-button">Commander mes fraises</a> <a href="espace-client.php" class="nav-button">Espace client</a> </nav>
        </div>
    </div>

    <section id="qui-sommes-nous" class="about-section"> <div class="container">
            <div class="about-content">
                <div class="about-video-wrapper">
                    <video id="aboutVideo" autoplay loop muted playsinline poster="/images/video-poster.jpg"> <source src="/videos/mpf.mp4" type="video/mp4">
                        Votre navigateur ne supporte pas la lecture de vidéos.
                    </video>
                    <div class="about-video-controls">
                        <button id="toggleMuteButton">
                            <span id="volumeIcon">🔇</span> <span id="volumeText">Activer le son</span>
                        </button>
                    </div>
                </div>
                <div class="about-text">
                    <h2>Qui sommes-nous ?</h2>
                    <p>
                        <strong>Mon Plant Fraise</strong>, une initiative de MPF Group, c’est l’alliance unique du goût authentique et de l’investissement participatif. En parrainant nos plants, vous partagez la valeur de récoltes exceptionnelles.
                    </p>
                     <p>
                         Situés en Haute-Savoie, nous cultivons avec passion des fraises locales, <strong>garanties sans pesticides de synthèse</strong>. Notre approche agro-écologique préserve la richesse des sols et favorise la biodiversité de notre terroir.
                     </p>
                    <p>
                        Choisissez vos plants, suivez leur épanouissement via votre espace client dédié, et bénéficiez d'un rendement lié à nos ventes directes et transformations artisanales (confitures, sirops...). Transparence et traçabilité sont au cœur de notre démarche.
                    </p>
                     <p><small><i>Investir dans des projets agricoles comporte des risques, incluant un risque de perte partielle ou totale du capital investi. Les rendements ne sont pas garantis.</i></small></p>
                </div>
            </div>
        </div>
    </section>

    <section id="fonctionnement" class="how-it-works-section"> <div class="container">
            <h2>Comment ça marche ?</h2>
            <div class="process-steps">
                <div class="step">
                    <div class="step-icon">
                        <img src="/images/icon-step1.png" alt="Icône Choisissez vos plants">
                    </div>
                    <h3>1. Parrainez vos plants</h3>
                    <p>Sélectionnez le nombre de plants de fraisiers que vous souhaitez soutenir via nos différentes offres.</p>
                </div>
                <div class="step">
                    <div class="step-icon">
                        <img src="/images/icon-step2.png" alt="Icône Nous les cultivons">
                    </div>
                    <h3>2. Culture experte</h3>
                    <p>Nos agronomes veillent sur vos plants, appliquant des méthodes durables pour une croissance saine.</p>
                </div>
                <div class="step">
                    <div class="step-icon">
                        <img src="/images/icon-step3.png" alt="Icône Suivez leur croissance">
                    </div>
                    <h3>3. Suivi en ligne</h3>
                    <p>Via votre espace client, observez l'évolution de vos plants et la performance estimée de vos parrainages.</p>
                </div>
                <div class="step">
                    <div class="step-icon">
                        <img src="/images/icon-step4.png" alt="Icône Récoltez les fruits">
                    </div>
                    <h3>4. Partagez la valeur</h3>
                    <p>À la fin du cycle, nous commercialisons la récolte et vous recevez votre part de la valeur générée.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="commander" style="padding: 60px 20px; text-align: center; background: #fff;">
         <div class="container">
             <h2>Commander nos Produits</h2>
             <p>Bientôt disponible : commandez directement nos fraises fraîches et produits transformés issus de nos récoltes.</p>
             </div>
     </section>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const video = document.getElementById('aboutVideo');
            const toggleMuteButton = document.getElementById('toggleMuteButton');
            const volumeIcon = document.getElementById('volumeIcon');
            const volumeText = document.getElementById('volumeText');

            // Met à jour l'icône et le texte en fonction de l'état du son
            function updateVolumeButton() {
                if (!video || !volumeIcon || !volumeText) return; // Sécurité
                if (video.muted) {
                    volumeIcon.textContent = '🔇';
                    volumeText.textContent = 'Activer son'; // Texte plus court
                } else {
                    volumeIcon.textContent = '🔊';
                    volumeText.textContent = 'Couper son'; // Texte plus court
                }
            }

            // Gère le clic sur le bouton de son
            if (toggleMuteButton && video) {
                toggleMuteButton.addEventListener('click', function() {
                    video.muted = !video.muted;
                    updateVolumeButton();
                });
            }

            // Initialise le bouton au chargement
            updateVolumeButton();

            // Tentative de lancer la vidéo même si autoplay est bloqué (utile sur certains mobiles)
             if (video) {
                 video.play().catch(error => {
                     console.log("La lecture automatique a été bloquée par le navigateur. L'utilisateur devra peut-être interagir.");
                     // Optionnel: Afficher un bouton play/pause si l'autoplay échoue
                 });
             }

        });
    </script>

</body>
</html>