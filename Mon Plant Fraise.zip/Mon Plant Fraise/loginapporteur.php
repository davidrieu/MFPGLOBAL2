<?php
// loginapporteur.php — Auth apporteur (username/password) + initialisation session
session_start();
require_once __DIR__ . '/db_connection.php'; // Doit définir $pdo (PDO)

if (!isset($pdo) || !($pdo instanceof PDO)) {
  http_response_code(500);
  exit("db_connection.php doit définir \$pdo (PDO).");
}

/**
 * Crée la table apporteurs_login si absente et bootstrap un compte par défaut :
 *   username: MPFAPPORT / password: 69MPF/TELE / sponsorship_code: AMA123
 */
function ensureApporteurTableAndSeed(PDO $pdo): void {
  $pdo->exec("
    CREATE TABLE IF NOT EXISTS apporteurs_login (
      id BIGINT PRIMARY KEY AUTO_INCREMENT,
      username VARCHAR(64) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      sponsorship_code VARCHAR(64) NOT NULL,
      name VARCHAR(120) NULL,
      email VARCHAR(190) NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  ");
  // compte par défaut si introuvable
  $stmt = $pdo->prepare("SELECT id FROM apporteurs_login WHERE username = ?");
  $stmt->execute(['MPFAPPORT']);
  if (!$stmt->fetchColumn()) {
    $hash = password_hash('69MPF/TELE', PASSWORD_DEFAULT);
    $ins = $pdo->prepare("INSERT INTO apporteurs_login (username, password_hash, sponsorship_code, name) VALUES (?,?,?,?)");
    $ins->execute(['MPFAPPORT', $hash, 'AMA123', 'Compte Apporteur']);
  }
}
ensureApporteurTableAndSeed($pdo);

// Déconnexion (optionnel)
if (isset($_GET['logout'])) {
  session_destroy();
  header('Location: loginapporteur.php');
  exit;
}

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

// Protection contre redirection externe
function safe_next(string $next): string {
  if (preg_match('~^https?://~i', $next)) return 'dashboardapporteur.php';
  if ($next === '' || $next === '/') return 'dashboardapporteur.php';
  return $next;
}

$error = null;
$next  = safe_next($_GET['next'] ?? $_POST['next'] ?? 'dashboardapporteur.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = (string)($_POST['password'] ?? '');
  $stmt = $pdo->prepare("SELECT * FROM apporteurs_login WHERE username = ?");
  $stmt->execute([$username]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if ($user && password_verify($password, $user['password_hash'])) {
    // Init session apporteur
    $_SESSION['apporteur_id']       = (int)$user['id'];
    $_SESSION['apporteur_username'] = $user['username'];
    $_SESSION['apporteur_code']     = $user['sponsorship_code']; // <-- sert à filtrer users/contrats
    header("Location: " . $next);
    exit;
  } else {
    $error = "Identifiants invalides.";
  }
}
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8"/>
  <title>Connexion apporteur</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,'Helvetica Neue',Arial,'Noto Sans',sans-serif;background:#f8fafc;margin:0}
    .wrap{max-width:460px;margin:10vh auto;padding:24px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,.05)}
    h1{margin:0 0 10px 0;font-size:20px}
    .muted{color:#64748b;font-size:13px;margin:0 0 14px 0}
    .row{display:flex;gap:8px;align-items:center}
    .input{width:100%;border:1px solid #e5e7eb;border-radius:8px;padding:10px}
    .btn{border:1px solid #111827;background:#111827;color:#fff;border-radius:8px;padding:10px 14px;cursor:pointer;width:100%}
    .flash{background:#fff7ed;border:1px solid #fdba74;color:#9a3412;border-radius:8px;padding:8px 10px;margin-bottom:10px;font-size:14px}
    label{display:block;font-size:12px;color:#64748b;margin:8px 0 6px}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Connexion apporteur</h1>
    <p class="muted">Entrez votre nom d’utilisateur et votre mot de passe pour accéder au dashboard.</p>
    <?php if ($error): ?><div class="flash"><?= h($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="username">
      <input type="hidden" name="next" value="<?= h($next) ?>"/>
      <label>Nom d’utilisateur</label>
      <input class="input" name="username" required value="<?= h($_POST['username'] ?? 'MPFAPPORT') ?>"/>
      <label>Mot de passe</label>
      <input class="input" name="password" type="password" required placeholder="••••••••"/>
      <div style="margin-top:12px">
        <button class="btn" type="submit">Se connecter</button>
      </div>
    </form>
    <p class="muted" style="margin-top:10px">Bienvenue sur votre espace</p>
  </div>
</body>
</html>
