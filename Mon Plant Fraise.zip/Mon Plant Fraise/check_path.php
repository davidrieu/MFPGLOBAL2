<?php
// Active l'affichage des erreurs pour ce test
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>Test de chemin pour PHPMailer</h1>";

// Test 1 : Le chemin que nous utilisons actuellement
$path_actuel = __DIR__ . '/vendor/autoload.php';
echo "<p><strong>Test 1 :</strong> Vérification du chemin <code>" . $path_actuel . "</code>...</p>";

if (is_readable($path_actuel)) {
    echo "<p style='color:green; font-weight:bold;'>SUCCÈS : Le fichier a été trouvé et est lisible dans le même dossier !</p>";
    echo "<p>Cela signifie que le problème est très probablement lié aux permissions ou à un conflit dans le code. Le chemin est correct.</p>";
} else {
    echo "<p style='color:red;'>ÉCHEC : Le fichier est introuvable ou illisible à cet emplacement.</p>";
    
    // Test 2 : Le chemin le plus courant (dossier parent)
    $path_parent = __DIR__ . '/../vendor/autoload.php';
    echo "<hr>";
    echo "<p><strong>Test 2 :</strong> Vérification du chemin <code>" . $path_parent . "</code> (dossier parent)...</p>";

    if (is_readable($path_parent)) {
        echo "<p style='color:green; font-weight:bold;'>SUCCÈS : Le fichier a été trouvé et est lisible dans le dossier parent !</p>";
        echo "<p><strong>SOLUTION :</strong> Le chemin dans le fichier <code>demande_reset.php</code> doit être modifié pour utiliser <code>require __DIR__ . '/../vendor/autoload.php';</code></p>";
    } else {
        echo "<p style='color:red; font-weight:bold;'>ÉCHEC FINAL : Le fichier est introuvable ou illisible dans le dossier parent également.</p>";
        echo "<p><strong>CAUSE PROBABLE :</strong> Le dossier <code>vendor</code> n'a pas été téléversé sur le serveur, ou il n'est pas au bon endroit.</p>";
    }
}
?>