<?php
// On démarre la session pour stocker le panier ET la réduction. C'est crucial !
session_start();

// --- NOUVEAU BLOC : CONNEXION À LA BASE DE DONNÉES ---
// Ce fichier est nécessaire pour vérifier le code dans la table 'promo_codes'.
// Assurez-vous que le chemin est correct.
require_once 'db_connection.php'; 

// Fonction pour nettoyer le code promo saisi (similaire à votre page admin)
function normalizeCodeInput(string $s): string {
    $s = strtoupper(trim($s));
    $s = preg_replace('/[^A-Z0-9\-]/u', '', $s);
    return preg_replace('/-+/', '-', $s);
}

// --- NOUVEAU BLOC : TRAITEMENT DU CODE PROMO ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['promo_code'])) {
    $submitted_code = normalizeCodeInput($_POST['promo_code']);
    
    // On cherche un code qui correspond ET qui est actuellement valide
    $stmt = $pdo->prepare(
        "SELECT * FROM promo_codes 
         WHERE code = :code 
           AND is_active = 1
           AND starts_at <= NOW()
           AND (ends_at IS NULL OR ends_at >= NOW())"
    );
    $stmt->execute([':code' => $submitted_code]);
    $promo = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($promo) {
        // Le code existe et est actif. On vérifie la limite d'utilisation.
        if (!is_null($promo['usage_limit']) && $promo['usage_count'] >= $promo['usage_limit']) {
            $_SESSION['promo_message'] = "Ce code promo a atteint sa limite d'utilisation.";
            unset($_SESSION['discount_percent']); // On s'assure qu'aucune réduction n'est appliquée
        } else {
            // Le code est valide ! On le stocke en session.
            $_SESSION['discount_percent'] = $promo['discount_percent'];
            $_SESSION['promo_code'] = $promo['code'];
            $_SESSION['promo_message'] = "Code promo appliqué avec succès !";
        }
    } else {
        // Le code n'existe pas ou est invalide
        $_SESSION['promo_message'] = "Ce code promo est invalide ou a expiré.";
        unset($_SESSION['discount_percent']);
        unset($_SESSION['promo_code']);
    }

    // On redirige pour éviter de renvoyer le formulaire en cas de rechargement de la page
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

// On récupère le message de la session pour l'afficher, puis on le supprime
$promo_message = $_SESSION['promo_message'] ?? '';
unset($_SESSION['promo_message']);

// --- Le reste de votre logique de panier reste inchangée ---
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: commander.php');
    exit();
}
$cart_items = $_SESSION['cart'];

// On calcule le total côté serveur
$subtotal = 0; // Renommé en "subtotal" pour plus de clarté
foreach ($cart_items as $item) {
    if (isset($item['price'], $item['quantity']) && is_numeric($item['price']) && is_numeric($item['quantity'])) {
        $subtotal += $item['price'] * $item['quantity'];
    }
}

// --- NOUVEAU BLOC : CALCUL DE LA RÉDUCTION ET DU TOTAL FINAL ---
$discount_percent = $_SESSION['discount_percent'] ?? 0;
$discount_amount = 0;
if ($discount_percent > 0) {
    $discount_amount = ($subtotal * $discount_percent) / 100;
}
$final_total = $subtotal - $discount_amount;
$_SESSION['final_total'] = $final_total; // On stocke le total final pour la page de paiement
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Récapitulatif de Commande - Mon Plant Fraise</title>
    <!-- ... vos autres balises meta et link ... -->
<style>
    /* ... votre CSS reste inchangé ... */
    
    /* NOUVEAUX STYLES pour le code promo */
    .promo-code-section {
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #eee;
        max-width: 400px;
        margin-left: auto;
        margin-right: auto;
        text-align: left;
    }
    .promo-code-section form {
        display: flex;
        gap: 10px;
    }
    .promo-code-section input[type="text"] {
        flex-grow: 1;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 1rem;
    }
    .promo-code-section button {
        padding: 10px 20px;
        border: none;
        background-color: #555;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .promo-code-section button:hover {
        background-color: #333;
    }
    .promo-message {
        margin-top: 10px;
        font-weight: 600;
    }
    .promo-success { color: #28a745; }
    .promo-error { color: #dc3545; }

    .totals-summary {
        text-align: right;
        font-size: 1.2em;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 2px solid #eee;
    }
    .totals-summary div {
        margin-bottom: 10px;
    }
    .final-total {
        font-size: 1.4em;
        font-weight: 700;
        color: #333;
        margin-top: 15px;
        padding-top: 15px;
        border-top: 2px solid #6B8E23;
    }
    .final-total strong { color: #6B8E23; }
</style>
</head>
<body>
    <!-- ... votre header et bannière restent inchangés ... -->
    <header>
        <!-- ... -->
    </header>
    <div class="banner">
        <!-- ... -->
    </div>

    <div class="container">
        <div class="summary-section">
            <h2>Vérifiez votre panier 🍓</h2>
            
            <table class="order-summary-table">
                <!-- ... votre tableau de produits reste inchangé ... -->
                <tbody>
                    <?php if (empty($cart_items)): ?>
                        <tr><td colspan="4" style="text-align:center;">Votre panier est vide.</td></tr>
                    <?php else: ?>
                        <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td data-label="Produit" class="product-name"><?php echo htmlspecialchars($item['name']) . ' (' . htmlspecialchars($item['weight']) . ')'; ?></td>
                                <td data-label="Quantité" class="text-right"><?php echo (int)$item['quantity']; ?></td>
                                <td data-label="Prix Unitaire" class="text-right"><?php echo number_format($item['price'], 2, ',', ' '); ?> €</td>
                                <td data-label="Sous-total" class="text-right"><?php echo number_format($item['price'] * $item['quantity'], 2, ',', ' '); ?> €</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if (!empty($cart_items)): ?>

                <!-- NOUVELLE SECTION : FORMULAIRE CODE PROMO -->
                <div class="promo-code-section">
                    <form action="" method="POST">
                        <input type="text" name="promo_code" placeholder="Entrez votre code promo" value="<?= h($_SESSION['promo_code'] ?? '') ?>">
                        <button type="submit">Appliquer</button>
                    </form>
                    <?php if ($promo_message): ?>
                        <p class="promo-message <?= (isset($_SESSION['discount_percent'])) ? 'promo-success' : 'promo-error' ?>">
                            <?= h($promo_message) ?>
                        </p>
                    <?php endif; ?>
                </div>

                <!-- MODIFIÉ : AFFICHAGE DÉTAILLÉ DES TOTAUX -->
                <div class="totals-summary">
                    <div>
                        Sous-total : <span><?php echo number_format($subtotal, 2, ',', ' '); ?> €</span>
                    </div>
                    <?php if ($discount_amount > 0): ?>
                        <div class="promo-success">
                            Réduction (<?= h($discount_percent) ?>%) : <span>- <?php echo number_format($discount_amount, 2, ',', ' '); ?> €</span>
                        </div>
                    <?php endif; ?>
                    <div class="final-total">
                        Total à payer : <strong><?php echo number_format($final_total, 2, ',', ' '); ?> €</strong>
                    </div>
                </div>

                <div class="payment-form">
                    <form action="create-checkout-session.php" method="POST">
                        <button type="submit" class="proceed-to-payment-button">
                            <span class="material-symbols-outlined">credit_card</span>
                            Procéder au paiement
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>