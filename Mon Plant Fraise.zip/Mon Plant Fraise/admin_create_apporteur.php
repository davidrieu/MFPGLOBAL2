<?php
// ============================================================================
// admin_create_apporteur.php — Création d’un apporteur + réglage d’affiliation
// - Formulaire admin : username, name, email, password, sponsorship_code,
//   discount_mode (reduction|bonus), discount_percent (ex: 20)
// - Insère dans apporteurs_login + enregistre la règle dans apporteur_affiliations
// - Affiche le lien d’affiliation final
// ============================================================================

declare(strict_types=1);
session_start();

// --------------------------------------------------------------------
// Sécurité affichage / logs (prod: display_errors=0)
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// --------------------------------------------------------------------
// Auth admin (adaptation: si vous avez une session admin, décommentez)
// if (empty($_SESSION['admin_id'])) {
//     header('Location: /admin/login.php');
//     exit;
// }

// --------------------------------------------------------------------
// Connexion DB
require_once __DIR__ . '/db_connection.php'; // Doit définir $pdo (PDO)
if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('db_connection.php doit définir $pdo (PDO).');
}
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// --------------------------------------------------------------------
// Helpers
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

// CSRF minimal
if (empty($_SESSION['csrf_token_admin'])) {
    $_SESSION['csrf_token_admin'] = bin2hex(random_bytes(32));
}

// --------------------------------------------------------------------
// Ensure tables (sans toucher à apporteurs_login qui existe déjà)
// - apporteurs_login (existant) : id, username, password_hash, sponsorship_code, name, email, created_at
// - apporteur_affiliations (nouvelle) : réglages d’affiliation par apporteur
$pdo->exec("
    CREATE TABLE IF NOT EXISTS apporteur_affiliations (
        apporteur_id BIGINT NOT NULL,
        discount_mode ENUM('reduction','bonus') NOT NULL DEFAULT 'reduction',
        discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (apporteur_id),
        INDEX idx_mode (discount_mode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// --------------------------------------------------------------------
// Traitement formulaire
$done = false;
$error = '';
$created = null; // infos pour affichage

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // CSRF
        $csrf = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['csrf_token_admin'] ?? '', $csrf)) {
            throw new RuntimeException('Jeton CSRF invalide.');
        }

        // Champs
        $username         = trim((string)($_POST['username'] ?? ''));
        $name             = trim((string)($_POST['name'] ?? ''));
        $email            = trim((string)($_POST['email'] ?? ''));
        $password_plain   = (string)($_POST['password'] ?? '');
        $sponsorship_code = strtoupper(trim((string)($_POST['sponsorship_code'] ?? '')));
        $discount_mode    = strtolower(trim((string)($_POST['discount_mode'] ?? 'reduction')));
        $discount_percent = (float)($_POST['discount_percent'] ?? 0);

        if ($username === '' || $name === '' || $email === '' || $password_plain === '' || $sponsorship_code === '') {
            throw new InvalidArgumentException('Tous les champs obligatoires doivent être remplis.');
        }
        if (!in_array($discount_mode, ['reduction','bonus'], true)) {
            throw new InvalidArgumentException('Le mode de discount doit être "reduction" ou "bonus".');
        }
        if ($discount_percent < 0 || $discount_percent > 100) {
            throw new InvalidArgumentException('Le pourcentage de discount doit être entre 0 et 100.');
        }

        // Vérifs d’unicité basiques
        $st = $pdo->prepare("SELECT 1 FROM apporteurs_login WHERE username = ? OR sponsorship_code = ? OR email = ? LIMIT 1");
        $st->execute([$username, $sponsorship_code, $email]);
        if ($st->fetchColumn()) {
            throw new InvalidArgumentException("Username, email ou sponsorship_code déjà utilisé.");
        }

        // Hash password
        $password_hash = password_hash($password_plain, PASSWORD_DEFAULT);

        // Insertion
        $ins = $pdo->prepare("
            INSERT INTO apporteurs_login (username, password_hash, sponsorship_code, name, email, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $ins->execute([$username, $password_hash, $sponsorship_code, $name, $email]);
        $apporteur_id = (int)$pdo->lastInsertId();

        // Règle affiliation
        $ins2 = $pdo->prepare("
            INSERT INTO apporteur_affiliations (apporteur_id, discount_mode, discount_percent)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE discount_mode = VALUES(discount_mode), discount_percent = VALUES(discount_percent)
        ");
        $ins2->execute([$apporteur_id, $discount_mode, $discount_percent]);

        $done = true;
        $created = [
            'id'               => $apporteur_id,
            'username'         => $username,
            'name'             => $name,
            'email'            => $email,
            'sponsorship_code' => $sponsorship_code,
            'discount_mode'    => $discount_mode,
            'discount_percent' => $discount_percent,
            'aff_link'         => 'https://mpf-global.com/loginap.php?parrain=' . rawurlencode($sponsorship_code)
                                   . '&discount=' . rawurlencode($discount_mode . ':' . $discount_percent)
        ];
    } catch (Throwable $e) {
        $error = $e->getMessage();
        error_log('[admin_create_apporteur] '.$e->getMessage());
    }
}

?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<title>Créer un apporteur — Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  :root{--bg:#f6f7fb;--card:#fff;--border:#e5e7eb;--text:#111;--muted:#6b7280;--primary:#2E7D32}
  body{margin:0;background:var(--bg);font-family:system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;color:var(--text)}
  .wrap{max-width:900px;margin:24px auto;padding:16px}
  .card{background:var(--card);border:1px solid var(--border);border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.06);padding:18px}
  h1{margin:0 0 12px 0}
  label{display:block;font-weight:600;margin:10px 0 6px}
  input, select{width:100%;padding:10px;border:1px solid var(--border);border-radius:10px;background:#fff}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
  .btn{display:inline-block;background:var(--primary);color:#fff;border:none;border-radius:10px;padding:10px 16px;margin-top:12px;cursor:pointer}
  .muted{color:var(--muted)}
  .ok{background:#ecfdf5;border:1px solid #10b981;color:#065f46;padding:10px;border-radius:10px;margin:12px 0}
  .err{background:#fff1f2;border:1px solid #fecaca;color:#7f1d1d;padding:10px;border-radius:10px;margin:12px 0}
  code{background:#f3f4f6;padding:2px 6px;border-radius:6px}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>Créer un apporteur</h1>
    <p class="muted">Définissez aussi son **discount** (réduction ou bonus) qui sera inclus dans le lien d’affiliation.</p>

    <?php if ($error): ?>
      <div class="err"><?= h($error) ?></div>
    <?php endif; ?>

    <?php if ($done && $created): ?>
      <div class="ok">
        <strong>Apporteur créé (#<?= (int)$created['id'] ?>)</strong><br>
        Nom : <?= h($created['name']) ?> — Username : <code><?= h($created['username']) ?></code> — Email : <code><?= h($created['email']) ?></code><br>
        Code d’affiliation : <code><?= h($created['sponsorship_code']) ?></code><br>
        Règle : <code><?= h($created['discount_mode']) ?>:<?= h((string)$created['discount_percent']) ?></code><br>
        Lien d’affiliation :<br>
        <code><?= h($created['aff_link']) ?></code>
      </div>
    <?php endif; ?>

    <form method="post" action="">
      <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token_admin']) ?>">

      <div class="row">
        <div>
          <label>Username *</label>
          <input type="text" name="username" required>
        </div>
        <div>
          <label>Nom complet *</label>
          <input type="text" name="name" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Email *</label>
          <input type="email" name="email" required>
        </div>
        <div>
          <label>Mot de passe *</label>
          <input type="text" name="password" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Code d’affiliation (sponsorship_code) *</label>
          <input type="text" name="sponsorship_code" placeholder="MPF102569" required>
        </div>
        <div>
          <label>Mode de discount *</label>
          <select name="discount_mode" required>
            <option value="reduction">réduction (−%)</option>
            <option value="bonus">bonus (+% au montant)</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Pourcentage (ex: 20 pour 20%) *</label>
          <input type="number" name="discount_percent" step="0.01" min="0" max="100" value="0" required>
        </div>
        <div></div>
      </div>

      <button class="btn" type="submit">Créer l’apporteur</button>
    </form>
  </div>
</div>
</body>
</html>
