<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Démarrer la session et vérifier la connexion de l'utilisateur
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 2. Connexion à la base de données
require_once 'db_connection.php';
include 'back_to_top.php';

// --- LOGIQUE DE VÉRIFICATION ET DE MESSAGE ---
$user_id = $_SESSION['user_id'];
$user_is_verified = false;
$somme_contrats_en_cours = 0;
$achats_bloques = false;
define('LIMITE_NON_VERIFIE', 3000);

// Initialisation des variables pour le message
$message_texte = "";
$message_classe_css = "";
$message_icone = "";

try {
    // Étape A : Récupérer le statut de vérification
    $user_stmt = $pdo->prepare("SELECT verifie FROM users WHERE id = :user_id");
    $user_stmt->execute(['user_id' => $user_id]);
    $user_data = $user_stmt->fetch(PDO::FETCH_ASSOC);
    if ($user_data && $user_data['verifie'] === 'oui') {
        $user_is_verified = true;
    }

    // Étape B : Calculer la somme des contrats en cours (basé sur l'apport initial)
    $contrats_stmt = $pdo->prepare("SELECT SUM(apport) as total FROM contrats WHERE user_id = :user_id AND statut = 'actif'");
    $contrats_stmt->execute(['user_id' => $user_id]);
    $result = $contrats_stmt->fetch(PDO::FETCH_ASSOC);
    if ($result && $result['total']) {
        $somme_contrats_en_cours = (float)$result['total'];
    }

    // Étape C : Appliquer la règle de blocage et définir le message
    if ($user_is_verified) {
        // ✅ Cas 1 : Utilisateur vérifié
        $achats_bloques = false;
        $message_texte = "Votre compte est vérifié et vous avez un accès complet.";
        $message_classe_css = "verifie";
        $message_icone = "verified_user";
    } else {
        if ($somme_contrats_en_cours >= LIMITE_NON_VERIFIE) {
            // 🛑 Cas 2 : Non vérifié ET limite atteinte
            $achats_bloques = true;
            $message_texte = "Compte restreint : Vous avez atteint la limite de " . number_format(LIMITE_NON_VERIFIE, 0, '', ' ') . " €. <a href='profil.php'>Vérifiez votre compte</a>.";
            $message_classe_css = "restreint";
            $message_icone = "lock";
        } else {
            // ⚠️ Cas 3 : Non vérifié mais sous la limite
            $achats_bloques = false;
            $message_texte = "Compte non vérifié : Une limite d'achat de " . number_format(LIMITE_NON_VERIFIE, 0, '', ' ') . " € s'applique. <a href='profil.php'>Vérifiez votre compte</a>.";
            $message_classe_css = "non-verifie";
            $message_icone = "unpublished";
        }
    }

    // 3. Récupérer tous les produits de la base de données
    $sql = "SELECT *, paiement_mensuel_disponible FROM produits ORDER BY stock_restant DESC, name ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("ERREUR TECHNIQUE : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booster ma récolte - Mon Plant Fraise</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    <style>
        *, *::before, *::after {
            box-sizing: border-box;
        }

        :root {
            --primary-color: #2E7D32;
            --primary-color-dark: #1B5E20;
            --primary-color-light: #C8E6C9;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --text-color: #212121;
            --text-color-light: #757575;
            --background-color: #F4F6F8;
            --card-background-color: #FAFAFA;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        
        body {
            background-color: var(--background-color);
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            display: flex;
            color: var(--text-color);
        }
        
        .sidebar {
            background-color: var(--card-background-color);
            width: 260px;
            height: 100vh;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-header { margin-bottom: 30px; }
        .sidebar-header a img { max-width: 80%; height: auto; display: block; margin: 0 auto; }
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover { background-color: #eeeeee; }
        .sidebar ul li a[href="investclient.php"] { background-color: var(--primary-color); color: white; }
        
        .container {
            margin-left: 260px;
            padding: 30px;
            width: calc(100% - 260px);
            transition: margin-left 0.3s ease-in-out;
        }
        .main-header {
            font-family: 'Poppins', sans-serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        /* --- STYLES POUR LE BADGE DE STATUT --- */
        .statut-compte-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 20px;
        }
        .statut-compte-badge .material-symbols-outlined {
            margin-right: 8px;
            font-size: 20px;
        }
        .statut-compte-badge.verifie {
            background-color: var(--primary-color-light);
            color: var(--primary-color-dark);
        }
        .statut-compte-badge.non-verifie {
            background-color: #FFF3E0;
            color: #E65100;
        }
        .statut-compte-badge.restreint {
            background-color: #FFCDD2;
            color: #C62828;
        }
        .statut-compte-badge a {
            color: inherit;
            font-weight: bold;
            text-decoration: underline;
            margin-left: 5px;
        }
        /* ------------------------------------------- */

        .product-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 25px;
        }
        .product-filters button {
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 500;
            border-radius: 20px;
            border: 1px solid #ddd;
            background-color: var(--card-background-color);
            color: var(--text-color-light);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .product-filters button.active {
            background: var(--primary-gradient);
            color: white;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(46, 125, 50, 0.3);
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 25px;
        }
        .card {
            background-color: var(--card-background-color);
            box-shadow: var(--box-shadow);
            border-radius: var(--border-radius);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        .card-image {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        .card-content {
            padding: 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }
        .card h3 {
            font-family: 'Poppins', sans-serif;
            color: var(--text-color);
            margin-top: 0;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .card-description {
            font-size: 14px;
            color: var(--text-color-light);
            line-height: 1.6;
            margin-bottom: 20px;
            flex-grow: 1;
        }
        .card-stats {
            display: flex;
            justify-content: space-around;
            gap: 15px;
            padding: 15px 0;
            border-top: 1px solid #f0f0f0;
            margin-bottom: 15px;
        }
        .stat-item { text-align: center; }
        .stat-item .label { font-size: 12px; color: var(--text-color-light); }
        .stat-item .value { font-size: 18px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 6px; }
        .stat-item .material-symbols-outlined { color: var(--primary-color); font-size: 22px; }

        .price {
            font-family: 'Poppins', sans-serif;
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
        }
        .btn-primary {
            display: block;
            width: 100%;
            padding: 12px 20px;
            background: var(--primary-gradient);
            color: white;
            text-decoration: none;
            border-radius: var(--border-radius);
            font-weight: 700;
            transition: all 0.2s ease;
            text-align: center;
            border: none;
            cursor: pointer;
        }
        .btn-primary:hover {
             box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4);
             transform: translateY(-2px);
        }
        .stock-tag {
            font-size: 12px;
            color: var(--text-color-light);
            text-align: right;
            margin-bottom: 15px;
        }
        .card.out-of-stock { filter: grayscale(90%); }
        .stock-overlay {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            display: flex; justify-content: center; align-items: center;
            color: white; background-color: rgba(33, 33, 33, 0.7);
            font-family: 'Poppins', sans-serif;
            font-size: 2em; font-weight: 700;
            pointer-events: none; text-align: center;
        }
        .btn-primary:disabled {
            background: #BDBDBD;
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }
        .card-footer { display: block; }
        .price-line { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .payment-choice { display: flex; flex-direction: column; gap: 8px; margin-bottom: 15px; }
        .payment-choice label { display: flex; align-items: center; font-size: 14px; cursor: pointer; }
        .payment-choice input { margin-right: 8px; accent-color: var(--primary-color); }

        #panier-flottant {
            position: fixed;
            bottom: 20px;
            right: 30px;
            width: 380px;
            max-width: 90vw;
            max-height: 500px;
            background-color: var(--card-background-color);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 1002;
            display: flex;
            flex-direction: column;
            transform: translateY(120%);
            transition: transform 0.3s ease-in-out;
            color: var(--text-color);
        }
        #panier-flottant.visible { transform: translateY(0); }
        .panier-header { display: flex; justify-content: space-between; align-items: center; padding: 15px; border-bottom: 1px solid #f0f0f0; }
        .panier-header h3 { margin: 0; display: flex; align-items: center; gap: 8px; font-size: 18px; font-family: 'Poppins', sans-serif;}
        #close-panier { background: none; border: none; font-size: 28px; cursor: pointer; color: var(--text-color-light); line-height: 1; }
        #liste-panier { list-style-type: none; padding: 10px 15px; margin: 0; overflow-y: auto; flex-grow: 1; }
        #liste-panier li { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; font-size: 14px; }
        #liste-panier li:not(:last-child) { border-bottom: 1px solid #f0f0f0; }
        .panier-vide { justify-content: center !important; color: var(--text-color-light); padding: 20px 0; }
        .item-details { flex-grow: 1; margin-right: 10px; }
        .item-details span { display: block; font-weight: 500; }
        .item-details small { color: var(--text-color-light); }
        .item-total { text-align: right; font-weight: bold; width: 80px; font-family: 'Poppins', sans-serif;}
        .panier-footer { padding: 15px; border-top: 1px solid #f0f0f0; background-color: #f9f9f9; }
        .panier-footer p { margin: 0 0 15px 0; font-size: 18px; text-align: right; display: flex; justify-content: space-between; align-items: center; font-family: 'Poppins', sans-serif;}
        #valider-panier { width: 100%; }
        .quantite-manager { display: flex; align-items: center; margin-right: 15px; }
        .quantite-manager button { background-color: #f0f0f0; border: 1px solid #ddd; color: var(--text-color); border-radius: 50%; width: 28px; height: 28px; cursor: pointer; font-size: 16px; font-weight: bold; line-height: 1; transition: background-color 0.2s; }
        .quantite-manager button:hover { background-color: #e0e0e0; }
        .quantite-valeur { font-weight: 500; min-width: 25px; text-align: center; }

        .toggle-btn { display: none; }
        
        .card.is-locked {
            filter: grayscale(80%);
            pointer-events: none;
        }
        .card.is-locked .card-content {
            opacity: 0.6;
        }
        .lock-overlay {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            display: flex; flex-direction: column; justify-content: center; align-items: center;
            color: white;
            background-color: rgba(33, 33, 33, 0.75);
            font-family: 'Poppins', sans-serif;
            font-size: 1.1em; font-weight: 600;
            text-align: center;
            padding: 20px;
            z-index: 2;
        }
        .lock-overlay .material-symbols-outlined {
            font-size: 40px;
            margin-bottom: 10px;
        }
        .lock-overlay a {
            color: #C8E6C9;
            font-weight: 700;
            pointer-events: auto;
            text-decoration: underline;
            font-size: 0.9em;
            margin-top: 5px;
        }
        
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .container { 
                margin-left: 0; 
                padding: 15px; 
                width: 100%; 
            }
            .products-grid { grid-template-columns: 1fr; }
            .toggle-btn { display: block; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size: 24px; display: flex; align-items: center; justify-content: center; }
            .main-header { 
                margin-top: 70px;
                font-size: 24px;
            }
        }
        #scrollTopBtn { position: fixed; bottom: 20px; right: 30px; z-index: 1000; border: none; outline: none; background-color: var(--primary-color); color: white; cursor: pointer; padding: 10px; border-radius: 50%; width: 50px; height: 50px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); transition: background-color 0.3s, transform 0.2s; display: flex; align-items: center; justify-content: center; }
        #scrollTopBtn:hover { background-color: var(--primary-color-dark); transform: scale(1.1); }
        #scrollTopBtn .material-symbols-outlined { font-size: 2rem; }
    </style>
</head>
<body>
    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>

    <div class="sidebar">
        <div class="sidebar-header">
            <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
        </div>
        <ul>
            <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
            <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
            <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
            <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
            <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
            <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
            <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
        </ul>
    </div>

    <div class="container">
        <h1 class="main-header">Choisissez vos prochains plants</h1>

        <?php if (!empty($message_texte)): ?>
            <p class="statut-compte-badge <?php echo $message_classe_css; ?>">
                <span class="material-symbols-outlined"><?php echo $message_icone; ?></span>
                <?php echo $message_texte; ?>
            </p>
        <?php endif; ?>

        <div id="product-filters" class="product-filters">
            <button data-filter="all">Tous les plants</button>
            <button class="active" data-filter="instock">Disponibles</button>
            <button data-filter="outofstock">Épuisés</button>
        </div>

        <div class="products-grid">
            <?php foreach ($produits as $produit) : ?>
                <?php
                    $is_locked = ($achats_bloques && $produit['stock_restant'] > 0);
                ?>
                <div class="card <?php echo ($produit['stock_restant'] <= 0) ? 'out-of-stock' : ''; ?> <?php echo $is_locked ? 'is-locked' : ''; ?>" data-product-id="<?php echo $produit['id']; ?>">
                    
                    <?php if ($produit['stock_restant'] <= 0) : ?>
                        <div class="stock-overlay">ÉPUISÉ</div>
                    <?php elseif ($is_locked) : ?>
                        <div class="lock-overlay">
                            <span class="material-symbols-outlined">lock</span>
                            Limite de <?php echo number_format(LIMITE_NON_VERIFIE, 0, '', ' '); ?>€ atteinte.
                            <a href="profil.php">Vérifiez votre compte</a>
                        </div>
                    <?php endif; ?>

                    <img src="<?php echo htmlspecialchars($produit['image_url'] ?? ''); ?>" alt="<?php echo htmlspecialchars($produit['name'] ?? ''); ?>" class="card-image">
                    <div class="card-content">
                        <h3><?php echo htmlspecialchars($produit['name'] ?? ''); ?></h3>
                        <p class="card-description"><?php echo htmlspecialchars($produit['descriptif'] ?? ''); ?></p>
                        
                        <div class="card-stats">
                            <div class="stat-item">
                                <div class="label">Rendement</div>
                                <div class="value">
                                    <span class="material-symbols-outlined">trending_up</span>
                                    <strong><?php echo htmlspecialchars($produit['taux'] ?? '0'); ?>%</strong>
                                </div>
                            </div>
                            <div class="stat-item">
                                <div class="label">Durée</div>
                                <div class="value">
                                    <span class="material-symbols-outlined">calendar_month</span>
                                    <strong><?php echo htmlspecialchars($produit['duree_mois'] ?? '0'); ?></strong> mois
                                </div>
                            </div>
                        </div>
                        
                        <div class="stock-tag">Stock : <?php echo htmlspecialchars($produit['stock_restant'] ?? '0'); ?> restants</div>
                        
                        <div class="card-footer">
                            <div class="price-line">
                                <div class="price" id="price-<?php echo $produit['id']; ?>"><?php echo number_format($produit['prix'] ?? 0, 2, ',', ' '); ?> €</div>
                            </div>

                            <?php if ($produit['paiement_mensuel_disponible']) : ?>
                            <div class="payment-choice">
                                <label>
                                    <input type="radio" name="payment-type-<?php echo $produit['id']; ?>" value="unique" checked>
                                    Paiement unique
                                </label>
                                <label>
                                    <input type="radio" name="payment-type-<?php echo $produit['id']; ?>" value="mensuel">
                                    Paiement mensuel (<?php echo number_format(($produit['prix'] ?? 0) / 12, 2, ',', ' '); ?> €/mois)
                                </label>
                            </div>
                            <?php endif; ?>

                            <button class="btn-primary investir-btn"
                                    data-id="<?php echo $produit['id']; ?>"
                                    data-nom="<?php echo htmlspecialchars($produit['name']); ?>"
                                    data-prix="<?php echo $produit['prix']; ?>"
                                    data-rendement="<?php echo htmlspecialchars($produit['taux'] ?? '0'); ?>"
                                    data-mensuel-dispo="<?php echo $produit['paiement_mensuel_disponible'] ? '1' : '0'; ?>"
                                    <?php echo ($produit['stock_restant'] <= 0 || $is_locked) ? 'disabled' : ''; ?>>
                                Investir
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if (empty($produits)): ?>
                <p>Aucun produit n'est disponible pour le moment.</p>
            <?php endif; ?>
        </div>
    </div>

    <div id="panier-flottant">
        <div class="panier-header">
            <h3><span class="material-symbols-outlined">shopping_cart</span> Mon Panier</h3>
            <button id="close-panier" title="Fermer le panier">&times;</button>
        </div>
        <ul id="liste-panier"></ul>
        <div class="panier-footer">
            <p><span>Total :</span> <strong id="total-panier">0.00 €</strong></p>
            <button id="valider-panier" class="btn-primary" disabled>Valider mon panier</button>
        </div>
    </div>

    <script>
    function toggleSidebar() { document.querySelector('.sidebar').classList.toggle('open'); }
    document.addEventListener('DOMContentLoaded', () => {
        const filterContainer = document.getElementById('product-filters');
        if (filterContainer) {
            const productCards = document.querySelectorAll('.products-grid .card');
            function applyFilter(filter) {
                productCards.forEach(card => {
                    const isOutOfStock = card.classList.contains('out-of-stock');
                    switch (filter) {
                        case 'all': card.style.display = 'flex'; break;
                        case 'instock': card.style.display = isOutOfStock ? 'none' : 'flex'; break;
                        case 'outofstock': card.style.display = isOutOfStock ? 'flex' : 'none'; break;
                    }
                });
            }
            applyFilter('instock'); 
            filterContainer.addEventListener('click', (event) => {
                if (event.target.tagName !== 'BUTTON') return;
                const filter = event.target.dataset.filter;
                filterContainer.querySelector('button.active').classList.remove('active');
                event.target.classList.add('active');
                applyFilter(filter);
            });
        }
        const panierFlottant = document.getElementById('panier-flottant');
        const listePanierUI = document.getElementById('liste-panier');
        const totalPanierUI = document.getElementById('total-panier');
        const validerPanierBtn = document.getElementById('valider-panier');
        const closePanierBtn = document.getElementById('close-panier');
        const afficherPanier = (panierData) => {
            listePanierUI.innerHTML = '';
            let total = 0;
            const items = panierData && Object.values(panierData);
            if (!items || items.length === 0) {
                listePanierUI.innerHTML = '<li class="panier-vide">Votre panier est vide.</li>';
                validerPanierBtn.disabled = true;
                panierFlottant.classList.remove('visible');
            } else {
                items.forEach(item => {
                    const li = document.createElement('li');
                    const paymentModeText = item.paymentMode === 'mensuel' 
                        ? `<small>Paiement: <strong>Mensuel</strong> (${(item.price / 12).toFixed(2).replace('.', ',')} €/mois)</small>` 
                        : `<small>Paiement: <strong>Unique</strong></small>`;
                    
                    li.innerHTML = `
                        <div class="item-details">
                            <span>${item.name}</span>
                            ${paymentModeText}
                        </div>
                        <div class="quantite-manager">
                            <button class="moins-btn" data-key="${item.cartKey}" title="Diminuer">-</button>
                            <span class="quantite-valeur">${item.quantity}</span>
                            <button class="plus-btn" data-key="${item.cartKey}" title="Augmenter">+</button>
                        </div>
                        <div class="item-total">
                            ${(item.quantity * item.price).toFixed(2).replace('.', ',')} €
                        </div>
                    `;
                    listePanierUI.appendChild(li);
                    total += item.quantity * item.price;
                });
                validerPanierBtn.disabled = false;
                panierFlottant.classList.add('visible');
            }
            totalPanierUI.textContent = `${total.toFixed(2).replace('.', ',')} €`;
        };
        const mettreAJourPanierServeur = async (action, data) => {
            try {
                const response = await fetch('gerer_panier.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: action, data: data })
                });
                if (!response.ok) throw new Error('La réponse du serveur est invalide.');
                const result = await response.json();
                if (result.success) {
                    afficherPanier(result.cart);
                } else {
                    alert(result.error || 'Une erreur est survenue.');
                }
            } catch (error) {
                console.error("Erreur de communication:", error);
                alert("Impossible de mettre à jour le panier.");
            }
        };
        document.querySelector('.products-grid').addEventListener('click', (e) => {
            if (e.target.classList.contains('investir-btn')) {
                const bouton = e.target;
                if (bouton.disabled) return;
                const card = bouton.closest('.card');
                const paymentChoiceRadio = card.querySelector('input[name^="payment-type-"]:checked');
                const paymentMode = paymentChoiceRadio ? paymentChoiceRadio.value : 'unique';
                const produit = {
                    id: bouton.dataset.id,
                    nom: bouton.dataset.nom,
                    prix: parseFloat(bouton.dataset.prix),
                    rendement: parseFloat(bouton.dataset.rendement),
                    paymentMode: paymentMode 
                };
                mettreAJourPanierServeur('ajouter', produit);
            }
        });
        listePanierUI.addEventListener('click', (e) => {
            const target = e.target;
            const cartKey = target.dataset.key;
            if (!cartKey) return;
            const data = { cartKey: cartKey };
            if (target.classList.contains('plus-btn')) {
                mettreAJourPanierServeur('augmenter', data);
            } else if (target.classList.contains('moins-btn')) {
                mettreAJourPanierServeur('diminuer', data);
            }
        });
        validerPanierBtn.addEventListener('click', () => {
            window.location.href = 'recapitulatifclient.php';
        });
        closePanierBtn.addEventListener('click', () => {
            panierFlottant.classList.remove('visible');
        });
        const initialiserPanier = async () => {
            await mettreAJourPanierServeur('recuperer', {});
        }
        initialiserPanier();
    });
    </script>

</body>
</html>