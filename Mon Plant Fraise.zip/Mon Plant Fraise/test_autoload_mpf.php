<?php
// htdocs/test_autoload_mpf.php

// (Optionnel) vider l'opcache pour éviter un cache têtu
if (function_exists('opcache_reset')) { @opcache_reset(); }

header('Content-Type: text/plain; charset=utf-8');

$base = __DIR__;
$tries = [
    ['path' => $base . '/vendor_mpf/autoload.php',            'label' => 'vendor_mpf (Composer isolé)'],
    ['path' => $base . '/libs/dompdf/autoload.inc.php',       'label' => 'libs/dompdf (drop-in autoload.inc.php)'],
    ['path' => $base . '/libs/dompdf/src/Autoloader.php',     'label' => 'libs/dompdf (fallback src/Autoloader.php)'],
    ['path' => $base . '/vendor/autoload.php',                'label' => 'vendor global (existant)'],
];

$used = null;
$label = null;

// On tente chaque chemin et on vérifie après chaque require si Dompdf est bien chargé
foreach ($tries as $t) {
    if (!is_file($t['path'])) continue;

    require_once $t['path'];

    // Si on a chargé directement Autoloader.php, il faut enregistrer l'autoloader Dompdf
    if (strpos($t['path'], '/libs/dompdf/src/Autoloader.php') !== false && class_exists('Dompdf\\Autoloader', false)) {
        \Dompdf\Autoloader::register();
    }

    if (class_exists('Dompdf\\Options', false) || class_exists('Dompdf\\Dompdf', false)) {
        $used  = $t['path'];
        $label = $t['label'];
        break;
    }
}

// Résultats
echo "Autoload retenu : " . ($used ?: 'AUCUN (échec)') . "\n";
echo "Provenance     : " . ($label ?: '—') . "\n";
echo "class_exists(Dompdf\\Options) = " . (class_exists('Dompdf\\Options') ? 'OUI' : 'NON') . "\n";
echo "class_exists(Dompdf\\Dompdf)  = " . (class_exists('Dompdf\\Dompdf')  ? 'OUI' : 'NON') . "\n";


// Indice supplémentaire : la présence du fichier Options.php côté drop-in
$optPath = $base . '/libs/dompdf/src/Options.php';
echo "Fichier drop-in Options.php présent : " . (file_exists($optPath) ? 'OUI' : 'NON') . " => $optPath\n";

// Si Composer (vendor_mpf ou vendor) est utilisé et disponible, afficher la version dompdf détectée
if (class_exists('Composer\\InstalledVersions')) {
    $pkg = 'dompdf/dompdf';
    $has = \Composer\InstalledVersions::isInstalled($pkg);
    echo "Composer détecté : OUI\n";
    echo "Package $pkg installé : " . ($has ? 'OUI' : 'NON') . "\n";
    if ($has) {
        echo "Version $pkg : " . \Composer\InstalledVersions::getPrettyVersion($pkg) . "\n";
    }
} else {
    echo "Composer\\InstalledVersions non disponible (pas d’info version via Composer).\n";
}

echo "\nAstuce : chemins testés dans l’ordre :\n";
foreach ($tries as $t) {
    echo " - {$t['label']} => {$t['path']} (".(file_exists($t['path'])?'existe':'absent').")\n";
}
