<?php
// 1. Démarrer la session et vérifier la connexion
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 2. Connexion à la base de données
require_once 'db_connection.php';

// 3. Initialisation des variables
$prenom = $_SESSION['user_prenom'] ?? '';
$somme_contrats_en_cours = 0;
$somme_rendements_actuels = 0;
$statut_verification_text = '';
$statut_verification_class = '';

try {
    $user_id = $_SESSION['user_id'];
    
    // --- Récupération du statut de vérification de l'utilisateur (AVEC LA TABLE "USERS") ---
    $sql_user = "SELECT verifie FROM users WHERE id = :user_id"; // Nom de table corrigé
    $stmt_user = $pdo->prepare($sql_user);
    $stmt_user->execute(['user_id' => $user_id]);
    $user_data = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if ($user_data) {
        if ($user_data['verifie'] == 'oui') {
            $statut_verification_text = "Compte vérifié";
            $statut_verification_class = "verifie";
        } else {
            $statut_verification_text = "Compte non vérifié";
            $statut_verification_class = "non-verifie";
        }
    }
    // --- FIN DU BLOC POUR LA VÉRIFICATION ---

    // Calcul des totaux des contrats (votre code existant)
    $sql = "SELECT c.apport, c.montant, c.taux_moyen, c.date_souscription, p.duree_mois
            FROM contrats AS c
            JOIN produits AS p ON c.produit_id = p.id
            WHERE c.user_id = :user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $user_id]);
    
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($results as $contrat) {
        $duree_mois = (int)$contrat['duree_mois'];
        $date_souscription = new DateTime($contrat['date_souscription']);
        $aujourdhui = new DateTime();
        $date_fin = (clone $date_souscription)->add(new DateInterval("P{$duree_mois}M"));
        $total_duree_secondes = $date_fin->getTimestamp() - $date_souscription->getTimestamp();
        $ecoule_secondes = $aujourdhui->getTimestamp() - $date_souscription->getTimestamp();
        
        $pourcentage_temps_ecoule = 0;
        if ($total_duree_secondes > 0) {
            $ecoule_secondes = max(0, $ecoule_secondes);
            $pourcentage_temps_ecoule = ($ecoule_secondes / $total_duree_secondes) * 100;
        }
        $pourcentage_temps_ecoule = min(100, $pourcentage_temps_ecoule);

        // On ne compte que les contrats non-échus
        if ($aujourdhui < $date_fin) {
            $somme_contrats_en_cours += $contrat['apport'];
            $rendement_total_contrat = $contrat['montant'] * ($contrat['taux_moyen'] / 100);
            $rendement_actuel = $rendement_total_contrat * ($pourcentage_temps_ecoule / 100);
            $somme_rendements_actuels += $rendement_actuel;
        }
    }

} catch (PDOException $e) {
    $somme_contrats_en_cours = 0;
    $somme_rendements_actuels = 0;
    error_log("Erreur sur espace-client.php: " . $e->getMessage());
} finally {
    $pdo = null;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Client - Mon Plant Fraise</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    <style>
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --primary-color: #2E7D32;
            --primary-color-dark: #1B5E20;
            --primary-color-light: #C8E6C9;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --secondary-color: #8BC34A;
            --text-color: #212121;
            --text-color-light: #757575;
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; transition: transform 0.3s ease-in-out; }
        .sidebar-header { margin-bottom: 30px; text-align: center; }
        .sidebar-header a img { max-width: 80%; height: auto; }
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover { background-color: #eeeeee; }
        .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        
        .container { margin-left: 260px; padding: 30px; width: calc(100% - 260px); }
        
        .dashboard-grid {
            display: grid;
            gap: 25px;
            grid-template-columns: repeat(4, 1fr);
            grid-template-areas:
                "welcome welcome kpi1 kpi2"
                "chart chart cta1 cta1"
                "chart chart cta2 cta2";
        }

        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .card h3 { font-family: 'Poppins', sans-serif; color: var(--text-color); margin-top: 0; font-size: 20px; font-weight: 600; }
        
        .welcome-card { grid-area: welcome; }
        .kpi-card { grid-area: kpi; padding: 20px; display: flex; flex-direction: column; justify-content: space-between; }
        #kpi-card-1 { grid-area: kpi1; }
        #kpi-card-2 { grid-area: kpi2; }
        .chart-card { grid-area: chart; display: flex; flex-direction: column; }
        .cta-card { grid-area: cta; display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s ease, box-shadow 0.2s ease; }
        .cta-card:hover { transform: translateY(-5px); box-shadow: 0 8px 16px rgba(0,0,0,0.1); }
        #cta-card-1 { grid-area: cta1; }
        #cta-card-2 { grid-area: cta2; }
        
        .welcome-card h1 { font-family: 'Poppins', sans-serif; margin-top: 0; font-size: 28px; }
        .welcome-card p { color: var(--text-color-light); line-height: 1.6; }

        .kpi-card .kpi-title { font-size: 14px; color: var(--text-color-light); }
        .kpi-card .kpi-value { font-family: 'Poppins', sans-serif; font-size: 32px; font-weight: 700; color: var(--primary-color); margin: 10px 0; }
        .kpi-card .kpi-icon { font-size: 28px; align-self: flex-end; color: var(--primary-color-light); }

        .chart-container { position: relative; flex-grow: 1; min-height: 250px; }

        .cta-card .cta-icon { font-size: 48px; color: var(--primary-color); margin-bottom: 15px; }
        .cta-card p { color: var(--text-color-light); line-height: 1.6; flex-grow: 1;}
        .btn-primary { background: var(--primary-gradient); color: white; padding: 12px 28px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 14px; font-weight: 700; text-decoration: none; display: inline-block; transition: all 0.2s ease; margin-top: 15px; text-align: center;}
        .btn-primary:hover { box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4); transform: translateY(-2px); }

        .toggle-btn { display: none; }

        .statut-compte {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            margin: -10px 0 15px 0;
        }

        .statut-compte .material-symbols-outlined {
            margin-right: 8px;
            font-size: 20px;
        }

        .statut-compte.verifie {
            background-color: var(--primary-color-light);
            color: var(--primary-color-dark);
        }

        .statut-compte.non-verifie {
            background-color: #FFF3E0; /* Orange clair */
            color: #E65100; /* Orange foncé */
        }

        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: 1fr 1fr;
                grid-template-areas:
                    "welcome welcome"
                    "kpi1 kpi2"
                    "chart chart"
                    "cta1 cta2";
            }
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .container { margin-left: 0; padding: 15px; width: 100%; }
            .toggle-btn { display: block; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size: 24px; display: flex; align-items: center; justify-content: center; }
            .dashboard-grid {
                grid-template-columns: 1fr;
                grid-template-areas: "welcome" "kpi1" "kpi2" "chart" "cta1" "cta2";
            }
            .welcome-card h1 { margin-top: 60px; font-size: 24px; }
            .kpi-card .kpi-value { font-size: 28px; }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()">☰</button>

<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php" class="active"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="dashboard-grid">

        <div class="welcome-card">
            <h1>Bienvenue, <?php echo htmlspecialchars($prenom); ?> !</h1>
            
            <p class="statut-compte <?php echo htmlspecialchars($statut_verification_class); ?>">
                <span class="material-symbols-outlined">
                    <?php echo ($statut_verification_class == 'verifie') ? 'verified_user' : 'unpublished'; ?>
                </span>
                <?php echo htmlspecialchars($statut_verification_text); ?>
            </p>

            <p>Voici un aperçu de la croissance de votre jardin financier. Continuez à cultiver vos investissements !</p>
        </div>

        <div class="card kpi-card" id="kpi-card-1">
            <div class="kpi-title">Valeur de vos apports</div>
            <div class="kpi-value" id="kpi-total-value">0,00 €</div>
            <span class="material-symbols-outlined kpi-icon">potted_plant</span>
        </div>

        <div class="card kpi-card" id="kpi-card-2">
            <div class="kpi-title">Rendements actuels</div>
            <div class="kpi-value" id="kpi-returns-value">0,00 €</div>
            <span class="material-symbols-outlined kpi-icon">trending_up</span>
        </div>

        <div class="card chart-card">
            <h3>Répartition de vos avoirs</h3>
            <div class="chart-container">
                <canvas id="doughnutChart"></canvas>
            </div>
        </div>
        
        <div class="card cta-card" id="cta-card-1">
             <span class="material-symbols-outlined cta-icon">rocket_launch</span>
            <h3>Augmentez votre production !</h3>
            <p>Des plants hautement productifs sont disponibles pour agrandir votre parcelle.</p>
            <a href="investclient.php" class="btn-primary">Booster ma récolte</a>
        </div>

        <div class="card cta-card" id="cta-card-2">
            <span class="material-symbols-outlined cta-icon">group_add</span>
            <h3>Le Parrainage est arrivé !</h3>
            <p>Partagez l’amour des fraises avec vos amis et gagnez des récompenses pour chaque filleul.</p>
            <a href="parrainage.php" class="btn-primary">En savoir plus</a>
        </div>

    </div>
</div>

<script>
    function toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('open');
    }

    document.addEventListener('DOMContentLoaded', function() {
        const dynamicData = {
            somme_contrats_en_cours: <?php echo json_encode($somme_contrats_en_cours); ?>,
            somme_rendements_actuels: <?php echo json_encode($somme_rendements_actuels); ?>
        };

        function animateCountUp(elementId, endValue, duration = 1500) {
            const element = document.getElementById(elementId);
            const startValue = 0;
            const range = endValue - startValue;
            let startTime = null;

            function step(timestamp) {
                if (!startTime) startTime = timestamp;
                const progress = Math.min((timestamp - startTime) / duration, 1);
                const currentValue = startValue + range * progress;
                element.textContent = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(currentValue);
                if (progress < 1) {
                    window.requestAnimationFrame(step);
                }
            }
            window.requestAnimationFrame(step);
        }

        animateCountUp('kpi-total-value', dynamicData.somme_contrats_en_cours);
        animateCountUp('kpi-returns-value', dynamicData.somme_rendements_actuels);

        const chartCanvas = document.getElementById('doughnutChart');
        let chartHasBeenRendered = false;

        const chartObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !chartHasBeenRendered) {
                    renderDoughnutChart();
                    chartHasBeenRendered = true;
                    observer.unobserve(chartCanvas);
                }
            });
        }, { threshold: 0.5 });

        chartObserver.observe(chartCanvas);

        function renderDoughnutChart() {
            const centerTextPlugin = {
                id: 'centerText',
                beforeDraw: function(chart) {
                    if (chart.config.options.plugins.centerText.display) {
                        const ctx = chart.ctx;
                        const chartArea = chart.chartArea;
                        const total = chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                        const text = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(total);

                        ctx.save();
                        ctx.font = "bold 24px 'Poppins', sans-serif";
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-color').trim();
                        const centerX = (chartArea.left + chartArea.right) / 2;
                        const centerY = (chartArea.top + chartArea.bottom) / 2;
                        ctx.fillText(text, centerX, centerY);
                        ctx.restore();
                    }
                }
            };
            
            new Chart(chartCanvas.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['Votre apport', 'Rendements actuels'],
                    datasets: [{
                        data: [dynamicData.somme_contrats_en_cours, dynamicData.somme_rendements_actuels],
                        backgroundColor: [
                            getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim(),
                            getComputedStyle(document.documentElement).getPropertyValue('--secondary-color').trim()
                        ],
                        borderColor: 'var(--card-background-color)',
                        borderWidth: 5,
                        hoverOffset: 15
                    }]
                },
                plugins: [centerTextPlugin],
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '75%',
                    plugins: {
                        legend: { display: true, position: 'bottom', labels: { color: '#333', padding: 20 } },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed !== null) {
                                        label += new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(context.parsed);
                                    }
                                    return label;
                                }
                            }
                        },
                        centerText: {
                            display: true
                        }
                    }
                }
            });
        }
    });
</script>

</body>
</html>