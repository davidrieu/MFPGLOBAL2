<?php
// ==============================================================================
// create-checkout-session.php — Version corrigée (dual-mode: AJAX / non-AJAX)
// - Ne change PAS la logique métier existante
// - Pour un succès "manuel/0 €": 
//     * AJAX      -> renvoie strictement {"id":"manual"}
//     * non-AJAX  -> redirige vers success.php?session_id=manual
// - Pour Stripe: renvoie {"id":"cs_..."} (AJAX) comme avant
// ==============================================================================

// ---------- Détection AJAX (sans modifier le front) ----------
function is_ajax_request(): bool {
    // fetch() / XHR envoient souvent cet header
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        return true;
    }
    // fetch précise souvent Accept: application/json
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    if (stripos($accept, 'application/json') !== false) return true;
    // fallback : si le front envoie explicitement ajax=1
    if (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1') return true;
    return false;
}

// ---------- Enveloppes de réponse sûres ----------
function respond_json(array $payload, int $code = 200): void {
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        // Anti-cache
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit();
}
function redirect_to(string $url): void {
    if (!headers_sent()) {
        header('Location: ' . $url, true, 302);
    }
    exit();
}

// ==============================================================================
// INITIALISATION & SÉCURITÉ
// ==============================================================================
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

session_start();

require 'vendor/autoload.php';      // inclut PHPMailer/Stripe
require_once 'db_connection.php';   // définit $pdo

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

$stripeSecret = defined('STRIPE_SECRET_KEY')
    ? STRIPE_SECRET_KEY
    : (getenv('STRIPE_SECRET_KEY') ?: ($_SERVER['STRIPE_SECRET_KEY'] ?? null));

if (!$stripeSecret) {
    // Même en non-AJAX, on reste en JSON pour signaler proprement l’erreur
    respond_json(['error' => 'Configuration du serveur de paiement manquante.'], 500);
}
\Stripe\Stripe::setApiKey($stripeSecret);

// Exceptions "métier" à afficher côté utilisateur
class UserFacingException extends Exception {
    public ?string $field;
    public function __construct(string $message, ?string $field = null) {
        parent::__construct($message);
        $this->field = $field;
    }
}

// ==============================================================================
// LOGIQUE
// ==============================================================================
try {
    // Auth + CSRF
    if (!isset($_SESSION['user_id'])) {
        respond_json(['error' => 'Accès non autorisé. Veuillez vous reconnecter.'], 403);
    }
    $userId = (int)$_SESSION['user_id'];

    $csrf_post = (string)($_POST['csrf_token'] ?? '');
    $csrf_sess = (string)($_SESSION['csrf_token'] ?? '');
    if ($csrf_post === '' || $csrf_sess === '' || !hash_equals($csrf_sess, $csrf_post)) {
        respond_json(['error' => 'Erreur de sécurité (CSRF). Veuillez rafraîchir la page et réessayer.'], 403);
    }

    // Utils IBAN (format souple)
    function sanitize_iban(string $ibanRaw): string {
        return strtoupper(preg_replace('/\s+/', '', $ibanRaw));
    }
    function is_valid_iban_format(string $iban): bool { return true; }

    // Infos user
    $user_info_stmt = $pdo->prepare("SELECT id, prenom, email FROM users WHERE id = ?");
    $user_info_stmt->execute([$userId]);
    $userInfo = $user_info_stmt->fetch(PDO::FETCH_ASSOC);
    if (!$userInfo) throw new UserFacingException("Utilisateur introuvable.");

    // URLs
    $baseUrl           = 'https://mpf-global.com/';
    $successUrl        = $baseUrl . 'success.php?session_id={CHECKOUT_SESSION_ID}';
    $successUrlManual  = $baseUrl . 'success.php?session_id=manual';
    $cancelUrlNewInvest = $baseUrl . 'investclient.php';
    $cancelUrlRenewal   = $baseUrl . 'recoltes.php';

    // Paramètres généraux
    $actionType     = $_POST['action_type'] ?? (isset($_POST['contract_id']) ? 'renewal_custom' : 'new_invest');
    $paymentPlan    = $_POST['payment_plan'] ?? ($_POST['payment_plan_choice'] ?? 'full');
    $monthly12      = isset($_POST['monthly_12x']) ? (float)$_POST['monthly_12x'] : 0.0;
    $promoCode      = strtoupper(trim($_POST['promo_code'] ?? ''));
    $referralCode   = strtoupper(trim($_POST['referral_code'] ?? ''));
    $currency       = 'eur';

    $isAjax = is_ajax_request();

    $newProductsInput = [];
    $newProductsDetails = [];
    $grossNewContractsValue = 0.0;
    $totalDiscount = max(0.0, (float)($_POST['contract_discount_total'] ?? 0));
    $bonusPlus30Value = 0.0;

    // Récup panier si fourni
    if (isset($_POST['cart'])) {
        $cartRaw = $_POST['cart'];
        if (is_string($cartRaw)) {
            $decoded = json_decode($cartRaw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) $newProductsInput = $decoded;
        } elseif (is_array($cartRaw)) $newProductsInput = $cartRaw;
    }
    if (empty($newProductsInput) && isset($_POST['new_products']) && is_array($_POST['new_products'])) {
        $newProductsInput = $_POST['new_products'];
    }

    // Normalisation panier
    $normalizeItems = function(array $items): array {
        $out = [];
        foreach ($items as $it) {
            $id = isset($it['id']) ? (int)$it['id'] : (isset($it['product_id']) ? (int)$it['product_id'] : 0);
            if ($id <= 0) continue;
            $qty = (int)($it['quantity'] ?? 1);
            if ($qty <= 0) $qty = 1;
            $ptype = ($it['plant_type'] ?? ($it['type'] ?? 'new')) === 'mature' ? 'mature' : 'new';
            $out[] = ['id' => $id, 'quantity' => $qty, 'plant_type' => $ptype];
        }
        return $out;
    };
    $newProductsInput = $normalizeItems($newProductsInput);

    $checkout_session = null;
    $is_manual_success = false;
    $manual_success_data = [];

    // --------------------------------------------------------------------------
    // BRANCHE 1 — Nouvelle souscription
    // --------------------------------------------------------------------------
    if ($actionType === 'new_invest') {
        if (empty($newProductsInput)) throw new UserFacingException("Votre panier est vide.");

        $productIds = array_column($newProductsInput, 'id');
        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        $prod_stmt = $pdo->prepare("SELECT id, name, prix, taux, is_active FROM produits WHERE id IN ($placeholders)");
        $prod_stmt->execute($productIds);
        $rows = $prod_stmt->fetchAll(PDO::FETCH_ASSOC);
        $productMap = array_column($rows, null, 'id');

        $customAmountPost = (float)($_POST['custom_amount'] ?? 0.0);
        $topUpPosted      = (float)($_POST['top_up_after_discount'] ?? 0.0);

        foreach ($newProductsInput as $it) {
            if (!isset($productMap[$it['id']])) throw new UserFacingException("Un produit de votre panier n'existe plus.");
            $p = $productMap[$it['id']];
            if ((int)($p['is_active'] ?? 0) !== 1) throw new UserFacingException("Le produit « {$p['name']} » n'est plus disponible.");
            $qty   = (int)$it['quantity'];
            $price = (float)$p['prix'];
            $newProductsDetails[] = [
                'id' => (int)$p['id'],
                'name' => $p['name'],
                'prix' => $price,
                'taux' => (float)($p['taux'] ?? 0),
                'quantity' => $qty,
                'plant_type' => $it['plant_type']
            ];
            $grossNewContractsValue += $price * $qty;
        }

        if ($customAmountPost > 0) $grossNewContractsValue = $customAmountPost;
        if ($totalDiscount > $grossNewContractsValue) throw new UserFacingException("La remise ne peut pas excéder la valeur du panier.");

        $netNew = max(0.0, $grossNewContractsValue - $totalDiscount);
        $topUpAfterDiscount = $topUpPosted > 0 ? min(max($netNew, 0.0) ?: $grossNewContractsValue, $topUpPosted) : round($netNew, 2);
        $topUpAfterDiscount = round(max(0.0, min($topUpAfterDiscount, $grossNewContractsValue)), 2);

        if ($referralCode === 'MPF102569') $bonusPlus30Value = round($grossNewContractsValue * 0.30, 2);

        // Données que success.php exploitera
        $manual_success_data = [
            'user_id' => (string)$userId,
            'action_type' => 'new_invest',
            'original_contract_id' => '0',
            'withdraw_amount' => '0',
            'iban' => '',
            'new_products' => json_encode(array_map(function($x){ return ['id'=>$x['id'],'quantity'=>$x['quantity'],'plant_type'=>$x['plant_type'], 'price' => $x['prix']]; }, $newProductsDetails)),
            'promo_code' => $promoCode,
            'referral_code' => $referralCode,
            'total_discount' => number_format($totalDiscount, 2, '.', ''),
            'top_up_amount' => number_format($topUpAfterDiscount, 2, '.', ''),
            'payment_plan' => $paymentPlan,
            'bonus_plus30_code' => $referralCode === 'MPF102569' ? 'MPF102569' : '',
            'bonus_plus30_value' => number_format($bonusPlus30Value, 2, '.', '')
        ];

        if ($customAmountPost > 0 && isset($newProductsDetails[0])) {
            $manual_success_data['top_up_amount'] = number_format($customAmountPost, 2, '.', '');
            $newProductsDetails[0]['prix'] = 0.0;
            $manual_success_data['new_products'] = json_encode(array_map(function($x){ return ['id'=>$x['id'],'quantity'=>$x['quantity'],'plant_type'=>$x['plant_type'], 'price' => $x['prix']]; }, $newProductsDetails));
        }

        // Paiement 0 € => succès manuel
        if ($paymentPlan === '12x') {
            $centsMonthly = (int) round($monthly12 * 100);
            if ($centsMonthly < 50) $is_manual_success = true;
        } else {
            $cents = (int) round($topUpAfterDiscount * 100);
            if ($cents < 50) $is_manual_success = true;
        }

        // Si l’appelant demande explicitement un "paiement manuel" (virement/crypto), on force le manuel
        if (isset($_POST['is_manual_payment']) && $_POST['is_manual_payment'] === '1') {
            $_SESSION['manual_success_data'] = $manual_success_data;
            // AJAX -> JSON | non-AJAX -> redirect
            if ($isAjax) respond_json(['id' => 'manual']);
            redirect_to($successUrlManual);
        }

        // Stripe si non-manuel
        if (!$is_manual_success) {
            if ($paymentPlan === '12x') {
                if ($monthly12 <= 0.0) throw new UserFacingException("Montant mensuel invalide (12x).");
                $product = \Stripe\Product::create(['name' => 'Nouvelle souscription MPF — Paiement 12 mensualités']);
                $price = \Stripe\Price::create([
                    'unit_amount' => (int) round($monthly12 * 100),
                    'currency' => $currency,
                    'recurring' => ['interval' => 'month'],
                    'product' => $product->id
                ]);
                $checkout_session = \Stripe\Checkout\Session::create([
                    'mode' => 'subscription',
                    'success_url' => $successUrl,
                    'cancel_url'  => $cancelUrlNewInvest,
                    'customer_email' => $userInfo['email'],
                    'line_items' => [['price' => $price->id, 'quantity' => 1]],
                    'subscription_data' => [
                        'metadata' => [
                            'user_id' => (string)$userId,
                            'action_type' => 'new_invest',
                            'original_contract_id' => '0',
                            'plan' => '12x',
                            'monthly_eur' => number_format($monthly12, 2, '.', ''),
                            'total_top_up' => number_format($manual_success_data['top_up_amount'], 2, '.', ''),
                            'type_paiement' => 'abonnement'
                        ]
                    ],
                    'metadata' => $manual_success_data + ['type_paiement' => 'abonnement', 'top_up_after_discount' => $manual_success_data['top_up_amount']]
                ]);
            } else {
                $checkout_session = \Stripe\Checkout\Session::create([
                    'payment_method_types' => ['card'],
                    'line_items' => [[
                        'price_data' => [
                            'currency' => $currency,
                            'product_data' => ['name' => 'Nouvelle souscription Mon Plant Fraise'],
                            'unit_amount' => (int) round(((float)$manual_success_data['top_up_amount']) * 100)
                        ],
                        'quantity' => 1
                    ]],
                    'mode' => 'payment',
                    'success_url' => $successUrl,
                    'cancel_url'  => $cancelUrlNewInvest,
                    'metadata' => $manual_success_data + ['type_paiement' => 'paiement_unique', 'top_up_after_discount' => $manual_success_data['top_up_amount']],
                    'customer_email' => $userInfo['email']
                ]);
            }
        } else {
            // Succès manuel 0€
            $_SESSION['manual_success_data'] = $manual_success_data;
            if ($isAjax) respond_json(['id' => 'manual']);
            redirect_to($successUrlManual);
        }

    // --------------------------------------------------------------------------
    // BRANCHE 2 — Renouvellement / Retrait
    // --------------------------------------------------------------------------
    } else {
        $originalContractId = filter_input(INPUT_POST, 'contract_id', FILTER_VALIDATE_INT);
        if (!$originalContractId) throw new UserFacingException("Contrat non spécifié ou invalide.");

        $stmt = $pdo->prepare("
            SELECT c.id, c.montant, c.apport, c.taux_moyen, p.id AS produit_id
            FROM contrats c
            JOIN produits p ON c.produit_id = p.id
            WHERE c.id = ? AND c.user_id = ?
            LIMIT 1
        ");
        $stmt->execute([$originalContractId, $userId]);
        $originalContract = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$originalContract) throw new UserFacingException("Contrat introuvable.");

        $base = (float)($originalContract['montant'] ?? $originalContract['apport']);
        $totalAvailable = $base + ($base * (float)$originalContract['taux_moyen'] / 100.0);

        // Actions rapides
        if ($actionType === 'reinvest_all') {
            $_SESSION['manual_success_data'] = [
                'user_id' => (string)$userId,
                'action_type' => 'reinvest_all',
                'original_contract_id' => (string)$originalContractId,
                'withdraw_amount' => '0',
                'iban' => '',
                'new_products' => json_encode([[
                    'id' => (int)$originalContract['produit_id'],
                    'quantity' => 1,
                    'plant_type' => 'mature'
                ]]),
                'total_reinvest_amount' => number_format($totalAvailable, 2, '.', '')
            ];
            if ($isAjax) respond_json(['id' => 'manual']);
            redirect_to($successUrlManual);
        }
        if ($actionType === 'withdraw_all') {
            $iban = sanitize_iban((string)($_POST['iban'] ?? ''));
            if (empty($iban) || !is_valid_iban_format($iban)) {
                throw new UserFacingException("L'IBAN est manquant ou invalide pour un retrait total.", 'iban');
            }
            $_SESSION['manual_success_data'] = [
                'user_id' => (string)$userId,
                'action_type' => 'withdraw_all',
                'original_contract_id' => (string)$originalContractId,
                'withdraw_amount' => number_format($totalAvailable, 2, '.', ''),
                'iban' => $iban,
                'new_products' => '[]'
            ];
            if ($isAjax) respond_json(['id' => 'manual']);
            redirect_to($successUrlManual);
        }

        // Renouvellement personnalisé
        if (!empty($newProductsInput)) {
            $productIds = array_column($newProductsInput, 'id');
            $placeholders = implode(',', array_fill(0, count($productIds), '?'));
            $prod_stmt = $pdo->prepare("SELECT id, name, prix, taux FROM produits WHERE id IN ($placeholders)");
            $prod_stmt->execute($productIds);
            $rows = $prod_stmt->fetchAll(PDO::FETCH_ASSOC);
            $productMap = array_column($rows, null, 'id');

            foreach ($newProductsInput as $it) {
                $pid = $it['id'];
                if (!isset($productMap[$pid])) throw new UserFacingException("Le produit demandé (ID $pid) n'existe plus.");
                $p = $productMap[$pid];
                $qty = (int)$it['quantity'];
                $price = (float)$p['prix'];
                $newProductsDetails[] = [
                    'id' => (int)$p['id'],
                    'name' => $p['name'],
                    'prix' => $price,
                    'taux' => (float)($p['taux'] ?? 0),
                    'quantity' => $qty,
                    'plant_type' => ($it['plant_type'] === 'mature') ? 'mature' : 'new'
                ];
                $grossNewContractsValue += $price * $qty;
            }
        }

        if ($totalDiscount > $grossNewContractsValue) throw new UserFacingException("La remise ne peut pas être supérieure à la valeur des contrats.");
        $netNew = max(0.0, $grossNewContractsValue - $totalDiscount);

        $usedFromAvailable = min($netNew, $totalAvailable);
        $withdrawCents = max(0, (int) round(($totalAvailable - $usedFromAvailable) * 100));
        $topUpCents    = max(0, (int) round(($netNew - $totalAvailable) * 100));

        $withdrawAmount      = $withdrawCents / 100.0;
        $topUpAfterDiscount  = $topUpCents / 100.0;

        $iban = '';
        if ($withdrawCents >= 1) {
            $iban = sanitize_iban((string)($_POST['iban'] ?? ''));
            if (empty($iban) || !is_valid_iban_format($iban)) {
                throw new UserFacingException("IBAN invalide ou manquant. Merci de renseigner un IBAN au format correct (ex. FR76...).", 'iban');
            }
        }

        if ($referralCode === 'MPF102569') $bonusPlus30Value = round($grossNewContractsValue * 0.30, 2);

        $manual_success_data = [
            'user_id' => (string)$userId,
            'action_type' => $actionType,
            'original_contract_id' => (string)$originalContractId,
            'withdraw_amount' => number_format($withdrawAmount, 2, '.', ''),
            'iban' => $iban,
            'new_products' => json_encode(array_map(function($x){ return ['id'=>$x['id'],'quantity'=>$x['quantity'],'plant_type'=>$x['plant_type']]; }, $newProductsDetails)),
            'promo_code' => $promoCode,
            'referral_code' => $referralCode,
            'total_discount' => number_format($totalDiscount, 2, '.', ''),
            'top_up_amount' => number_format($topUpAfterDiscount, 2, '.', ''),
            'payment_plan' => $paymentPlan,
            'bonus_plus30_code' => $referralCode === 'MPF102569' ? 'MPF102569' : '',
            'bonus_plus30_value' => number_format($bonusPlus30Value, 2, '.', '')
        ];

        // Paiement 0 € => succès manuel
        if ($paymentPlan === '12x') {
            $centsMonthly = (int) round($monthly12 * 100);
            if ($centsMonthly < 50) $is_manual_success = true;
        } else {
            $cents = (int) round($topUpAfterDiscount * 100);
            if ($cents < 50) $is_manual_success = true;
        }

        // Paiement "manuel" explicite
        if (isset($_POST['is_manual_payment']) && $_POST['is_manual_payment'] === '1') {
            $_SESSION['manual_success_data'] = $manual_success_data;
            if ($isAjax) respond_json(['id' => 'manual']);
            redirect_to($successUrlManual);
        }

        // Stripe si non-manuel
        if (!$is_manual_success) {
            if ($paymentPlan === '12x') {
                if ($monthly12 <= 0.0) throw new UserFacingException("Montant mensuel invalide (12x).");
                $product = \Stripe\Product::create(['name' => 'Renouvellement MPF — Paiement 12 mensualités']);
                $price = \Stripe\Price::create([
                    'unit_amount' => (int) round($monthly12 * 100),
                    'currency' => $currency,
                    'recurring' => ['interval' => 'month'],
                    'product' => $product->id
                ]);
                $checkout_session = \Stripe\Checkout\Session::create([
                    'mode' => 'subscription',
                    'success_url' => $successUrl,
                    'cancel_url'  => $cancelUrlRenewal,
                    'customer_email' => $userInfo['email'],
                    'line_items' => [['price' => $price->id, 'quantity' => 1]],
                    'subscription_data' => [
                        'metadata' => [
                            'user_id' => (string)$userId,
                            'action_type' => $actionType,
                            'original_contract_id' => (string)$originalContractId,
                            'plan' => '12x',
                            'monthly_eur' => number_format($monthly12, 2, '.', ''),
                            'total_top_up' => number_format($manual_success_data['top_up_amount'], 2, '.', ''),
                            'type_paiement' => 'abonnement'
                        ]
                    ],
                    'metadata' => $manual_success_data + ['type_paiement' => 'abonnement', 'top_up_after_discount' => $manual_success_data['top_up_amount']]
                ]);
            } else {
                $checkout_session = \Stripe\Checkout\Session::create([
                    'payment_method_types' => ['card'],
                    'line_items' => [[
                        'price_data' => [
                            'currency' => $currency,
                            'product_data' => ['name' => 'Paiement complémentaire Mon Plant Fraise'],
                            'unit_amount' => (int) round(((float)$manual_success_data['top_up_amount']) * 100)
                        ],
                        'quantity' => 1
                    ]],
                    'mode' => 'payment',
                    'success_url' => $successUrl,
                    'cancel_url'  => $cancelUrlRenewal,
                    'metadata' => $manual_success_data + ['type_paiement' => 'paiement_unique', 'top_up_after_discount' => $manual_success_data['top_up_amount']],
                    'customer_email' => $userInfo['email']
                ]);
            }
        } else {
            $_SESSION['manual_success_data'] = $manual_success_data;
            if ($isAjax) respond_json(['id' => 'manual']);
            redirect_to($successUrlManual);
        }
    }

    // --------------------------------------------------------------------------
    // RÉPONSES FINALES
    // --------------------------------------------------------------------------
    if ($checkout_session) {
        // Flux Stripe: toujours JSON avec l'id de session
        respond_json(['id' => $checkout_session->id]);
    }

    // Sécurité: si on arrive ici, c'est une incohérence
    respond_json(['error' => 'La session de paiement n’a pas pu être déterminée.'], 500);

} catch (UserFacingException $e) {
    respond_json(['error' => $e->getMessage(), 'field' => $e->field], 400);

} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log('ERREUR API STRIPE: ' . $e->getMessage());
    respond_json(['error' => 'Erreur de communication avec le service de paiement. Veuillez réessayer.'], 502);

} catch (Exception $e) {
    error_log('ERREUR create-checkout-session: ' . $e->getMessage());
    respond_json(['error' => 'Oups, une erreur technique est survenue. Merci de réessayer.'], 500);
}

// ------------------------------------------------------------------------------
// Optionnel : email (laissé identique, non utilisé ici, conservé si besoin)
// ------------------------------------------------------------------------------
function sendRenewalConfirmationEmail($userInfo, $renewalData) {
    $smtpPass = getenv('SMTP_PASS');
    if (!$smtpPass) { error_log("SMTP_PASS manquant"); return; }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.ionos.fr';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@monplantfraise.com';
        $mail->Password   = $smtpPass;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom('info@monplantfraise.com', 'Mon Plant Fraise');
        $mail->addAddress($userInfo['email'], $userInfo['prenom']);
        $mail->isHTML(true);
        $mail->Subject = 'Confirmation de votre opération sur votre contrat';
        $body  = "<p>Bonjour " . htmlspecialchars($userInfo['prenom']) . ",</p>";
        $body .= "<p>Votre opération a bien été prise en compte.</p>";
        $mail->Body = $body;
        $mail->send();
    } catch (PHPMailerException $e) {
        error_log("Erreur PHPMailer: {$mail->ErrorInfo}");
    }
}

