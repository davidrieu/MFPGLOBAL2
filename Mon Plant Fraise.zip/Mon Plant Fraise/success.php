<?php
// ====================================================================================
/* success.php - VERSION CORRIGÉE ET AMÉLIORÉE (v4.1)
   - SMTP PHPMailer : STARTTLS:587 → fallback SMTPS:465 (IONOS) + ?maildebug=1
   - Stripe (Google Pay / Apple Pay) : vérif utilisateur tolérante si session perdue
   - Idempotence commandes/contrats conservée
   - Corps email enrichi + récap contrats
*/
// ====================================================================================

session_start();

// En prod: display_errors=0
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Dépendances
require __DIR__ . '/vendor/autoload.php';
require_once 'db_connection.php'; // Doit définir $pdo

// --- Ajout manuel de PHPMailer (si autoload capricieux) ---
require_once __DIR__ . '/vendor/phpmailer/src/Exception.php';
require_once __DIR__ . '/vendor/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/vendor/phpmailer/src/SMTP.php';
// --- Fin ---

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

// -----------------------------------------------------------------------------
// Vérification BDD
// -----------------------------------------------------------------------------
if (!isset($pdo) || !$pdo instanceof PDO) {
    error_log("Erreur critique success.php : la variable \$pdo n'est pas définie par db_connection.php.");
    $isError = true;
    $message = "Erreur de connexion au serveur de données. L'administrateur a été notifié.";
    goto display_page;
}
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// -----------------------------------------------------------------------------
// Stripe (optionnel si flux manuel)
// -----------------------------------------------------------------------------
$stripeSecret = defined('STRIPE_SECRET_KEY')
    ? STRIPE_SECRET_KEY
    : (getenv('STRIPE_SECRET_KEY') ?: ($_SERVER['STRIPE_SECRET_KEY'] ?? null));
$stripeReady = !empty($stripeSecret);
if ($stripeReady) {
    \Stripe\Stripe::setApiKey($stripeSecret);
} else {
    error_log('success.php: STRIPE_SECRET_KEY manquante ou vide');
}

// ====================================================================================
// OUTILS / HELPERS
// ====================================================================================

/**
 * Envoie l'email de confirmation avec debug optionnel et failover 587→465.
 */
function sendConfirmationEmail(string $recipientEmail, string $recipientName, string $subject, string $body) {
    $mail = new PHPMailer(true);

    // Récupération du mot de passe SMTP
    $smtpPass = defined('SMTP_PASS')
        ? SMTP_PASS
        : (getenv('SMTP_PASS') ?: ($_SERVER['SMTP_PASS'] ?? null));

    if (empty($smtpPass)) {
        error_log("Email non envoyé à {$recipientEmail}: SMTP_PASS non configuré (via defined, getenv, ou \$_SERVER).");
        return;
    }

    // DEBUG optionnel : ?maildebug=1
    if (isset($_GET['maildebug']) && $_GET['maildebug'] == '1') {
        $mail->SMTPDebug  = SMTP::DEBUG_SERVER;
        $mail->Debugoutput = function($str, $level) {
            error_log("PHPMailer[$level] $str");
        };
    }

    try {
        // --- config de base ---
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->Host     = 'smtp.ionos.fr';
        $mail->Username = 'info@monplantfraise.com';
        $mail->Password = $smtpPass;
        $mail->CharSet  = 'UTF-8';

        // --- préparer le message AVANT d'appeler send() ---
        $mail->setFrom('info@monplantfraise.com', 'Mon Plant Fraise'); // = Username
        $mail->addAddress($recipientEmail, $recipientName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);

        // 1) Essai STARTTLS 587 (recommandé)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        try {
            $mail->send();
            error_log('[MAIL] Envoyé via STARTTLS:587 à '.$recipientEmail);
        } catch (PHPMailerException $e1) {
            error_log('[MAIL] Échec 587/STARTTLS: '.$mail->ErrorInfo.' | tentative 465/SMTPS...');

            // 2) Fallback SMTPS 465
            $mail->smtpClose();
            $mail->isSMTP();
            $mail->SMTPAuth   = true;
            $mail->Host       = 'smtp.ionos.fr';
            $mail->Username   = 'info@monplantfraise.com';
            $mail->Password   = $smtpPass;
            $mail->CharSet    = 'UTF-8';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;

            // Destinataires/subject/body déjà posés
            $mail->send();
            error_log('[MAIL] Envoyé via SMTPS:465 à '.$recipientEmail);
        }

    } catch (PHPMailerException $e) {
        error_log("PHPMailer: échec d'envoi vers {$recipientEmail} ({$mail->ErrorInfo})");
    }
}

/** Mappe le libellé local vers la valeur DB attendue pour contrats.type_paiement. */
function mapTypePaiementForDb(string $mode): string {
    $m = strtolower(trim($mode));
    if (in_array($m, ['12x','abonnement','mensuel','subscription','monthly'], true)) return 'abonnement';
    return 'paiement_unique';
}

/** Programme l'arrêt auto d'une Subscription Stripe à 12 prélèvements au total. */
function scheduleAutoCancelFor12x(string $subscriptionId, string $tzName = 'Europe/Paris'): void {
    if (empty($subscriptionId) || !$GLOBALS['stripeReady']) {
         error_log("scheduleAutoCancelFor12x annulé: ID vide ou Stripe non prêt.");
         return;
    }
    try {
        $sub = \Stripe\Subscription::retrieve($subscriptionId);
        if (!empty($sub->cancel_at)) {
            error_log("Subscription {$subscriptionId}: cancel_at déjà présent.");
            return;
        }
        $cps = (int)($sub->current_period_start ?? 0);
        $tz  = new DateTimeZone($tzName);
        if ($cps <= 0) {
            $now = new DateTimeImmutable('now', $tz);
            $cancelAt = $now->modify('+11 months')->getTimestamp();
        } else {
            $d = (new DateTimeImmutable("@{$cps}"))->setTimezone($tz);
            $cancelAt = $d->modify('+11 months')->getTimestamp();
        }
        \Stripe\Subscription::update($subscriptionId, ['cancel_at' => $cancelAt]);
        error_log("Subscription {$subscriptionId} mise à jour (cancel_at={$cancelAt})");
    } catch (\Throwable $e) {
        error_log("scheduleAutoCancelFor12x error: ".$e->getMessage());
    }
}

/** Bonus parrain spécifique. */
function applyParrainBonus(float $montantBase, ?string $parrain): float {
    $code = strtoupper(trim((string)$parrain));
    if ($code === 'MPF102569') {
        return (float)ceil($montantBase * 1.30);
    }
    return $montantBase;
}

/** Helpers robustes pour les items (gèrent FR/EN et alternatives) */
function getUnitPrice(array $it): float {
    foreach (['price','prix','unit_price','amount'] as $k) {
        if (isset($it[$k]) && is_numeric($it[$k])) return (float)$it[$k];
    }
    return 0.0;
}
function getQty(array $it): int {
    foreach (['quantity','quantite','qty'] as $k) {
        if (isset($it[$k]) && (int)$it[$k] > 0) return (int)$it[$k];
    }
    return 1;
}
function getPlantType(array $it): string {
    return (string)($it['plant_type'] ?? $it['type'] ?? 'new');
}
function getProductId(array $it): int {
    foreach (['id','product_id'] as $k) {
        if (isset($it[$k]) && (int)$it[$k] > 0) return (int)$it[$k];
    }
    return 0;
}
function numOrZero($v): float {
    return is_numeric($v) ? (float)$v : 0.0;
}

/**
 * Récupère les noms des produits et formate les libellés pour l'affichage.
 * Utilise la colonne 'name' (au lieu de 'nom').
 */
function enrichContractDetails(PDO $pdo, array $contracts): array {
    if (empty($contracts)) return [];

    $productIds = array_unique(array_map(fn($c) => (int)$c['produit_id'], $contracts));
    $productIds = array_filter($productIds, fn($id) => $id > 0);

    if (empty($productIds)) {
        foreach ($contracts as $i => $c) {
            $contracts[$i]['produit_nom'] = 'Investissement Libre';
            $contracts[$i]['type_paiement_label'] = ($c['type_paiement'] === 'abonnement') ? 'Paiement en 12x' : 'Paiement unique';
            $contracts[$i]['montant_label'] = ($c['type_paiement'] === 'abonnement') ? 'Première mensualité' : 'Montant';
        }
        return $contracts;
    }

    $mapNoms = [];
    try {
        $ph = implode(',', array_fill(0, count($productIds), '?'));
        $st_noms = $pdo->prepare("SELECT id, name FROM produits WHERE id IN ($ph)");
        $st_noms->execute($productIds);
        while ($r = $st_noms->fetch(PDO::FETCH_ASSOC)) {
            $mapNoms[(int)$r['id']] = $r['name'];
        }
    } catch (Exception $e) {
        error_log("enrichContractDetails failed: " . $e->getMessage());
    }

    foreach ($contracts as $i => $c) {
        $pid = (int)$c['produit_id'];
        $contracts[$i]['produit_nom'] = $mapNoms[$pid] ?? 'Produit Inconnu';
        $contracts[$i]['type_paiement_label'] = ($c['type_paiement'] === 'abonnement') ? 'Paiement en 12x' : 'Paiement unique';
        $contracts[$i]['montant_label'] = ($c['type_paiement'] === 'abonnement') ? 'Première mensualité' : 'Montant';
    }
    return $contracts;
}

/**
 * Génère le corps de l'e-mail de confirmation enrichi.
 */
function generateEmailBody(string $prenom, string $paymentMethod, array $contracts, ?int $orderId): string {
    $body = "<style>
        body { font-family: Arial, sans-serif; line-height: 1.6; }
        .container { width: 90%; margin: auto; padding: 20px; }
        .header { font-size: 24px; color: #2ecc71; }
        .card { border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 8px; }
        .steps { margin-top: 20px; }
        .steps li { margin-bottom: 10px; }
    </style>";

    $body .= "<div class='container'>";
    $body .= "<h1 class='header'>Merci, " . htmlspecialchars($prenom) . " !</h1>";
    $body .= "<p>Nous avons bien reçu votre paiement via <strong>" . htmlspecialchars($paymentMethod) . "</strong>.</p>";

    if ($orderId) {
        $body .= "<p>Votre commande <strong>#" . $orderId . "</strong> est confirmée.</p>";
    } else {
        $body .= "<p>Votre opération de renouvellement est confirmée.</p>";
    }

    $body .= "<h2>Récapitulatif des contrats créés :</h2>";

    if (empty($contracts)) {
        $body .= "<p>Aucun nouveau contrat n'a été créé (ex: retrait total).</p>";
    } else {
        foreach ($contracts as $c) {
            $body .= "<div class='card'>";
            $body .= "<strong>Produit :</strong> " . htmlspecialchars($c['produit_nom']) . " (" . htmlspecialchars($c['plant_type']) . ")<br>";
            $body .= "<strong>" . htmlspecialchars($c['montant_label']) . " :</strong> " . number_format($c['montant_investi'], 2, ',', ' ') . " €<br>";
            $body .= "<strong>Type de paiement :</strong> " . htmlspecialchars($c['type_paiement_label']) . "<br>";
            if (($c['type_paiement'] ?? '') === 'abonnement') {
                $body .= "<strong>Montant total estimé :</strong> " . number_format($c['montant_base'], 2, ',', ' ') . " € (sur 12 mois)<br>";
            }
            $body .= "</div>";
        }
    }

    $body .= "<div class='steps'>";
    $body .= "<h2>Prochaines étapes :</h2>";
    $body .= "<ol>";
    $body .= "<li>Vos contrats sont en cours de génération.</li>";
    $body .= "<li>Sous 24h, les documents contractuels (PDF) seront disponibles dans votre espace client.</li>";
    $body .= "<li>Vous pouvez suivre l'évolution de vos plants directement depuis votre tableau de bord.</li>";
    $body .= "</ol>";
    $body .= "</div>";

    $body .= "<p>À très bientôt,<br>L'équipe Mon Plant Fraise</p>";
    $body .= "</div>";

    return $body;
}


// ====================================================================================
// FULFILLMENTS (LOGIQUE MÉTIER)
// ====================================================================================

/**
 * Finalise un NOUVEL ACHAT de plants.
 * Retourne un array: ['status' => 'success'|'already_done', 'message' => '...', 'commande_id' => ?, 'contrats' => []]
 */
function fulfillNewPurchase(PDO $pdo, array $metadata, string $payment_id): array {
    // Idempotence commandes
    $stmt_check_cmd = $pdo->prepare("SELECT id FROM commandes WHERE stripe_session_id = ? LIMIT 1");
    $stmt_check_cmd->execute([$payment_id]);
    if ($stmt_check_cmd->fetchColumn()) {
        return ['status' => 'already_done', 'message' => "Opération déjà traitée (commande trouvée).", 'commande_id' => null, 'contrats' => []];
    }

    $pdo->beginTransaction();
    $contratsCrees = [];

    try {
        $userId   = (int)$metadata['user_id'];
        $cartItems = json_decode($metadata['new_products'] ?? '[]', true);
        if (empty($cartItems) || !is_array($cartItems)) {
            throw new Exception("Panier vide ('new_products') dans les métadonnées.");
        }

        // Remises et top-up
        $top_up_amount  = numOrZero($metadata['top_up_amount'] ?? $metadata['top_up_after_discount'] ?? 0);
        $total_discount = numOrZero($metadata['total_discount'] ?? 0);

        // Commande
        $stmt_commande = $pdo->prepare(
            "INSERT INTO commandes (user_id, stripe_session_id, montant_total, statut) 
             VALUES (:user_id, :sid, :total, 'payée')"
        );
        $stmt_commande->execute([
            ':user_id' => $userId,
            ':sid'     => $payment_id,
            ':total'   => $top_up_amount,
        ]);
        $orderId = (int)$pdo->lastInsertId();

        // User infos
        $stmt_user = $pdo->prepare("SELECT prenom, email, parrain FROM users WHERE id = ?");
        $stmt_user->execute([$userId]);
        $userInfo = $stmt_user->fetch(PDO::FETCH_ASSOC);
        if (!$userInfo) { throw new Exception("Utilisateur introuvable."); }
        $userParrain = $metadata['referral_code'] ?? $userInfo['parrain'] ?? null;

        // Type paiement
        $typePaiementMeta = mapTypePaiementForDb($metadata['payment_plan'] ?? 'full');

        // Détail produits
        $stmt_prod = $pdo->prepare(
            "INSERT INTO commande_produits (commande_id, produit_id, quantite, prix_unitaire)
             VALUES (:commande_id, :produit_id, :qte, :pu)"
        );

        // Prépare insert contrats
        $stmt_contrat = $pdo->prepare("
            INSERT INTO contrats
                (user_id, user_prenom, email, date_souscription, created_at,
                 montant, apport, montant_base, taux_moyen, produit_id, type_paiement,
                 mensualites_payees, code_parrain, promo_code, statut, note, plant_type)
            VALUES
                (:user_id, :user_prenom, :email, NOW(), NOW(),
                 :montant, :apport, :montant_base, :taux_moyen, :produit_id, :type_paiement,
                 :mensualites_payees, :code_parrain, :promo_code, 'En cours', :note, :plant_type)
        ");

        // Investissement libre ?
        $isInvestissementLibre = (count($cartItems) === 1 && (float)getUnitPrice($cartItems[0]) === 0.0);

        // Map taux par produit
        $productIds = array_map('getProductId', $cartItems);
        $productIds = array_values(array_filter($productIds, fn($v) => $v > 0));
        $mapTaux = [];

        if (!empty($productIds)) {
            $ph = implode(',', array_fill(0, count($productIds), '?'));
            $st_taux = $pdo->prepare("SELECT id, taux FROM produits WHERE id IN ($ph)");
            $st_taux->execute($productIds);
            while ($r = $st_taux->fetch(PDO::FETCH_ASSOC)) {
                $mapTaux[(int)$r['id']] = (float)($r['taux'] ?? 40.0);
            }
        }

        // Valeur brute panier
        $grossTotal = 0.0;
        foreach ($cartItems as $it) {
            $grossTotal += getUnitPrice($it) * getQty($it);
        }
        $grossTotal = max(0.0, $grossTotal);

        foreach ($cartItems as $item) {
            $pid        = getProductId($item);
            $qty        = getQty($item);
            $price      = getUnitPrice($item);
            $taux_final = $mapTaux[$pid] ?? 40.0;
            $plant_type = getPlantType($item);

            if ($pid <= 0 || $qty <= 0) {
                 if (!$isInvestissementLibre) continue;
                 if ($isInvestissementLibre && $pid <= 0) $pid = 0;
            }

            if (!$isInvestissementLibre && $pid > 0) {
                 $stmt_prod->execute([
                    ':commande_id' => $orderId,
                    ':produit_id'  => $pid,
                    ':qte'         => $qty,
                    ':pu'          => $price
                ]);
            }

            for ($i = 0; $i < $qty; $i++) {
                $note           = "Commande #{$orderId}. Payment ID: {$payment_id}";
                $apport_contrat = 0.0;

                if ($isInvestissementLibre) {
                    $apport_contrat = $top_up_amount;
                    $note          .= " (Investissement Libre)";
                    if ($i > 0) $apport_contrat = 0.0;
                } else {
                    $unit_discount = ($grossTotal > 0 && $price > 0)
                        ? ($total_discount * ($price / $grossTotal))
                        : 0.0;
                    $apport_contrat = max(0.0, $price - $unit_discount);
                }

                if ($typePaiementMeta === 'abonnement') {
    // Ici $apport_contrat représente le montant TOTAL (ex: 1000€)
    $montant_base = $apport_contrat;          // 1000€ = valeur de référence du contrat
    $mensualite   = $montant_base / 12.0;     // 83.33€ = mensualité
    $apport_contrat = $mensualite;            // ce qu’on stocke dans 'apport'
    $note        .= " (Plan 12x)";
} else {
    $montant_base = $apport_contrat;
    $note        .= " (Paiement unique)";
}

                $montant_contrat = applyParrainBonus($montant_base, $userParrain);

                $stmt_contrat->execute([
                    ':user_id'            => $userId,
                    ':user_prenom'        => $userInfo['prenom'],
                    ':email'              => $userInfo['email'],
                    ':montant'            => $montant_contrat,
                    ':apport'             => $apport_contrat,
                    ':montant_base'       => $montant_base,
                    ':taux_moyen'         => $taux_final,
                    ':produit_id'         => $pid,
                    ':type_paiement'      => $typePaiementMeta,
                    ':mensualites_payees' => ($typePaiementMeta === 'abonnement') ? 1 : 0,
                    ':code_parrain'       => $userParrain,
                    ':promo_code'         => $metadata['promo_code'] ?? null,
                    ':note'               => $note,
                    ':plant_type'         => $plant_type
                ]);

                $contratsCrees[] = [
                    'produit_id'      => $pid,
                    'montant_investi' => $apport_contrat,
                    'montant_base'    => $montant_base,
                    'type_paiement'   => $typePaiementMeta,
                    'plant_type'      => $plant_type
                ];

                if ($isInvestissementLibre) break 2;
            }
        }

        $pdo->commit();
        return [
            'status' => 'success',
            'message' => "Paiement validé ! Vos nouveaux contrats ont été créés. Votre numéro de commande est le #{$orderId}.",
            'commande_id' => $orderId,
            'contrats' => $contratsCrees
        ];

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log("Erreur Fulfill New Purchase (PaymentID: {$payment_id}): " . $e->getMessage() . " | Meta: " . json_encode($metadata));
        throw $e;
    }
}

/**
 * Finalise un RENOUVELLEMENT (manuel/Stripe).
 */
function fulfillRenewal(PDO $pdo, array $metadata): array {
    $pdo->beginTransaction();
    $contratsCrees = [];

    try {
        $userId               = (int)$metadata['user_id'];
        $originalContractId   = (int)($metadata['original_contract_id'] ?? 0);
        $withdrawAmount       = numOrZero($metadata['withdraw_amount'] ?? 0.0);
        $iban                 = trim((string)($metadata['iban'] ?? ''));
        $newProductsInput     = json_decode($metadata['new_products'] ?? '[]', true);
        $stripe_session_id    = $metadata['__stripe_session_id'] ?? 'manual_renewal';
        $top_up_amount        = numOrZero($metadata['top_up_amount'] ?? $metadata['top_up_after_discount'] ?? 0.0);
        $total_discount       = numOrZero($metadata['total_discount'] ?? 0.0);

        $stmt_user = $pdo->prepare("SELECT prenom, email, parrain FROM users WHERE id = ?");
        $stmt_user->execute([$userId]);
        $userInfo = $stmt_user->fetch(PDO::FETCH_ASSOC);
        if (!$userInfo) throw new Exception("Utilisateur introuvable.");
        $userParrain = $metadata['referral_code'] ?? $userInfo['parrain'] ?? null;

        $stmt_check = $pdo->prepare("SELECT statut FROM contrats WHERE id = ? AND user_id = ?");
        $stmt_check->execute([$originalContractId, $userId]);
        $currentStatus = $stmt_check->fetchColumn();
        if ($currentStatus === 'Renouvelé' || $currentStatus === 'Clôturé') {
            $pdo->rollBack();
            return ['status' => 'already_done', 'message' => "Cette opération sur le contrat #{$originalContractId} a déjà été traitée.", 'contrats' => []];
        }

        if ($withdrawAmount > 0.01) {
            $stmt_w = $pdo->prepare("INSERT INTO demandes_retrait (user_id, contrat_id, montant, iban, statut, created_at) VALUES (?, ?, ?, ?, 'En attente', NOW())");
            $stmt_w->execute([$userId, $originalContractId, $withdrawAmount, $iban ?: null]);
        }

        if (empty($newProductsInput) || ($metadata['action_type'] ?? null) === 'withdraw_all') {
            $pdo->prepare("UPDATE contrats SET statut='Clôturé' WHERE id=? AND user_id=?")
                ->execute([$originalContractId, $userId]);
            $pdo->commit();
            return ['status' => 'success', 'message' => "Retrait total enregistré. Le contrat #{$originalContractId} est clôturé.", 'contrats' => []];
        }

        $pdo->prepare("UPDATE contrats SET statut='Renouvelé' WHERE id=? AND user_id=?")
            ->execute([$originalContractId, $userId]);

        // Construire la map produits (prix/taux)
        $ids = [];
        foreach ($newProductsInput as $it) {
            $pid = getProductId($it);
            if ($pid > 0) $ids[] = $pid;
        }
        if (empty($ids)) throw new Exception("Aucun produit valide pour renouvellement.");

        $ph = implode(',', array_fill(0, count($ids), '?'));
        $stmt_p = $pdo->prepare("SELECT id, prix, taux FROM produits WHERE id IN ($ph)");
        $stmt_p->execute($ids);
        $prodMap = [];
        while ($r = $stmt_p->fetch(PDO::FETCH_ASSOC)) {
            $pid = (int)$r['id'];
            $prodMap[$pid] = [
                'prix' => (float)($r['prix'] ?? 0.0),
                'taux' => isset($r['taux']) ? (float)$r['taux'] : 40.0
            ];
        }

        $lines = [];
        $grossTotal = 0.0;
        foreach ($newProductsInput as $it) {
            $pid = getProductId($it);
            $qty = getQty($it);
            if ($pid <= 0 || $qty <= 0 || !isset($prodMap[$pid])) continue;
            $prix  = $prodMap[$pid]['prix'];
            $taux  = $prodMap[$pid]['taux'];
            $gross = $prix * $qty;

            $grossTotal += $gross;
            $lines[] = [
                'id' => $pid,
                'qty' => $qty,
                'prix' => $prix,
                'taux' => $taux,
                'gross' => $gross,
                'plant_type' => getPlantType($it)
            ];
        }
        $grossTotal = max(0.0, $grossTotal);

        $typePaiement = mapTypePaiementForDb($metadata['payment_plan'] ?? 'full');
        $mensuInit    = ($typePaiement === 'abonnement') ? 1 : 0;

        $ins = $pdo->prepare("
            INSERT INTO contrats
                (user_id, user_prenom, email, date_souscription, created_at, montant, apport, montant_base, taux_moyen, produit_id,
                 type_paiement, mensualites_payees, code_parrain, promo_code, statut, note, plant_type)
            VALUES
                (:user_id, :user_prenom, :email, NOW(), NOW(), :montant, :apport, :montant_base, :taux_moyen, :produit_id,
                 :type_paiement, :mensualites_payees, :code_parrain, :promo_code, 'En cours', :note, :plant_type)
        ");

        if (($metadata['action_type'] ?? null) === 'reinvest_all') {
            $totalReinvestAmount = numOrZero($metadata['total_reinvest_amount'] ?? 0.0);
            $productToReinvest   = $lines[0] ?? null;

            if ($totalReinvestAmount > 0 && $productToReinvest) {
                $apport        = $totalReinvestAmount;
                $montant_base  = $apport;
                $montant_final = applyParrainBonus($montant_base, $userParrain);
                $mensuInit     = 0;
                $typePaiement  = 'paiement_unique';
                $plantType     = 'mature';

                $ins->execute([
                    ':user_id'            => $userId,
                    ':user_prenom'        => $userInfo['prenom'],
                    ':email'              => $userInfo['email'],
                    ':montant'            => $montant_final,
                    ':apport'             => $apport,
                    ':montant_base'       => $montant_base,
                    ':taux_moyen'         => $productToReinvest['taux'],
                    ':produit_id'         => $productToReinvest['id'],
                    ':type_paiement'      => $typePaiement,
                    ':mensualites_payees' => $mensuInit,
                    ':code_parrain'       => $userParrain,
                    ':promo_code'         => $metadata['promo_code'] ?? null,
                    ':note'               => "Réinvestissement total du contrat #{$originalContractId}",
                    ':plant_type'         => $plantType
                ]);

                $contratsCrees[] = [
                    'produit_id'      => $productToReinvest['id'],
                    'montant_investi' => $apport,
                    'montant_base'    => $montant_base,
                    'type_paiement'   => $typePaiement,
                    'plant_type'      => $plantType
                ];
            }
        } else {
            foreach ($lines as $ln) {
                $pid  = $ln['id']; $qty = $ln['qty']; $prix = $ln['prix']; $taux = $ln['taux']; $gross = $ln['gross'];
                $lineDiscount = ($grossTotal > 0.0) ? ($total_discount * ($gross / $grossTotal)) : 0.0;
                $lineNet      = max(0.0, $gross - $lineDiscount);
                $apportUnit   = $qty > 0 ? ($lineNet / $qty) : $lineNet;

                for ($i = 0; $i < $qty; $i++) {
                    if ($typePaiement === 'abonnement') {
    // $apportUnit = montant TOTAL du contrat
    $montant_base  = $apportUnit;             // 1000€
    $mensualite    = $montant_base / 12.0;    // 83.33€
    $apportVal     = $mensualite;             // ce qui va dans 'apport'
    $montant_final = applyParrainBonus($montant_base, $userParrain);
} else {
    $apportVal     = $apportUnit;
    $montant_base  = $apportUnit;
    $montant_final = applyParrainBonus($montant_base, $userParrain);
}

                    $ins->execute([
                        ':user_id'            => $userId,
                        ':user_prenom'        => $userInfo['prenom'],
                        ':email'              => $userInfo['email'],
                        ':montant'            => $montant_final,
                        ':apport'             => $apportVal,
                        ':montant_base'       => $montant_base,
                        ':taux_moyen'         => $taux,
                        ':produit_id'         => $pid,
                        ':type_paiement'      => $typePaiement,
                        ':mensualites_payees' => $mensuInit,
                        ':code_parrain'       => $userParrain,
                        ':promo_code'         => $metadata['promo_code'] ?? null,
                        ':note'               => "Renouvellement depuis contrat #{$originalContractId}. Top-up: {$top_up_amount}€. SID: {$stripe_session_id}",
                        ':plant_type'         => $ln['plant_type']
                    ]);

                    $contratsCrees[] = [
                        'produit_id'      => $pid,
                        'montant_investi' => $apportVal,
                        'montant_base'    => $montant_base,
                        'type_paiement'   => $typePaiement,
                        'plant_type'      => $ln['plant_type']
                    ];
                }
            }
        }

        $pdo->commit();
        return [
            'status' => 'success',
            'message' => "Renouvellement enregistré : ancien contrat mis à jour et nouveaux contrats créés.",
            'contrats' => $contratsCrees
        ];
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log("Erreur Fulfill Renewal (Contrat: ".($metadata['original_contract_id'] ?? '?')."): " . $e->getMessage() . " | Meta: " . json_encode($metadata));
        throw $e;
    }
}

// ====================================================================================
// LOGIQUE PRINCIPALE + PRÉPARATION VUE
// ====================================================================================
$userIdForEmail = null;
$message        = "Une erreur inattendue est survenue. Veuillez contacter le support.";
$isError        = true;       // défaut: erreur
$isAlreadyDone  = false;      // pour les refresh

// Variables pour la vue de succès
$pageTitle        = "Confirmation d'opération";
$clientName       = "";
$paymentMethod    = "Inconnu";
$createdContracts = [];
$orderId          = null;
$clientEmail      = "";


try {
    // Flux POST (virement/crypto directs) — non supporté ici
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $message = "Les soumissions directes (POST) à cette page ne sont pas supportées.";
        throw new Exception($message);
    }

    $session_id = $_GET['session_id'] ?? null;

    if (!$session_id) {
        $message = "Référence de validation manquante ou type de paiement non reconnu.";
        throw new Exception($message);
    }

    if ($session_id === 'manual') {
        // Flux manuel en session (RENOUVELLEMENT OU NOUVEL ACHAT virement/crypto)
        if (!isset($_SESSION['manual_success_data'])) {
            throw new Exception("Opération déjà traitée ou session expirée.", 100);
        }
        $metadata = $_SESSION['manual_success_data'];
        unset($_SESSION['manual_success_data']); // Idempotence session

        if (!isset($metadata['user_id']) || (int)$metadata['user_id'] !== (int)($_SESSION['user_id'] ?? 0)) {
            throw new Exception("Erreur de sécurité : incohérence d'utilisateur.");
        }

        $paymentMethod  = htmlspecialchars($metadata['payment_method_label'] ?? "Opération manuelle");
        $userIdForEmail = (int)$metadata['user_id'];
        $result = null;

        // Renouvellement vs Nouvel achat
        $isRenewal = !empty($metadata['original_contract_id']) && (int)$metadata['original_contract_id'] > 0;

        if ($isRenewal) {
            $result = fulfillRenewal($pdo, $metadata);
        } else {
            $manual_payment_id = 'manual_' . bin2hex(random_bytes(16));
            $result = fulfillNewPurchase($pdo, $metadata, $manual_payment_id);
            if (isset($result['commande_id'])) {
                $orderId = (int)$result['commande_id'];
            }
        }

        if ($result['status'] === 'success') {
            $isError = false;
            $message = $result['message'];
            $createdContracts = enrichContractDetails($pdo, $result['contrats']);
        } elseif ($result['status'] === 'already_done') {
            throw new Exception($result['message'], 100);
        } else {
            throw new Exception($result['message'] ?? "Erreur lors du traitement manuel.");
        }

    } else {
        // -----------------------------------------
        // Flux Stripe (inclut Google Pay / Apple Pay)
        // -----------------------------------------
        if (!$stripeReady) {
            throw new Exception('Connexion au service de paiement (Stripe) non configurée côté serveur.');
        }

        $sid = trim((string)$session_id);
        if ($sid === '' || !preg_match('~^cs_(live|test)_[A-Za-z0-9_\-]+$~', $sid)) {
            throw new Exception('Référence de session de paiement invalide.');
        }

        // Idempotence (déjà traitée ?)
        $stmt_check_cmd = $pdo->prepare("SELECT id FROM commandes WHERE stripe_session_id = ? LIMIT 1");
        $stmt_check_cmd->execute([$sid]);
        if ($stmt_check_cmd->fetchColumn()) {
            throw new Exception("Opération déjà traitée (commande trouvée).", 100);
        }

        $session = \Stripe\Checkout\Session::retrieve($sid);
        $metadata = !empty($session->metadata) ? $session->metadata->toArray() : [];
        $metadata['__stripe_session_id'] = $sid;
        $paymentMethod = "Carte Bancaire (via Stripe)";

        // --- Vérif utilisateur tolérante aux wallets (Google Pay / Apple Pay) ---
        $metaUserId    = (int)($metadata['user_id'] ?? 0);
        $sessionUserId = (int)($_SESSION['user_id'] ?? 0);

        if (!$metaUserId) {
            throw new Exception("Session de paiement Stripe sans user_id (metadata).");
        }

        // Si session présente et différente, vérifie l'email Stripe vs DB
        if ($sessionUserId && $metaUserId !== $sessionUserId) {
            $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
            $stmt->execute([$metaUserId]);
            $emailDb = strtolower(trim($stmt->fetchColumn() ?: ''));
            $emailStripe = strtolower(trim((string)($session->customer_details->email ?? '')));

            if ($emailDb && $emailStripe && $emailDb !== $emailStripe) {
                throw new Exception("Erreur de sécurité : utilisateur différent (email mismatch).");
            }
        }

        // À partir d'ici, on se base sur Stripe/metadata
        $userIdForEmail = $metaUserId;

        $paid = ($session->payment_status ?? '') === 'paid';
        if (!$paid) {
            $message = "Votre paiement est en attente ou a échoué.";
        } else {
            // Auto-cancel 12x si subscription
            if ($session->mode === 'subscription' && !empty($session->subscription)) {
                $subscriptionId = is_string($session->subscription) ? $session->subscription : $session->subscription->id;
                scheduleAutoCancelFor12x($subscriptionId, 'Europe/Paris');
            }

            $result = null;
            $isRenewal = !empty($metadata['original_contract_id']) && (int)$metadata['original_contract_id'] > 0;

            if ($isRenewal) {
                $result = fulfillRenewal($pdo, $metadata);
            } else {
                $result = fulfillNewPurchase($pdo, $metadata, $sid);
                if (isset($result['commande_id'])) {
                    $orderId = (int)$result['commande_id'];
                }
            }

            if ($result['status'] === 'success') {
                $isError = false;
                $message = $result['message'];
                $createdContracts = enrichContractDetails($pdo, $result['contrats']);
            } elseif ($result['status'] === 'already_done') {
                throw new Exception($result['message'], 100);
            } else {
                throw new Exception($result['message']);
            }
        }
    }

    // Envoi de l'email de confirmation si OK
    if ($userIdForEmail && !$isError && !$isAlreadyDone) {
        $stmt = $pdo->prepare("SELECT prenom, email FROM users WHERE id = ?");
        $stmt->execute([$userIdForEmail]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $clientName  = $user['prenom'];
            $clientEmail = $user['email'];
            $pageTitle   = "Merci, " . htmlspecialchars($clientName) . " !";

            $emailSubject = "Confirmation de votre opération Mon Plant Fraise";
            $emailBody = generateEmailBody($clientName, $paymentMethod, $createdContracts, $orderId);

            sendConfirmationEmail($user['email'], $clientName, $emailSubject, $emailBody);
        }
    }

} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log("Erreur API Stripe success.php : " . $e->getMessage());
    $message = "Une erreur est survenue lors de la vérification de votre paiement (Stripe API Error). L'équipe a été notifiée.";
    $isError = true;

} catch (Throwable $e) {
    if ((int)$e->getCode() === 100) { // déjà traité
        $message = "Votre opération a déjà été validée avec succès. Vous pouvez retourner à votre espace client.";
        $isError = false;
        $isAlreadyDone = true;
        $pageTitle = "Opération déjà validée";
    } else {
        error_log("Erreur critique success.php : " . $e->getMessage() . " @".$e->getFile().":".$e->getLine());
        $message = "Une erreur technique est survenue. Notre équipe a été notifiée. Veuillez contacter le support si le problème persiste.";
        $isError = true;
        $pageTitle = "Erreur";

        if (ini_get('display_errors')) {
            echo "<h1>Erreur Fatale (success.php) :</h1>";
            echo "<p><strong>Message:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
            echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
            die();
        }
    }
}

// Point de sortie générique (et en cas d'erreur BDD plus haut)
display_page:

// Nettoyage final
unset($_SESSION['manual_success_data']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            margin: 0;
            padding: 30px;
            box-sizing: border-box;
        }
        .container {
            background-color: white;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
            text-align: center;
            max-width: 700px;
            width: 100%;
        }
        .success h1 { color: #2ecc71; }
        .error h1 { color: #e74c3c; }
        .already-done h1 { color: #3498db; }
        h1 { font-size: 2.2em; margin-bottom: 15px; }
        p { font-size: 1.1em; color: #555; line-height: 1.6; }
        .button {
            display: inline-block;
            margin-top: 25px;
            padding: 14px 28px;
            background-color: #34495e;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.2s, transform 0.2s;
        }
        .button:hover {
            background-color: #2c3e50;
            transform: translateY(-2px);
        }
        .timeline {
            list-style: none;
            padding: 0;
            margin: 30px 0;
            display: flex;
            justify-content: space-between;
            text-align: left;
        }
        .timeline li {
            flex-basis: 30%;
            position: relative;
            padding-left: 30px;
        }
        .timeline li::before {
            content: '✓';
            display: block;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #2ecc71;
            color: white;
            text-align: center;
            line-height: 20px;
            font-weight: bold;
            position: absolute;
            left: 0;
            top: 0;
        }
        .timeline li strong { display: block; color: #333; }
        .timeline li span { font-size: 0.9em; color: #777; }
        .summary {
            text-align: left;
            margin-top: 30px;
            border-top: 1px solid #eee;
            padding-top: 25px;
        }
        .summary h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #34495e;
        }
        .contract-card {
            background: #fdfdfd;
            border: 1px solid #eaeaea;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 15px;
        }
        .contract-card strong {
            color: #333;
            display: inline-block;
            min-width: 150px;
        }
        .payment-info {
            font-size: 1.1em;
            background: #f4f7f6;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="<?php if (!empty($isError)) echo 'error'; elseif (!empty($isAlreadyDone)) echo 'already-done'; else echo 'success'; ?>">

    <div class="container">

        <?php if (!empty($isError)): ?>
            <h1>Oups ! Une erreur est survenue</h1>
            <p><?php echo htmlspecialchars($message ?? ''); ?></p>

        <?php elseif (!empty($isAlreadyDone)): ?>
            <h1>Opération déjà validée</h1>
            <p><?php echo htmlspecialchars($message ?? ''); ?></p>

        <?php else: // Cas de succès ! ?>
            <h1>✅ Merci, <?php echo htmlspecialchars($clientName ?: 'Client'); ?> !</h1>
            <p>Votre opération a été validée avec succès.</p>

            <div class="summary">

                <div class="payment-info">
                    <strong>Mode de paiement :</strong> <?php echo htmlspecialchars($paymentMethod); ?><br>
                    <?php if ($orderId): ?>
                        <strong>Commande N° :</strong> #<?php echo $orderId; ?>
                    <?php endif; ?>
                </div>

                <h2>Récapitulatif de l'opération</h2>

                <?php if (empty($createdContracts)): ?>
                    <p style="text-align: center;">
                        <?php echo htmlspecialchars($message); ?>
                        (Ex: Retrait total effectué, aucun nouveau contrat créé).
                    </p>
                <?php else: ?>
                    <p style="text-align: center; margin-bottom: 20px;">
                        Nous confirmons la mise en place du/des contrat(s) suivant(s) :
                    </p>
                    <?php foreach ($createdContracts as $contract): ?>
                        <div class="contract-card">
                            <div><strong>Produit :</strong> <?php echo htmlspecialchars($contract['produit_nom']); ?> (<?php echo htmlspecialchars($contract['plant_type']); ?>)</div>
                            <div><strong><?php echo htmlspecialchars($contract['montant_label']); ?> :</strong> <?php echo number_format($contract['montant_investi'], 2, ',', ' '); ?> €</div>
                            <div><strong>Formule :</strong> <?php echo htmlspecialchars($contract['type_paiement_label']); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <hr style="border: 0; border-top: 1px solid #eee; margin: 30px 0;">

                <h2>Prochaines étapes</h2>
                <ul class="timeline">
                    <li>
                        <strong>Paiement validé</strong>
                        <span>C'est fait !</span>
                    </li>
                    <li>
                        <strong>Contrat généré</strong>
                        <span>En cours (24h max)</span>
                    </li>
                    <li>
                        <strong>Accès Dashboard</strong>
                        <span>Suivez vos plants !</span>
                    </li>
                </ul>

                <p style="margin-top: 20px; font-size: 1em; color: #777;">
                    <?php if (!empty($clientEmail)): ?>
                        Un email de confirmation vient de vous être envoyé à
                        <strong><?php echo htmlspecialchars($clientEmail); ?></strong>.
                    <?php else: ?>
                        Un email de confirmation sera envoyé (dès que l'adresse email sera vérifiée).
                    <?php endif; ?>
                    Vous retrouverez tous vos documents dans votre espace client.
                </p>

            </div>

        <?php endif; ?>

        <a href="/espace-client.php" class="button">Retourner à mon espace client</a>
    </div>

</body>
</html>
