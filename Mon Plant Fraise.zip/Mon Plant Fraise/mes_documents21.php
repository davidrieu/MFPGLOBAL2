<?php
// mes_documents.php — Espace client > Mes documents (design harmonisé + liens OK depuis file_path "./...")

// 1) Session & auth
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// (Débogage à retirer en prod)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2) Dépendances
require_once __DIR__ . '/db_connection.php';
if (file_exists(__DIR__ . '/badge_sentinel.php')) {
    require_once __DIR__ . '/badge_sentinel.php';
}

// 3) Helpers
/**
 * Normalise la catégorie (tolère casse/pluriels/typos courantes)
 */
function normalize_cat($raw) {
    $s = trim((string)$raw);
    $k = mb_strtolower($s, 'UTF-8');
    if (in_array($k, ['contrat','contrats','contract','contracts'], true)) return 'Contrats';
    if (in_array($k, ["pièce d'identité","pièces d'identité","piece d'identite","pieces d'identite","id","identité","identite"], true)) return "Pièces d'identité";
    return 'Autres';
}

/**
 * Transforme un file_path BDD en URL publique.
 * Exemples:
 *   "./documents/recus/a.pdf"  -> "/documents/recus/a.pdf"
 *   "/documents/contrats/a.pdf"-> "/documents/contrats/a.pdf"
 *   "documents/autre/a.pdf"    -> "/documents/autre/a.pdf"
 */
function public_url_from_file_path(?string $fp): string {
    $fp = trim((string)$fp);
    if ($fp === '') return '#';
    if (strpos($fp, './') === 0) {
        return '/' . ltrim(substr($fp, 2), '/');
    }
    if ($fp[0] !== '/') {
        return '/' . ltrim($fp, '/');
    }
    return $fp;
}

// 4) Récupération des documents du client
$user_id = (int) $_SESSION['user_id'];
try {
    $stmt = $pdo->prepare("
        SELECT id, filename, file_path, category, upload_date
        FROM documents
        WHERE user_id = ?
        ORDER BY upload_date DESC, id DESC
    ");
    $stmt->execute([$user_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('mes_documents.php SELECT error: ' . $e->getMessage());
    die('Erreur lors du chargement de vos documents.');
}

// 5) Groupement et préparation des données d’affichage
$groups = ['Contrats' => [], "Pièces d'identité" => [], 'Autres' => []];

foreach ($rows as $r) {
    $cat = normalize_cat($r['category'] ?? '');
    $groups[$cat][] = [
        'id'   => (int)($r['id'] ?? 0),
        'nom'  => $r['filename'] ?: 'Document',
        'date' => !empty($r['upload_date']) ? date('d/m/Y H:i', strtotime($r['upload_date'])) : '',
        'url'  => public_url_from_file_path($r['file_path'] ?? ''), // ← on utilise la colonne file_path telle que stockée
    ];
}

$counts = [
    'Contrats' => count($groups['Contrats']),
    "Pièces d'identité" => count($groups["Pièces d'identité"]),
    'Autres' => count($groups['Autres']),
];

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Documents - Mon Plant Fraise</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonts / Icônes -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0"/>

    <style>
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --primary-color: #2E7D32;
            --primary-color-dark: #1B5E20;
            --primary-color-light: #C8E6C9;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --secondary-color: #8BC34A;

            --text-color: #212121;
            --text-color-light: #757575;
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;

            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            --bd: #eee;
        }

        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }

        /* Sidebar (même design que ta page de référence) */
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0;
                   box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; transition: transform 0.3s ease-in-out; }
        .sidebar-header { margin-bottom: 30px; text-align: center; }
        .sidebar-header a img { max-width: 80%; height: auto; }
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light);
                           border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover { background-color: #eeeeee; }
        .sidebar ul li a.active { background-color: var(--primary-color); color: white; }

        /* Conteneur */
        .container { margin-left: 260px; padding: 30px; width: calc(100% - 260px); }

        /* En-tête de page */
        .page-header { display:flex; align-items:center; justify-content:space-between; gap:16px; margin-bottom: 20px; }
        .page-title { font-family: 'Poppins', sans-serif; font-size: 28px; font-weight: 700; margin: 0; }
        .subtitle { color: var(--text-color-light); margin: 4px 0 0; }

        /* Barre d’actions */
        .actions-bar { display:flex; align-items:center; gap:16px; flex-wrap:wrap; margin-bottom: 20px; }
        .search { flex:1; min-width: 240px; }
        .search input { width: 100%; padding: 12px 14px; border: 1px solid var(--bd); border-radius: 10px; background:#fff; }

        /* Onglets style “chips” */
        .tabs { display:flex; gap:10px; flex-wrap:wrap; }
        .tab { border:1px solid var(--bd); padding:8px 14px; border-radius: 999px; background:#fff; cursor:pointer; font-weight:600; }
        .tab.active { background: var(--primary-color); color:#fff; border-color:var(--primary-color); }
        .tab .badge { margin-left:8px; padding:0 8px; border-radius:999px; background:rgba(255,255,255,.15); border:1px solid rgba(255,255,255,.35) }

        /* Liste des documents */
        .doc-list { display: grid; gap: 16px; grid-template-columns: 1fr; }
        .card { background-color: var(--card-background-color); padding: 20px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); border: 1px solid var(--bd);
                display:flex; align-items:center; justify-content:space-between; gap:16px; transition: transform .2s ease, box-shadow .2s ease; }
        .card:hover { transform: translateY(-3px); box-shadow: 0 8px 16px rgba(0,0,0,0.08); }

        .doc-info { display:flex; align-items:center; gap:16px; }
        .doc-icon { font-size: 34px; color: var(--primary-color); background-color: var(--primary-color-light); padding: 10px; border-radius: 50%; }
        .doc-meta h3 { margin:0 0 4px; font-size: 16px; font-weight: 600; }
        .doc-meta .muted { color: var(--text-color-light); font-size: 14px; }

        .btn-primary { background: var(--primary-gradient); color: white; padding: 10px 18px; border: none; border-radius: var(--border-radius); cursor: pointer;
                       font-size: 14px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap:8px; transition: all 0.2s ease; }
        .btn-primary:hover { box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4); transform: translateY(-2px); }

        .empty { text-align:center; color: var(--text-color-light); padding: 28px; background:#fff; border:1px solid var(--bd); border-radius: var(--border-radius); }

        /* Responsive + bouton burger */
        .toggle-btn { display: none; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .container { margin-left: 0; padding: 15px; width: 100%; }
            .toggle-btn { display: block; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%;
                          width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size: 24px; display: flex; align-items: center; justify-content: center; }
            .page-title { margin-top: 60px; font-size: 24px; }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="document.querySelector('.sidebar').classList.toggle('open')">☰</button>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php" class="active"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<!-- Contenu -->
<div class="container">
    <!-- En-tête -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Mes documents</h1>
            <p class="subtitle">Retrouvez vos contrats, pièces et justificatifs au même endroit.</p>
        </div>
    </div>

    <!-- Actions : recherche + onglets -->
    <div class="actions-bar">
        <div class="search">
            <input id="q" placeholder="Rechercher un document (nom, date)…">
        </div>
        <div class="tabs" id="tabs">
            <button class="tab active" data-tab="Contrats">Contrats<span class="badge"><?= $counts['Contrats'] ?></span></button>
            <button class="tab" data-tab="Pièces d'identité">Pièces d'identité<span class="badge"><?= $counts["Pièces d'identité"] ?></span></button>
            <button class="tab" data-tab="Autres">Autres<span class="badge"><?= $counts['Autres'] ?></span></button>
        </div>
    </div>

    <!-- Panneaux par catégorie -->
    <?php foreach (['Contrats',"Pièces d'identité",'Autres'] as $label): ?>
        <div class="tab-panel" id="panel-<?= htmlspecialchars($label) ?>" style="<?= $label==='Contrats'?'':'display:none' ?>">
            <?php if (empty($groups[$label])): ?>
                <div class="empty">Aucun document dans « <?= htmlspecialchars($label) ?> ».</div>
            <?php else: ?>
                <div class="doc-list">
                    <?php foreach ($groups[$label] as $d): ?>
                        <div class="card">
                            <div class="doc-info">
                                <span class="material-symbols-outlined doc-icon">description</span>
                                <div class="doc-meta">
                                    <h3><?= htmlspecialchars($d['nom']) ?></h3>
                                    <div class="muted">Ajouté le <?= htmlspecialchars($d['date']) ?></div>
                                </div>
                            </div>
                            <a class="btn-primary" href="<?= htmlspecialchars($d['url']) ?>" target="_blank" rel="noopener">
                                <span class="material-symbols-outlined">download</span>
                                Télécharger
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<script>
    // Gestion des onglets
    const tabs = document.querySelectorAll('.tab');
    const q = document.getElementById('q');

    function showTab(name){
        document.querySelectorAll('.tab-panel').forEach(p=>p.style.display='none');
        const active = document.getElementById('panel-'+name);
        if(active) active.style.display = '';
        tabs.forEach(t=>t.classList.toggle('active', t.dataset.tab===name));
        q.value=''; filterCards('');
    }
    tabs.forEach(t=> t.addEventListener('click', ()=> showTab(t.dataset.tab)));

    // Filtre côté client
    function filterCards(term){
        const activeTab = document.querySelector('.tab.active')?.dataset.tab;
        if(!activeTab) return;
        const panel = document.getElementById('panel-'+activeTab);
        const cards = panel?.querySelectorAll('.card') || [];
        const needle = (term||'').toLowerCase();
        cards.forEach(c => {
            const txt = c.innerText.toLowerCase();
            c.style.display = txt.includes(needle) ? '' : 'none';
        });
    }
    q.addEventListener('input', e => filterCards(e.target.value));
</script>

</body>
</html>

