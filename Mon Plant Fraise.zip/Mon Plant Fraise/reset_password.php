<?php
// reset_password.php — version universelle (token -> user ; fallback email+token)
require_once 'db_connection.php';

$error_message   = '';
$success_message = '';
$token_is_valid  = false;
$user_id         = null;
$user_email      = null;

// --- util ---
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Récupération robuste du token (GET ou POST)
function get_token_from_request(): string {
    $token = '';
    if (isset($_GET['token'])) $token = (string)$_GET['token'];
    elseif (isset($_GET['t'])) $token = (string)$_GET['t'];
    elseif (isset($_POST['token'])) $token = (string)$_POST['token'];
    elseif (!empty($_SERVER['QUERY_STRING']) && preg_match('/(?:^|[?&])token=([^&]+)/', $_SERVER['QUERY_STRING'], $m)) $token = (string)$m[1];
    return trim($token);
}

$token = get_token_from_request();

// ---------------------------------------------------------
// 1) TENTER de résoudre l'utilisateur par le token (GET)
// ---------------------------------------------------------
if ($token !== '') {
    try {
        $sql = "SELECT id, email, reset_token_expires_at
                FROM users
                WHERE reset_token = :token
                LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':token' => $token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $now     = new DateTime();
            $expires = !empty($user['reset_token_expires_at']) ? new DateTime($user['reset_token_expires_at']) : null;

            if ($expires && $now < $expires) {
                $token_is_valid = true;
                $user_id    = (int)$user['id'];
                $user_email = (string)$user['email']; // pour affichage (readonly)
            } else {
                $error_message = 'Le jeton est invalide ou a expiré. Veuillez refaire une demande.';
            }
        } else {
            // Pas trouvé par token : on n’affiche pas d’erreur bloquante,
            // on proposera le fallback (email + token en formulaire).
        }
    } catch (Throwable $e) {
        $error_message = 'Une erreur est survenue.';
    }
}

// ---------------------------------------------------------
// 2) Traitement POST (mise à jour du mot de passe)
//    Deux modes supportés :
//    A) token seul (quand user_id déjà résolu ci-dessus)
//    B) email + token (fallback quand token non résolu en GET)
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password         = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $posted_email     = trim((string)($_POST['email'] ?? ''));

    // Si on n’a pas résolu le token en GET, on tente en POST avec email + token
    if (!$token_is_valid || $user_id === null) {
        if ($token === '' || $posted_email === '') {
            $error_message = 'Veuillez renseigner votre e-mail et le jeton.';
        } else {
            try {
                $sql = "SELECT id, reset_token_expires_at
                        FROM users
                        WHERE reset_token = :token
                          AND LOWER(email) = LOWER(:email)
                        LIMIT 1";
                $st = $pdo->prepare($sql);
                $st->execute([':token' => $token, ':email' => $posted_email]);
                $u = $st->fetch(PDO::FETCH_ASSOC);

                if ($u) {
                    $now     = new DateTime();
                    $expires = !empty($u['reset_token_expires_at']) ? new DateTime($u['reset_token_expires_at']) : null;

                    if ($expires && $now < $expires) {
                        $token_is_valid = true;
                        $user_id    = (int)$u['id'];
                        $user_email = $posted_email; // pour affichage
                    } else {
                        $error_message = 'Le jeton est invalide ou a expiré. Veuillez refaire une demande.';
                    }
                } else {
                    $error_message = 'Jeton et e-mail ne correspondent pas.';
                }
            } catch (Throwable $e) {
                $error_message = 'Une erreur est survenue.';
            }
        }
    }

    // Si on a bien un user résolu par token (mode A ou B), on peut changer le mot de passe
    if ($token_is_valid && $user_id !== null && empty($error_message)) {
        if ($password !== $password_confirm) {
            $error_message = 'Les mots de passe ne correspondent pas.';
        } elseif (strlen($password) < 8) {
            $error_message = 'Le mot de passe doit faire au moins 8 caractères.';
        } else {
            try {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $sqlu = "UPDATE users
                         SET password = :pwd,
                             reset_token = NULL,
                             reset_token_expires_at = NULL
                         WHERE id = :id
                         LIMIT 1";
                $stu = $pdo->prepare($sqlu);
                $stu->execute([':pwd' => $hashed, ':id' => $user_id]);

                if ($stu->rowCount() > 0) {
                    $success_message = 'Votre mot de passe a été mis à jour ! Vous pouvez maintenant vous connecter.';
                    // Après succès, on invalide l’état pour masquer le formulaire
                    $token_is_valid = false;
                } else {
                    $error_message = 'Mise à jour impossible. Veuillez regénérer un lien.';
                }
            } catch (Throwable $e) {
                $error_message = 'Une erreur est survenue lors de la mise à jour du mot de passe.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réinitialiser le mot de passe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Roboto', system-ui, -apple-system, Segoe UI, Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex; justify-content: center; align-items: center;
            min-height: 100vh; margin: 0; padding: 16px;
        }
        .login-container {
            background-color: #fff; padding: 32px; border-radius: 10px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
            width: 100%; max-width: 460px; text-align: center;
        }
        .login-container h2 { margin: 0 0 18px; color: #222; font-size: 24px; }
        .subtitle { color: #666; font-size: 14px; margin-bottom: 18px; }
        .form-group { margin-bottom: 16px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; color: #444; font-weight: 600; font-size: 14px; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;
            box-sizing: border-box; font-size: 16px;
        }
        .btn-submit {
            width: 100%; padding: 14px; background-color: #4CAF50; color: white;
            border: none; border-radius: 8px; font-size: 16px; font-weight: 700; cursor: pointer;
            transition: transform .05s ease-in-out, box-shadow .2s;
            box-shadow: 0 8px 16px rgba(76,175,80,.18);
        }
        .btn-submit:hover { transform: translateY(-1px); box-shadow: 0 10px 18px rgba(76,175,80,.22); }
        .btn-link {
            display: inline-block; margin-top: 12px; text-decoration: none;
            color: #1a73e8; font-weight: 600;
        }
        .message {
            padding: 12px; border-radius: 8px; margin-bottom: 18px; border: 1px solid; text-align: left; font-size: 14px;
        }
        .message.success { background-color: #e8f5e9; color: #2e7d32; border-color: #2e7d32; }
        .message.error   { background-color: #ffebee; color: #c62828; border-color: #c62828; }
        .hint { font-size: 12px; color: #777; margin-top: 6px; }
        .readonly { background: #f8f8f8; color: #777; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Nouveau mot de passe</h2>
        <p class="subtitle">
            <?php if ($token_is_valid && $user_email): ?>
                Jeton validé pour <strong><?= h($user_email) ?></strong>.
            <?php else: ?>
                Renseignez votre e-mail, le jeton et votre nouveau mot de passe.
            <?php endif; ?>
        </p>

        <?php if (!empty($error_message)): ?>
            <div class="message error"><?= h($error_message) ?></div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="message success"><?= h($success_message) ?></div>
            <a href="login.php" class="btn-submit" style="text-decoration:none; display:block; text-align:center;">Se connecter</a>
        <?php endif; ?>

        <?php if (empty($success_message)): ?>
            <form action="" method="post" autocomplete="off">
                <!-- Token toujours soumis (depuis GET ou saisi manuellement) -->
                <input type="hidden" name="token" value="<?= h($token) ?>">

                <?php if ($token_is_valid && $user_email): ?>
                    <!-- Mode 1 : token a permis d’identifier l’utilisateur -->
                    <div class="form-group">
                        <label for="email">Adresse e-mail</label>
                        <input class="readonly" type="email" id="email" name="email" value="<?= h($user_email) ?>" readonly>
                        <div class="hint">Email détecté automatiquement via le lien sécurisé.</div>
                    </div>
                <?php else: ?>
                    <!-- Mode 2 (fallback) : on demande email + token -->
                    <div class="form-group">
                        <label for="email">Adresse e-mail</label>
                        <input type="email" id="email" name="email" required placeholder="votre@email.com" value="<?= h($_POST['email'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="token_field">Jeton (coller depuis l’email)</label>
                        <input type="text" id="token_field" name="token" required value="<?= h($token) ?>" placeholder="ex. 8f3a...">
                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="password">Nouveau mot de passe</label>
                    <input type="password" name="password" id="password" required minlength="8" placeholder="Au moins 8 caractères">
                    <div class="hint">Astuce : utilisez une phrase de passe (ex. 3–4 mots) pour plus de sécurité.</div>
                </div>
                <div class="form-group">
                    <label for="password_confirm">Confirmer le mot de passe</label>
                    <input type="password" name="password_confirm" id="password_confirm" required minlength="8" placeholder="Retapez le mot de passe">
                </div>
                <button type="submit" class="btn-submit">Mettre à jour</button>
            </form>
        <?php endif; ?>

        <?php if (!$token_is_valid && empty($success_message)): ?>
            <a class="btn-link" href="demande_reset.php">Demander un nouveau lien</a>
            &nbsp;•&nbsp;
            <a class="btn-link" href="login.php">Retour à la connexion</a>
        <?php endif; ?>
    </div>
</body>
</html>


