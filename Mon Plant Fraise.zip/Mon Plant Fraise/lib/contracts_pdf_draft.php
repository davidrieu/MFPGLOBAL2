<?php
/**
 * lib/contracts_pdf_draft.php
 * Génération PDF Contrats (brouillon + final) via Dompdf
 * - Gère paiement unique vs abonnement (12x) et tableau des mensualités
 * - Utilise les infos user (adresse, téléphone, email)
 * - Si profil incomplet : remonte les champs manquants, permet forcer ou relancer par email
 */

declare(strict_types=1);

/* ============================================================
 * 0) Contexte & Utils
 * ============================================================ */

if (!defined('UPLOAD_CONTRACTS_DIR')) {
    define('UPLOAD_CONTRACTS_DIR', realpath(__DIR__ . '/..') . '/documents/contrats/');
}
if (!is_dir(UPLOAD_CONTRACTS_DIR)) { @mkdir(UPLOAD_CONTRACTS_DIR, 0775, true); }

function _h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function _money(float $v): string { return number_format($v, 2, ',', ' ') . ' €'; }
function _percent($v): string {
    if ($v === null || $v === '') return '—';
    $n = (float)$v;
    $n = ($n <= 1.0) ? ($n * 100.0) : $n; // 0.4 -> 40%
    $n = round($n, 2);
    $txt = (abs($n - (int)$n) < 0.005) ? (string)(int)$n : number_format($n, 2, ',', ' ');
    return $txt . ' %';
}

/* ============================================================
 * 1) Chargement Dompdf (via vendor_mpf)
 * ============================================================ */
(function(){
    $base = realpath(__DIR__ . '/..') ?: __DIR__;
    $autoload = $base . '/vendor_mpf/autoload.php';
    if (!is_file($autoload)) {
        throw new RuntimeException("Autoload Composer introuvable : {$autoload} (attendu dans /vendor_mpf/).");
    }
    require_once $autoload;
    if (!class_exists(\Dompdf\Options::class) || !class_exists(\Dompdf\Dompdf::class)) {
        throw new RuntimeException("Dompdf non chargé via vendor_mpf.");
    }
})();

/* ============================================================
 * 2) Helpers BDD & Data
 * ============================================================ */

function load_contract_with_user(PDO $pdo, int $contract_id): array {
    $sql = "
        SELECT k.*,
               u.prenom,
               u.name  AS user_nom,
               u.email AS user_email,
               u.telephone AS user_telephone,
               u.adresse   AS user_adresse
        FROM contrats k
        JOIN users u ON u.id = k.user_id
        WHERE k.id = ?
        LIMIT 1
    ";
    $st = $pdo->prepare($sql);
    $st->execute([$contract_id]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new InvalidArgumentException("Contrat #{$contract_id} introuvable.");
    return $row;
}

/** Retourne le nom du produit (table produits) depuis contrats.produit_id */
function fetch_product_name(PDO $pdo, ?int $produit_id): ?string {
    if (empty($produit_id) || $produit_id <= 0) return null;
    try {
        $st = $pdo->prepare("SELECT name FROM produits WHERE id = ? LIMIT 1");
        $st->execute([$produit_id]);
        $name = $st->fetchColumn();
        return $name ? (string)$name : null;
    } catch (Throwable $e) {
        return null;
    }
}

/** Items produits du contrat (table contrat_items : product_name, quantity, unit_price) */
function fetch_contract_items(PDO $pdo, int $contract_id): array {
    try {
        $st = $pdo->prepare("
            SELECT product_name, quantity, unit_price
            FROM contrat_items
            WHERE contract_id = ?
            ORDER BY id ASC
        ");
        $st->execute([$contract_id]);
        $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $items = [];
    }
    $norm = [];
    foreach ($items as $r) {
        $qty  = max(1, (int)($r['quantity'] ?? 1));
        $unit = (float)($r['unit_price'] ?? 0);
        $name = trim((string)($r['product_name'] ?? 'Produit'));
        $norm[] = [
            'product_name' => $name ?: 'Produit',
            'quantity'     => $qty,
            'unit_price'   => $unit,
            'line_total'   => round($qty * $unit, 2),
        ];
    }
    return $norm;
}

/** Document de contrat le plus récent (catégorie Contrats) */
function fetch_doc_by_contract(PDO $pdo, int $contract_id): ?array {
    $st = $pdo->prepare("
        SELECT *
        FROM documents
        WHERE contract_id = ?
          AND LOWER(category) IN ('contrat','contrats','contract','contracts')
        ORDER BY id DESC
        LIMIT 1
    ");
    $st->execute([$contract_id]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

/* ============================================================
 * 3) Paiement & Produits
 * ============================================================ */

function resolve_payment_type(array $k): string {
    $raw = strtolower(trim((string)($k['type_paiement'] ?? $k['payment_type'] ?? '')));
    if (in_array($raw, ['abonnement','subscription','mensuel','mensuelle','12x','monthly','mensualite','mensualites'], true)) {
        return 'monthly';
    }
    if (in_array($raw, ['paiement_unique','one_time','comptant','full','payment'], true)) {
        return 'one_time';
    }
    if (isset($k['mensualites_payees']) && (int)$k['mensualites_payees'] > 0) {
        return 'monthly';
    }
    return 'one_time';
}

function payment_summary_fr(string $type, float $total, ?float $monthly, ?DateTimeInterface $firstDue): string {
    if ($type === 'one_time') {
        $d = $firstDue ? $firstDue->format('d/m/Y') : date('d/m/Y');
        return "Paiement unique de " . _money($total) . " le " . $d;
    }
    $m = $monthly !== null && $monthly > 0 ? _money($monthly) : _money(round($total / 12, 2));
    return "Paiement en 12 mensualités de {$m} (total " . _money($total) . ")";
}

function build_monthly_rows(float $total, ?float $monthlyAmount, ?DateTimeInterface $firstDue): array {
    $n = 12;
    $start = $firstDue ?: new DateTime();
    $monthly = $monthlyAmount && $monthlyAmount > 0 ? round($monthlyAmount, 2) : round($total / $n, 2);

    $rows = [];
    $sum = 0.0;
    for ($i = 0; $i < $n; $i++) {
        $date = (clone $start)->modify("+{$i} month");
        $amount = ($i < $n - 1) ? $monthly : round($total - $sum, 2);
        $sum = round($sum + $amount, 2);
        $rows[] = [
            'label'  => sprintf('Mensualité %02d/%02d', $i + 1, $n),
            'date'   => $date->format('d/m/Y'),
            'amount' => $amount,
        ];
    }
    return $rows;
}

function build_products_table_html(array $items, float $computedTotal, ?string $productNameFallback): string {
    $rows = '';
    if ($items) {
        foreach ($items as $r) {
            $rows .= '<tr>'.
                     '<td>'. _h($r['product_name']) .'</td>'.
                     '<td style="text-align:center">'. (int)$r['quantity'] .'</td>'.
                     '<td style="text-align:right">'. _money((float)$r['unit_price']) .'</td>'.
                     '<td style="text-align:right">'. _money((float)$r['line_total']) .'</td>'.
                     '</tr>';
        }
    } else {
        $label = $productNameFallback ?: 'Produit';
        $rows .= '<tr>'.
                 '<td>'. _h($label) .'</td>'.
                 '<td style="text-align:center">1</td>'.
                 '<td style="text-align:right">'. _money($computedTotal) .'</td>'.
                 '<td style="text-align:right">'. _money($computedTotal) .'</td>'.
                 '</tr>';
    }

    $html = <<<HTML
<div class="section">Produits / prestations</div>
<table style="width:100%; border-collapse:collapse;">
  <thead>
    <tr>
      <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:left;">Désignation</th>
      <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:center;">Qté</th>
      <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:right;">PU</th>
      <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:right;">Total</th>
    </tr>
  </thead>
  <tbody>
    {$rows}
    <tr>
      <td colspan="3" style="padding:6px; text-align:right; font-weight:900;">TOTAL</td>
      <td style="padding:6px; text-align:right; font-weight:900;">{_TOTAL_}</td>
    </tr>
  </tbody>
</table>
HTML;
    return str_replace('{_TOTAL_}', _money($computedTotal), $html);
}

function build_payment_table_html(string $type, float $total, ?float $monthly, ?DateTimeInterface $firstDue): array {
    if ($type === 'one_time') {
        $d = $firstDue ? $firstDue->format('d/m/Y') : date('d/m/Y');
        $rows = '<tr><td>Paiement unique</td><td style="text-align:center">'. _h($d) .'</td><td style="text-align:right">'. _money($total) .'</td></tr>';
        $summary = payment_summary_fr($type, $total, null, $firstDue);
        $html = <<<HTML
<div class="section">Modalités de paiement</div>
<div class="box small muted" style="margin-bottom:6px;">{$summary}</div>
<table style="width:100%; border-collapse:collapse;">
  <thead><tr>
    <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:left;">Échéance</th>
    <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:center;">Date</th>
    <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:right;">Montant</th>
  </tr></thead>
  <tbody>
    {$rows}
  </tbody>
</table>
HTML;
        return [$summary, $html, null];
    }

    $rows = build_monthly_rows($total, $monthly, $firstDue);
    $summary = payment_summary_fr($type, $total, $monthly, $firstDue);
    $trs = '';
    foreach ($rows as $r) {
        $trs .= '<tr>'.
                '<td>'. _h($r['label']) .'</td>'.
                '<td style="text-align:center">'. _h($r['date']) .'</td>'.
                '<td style="text-align:right">'. _money((float)$r['amount']) .'</td>'.
                '</tr>';
    }
    $html = <<<HTML
<div class="section">Modalités de paiement</div>
<div class="box small muted" style="margin-bottom:6px;">{$summary}</div>
<table style="width:100%; border-collapse:collapse;">
  <thead><tr>
    <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:left;">Échéance</th>
    <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:center;">Date</th>
    <th style="border-bottom:1px solid #e5e7eb; padding:6px; text-align:right;">Montant</th>
  </tr></thead>
  <tbody>
    {$trs}
  </tbody>
</table>
HTML;

    $indic = $monthly ?: round($total / 12, 2);
    return [$summary, $html, $indic];
}

/* ============================================================
 * 4) Signatures
 * ============================================================ */

function build_admin_signature_img_tag(PDO $pdo, int $contract_id): string {
    $doc = fetch_doc_by_contract($pdo, $contract_id);
    $admin_id = (int)((is_array($doc) && isset($doc['admin_sign_admin_id'])) ? $doc['admin_sign_admin_id'] : 0);
    if ($admin_id <= 0) { $admin_id = 1; } // fallback

    $baseAbs = realpath(__DIR__ . '/..');
    $global  = $baseAbs . "/documents/signatures/admin-{$admin_id}.png";
    if (is_file($global)) {
        $raw = @file_get_contents($global);
        if ($raw !== false) {
            $b64 = base64_encode($raw);
            return '<img class="sigimg" style="height:100px" src="data:image/png;base64,'.$b64.'" alt="Signature admin">';
        }
    }
    return '<span class="sigpending">En attente de signature administrateur</span>';
}

function build_client_signature_img_tag(int $contract_id): string {
    $baseAbs = realpath(__DIR__ . '/..');
    $webRel  = "/documents/signatures/contract-{$contract_id}-client.png";
    $absPath = $baseAbs . $webRel;
    if (is_file($absPath)) {
        $raw = @file_get_contents($absPath);
        if ($raw !== false) {
            $b64 = base64_encode($raw);
            return '<img class="sigimg" style="height:100px" src="data:image/png;base64,'.$b64.'" alt="Signature client">';
        }
    }
    return '<span class="sigpending">En attente de signature du client</span>';
}

/* ============================================================
 * 5) Rendu HTML (produits, plan paiement, clauses)
 * ============================================================ */

function render_contract_html(PDO $pdo, int $contract_id, bool $isDraft): string {
    $tpl = realpath(__DIR__ . '/../templates/contrat_modele.html');
    if (!$tpl || !is_file($tpl)) {
        throw new RuntimeException("Modèle HTML introuvable: templates/contrat_modele.html");
    }
    $html = file_get_contents($tpl);

    $k   = load_contract_with_user($pdo, $contract_id);
    $doc = fetch_doc_by_contract($pdo, $contract_id);

    // PRODUITS
    $items = fetch_contract_items($pdo, $contract_id);
    $productNameFromId = fetch_product_name($pdo, isset($k['produit_id']) ? (int)$k['produit_id'] : null);

    // Montants DB
    $montantValue = (float)($k['montant'] ?? 0);      // valeur réelle (bonus inclus)
    $montantBase  = (float)($k['montant_base'] ?? 0); // prix payé total (sur 12 mois si abonnement)
    $apportRaw    = (float)($k['apport'] ?? 0);       // 1ère mensualité si abo, total sinon

    // Total affiché dans la table produits = valeur réelle du contrat
    $computedTotal = 0.0;
    foreach ($items as $r) $computedTotal = round($computedTotal + (float)$r['line_total'], 2);
    $total = $montantValue > 0 ? $montantValue : ($items ? $computedTotal : 0.0);

    // Paiement
    $type = resolve_payment_type($k);
    $firstDue = null;
    if (!empty($k['first_due_date']))         $firstDue = new DateTime((string)$k['first_due_date']);
    elseif (!empty($k['date_souscription']))  $firstDue = new DateTime((string)$k['date_souscription']);

    // === Mensualité basée sur montant_base ===
    $monthlyFromDb = null;
    if ($type === 'monthly') {
        if ($montantBase > 0) {
            $monthlyFromDb = round($montantBase / 12.0, 2);
        } elseif ($apportRaw > 0) {
            $monthlyFromDb = $apportRaw; // fallback ultime
        }
    }

    // Pour le tableau des paiements :
    // - one_time  : total = montantValue
    // - monthly   : total = montantBase
    $totalForSchedule = ($type === 'monthly')
        ? ($montantBase > 0 ? $montantBase : max(0.0, round(($monthlyFromDb ?? 0) * 12, 2)))
        : ($montantValue > 0 ? $montantValue : $total);

    [$paySummary, $payTableHtml, $monthlyIndic] = build_payment_table_html($type, $totalForSchedule, $monthlyFromDb, $firstDue);

    // Apport à afficher (mensualité si abo, sinon total payé)
    $apportValue = ($type === 'monthly')
        ? ($monthlyFromDb !== null ? $monthlyFromDb : round($totalForSchedule / 12, 2))
        : ($apportRaw > 0 ? $apportRaw : $totalForSchedule);
    $APPORT_TXT = _money((float)$apportValue);

    // Taux moyen (affichage x%)
    $taux_moyen_display = isset($k['taux_moyen']) ? _percent($k['taux_moyen']) : '—';
    $taux_ratio = null;
    if (isset($k['taux_moyen']) && $k['taux_moyen'] !== '') {
        $taux_ratio = ((float)$k['taux_moyen'] <= 1.0) ? (float)$k['taux_moyen'] : ((float)$k['taux_moyen'] / 100.0);
    }

    // Date de fin de contrat
    $startDate = !empty($k['date_souscription']) ? new DateTime((string)$k['date_souscription']) : new DateTime();
    $duree = (int)($k['duree_mois'] ?? 12);
    $endDateObj = (clone $startDate)->modify('+' . max(0, $duree) . ' month');
    $DATE_FIN_CONTRAT = $endDateObj->format('d/m/Y');

    // Rendement estimé à la date de fin (sur valeur réelle)
    $rendementEstim = null;
    if ($taux_ratio !== null) {
        $period_years = max(0, $duree) / 12.0;
        $rendementEstim = round($total * $taux_ratio * $period_years, 2);
    }
    $RENDEMENT_ESTIME_FIN = ($rendementEstim !== null) ? _money($rendementEstim) : '—';

    // Signatures & dates (sécurisé si $doc === null)
    $admin_signed_at_raw  = is_array($doc) ? ($doc['admin_signed_at']  ?? null) : null;
    $client_signed_at_raw = is_array($doc) ? ($doc['client_signed_at'] ?? null) : null;

    $ADMIN_SIGNED_AT  = $admin_signed_at_raw  ? date('d/m/Y H:i', strtotime($admin_signed_at_raw))  : '';
    $CLIENT_SIGNED_AT = $client_signed_at_raw ? date('d/m/Y H:i', strtotime($client_signed_at_raw)) : '';
    $CLIENT_SIGNED_LABEL = $CLIENT_SIGNED_AT
        ? ('Signé électroniquement le '.$CLIENT_SIGNED_AT)
        : 'En attente de signature du client';

    $ADMIN_SIGNATURE_IMG  = build_admin_signature_img_tag($pdo, $contract_id);
    $CLIENT_SIGNATURE_IMG = build_client_signature_img_tag($contract_id);

    // Logo (embed base64 si dispo)
    $logoFs  = realpath(__DIR__ . '/../images/logo-mpf.jpeg');
    $logoSrc = '/images/logo-mpf.jpeg';
    if ($logoFs && is_file($logoFs)) {
        $raw = @file_get_contents($logoFs);
        if ($raw !== false) { $logoSrc = 'data:image/jpeg;base64,' . base64_encode($raw); }
    }

    // Bloc Produits + plan (TOTAL = valeur réelle du contrat)
    $productsHtml = build_products_table_html($items, $total, $productNameFromId);

    // === Encadré promo / parrainage
    $parrainCode = strtoupper(trim((string)($k['code_parrain'] ?? '')));
    $promoCode   = trim((string)($k['promo_code'] ?? ''));
    $promoPctRaw = $k['promo_percentage'] ?? null;
    $promoPctTxt = ($promoPctRaw !== null && $promoPctRaw !== '') ? _percent($promoPctRaw) : null;

    $bonus = round(max(0.0, $total - max(0.0, $montantBase)), 2);
    $paidLabel = ($type === 'monthly')
        ? _money($montantBase) . " (sur 12 mois, soit " . _money($apportValue) . " / mois)"
        : _money($montantBase > 0 ? $montantBase : $apportValue);

    $promoBoxHtml = '';
    if ($parrainCode === 'MPF102569' || $promoCode !== '' || $bonus > 0) {
        $lines = [];
        if ($parrainCode === 'MPF102569') {
            $lines[] = "Code parrain <strong>MPF102569</strong> : bonification de <strong>+30&nbsp;%</strong> appliquée sur le montant de base.";
        }
        if ($promoCode !== '') {
            $lines[] = "Code promo <strong>" . _h($promoCode) . "</strong>" . ($promoPctTxt ? " : " . $promoPctTxt : "") . " appliqué.";
        }
        if ($bonus > 0) {
            $lines[] = "Avantage total offert : <strong>+" . _money($bonus) . "</strong>.";
        }
        $lines[] = "Prix payé (montant de base) : <strong>{$paidLabel}</strong>.";
        $lines[] = "Valeur réelle du contrat : <strong>" . _money($total) . "</strong>.";

        $li = '<li>' . implode('</li><li>', $lines) . '</li>';
        $promoBoxHtml = <<<HTML
<div class="section">Avantage promotionnel / parrainage</div>
<div class="box small">
  <ul style="margin:0; padding-left:18px">{$li}</ul>
</div>
HTML;
    }

    // Plan de paiement
    [$paySummary, $payTableHtml, $monthlyIndic] = build_payment_table_html($type, $totalForSchedule, $monthlyFromDb, $firstDue);

    // Récap
    $recapHtml    = $productsHtml . "\n" . $promoBoxHtml . "\n" . $payTableHtml;

    // Clauses complémentaires
    $extraClausesHtml = <<<HTML
<div class="section">Clauses complémentaires</div>
<ol style="margin:0; padding-left:18px">
  <li><strong>Rendements estimés à la date de fin de contrat :</strong> {$RENDEMENT_ESTIME_FIN}</li>
  <li><strong>Date de fin de contrat :</strong> {$DATE_FIN_CONTRAT}</li>
</ol>
HTML;
    $recapHtml .= "\n" . $extraClausesHtml;

    // Placeholders user
    $userPrenom   = (string)($k['prenom'] ?? '');
    $userNom      = (string)($k['user_nom'] ?? '');
    $userAdresse  = (string)($k['user_adresse'] ?? '');
    $userTel      = (string)($k['user_telephone'] ?? '');
    $userMail     = (string)($k['user_email'] ?? '');

    $place = [
        '{{CONTRACT_ID}}'           => (string)$k['id'],
        '{{DATE_SOUSCRIPTION}}'     => !empty($k['date_souscription']) ? date('d/m/Y', strtotime($k['date_souscription'])) : '',
        '{{DATE_SIGNATURE}}'        => date('d/m/Y'),

        '{{USER_PRENOM}}'           => $userPrenom,
        '{{USER_NOM}}'              => $userNom,
        '{{USER_REPRESENTANT}}'     => 'Lui-même',
        '{{USER_ADRESSE}}'          => $userAdresse ?: 'À compléter',
        '{{USER_TEL}}'              => $userTel ?: 'À compléter',
        '{{USER_EMAIL}}'            => $userMail ?: 'À compléter',

        '{{DUREE_MOIS}}'            => (string)$duree,

        '{{MONTANT_EUR}}'           => _money($total),
        '{{APPORT_MENSUEL_EUR}}'    => $APPORT_TXT,
        '{{MONTANT_APPORT_EUR}}'    => $APPORT_TXT,

        '{{MODALITES_PAIEMENT}}'    => $paySummary,
        '{{RECAP_COMMANDE_HTML}}'   => $recapHtml,

        '{{TAUX_MOYEN}}'            => $taux_moyen_display,
        '{{DATE_FIN_CONTRAT}}'      => $DATE_FIN_CONTRAT,
        '{{RENDEMENT_ESTIME_FIN}}'  => $RENDEMENT_ESTIME_FIN,

        '{{LOGO_SRC}}'              => $logoSrc,
        '{{WATERMARK}}'             => $isDraft ? '<div class="watermark">BROUILLON</div>' : '',

        '{{ADMIN_SIGNATURE_IMG}}'   => $ADMIN_SIGNATURE_IMG,
        '{{ADMIN_SIGNED_AT}}'       => $ADMIN_SIGNED_AT,
        '{{CLIENT_SIGNATURE_IMG}}'  => $CLIENT_SIGNATURE_IMG,
        '{{CLIENT_SIGNED_LABEL}}'   => $CLIENT_SIGNED_LABEL,
    ];

    // CSS additionnel
    $injectCss = <<<CSS
<style>
  .section{ margin:14px 0 10px 0; font-weight:700; }
  .box{ border:1px solid #e5e7eb; border-radius:6px; padding:8px; }
  .small{ font-size:11px; }
  .muted{ color:#666; }
  table th, table td { padding:6px; border-bottom:1px solid #e5e7eb; }
  p, ul, ol, table, h2, h3 { page-break-inside: avoid; }
  tr { page-break-inside: avoid; }
  #article-10, .article-10 { page-break-before: always; break-before: page; }
</style>
CSS;

    $html = preg_replace('/(<head[^>]*>)/i', '$1' . $injectCss, $html, 1);

    return strtr($html, $place);
}

/* ============================================================
 * 6) Rendu PDF disque
 * ============================================================ */

function _render_pdf_to_disk(string $html, string $destPath): void {
    $opts = new \Dompdf\Options();
    $opts->set('isRemoteEnabled', true);
    $opts->set('defaultFont', 'DejaVu Sans');
    $opts->set('isHtml5ParserEnabled', true);

    $dompdf = new \Dompdf\Dompdf($opts);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->render();

    $dir = dirname($destPath);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);

    $tmp = $destPath . '.tmp';
    file_put_contents($tmp, $dompdf->output());
    @rename($tmp, $destPath);
}

/* ============================================================
 * 7) Email de relance — **HTML simple (pas de multipart)**
 * ============================================================ */

function send_profile_reminder_email(string $toEmail, string $toName): bool {
    if (!$toEmail) return false;

    if (function_exists('mb_language')) mb_language('uni');
    if (function_exists('mb_internal_encoding')) mb_internal_encoding('UTF-8');

    $fromEmail  = 'no-reply@monplantfraise.com';
    $fromName   = 'Mon Plant Fraise';
    $replyTo    = 'support@monplantfraise.com';
    $profileUrl = 'https://www.monplantfraise.com/profil.php';
    $logoUrl    = 'https://www.monplantfraise.com/images/logo-mpf.jpeg';
    $subjectRaw = 'Mon Plant Fraise – Merci de compléter votre profil';
    $subject    = function_exists('mb_encode_mimeheader')
        ? mb_encode_mimeheader($subjectRaw, 'UTF-8', 'B', "\r\n")
        : $subjectRaw;

    // Corps HTML (logo + bouton rouge)
    $htmlBody = '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">'.
        '<meta name="viewport" content="width=device-width,initial-scale=1">'.
        '<title>Mon Plant Fraise – Merci de compléter votre profil</title></head>'.
        '<body style="margin:0;padding:0;background:#f6f7f9;">'.
        '  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f6f7f9;padding:24px 0;">'.
        '    <tr><td align="center">'.
        '      <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background:#ffffff;border-radius:12px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;">'.
        '        <tr><td align="center" style="padding:24px 24px 0;">'.
        '          <img src="'.htmlspecialchars($logoUrl, ENT_QUOTES, 'UTF-8').'" alt="Mon Plant Fraise" width="160" style="display:block;border:0;outline:none;text-decoration:none;margin:0 auto 12px;border-radius:8px;">'.
        '        </td></tr>'.
        '        <tr><td align="center" style="padding:0 24px 8px;">'.
        '          <h1 style="margin:0;font-size:22px;line-height:1.3;color:#111;">Mon Plant Fraise – Merci de compléter votre profil</h1>'.
        '        </td></tr>'.
        '        <tr><td style="padding:8px 24px 0;font-size:15px;line-height:1.6;color:#333;">'.
        '          <p style="margin:0 0 12px;">Bonjour '.htmlspecialchars($toName, ENT_QUOTES, 'UTF-8').',</p>'.
        '          <p style="margin:0 0 12px;">Grande nouvelle&nbsp;! Nous avons mis en place la <strong>signature électronique</strong> pour vos contrats (y compris les anciens).</p>'.
        '          <p style="margin:0 0 16px;">Cependant, certaines informations sont manquantes afin de pouvoir vous transmettre votre contrat, merci de <strong>compléter votre profil</strong> depuis votre espace client.</p>'.
        '        </td></tr>'.
        '        <tr><td align="center" style="padding:0 24px 24px;">'.
        '          <a href="'.htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8').'" '.
        '             style="display:inline-block;padding:14px 22px;font-size:16px;text-decoration:none;'.
        '                    background:#e3342f;color:#ffffff;border-radius:8px;font-weight:bold;">'.
        '             Je complète mon profil'.
        '          </a>'.
        '        </td></tr>'.
        '        <tr><td style="padding:0 24px 24px;font-size:14px;line-height:1.6;color:#555;">'.
        '          <p style="margin:0;">Bien cordialement,<br>Mon Plant Fraise</p>'.
        '        </td></tr>'.
        '      </table>'.
        '      <div style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#999;margin-top:12px;max-width:600px;">'.
        '        Si le bouton ne fonctionne pas, copiez-collez ce lien dans votre navigateur&nbsp;: '.
        '        <a href="'.htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8').'" style="color:#888;">'.htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8').'</a>'.
        '      </div>'.
        '    </td></tr>'.
        '  </table>'.
        '</body></html>';

    // En-têtes **simples** pour HTML (pas de multipart)
    $eol = "\r\n";
    $headers  = [];
    $headers[] = 'From: '.$fromName.' <'.$fromEmail.'>';
    $headers[] = 'Reply-To: '.$replyTo;
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $headers[] = 'Content-Transfer-Encoding: 8bit';
    $headers[] = 'X-Mailer: PHP/'.PHP_VERSION;
    $headersStr = implode($eol, $headers);

    // Paramètre enveloppe (utile SPF/bounces)
    $params = '-f'.$fromEmail;

    if (function_exists('mb_send_mail')) {
        return @mb_send_mail($toEmail, $subject, $htmlBody, $headersStr, $params);
    }
    return @mail($toEmail, $subject, $htmlBody, $headersStr, $params);
}

/* ============================================================
 * 8) Vérification profil (obligatoire pour la logique de draft)
 * ============================================================ */

function required_profile_fields(): array {
    return ['user_adresse', 'user_telephone', 'user_email', 'prenom', 'user_nom'];
}

function check_profile_completeness(array $k): array {
    $miss = [];
    foreach (required_profile_fields() as $key) {
        $val = trim((string)($k[$key] ?? ''));
        if ($val === '') $miss[] = $key;
    }
    return ['ok' => count($miss) === 0, 'missing' => $miss];
}

/* ============================================================
 * 9) Draft & Final
 * ============================================================ */

function generate_contract_draft(PDO $pdo, int $contract_id, array $options = []): array {
    if ($contract_id <= 0) throw new InvalidArgumentException('contract_id invalide');

    $k = load_contract_with_user($pdo, $contract_id);
    $user_id   = (int)$k['user_id'];
    $userEmail = (string)($k['user_email'] ?? '');
    $userName  = trim(((string)($k['prenom'] ?? '')).' '.((string)($k['user_nom'] ?? '')));

    // 1) Vérifier le profil
    $chk = check_profile_completeness($k);
    if (!$chk['ok']) {
        if (!empty($options['send_reminder'])) {
            $sent = send_profile_reminder_email($userEmail, $userName ?: 'Client');
            return ['status' => $sent ? 'reminder_sent' : 'reminder_failed', 'missing' => $chk['missing']];
        }
        if (empty($options['force'])) {
            return ['status' => 'needs_profile', 'missing' => $chk['missing']];
        }
    }

    // 2) Rendu HTML (DRAFT)
    $html = render_contract_html($pdo, $contract_id, /*isDraft*/true);

    // 3) Sauvegarde PDF
    $storedFile = 'draft-contrat-' . $contract_id . '-' . date('Ymd-His') . '.pdf';
    $absPath   = rtrim(UPLOAD_CONTRACTS_DIR, '/') . '/' . $storedFile;
    _render_pdf_to_disk($html, $absPath);

    $dbPath = '/documents/contrats/' . $storedFile;

    // 4) Insertion document
    $sql = "
        INSERT INTO documents (user_id, contract_id, filename, file_path, category, upload_date, is_visible, status)
        VALUES (?, ?, ?, ?, 'Contrats', NOW(), 0, 'draft')
    ";
    $st = $pdo->prepare($sql);
    $st->execute([$user_id, $contract_id, 'Contrat #'.$contract_id.' (brouillon).pdf', $dbPath]);
    $doc_id = (int)$pdo->lastInsertId();

    return ['status' => 'draft_created', 'doc_id' => $doc_id, 'file_path' => $dbPath];
}

function regenerate_contract_pdf_final(PDO $pdo, int $contract_id, ?int $doc_id = null): void {
    if ($contract_id <= 0) {
        throw new InvalidArgumentException('regenerate_contract_pdf_final: contract_id manquant ou invalide');
    }

    // 1) Résolution du document
    if (empty($doc_id) || $doc_id <= 0) {
        $sql = "
            SELECT id, file_path
            FROM documents
            WHERE contract_id = ?
              AND LOWER(category) IN ('contrat','contrats','contract','contracts')
              AND (status = 'draft' OR is_visible = 0)
            ORDER BY id DESC
            LIMIT 1
        ";
        $st = $pdo->prepare($sql);
        $st->execute([$contract_id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            throw new RuntimeException("Aucun brouillon de contrat trouvé pour contract_id=$contract_id. Passez un doc_id explicite ou générez un draft d'abord.");
        }
        $doc_id   = (int)$row['id'];
        $filePath = (string)$row['file_path'];
    } else {
        $st = $pdo->prepare("SELECT id, file_path FROM documents WHERE id = ? LIMIT 1");
        $st->execute([$doc_id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            throw new RuntimeException("Document introuvable pour doc_id=$doc_id.");
        }
        $filePath = (string)$row['file_path'];
    }

    // 2) Génération HTML sans filigrane
    $html = render_contract_html($pdo, $contract_id, /*isDraft*/false);

    // 3) Chemin absolu vers le fichier
    $absBase = realpath(__DIR__ . '/..');
    if ($absBase === false) {
        throw new RuntimeException('Chemin base invalide pour l\'écriture du PDF.');
    }
    $absPath = $absBase . $filePath;

    // 4) Rendu PDF sur le même chemin que le draft
    _render_pdf_to_disk($html, $absPath);

    // 5) Publication
    $upd = $pdo->prepare("
        UPDATE documents
        SET is_visible = 1,
            status = 'approved',
            validated_at = NOW(),
            filename = ?
        WHERE id = ?
    ");
    $upd->execute(['Contrat #'.$contract_id.'.pdf', $doc_id]);
}





