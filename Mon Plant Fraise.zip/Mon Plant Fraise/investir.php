<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Participez à la Croissance - Mon Plant Fraise</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Styles Généraux */
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            color: #333;
            line-height: 1.6;
            background-color: #f8f8f8; /* Léger fond */
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px 0;
        }

        /* NOUVEAU: Style pour le lien d'inscription (remplace l'ancien bouton) */
        .signup-link-wrapper {
            padding-top: 40px; /* Espace avant le module d'appel */
            text-align: center;
            background-color: #f8f8f8; /* Même fond que body */
        }
        .signup-link-phrase {
            font-size: 1.1rem;
            font-weight: 600;
            color: #6B8E23; /* Vert du thème */
            text-decoration: underline;
            transition: color 0.3s ease;
        }
        .signup-link-phrase:hover {
            color: #5A7C1F; /* Vert plus foncé */
            text-decoration: none;
        }
        /* --- FIN NOUVEAU STYLE --- */

        /* Bannière */
        .banner {
            background-image: url('images/banniere-croissance.png'); /* MODIFIÉ */
            background-size: cover;
            background-position: center;
            height: 350px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            text-align: center;
            position: relative;
        }
        .banner::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0,0,0,0.3);
            z-index: 1;
        }
        .banner h1 {
            font-size: 3rem;
            font-weight: 700;
            z-index: 2;
            text-shadow: 0 2px 5px rgba(0,0,0,0.5); 
            max-width: 90%; 
        }

        /* Section Avantages */
        .advantages {
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
            padding: 60px 0;
            text-align: center;
        }
        .advantage-item {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
         .advantage-item:hover {
             transform: translateY(-5px);
             box-shadow: 0 8px 20px rgba(0,0,0,0.1);
         }
        .advantage-item img {
            height: 120px; 
            margin-bottom: 15px;
            object-fit: contain;
        }
        .advantage-item h3 {
            font-size: 1.4rem;
            margin-bottom: 10px;
            color: #6B8E23;
            font-weight: 600;
        }
        .advantage-item p {
            font-size: 0.95rem;
            color: #666;
        }

        /* Section Prise de Rendez-vous */
        .appointment-section {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 60px 0;
            gap: 40px;
            background-color: #fff; 
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        .explanation-text {
            flex: 1;
            padding: 10px;
            text-align: left;
        }
        .explanation-text h2 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 20px;
            font-weight: 600;
        }
        .explanation-text p {
            color: #555;
            font-size: 1rem;
            line-height: 1.8;
            margin-bottom: 15px;
        }
        .appointment-module {
            flex: 1;
            background-color: #fdfdfd;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            text-align: center;
            border: 1px solid #eee;
        }
        .appointment-module h2 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 25px;
            font-weight: 600;
        }

        /* Calendrier */
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 5px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            color: #777;
        }
        .calendar-grid div {
            padding: 8px 5px;
            border-radius: 4px;
        }
        .day-name { font-weight: 700; color: #333; }
        .date { background-color: #f0f0f0; cursor: default; } 
        .date.available { background-color: #D4EDDA; color: #333; font-weight: 600; cursor: pointer; transition: background-color 0.2s ease; }
        .date.available:hover { background-color: #b8dcb8; }
        .date.available.selected { background-color: #6B8E23; color: #fff; }
        .date:not(.available) { color: #bbb; }


        /* Créneaux Horaires */
        .time-slots {
            display: grid;
            grid-template-columns: repeat(2, 1fr); 
            gap: 10px;
            margin-bottom: 30px;
        }
        .time-slot { padding: 10px; border: 1px solid #ddd; border-radius: 5px; cursor: default; transition: background-color 0.2s ease, border-color 0.2s ease; font-size: 0.95rem; color: #999; background-color: #f9f9f9; } 
        .time-slot.available { background-color: #E6F3E6; border-color: #C6E0B1; color: #333; cursor: pointer; }
        .time-slot.available:hover { background-color: #C6E0B1; }
        .time-slot.selected { background-color: #6B8E23; color: #fff; border-color: #6B8E23; cursor: default; }

        /* Formulaire */
        .appointment-form input[type="text"],
        .appointment-form input[type="email"],
        .appointment-form input[type="tel"] {
            width: calc(100% - 24px); padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px; font-size: 1rem;
        }
        .appointment-form button {
            background-color: #6B8E23; color: #fff; padding: 15px 30px; border: none; border-radius: 5px; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: background-color 0.3s ease; width: 100%;
        }
        .appointment-form button:hover {
            background-color: #5A7C1F;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .banner h1 { font-size: 2.5rem; }
            .advantages { flex-direction: column; padding: 40px 0; gap: 30px; } 
            .appointment-section { flex-direction: column; align-items: center; }
            .explanation-text, .appointment-module {
                 width: 90%; max-width: 600px; margin: 0 auto 30px auto; padding: 25px;
            }
        }

        @media (max-width: 768px) {
            /* Ancien style de bouton s'inscrire supprimé */
            .banner { height: 250px; }
            .banner h1 { font-size: 2rem; max-width: 90%; }
            .advantages { grid-template-columns: 1fr; gap: 25px; } 
            .advantage-item img { height: 80px; }
            .advantage-item h3 { font-size: 1.2rem; }
            .explanation-text h2, .appointment-module h2 { font-size: 1.5rem; }
            .calendar-grid { font-size: 0.8rem; }
            .time-slots { grid-template-columns: 1fr; } 
             .appointment-section { padding: 40px 0; }
        }

        /* Popup Confirmation */
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.6); display: none; justify-content: center; align-items: center; z-index: 2000;
        }
        .modal-content {
            background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); text-align: center; max-width: 500px; width: 90%; position: relative;
        }
        .modal-content h2 { color: #6B8E23; margin-top: 0; }
        .modal-close { position: absolute; top: 10px; right: 15px; font-size: 28px; font-weight: bold; cursor: pointer; color: #aaa; }
        .modal-close:hover { color: #333; }
    </style>
</head>
<body>

    <div class="banner">
        <h1>Faites Fructifier Votre Engagement</h1> </div>

    <div class="container advantages">
        <div class="advantage-item">
            <img src="/images/icone-croissance-partagee.png" alt="Valorisation Partagée"> <h3>Valorisation Partagée</h3> <p>Soutenez nos cultures et recevez une part de la valeur générée. Votre soutien porte ses fruits.</p> </div>
        <div class="advantage-item">
            <img src="/images/icone-local.png" alt="Engagement Local"> <h3>Engagement Local & Durable</h3> <p>Participez à une agriculture raisonnée, sans pesticides de synthèse, et respectueuse de notre environnement.</p>
        </div>
        <div class="advantage-item">
            <img src="/images/icone-transparence.png" alt="Suivi Transparent"> <h3>Suivi Transparent</h3>
            <p>Accédez à votre espace dédié pour suivre l'évolution de votre contribution et la performance de nos cultures.</p> </div>
    </div>

    <div class="signup-link-wrapper">
        <div class="container">
             <a href="register.php" class="signup-link-phrase">S'inscrire avant l'appel de confirmation</a>
        </div>
    </div>

    <div class="container appointment-section" id="appointment-module">
        <div class="explanation-text">
            <h2>Un Échange Essentiel</h2> <p>Chez Mon Plant Fraise, nous privilégions une relation de confiance. Cet appel est l'occasion d'échanger sur notre modèle participatif et de répondre à toutes vos questions.</p> <p>Nous vous présenterons notre démarche, nos valeurs et comment vous pouvez participer concrètement à notre aventure agricole locale, de la plantation à la récolte.</p>
            <p>C'est une étape simple pour nous assurer que notre vision correspond à vos attentes avant de vous engager.</p> </div>
        <div class="appointment-module">
            <h2>Planifiez votre appel</h2>

            <?php
            // Affichage des messages (inchangé)
            if (isset($_GET['status'])) {
                 if ($_GET['status'] == 'success') {
                   echo '<p style="color: green; font-weight: bold; border: 1px solid green; padding: 10px; border-radius: 5px; background-color: #e6f3e6; margin-bottom: 15px;">Demande envoyée ! Vérifiez vos emails (et spams).</p>';
                 } elseif ($_GET['status'] == 'error') {
                     echo '<p style="color: red; font-weight: bold; border: 1px solid red; padding: 10px; border-radius: 5px; background-color: #fce4ec; margin-bottom: 15px;">Erreur lors de l\'envoi. Veuillez réessayer.</p>';
                 }
             }
            ?>

            <div class="calendar-grid">
                  <div class="day-name">Lun</div><div class="day-name">Mar</div><div class="day-name">Mer</div><div class="day-name">Jeu</div><div class="day-name">Ven</div><div class="day-name">Sam</div><div class="day-name">Dim</div>
                  <div class="date">27</div> <div class="date">28</div> <div class="date">29</div> <div class="date">30</div> <div class="date">31</div>
                  <div class="date">1</div><div class="date">2</div>
                  <div class="date available" data-date="2025-11-03">3</div><div class="date available" data-date="2025-11-04">4</div><div class="date available" data-date="2025-11-05">5</div><div class="date available" data-date="2025-11-06">6</div><div class="date available" data-date="2025-11-07">7</div>
                  <div class="date">8</div><div class="date">9</div>
                  <div class="date available" data-date="2025-11-10">10</div><div class="date available" data-date="2025-11-11">11</div><div class="date available" data-date="2025-11-12">12</div><div class="date available" data-date="2025-11-13">13</div><div class="date available" data-date="2025-11-14">14</div>
                  <div class="date">15</div><div class="date">16</div>
                  </div>

            <h3>Créneaux disponibles le <span id="selected-date-display"> -- Sélectionner une date -- </span></h3>
            <div class="time-slots">
                 <div class="time-slot available">9h00</div>
                 <div class="time-slot available">10h30</div>
                 <div class="time-slot available">14h00</div>
                 <div class="time-slot available">15h30</div>
                 <div class="time-slot">17h00</div> </div>

            <form class="appointment-form" action="process_rdv.php" method="POST">
                 <input type="hidden" name="date_rdv" id="hidden-date" required>
                 <input type="hidden" name="heure_rdv" id="hidden-time" required>
                 <input type="text" name="nom_complet" placeholder="Nom Complet *" required pattern=".*\S+.*" title="Le nom est requis.">
                 <input type="tel" name="telephone" placeholder="Numéro de Téléphone *" required pattern="^[0-9\s\+\-\(\)]{8,}$" title="Numéro de téléphone invalide (8 chiffres min).">
                 <input type="email" name="email" placeholder="Adresse E-mail *" required>
                 <button type="submit">Planifier mon appel</button>
            </form>
        </div>
    </div>

    <div id="confirmationModal" class="modal-overlay">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal()">&times;</span>
            <h2>Demande Envoyée !</h2>
            <p>Votre demande de rendez-vous a bien été enregistrée.</p>
            <p>Un email de confirmation vient de vous être envoyé. Pensez à vérifier vos spams.</p>
        </div>
    </div>

    <script>
        // Fonction pour fermer la popup (inchangée)
        function closeModal() {
            const modal = document.getElementById('confirmationModal');
            if(modal) modal.style.display = 'none';
            if (window.history.pushState) {
                const cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.hash;
                window.history.pushState({ path: cleanUrl }, '', cleanUrl);
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            // --- LOGIQUE DU CALENDRIER (inchangée) ---
            const dates = document.querySelectorAll('.calendar-grid .date.available');
            const timeSlots = document.querySelectorAll('.time-slots .time-slot'); 
            const selectedDateDisplay = document.getElementById('selected-date-display');
            const hiddenDateInput = document.getElementById('hidden-date');
            const hiddenTimeInput = document.getElementById('hidden-time');
            const monthNames = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

            dates.forEach(date => {
                date.addEventListener('click', function() {
                    if (!this.classList.contains('available')) return; 

                    dates.forEach(d => d.classList.remove('selected'));
                    this.classList.add('selected');
                    const fullDate = this.getAttribute('data-date');
                    hiddenDateInput.value = fullDate;
                    try {
                        const [year, month, day] = fullDate.split('-');
                        const dateObj = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day)));
                         if (!isNaN(dateObj.getTime())) {
                             selectedDateDisplay.textContent = `${dateObj.getUTCDate()} ${monthNames[dateObj.getUTCMonth()]} ${dateObj.getUTCFullYear()}`;
                         } else { selectedDateDisplay.textContent = "Date invalide"; }
                    } catch (e) { selectedDateDisplay.textContent = "Erreur date"; console.error(e); }

                    timeSlots.forEach(s => s.classList.remove('selected'));
                    hiddenTimeInput.value = '';
                });
            });

            timeSlots.forEach(slot => {
                slot.addEventListener('click', function() {
                    if (!this.classList.contains('available')) return; 
                    if (!hiddenDateInput.value) {
                         alert("Veuillez d'abord sélectionner une date disponible.");
                         return;
                     }
                    timeSlots.forEach(s => s.classList.remove('selected'));
                    this.classList.add('selected');
                    hiddenTimeInput.value = this.textContent.trim();
                });
            });

            // Validation avant soumission (inchangée)
            const appointmentForm = document.querySelector('.appointment-form');
            if (appointmentForm) {
                appointmentForm.addEventListener('submit', function(event) {
                    if (!hiddenDateInput.value || !hiddenTimeInput.value) {
                        alert('Veuillez sélectionner une date ET un créneau horaire disponibles.');
                        event.preventDefault();
                    }
                });
            }

            // --- LOGIQUE POPUP CONFIRMATION (inchangée) ---
            const modal = document.getElementById('confirmationModal');
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('status') && urlParams.get('status') === 'success' && modal) {
                modal.style.display = 'flex';
            }

            window.onclick = function(event) { if (event.target == modal) { closeModal(); } }
            window.addEventListener('keydown', function (event) { if (event.key === 'Escape' && modal && modal.style.display === 'flex') { closeModal(); } });
        });
    </script>
</body>
</html>