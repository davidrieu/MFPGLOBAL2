<?php
// mes_documents.php — Espace client > Mes documents (contrats + état PDF + signature)

// 1) Session & auth
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// (Débogage à retirer en prod)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2) Dépendances
require_once __DIR__ . '/db_connection.php';
if (file_exists(__DIR__ . '/badge_sentinel.php')) {
    require_once __DIR__ . '/badge_sentinel.php';
}

// 3) Helpers
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money_eur($x){
    if ($x === null || $x === '') return '—';
    return number_format((float)$x, 2, ',', ' ') . ' €';
}
function documents_has_contract_id(PDO $pdo): bool {
    try { $pdo->query("SELECT contract_id FROM documents WHERE 1=0"); return true; }
    catch (Throwable $e) { return false; }
}
function column_exists(PDO $pdo, string $table, string $col): bool {
    try { $pdo->query("SELECT {$col} FROM {$table} WHERE 1=0"); return true; }
    catch (Throwable $e) { return false; }
}
// Fallback (si pas de contract_id dans documents), tente de reconnaître un contrat par son nom de fichier/chemin
function doc_matches_contract(array $doc, int $contract_id): bool {
    $hay = mb_strtolower(trim(($doc['filename'] ?? '') . ' ' . ($doc['file_path'] ?? '')), 'UTF-8');
    if ($hay === '') return false;
    $id = (int)$contract_id;
    $needles = [
        'contrat-' . $id, 'contrats-' . $id, 'contract-' . $id,
        'contrat_' . $id, 'contrats_' . $id, 'contract_' . $id,
        '/'.$id.'.', '_'.$id.'.', '-'.$id.'.', ' '.$id.' ', '_'.$id.'_', '-'.$id.'-', '/'.$id.'/'
    ];
    foreach ($needles as $n) { if (strpos($hay, $n) !== false) return true; }
    return false;
}

// 4) Données utilisateur
$user_id = (int) $_SESSION['user_id'];

// 5) Charger les CONTRATS de l'utilisateur (+ nom du produit)
try {
    $stmtK = $pdo->prepare("
        SELECT
            k.id,
            k.date_souscription,
            k.montant,
            k.duree_mois,
            k.taux_moyen,
            k.plant_type,
            k.produit_id,
            k.statut,
            p.name AS produit_nom
        FROM contrats k
        LEFT JOIN produits p ON p.id = k.produit_id
        WHERE k.user_id = ?
        ORDER BY k.date_souscription DESC, k.id DESC
    ");
    $stmtK->execute([$user_id]);
    $contrats = $stmtK->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('mes_documents.php contrats SELECT error: ' . $e->getMessage());
    die('Erreur lors du chargement de vos contrats.');
}

// 6) Charger les DOCUMENTS visibles (catégorie Contrats) de l'utilisateur
$HAS_CONTRACT_ID      = documents_has_contract_id($pdo);
$HAS_CLIENT_SIGNED_AT = column_exists($pdo, 'documents', 'client_signed_at'); // optionnel
try {
    $selectContractId   = $HAS_CONTRACT_ID ? "d.contract_id" : "NULL AS contract_id";
    $selectClientSigned = $HAS_CLIENT_SIGNED_AT ? "d.client_signed_at" : "NULL AS client_signed_at";

    $stmtD = $pdo->prepare("
        SELECT d.id, d.user_id, d.filename, d.file_path, d.category, d.upload_date, d.is_visible, d.status,
               {$selectContractId}, {$selectClientSigned}
        FROM documents d
        WHERE d.user_id = ?
          AND d.is_visible = 1
          AND LOWER(d.category) IN ('contrat','contrats','contract','contracts')
        ORDER BY d.upload_date DESC, d.id DESC
    ");
    $stmtD->execute([$user_id]);
    $docs_visible = $stmtD->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('mes_documents.php documents SELECT error: ' . $e->getMessage());
    die('Erreur lors du chargement de vos documents.');
}

// 7) Index docs visibles par contract_id (si dispo)
$doc_by_contract_id = [];
if ($HAS_CONTRACT_ID) {
    foreach ($docs_visible as $d) {
        if (!is_null($d['contract_id'])) {
            $cid = (int)$d['contract_id'];
            // garder le plus récent
            if (!isset($doc_by_contract_id[$cid])) {
                $doc_by_contract_id[$cid] = $d;
            } else {
                $prev = $doc_by_contract_id[$cid];
                $prevT = strtotime($prev['upload_date'] ?? '1970-01-01 00:00:00');
                $curT  = strtotime($d['upload_date'] ?? '1970-01-01 00:00:00');
                if ($curT >= $prevT) $doc_by_contract_id[$cid] = $d;
            }
        }
    }
}

// 8) Construire les items d'affichage (1 carte = 1 contrat)
$sign_module_exists = file_exists(__DIR__ . '/sign_contract.php'); // module de signature
$items = [];
foreach ($contrats as $k) {
    $cid       = (int)$k['id'];
    $produit   = trim((string)($k['produit_nom'] ?? ''));
    $fallback  = trim((string)($k['plant_type'] ?? ''));
    $labelBase = $produit !== '' ? $produit : ($fallback !== '' ? $fallback : ('Contrat #' . $cid));
    $label     = $labelBase . (!empty($k['montant']) ? ' — ' . money_eur($k['montant']) : '');
    $date_sous = !empty($k['date_souscription']) ? date('d/m/Y', strtotime($k['date_souscription'])) : '';

    $doc = null;
    if ($HAS_CONTRACT_ID && isset($doc_by_contract_id[$cid])) {
        $doc = $doc_by_contract_id[$cid];
    } else {
        foreach ($docs_visible as $d) {
            if (doc_matches_contract($d, $cid)) { $doc = $d; break; }
        }
    }

    if ($doc) {
        $download_url     = '/download.php?id=' . (int)$doc['id'];  // téléchargement sécurisé
        $client_signed_at = $doc['client_signed_at'] ?? null;
        $is_signed        = !empty($client_signed_at);

        // URL de signature (si module présent)
        $sign_url = $sign_module_exists ? ('/sign_contract.php?contract_id=' . $cid) : null;

        $items[] = [
            'cid'        => $cid,
            'label'      => $label,
            'date_sous'  => $date_sous,
            'has_pdf'    => true,
            'url'        => $download_url,
            'date_doc'   => !empty($doc['upload_date']) ? date('d/m/Y H:i', strtotime($doc['upload_date'])) : '',
            'is_signed'  => $is_signed,
            'signed_at'  => $is_signed ? date('d/m/Y H:i', strtotime($client_signed_at)) : '',
            'sign_url'   => $sign_url,
        ];
    } else {
        $items[] = [
            'cid'        => $cid,
            'label'      => $label,
            'date_sous'  => $date_sous,
            'has_pdf'    => false,
            'url'        => null,
            'date_doc'   => '',
            'is_signed'  => false,
            'signed_at'  => '',
            'sign_url'   => null,
        ];
    }
}

// 9) Bandeau info si au moins un contrat n'a pas encore de PDF
$show_info_banner = false;
foreach ($items as $it) { if (!$it['has_pdf']) { $show_info_banner = true; break; } }

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Documents - Mon Plant Fraise</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonts / Icônes -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0"/>

    <style>
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --primary-color: #2E7D32;
            --primary-color-dark: #1B5E20;
            --primary-color-light: #C8E6C9;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --secondary-color: #8BC34A;

            --text-color: #212121;
            --text-color-light: #757575;
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;

            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            --bd: #eee;

            --info-bg: #FFF8E1;
            --info-bd: #FFE082;
            --ok-bg: #E8F5E9;
            --ok-bd: #C8E6C9;
            --warn-bg: #fdecea;
            --warn-bd: #f5c2c0;
        }

        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }

        /* Sidebar */
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0;
                   box-shadow: 0 2px 10px rgba(0,0,0,0.1); display: flex; flex-direction: column; z-index: 1000; transition: transform 0.3s ease-in-out; }
        .sidebar-header { margin-bottom: 30px; text-align: center; }
        .sidebar-header a img { max-width: 80%; height: auto; }
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light);
                           border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover { background-color: #eeeeee; }
        .sidebar ul li a.active { background-color: var(--primary-color); color: white; }

        /* Conteneur */
        .container { margin-left: 260px; padding: 30px; width: calc(100% - 260px); }

        .page-header { display:flex; align-items:center; justify-content:space-between; gap:16px; margin-bottom: 12px; }
        .page-title { font-family: 'Poppins', sans-serif; font-size: 28px; font-weight: 700; margin: 0; }
        .subtitle { color: var(--text-color-light); margin: 4px 0 0; }

        /* Bandeau info */
        .info-banner {
            display: flex; gap: 12px; align-items: flex-start;
            background: var(--info-bg); border: 1px solid var(--info-bd);
            padding: 14px 16px; border-radius: 12px; margin: 16px 0 20px;
        }
        .info-banner .material-symbols-outlined { font-size: 22px; }

        /* Recherche */
        .actions-bar { display:flex; align-items:center; gap:16px; flex-wrap:wrap; margin: 20px 0; }
        .search { flex:1; min-width: 240px; }
        .search input { width: 100%; padding: 12px 14px; border: 1px solid var(--bd); border-radius: 10px; background:#fff; }

        /* Liste contrats */
        .doc-list { display: grid; gap: 16px; grid-template-columns: 1fr; }
        .card { background-color: var(--card-background-color); padding: 16px 18px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); border: 1px solid var(--bd);
                display:flex; align-items:center; justify-content:space-between; gap:16px; }
        .card:hover { transform: translateY(-3px); box-shadow: 0 8px 16px rgba(0,0,0,0.08); }

        .doc-info { display:flex; align-items:center; gap:16px; }
        .doc-icon { font-size: 30px; color: var(--primary-color); background-color: var(--primary-color-light); padding: 10px; border-radius: 50%; }
        .doc-meta h3 { margin:0 0 4px; font-size: 16px; font-weight: 700; }
        .muted { color: var(--text-color-light); font-size: 14px; }

        .btn-primary { background: var(--primary-gradient); color: white; padding: 10px 16px; border: none; border-radius: var(--border-radius); cursor: pointer;
                       font-size: 14px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap:8px; }
        .btn-primary:hover { box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4); transform: translateY(-2px); }

        .btn-secondary { background: #ffffff; color: var(--primary-color); padding: 10px 16px; border: 1px solid var(--primary-color); border-radius: var(--border-radius);
                         font-weight: 700; text-decoration: none; display: inline-flex; align-items:center; gap:8px; }
        .btn-secondary:hover { background: var(--primary-color-light); }

        .badge-wait { background: var(--info-bg); border:1px solid var(--info-bd); padding:6px 10px; border-radius:999px; font-weight:600; }
        .badge-ok   { background: var(--ok-bg);   border:1px solid var(--ok-bd);   padding:6px 10px; border-radius:999px; font-weight:600; }
        .badge-warn { background: var(--warn-bg); border:1px solid var(--warn-bd); padding:6px 10px; border-radius:999px; font-weight:600; }

        .empty { text-align:center; color: var(--text-color-light); padding: 28px; background:#fff; border:1px solid var(--bd); border-radius: var(--border-radius); }

        /* Responsive + bouton burger */
        .toggle-btn { display:none; }
        @media (max-width: 1024px) {
            .card { flex-direction: column; align-items: flex-start; }
            .actions { width: 100%; display: flex; gap: 8px; flex-wrap: wrap; }
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .container { margin-left: 0; padding: 15px; width: 100%; }
            .toggle-btn { display:block; position:fixed; top:15px; left:15px; background-color:var(--primary-color); color:white; border:none; border-radius:50%;
                          width:50px; height:50px; cursor:pointer; z-index:1001; box-shadow:0 2px 5px rgba(0,0,0,0.3); font-size:24px; display:flex; align-items:center; justify-content:center; }
            .page-title { margin-top: 60px; font-size: 24px; }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="document.querySelector('.sidebar').classList.toggle('open')">☰</button>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <a href="index.php"><img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise"></a>
    </div>
    <ul>
        <li><a href="espace-client.php"><span class="material-symbols-outlined">home</span>Accueil</a></li>
        <li><a href="recoltes.php"><span class="material-symbols-outlined">grass</span>Mes récoltes</a></li>
        <li><a href="investclient.php"><span class="material-symbols-outlined">rocket_launch</span>Booster ma récolte</a></li>
        <li><a href="mes_documents.php" class="active"><span class="material-symbols-outlined">description</span>Mes documents</a></li>
        <li><a href="profil.php"><span class="material-symbols-outlined">person</span>Mon Profil</a></li>
        <li><a href="parrainage.php"><span class="material-symbols-outlined">group_add</span>Parrainage</a></li>
        <li><a href="logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<!-- Contenu -->
<div class="container">
    <div class="page-header">
        <div>
            <h1 class="page-title">Mes documents</h1>
            <p class="subtitle">Vos <strong>contrats</strong> associés à vos investissements.</p>
        </div>
    </div>

    <?php if ($show_info_banner && !empty($contrats)): ?>
        <div class="info-banner">
            <span class="material-symbols-outlined">info</span>
            <div>
                Votre commande pour votre <strong>contrat</strong> a bien été prise en compte.
                <br>Vos documents contractuels seront disponibles <strong>sous peu</strong>, dans cet espace.
            </div>
        </div>
    <?php endif; ?>

    <div class="actions-bar">
        <div class="search">
            <input id="q" placeholder="Rechercher (produit, libellé, date)…">
        </div>
    </div>

    <?php if (empty($contrats)): ?>
        <div class="empty">Aucun contrat enregistré pour le moment.</div>
    <?php else: ?>
        <div class="doc-list" id="doc-list">
            <?php foreach ($items as $it): ?>
                <div class="card" data-text="<?= h(mb_strtolower(($it['label'] ?? '') . ' ' . ($it['date_sous'] ?? '') . ' ' . ($it['has_pdf'] ? 'disponible' : 'bientot disponible'), 'UTF-8')) ?>">
                    <div class="doc-info">
                        <span class="material-symbols-outlined doc-icon">description</span>
                        <div class="doc-meta">
                            <h3><?= h($it['label']) ?></h3>
                            <div class="muted">
                                Souscrit le <?= h($it['date_sous'] ?: '—') ?>
                                <?php if ($it['has_pdf'] && !empty($it['date_doc'])): ?>
                                    · Document ajouté le <?= h($it['date_doc']) ?>
                                <?php endif; ?>
                                <?php if ($it['has_pdf']): ?>
                                    <?php if (!empty($it['is_signed'])): ?>
                                        · <span class="badge-ok">Signé le <?= h($it['signed_at']) ?></span>
                                    <?php else: ?>
                                        · <span class="badge-warn">Signature en attente</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="actions">
                        <?php if ($it['has_pdf'] && !empty($it['url'])): ?>
                            <a class="btn-primary" href="<?= h($it['url']) ?>" target="_blank" rel="noopener">
                                <span class="material-symbols-outlined">download</span>
                                Télécharger le contrat (PDF)
                            </a>
                            <?php if (!$it['is_signed'] && !empty($it['sign_url'])): ?>
                                <a class="btn-secondary" href="<?= h($it['sign_url']) ?>">
                                    <span class="material-symbols-outlined">draw</span>
                                    Signer en ligne
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="badge-wait">Contrat bientôt disponible</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
    // Filtre côté client
    const q = document.getElementById('q');
    if (q) {
        q.addEventListener('input', function(e){
            const needle = (e.target.value || '').toLowerCase();
            const cards = document.querySelectorAll('#doc-list .card');
            cards.forEach(c=>{
                const hay = (c.getAttribute('data-text')||c.innerText).toLowerCase();
                c.style.display = hay.includes(needle) ? '' : 'none';
            });
        });
    }
</script>

</body>
</html>

