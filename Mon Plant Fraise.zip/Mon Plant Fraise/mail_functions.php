<?php
// mail_functions.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/phpmailer/src/Exception.php';
require 'vendor/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/src/SMTP.php';

function send_appointment_email($to, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // Paramètres du serveur SMTP (à configurer avec vos informations)
        $mail->isSMTP();
        $mail->Host       = 'smtp.ionos.fr'; // Ex: smtp.ionos.fr, smtp.gmail.com
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@monplantfraise.com'; // Votre adresse email complète
        $mail->Password   = 'Lavieestbelle24/*'; // Le mot de passe de votre email
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // ou 'tls'
        $mail->Port       = 465; // ou 587 pour TLS

        // Expéditeur et destinataire
        $mail->setFrom('info@monplantfraise.com', 'Mon Plant Fraise');
        $mail->addAddress($to);

        // Contenu de l'email
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body); // Version texte simple pour les clients mail non-HTML

        $mail->send();
        return true;
    } catch (Exception $e) {
        // En mode développement, vous pouvez afficher l'erreur
        // error_log("Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>