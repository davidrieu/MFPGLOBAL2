<?php
/************************************************************
 * demande_reset.php — Mon Plant Fraise
 * Envoi du lien de réinitialisation via PHPMailer + IONOS
 * Adapté pour reset_mot_de_passe.php fourni
 ************************************************************/

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// ========= PARAMÈTRES SMTP =========
define('SMTP_HOST', 'smtp.ionos.fr');
define('SMTP_USER', 'info@monplantfraise.com');
define('SMTP_PASS', 'Lavieestbelle24/*'); // <-- REMPLACE ICI
define('SMTP_PORT', 587); // STARTTLS
// ===================================

// ========== Chargement PHPMailer (souple) ==========
function load_phpmailer() {
    $base = __DIR__;

    // 1) Composer
    if (is_readable("$base/vendor/autoload.php")) {
        require_once "$base/vendor/autoload.php";
        if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) return true;
    }
    // 2) Arbo standard
    $pathsA = [
        "$base/vendor/phpmailer/phpmailer/src/Exception.php",
        "$base/vendor/phpmailer/phpmailer/src/PHPMailer.php",
        "$base/vendor/phpmailer/phpmailer/src/SMTP.php",
    ];
    $ok = true; foreach ($pathsA as $p) { if (!is_readable($p)) { $ok = false; break; } }
    if ($ok) { require_once $pathsA[0]; require_once $pathsA[1]; require_once $pathsA[2]; return true; }

    // 3) Variante
    $pathsB = [
        "$base/vendor/phpmailer/src/Exception.php",
        "$base/vendor/phpmailer/src/PHPMailer.php",
        "$base/vendor/phpmailer/src/SMTP.php",
    ];
    $ok = true; foreach ($pathsB as $p) { if (!is_readable($p)) { $ok = false; break; } }
    if ($ok) { require_once $pathsB[0]; require_once $pathsB[1]; require_once $pathsB[2]; return true; }

    return false;
}
$PHPMAILER_OK = load_phpmailer();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// use PHPMailer\PHPMailer\SMTP; // décommente pour debug

// ========== DB + session ==========
require_once __DIR__ . '/db_connection.php';
session_start();

// ========== Helpers ==========
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function current_base_url(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host;
}

/** Longueur max de users.reset_token (pour éviter toute troncature) */
function reset_token_maxlen(PDO $pdo): ?int {
    try {
        // TABLE_SCHEMA = base courante
        $q = $pdo->query("SELECT DATABASE()"); $db = $q ? $q->fetchColumn() : null;
        if (!$db) return null;
        $sql = "SELECT CHARACTER_MAXIMUM_LENGTH
                  FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = :db
                   AND TABLE_NAME = 'users'
                   AND COLUMN_NAME = 'reset_token'
                 LIMIT 1";
        $st = $pdo->prepare($sql);
        $st->execute([':db'=>$db]);
        $max = $st->fetchColumn();
        return $max ? (int)$max : null;
    } catch (Throwable $e) {
        error_log('reset_token_maxlen error: '.$e->getMessage());
        return null;
    }
}

/** CSPRNG (fallback si random_bytes indispo) */
function secure_random_bytes_fallback(int $len): string {
    if (function_exists('random_bytes')) return random_bytes($len);
    if (function_exists('openssl_random_pseudo_bytes')) {
        $strong = false;
        $b = openssl_random_pseudo_bytes($len, $strong);
        if ($b !== false && $strong) return $b;
    }
    throw new RuntimeException("Aucune source CSPRNG disponible (random_bytes/openssl).");
}

/** Génère un token hex qui TIENT dans la colonne reset_token existante */
function generate_token_for_column(PDO $pdo): string {
    $maxlen = reset_token_maxlen($pdo); // ex: 64, 50, 32...
    // hex = 2 chars par octet → nb_bytes = floor(maxlen/2)
    if ($maxlen && $maxlen >= 16) { // sécurité minimale
        $bytes = max(8, (int)floor($maxlen / 2)); // min 16 hex chars
    } else {
        // colonne inconnue → on prend 32 octets (64 hex), cas le plus courant
        $bytes = 32;
        $maxlen = 64; // pour eventuel substr safety
    }
    $hex = bin2hex(secure_random_bytes_fallback($bytes));
    if (strlen($hex) > $maxlen) $hex = substr($hex, 0, $maxlen);
    return $hex;
}

// ========== UI ==========
$message = '';
$message_type = ''; // 'success' | 'error'

// ========== Traitement ==========
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
        $email = trim((string)$_POST['email']);

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Veuillez fournir une adresse e-mail valide.';
            $message_type = 'error';
        } else {
            // Recherche utilisateur (réponse générique quoi qu'il arrive)
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Token adapté à la colonne existante
                $token = generate_token_for_column($pdo);

                // Expiration : même fuseau que PHP par défaut (comme reset_mot_de_passe.php)
                $expires_at = (new DateTime('now')) // pas de TZ explicite -> identique à new DateTime() lors de la vérif
                                ->add(new DateInterval('PT1H'))
                                ->format('Y-m-d H:i:s');

                // Sauvegarde
                $upd = $pdo->prepare("
                    UPDATE users
                       SET reset_token = :t,
                           reset_token_expires_at = :e
                     WHERE id = :id
                ");
                $upd->execute([
                    ':t'  => $token,
                    ':e'  => $expires_at,
                    ':id' => (int)$user['id'],
                ]);

                // Lien vers la page existante
                // Lien vers la bonne page de réinitialisation
			$reset_link = rtrim(current_base_url(), '/') . '/reset_password.php?token=' . urlencode($token);


                // Envoi e-mail (si PHPMailer dispo)
                if ($PHPMAILER_OK) {
                    $mail = new PHPMailer(true);
                    try {
                        // $mail->SMTPDebug = SMTP::DEBUG_SERVER; // debug si besoin
                        $mail->isSMTP();
                        $mail->Host       = SMTP_HOST;
                        $mail->SMTPAuth   = true;
                        $mail->Username   = SMTP_USER;
                        $mail->Password   = SMTP_PASS;
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port       = SMTP_PORT;
                        $mail->CharSet    = 'UTF-8';
                        $mail->Encoding   = 'base64';

                        $mail->setFrom(SMTP_USER, 'Mon Plant Fraise');
                        $mail->addAddress($email);
                        $mail->addReplyTo(SMTP_USER, 'Mon Plant Fraise');

                        $mail->isHTML(true);
                        $mail->Subject = 'Réinitialisation de votre mot de passe';
                        $mail->Body = "
                            <div style='font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.6;color:#212121'>
                                <p>Bonjour,</p>
                                <p>Vous avez demandé à réinitialiser votre mot de passe. Cliquez ci-dessous&nbsp;:</p>
                                <p>
                                    <a href='{$reset_link}'
                                       style='display:inline-block;padding:12px 20px;background-color:#2E7D32;color:#ffffff;text-decoration:none;border-radius:8px;font-weight:bold'>
                                        Réinitialiser mon mot de passe
                                    </a>
                                </p>
                                <p>Ce lien est valide pendant une heure.</p>
                                <p>Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.</p>
                            </div>
                        ";
                        $mail->AltBody = "Lien de réinitialisation (valide 1h) : {$reset_link}";

                        $mail->send();
                    } catch (Exception $e) {
                        error_log('PHPMailer error: ' . $mail->ErrorInfo);
                        // on garde la réponse générique
                    }
                } else {
                    error_log('PHPMailer non chargé : email non envoyé (réponse générique affichée).');
                }
            }

            // Réponse générique (anti-énumération)
            if ($message_type !== 'error') {
                $message = "Si un compte est associé à cette adresse, un lien de réinitialisation vient d'être envoyé.";
                $message_type = 'success';
            }
        }
    }
} catch (Throwable $e) {
    error_log('ERREUR FATALE demande_reset.php : ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    // Debug manuel : /demande_reset.php?debug=1
    if (isset($_GET['debug']) && $_GET['debug'] === '1') {
        header('Content-Type: text/plain; charset=utf-8');
        echo "DEBUG ERREUR: " . $e->getMessage() . " @ " . $e->getFile() . ":" . $e->getLine();
        exit;
    }
    $message = "Une erreur inattendue est survenue. Le service est temporairement indisponible.";
    $message_type = 'error';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié - Mon Plant Fraise</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0">

    <style>
        *, *::before, *::after { box-sizing: border-box; }
        :root {
            --primary-color: #2E7D32;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;
            --text-color: #212121;
            --text-color-light: #757575;
            --success-color: #2E7D32;
            --success-bg-color: #e8f5e9;
            --error-color: #c62828;
            --error-bg-color: #ffebee;
            --border-radius: 12px;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--background-color);
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 450px;
            background-color: var(--card-background-color);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
        }
        h2 {
            font-family: 'Poppins', sans-serif;
            font-size: 26px;
            color: var(--text-color);
            margin-top: 0;
            margin-bottom: 10px;
        }
        p { color: var(--text-color-light); margin-bottom: 30px; line-height: 1.6; }
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; color: var(--text-color); font-weight: 500; }
        .input-wrapper { position: relative; }
        .input-wrapper .material-symbols-outlined {
            position: absolute; left: 15px; top: 50%;
            transform: translateY(-50%); color: var(--text-color-light);
        }
        input[type="email"] {
            width: 100%; padding: 12px 12px 12px 45px;
            border: 1px solid #ddd; border-radius: var(--border-radius);
            font-size: 16px; transition: border-color 0.2s, box-shadow 0.2s;
            background-color: #fff;
        }
        input[type="email"]:focus {
            outline: none; border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(46,125,50,0.15);
        }
        .btn-submit {
            width: 100%; padding: 14px; background: var(--primary-gradient);
            color: white; border: none; border-radius: var(--border-radius);
            font-size: 16px; font-weight: 700; cursor: pointer; transition: all 0.2s ease;
        }
        .btn-submit:hover { box-shadow: 0 4px 12px rgba(46,125,50,0.4); transform: translateY(-2px); }
        .message {
            display: flex; align-items: center; gap: 10px; padding: 12px;
            border-radius: var(--border-radius); margin-bottom: 20px; border: 1px solid; text-align: left;
        }
        .message.success { background-color: var(--success-bg-color); color: var(--success-color); border-color: var(--success-color); }
        .message.error { background-color: var(--error-bg-color); color: var(--error-color); border-color: var(--error-color); }
        .links { text-align: center; margin-top: 20px; font-size: 14px; }
        .links a { color: var(--primary-color); text-decoration: none; font-weight: 500; }
        .links a:hover { text-decoration: underline; }
        @media (max-width: 480px) { .container { padding: 25px; } }
    </style>
</head>
<body>
    <div class="container">
        <h2>Mot de passe oublié&nbsp;?</h2>
        <p>Pas de panique. Saisissez votre adresse e-mail et nous vous enverrons un lien pour le réinitialiser.</p>

        <?php if (!empty($message)): ?>
            <div class="message <?= h($message_type) ?>">
                 <span class="material-symbols-outlined">
                    <?= ($message_type === 'success') ? 'check_circle' : 'warning' ?>
                </span>
                <span><?= h($message) ?></span>
            </div>
        <?php endif; ?>

        <form action="demande_reset.php" method="post" autocomplete="email">
            <div class="form-group">
                <label for="email">Votre adresse e-mail</label>
                <div class="input-wrapper">
                    <span class="material-symbols-outlined">mail</span>
                    <input type="email" name="email" id="email" required>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-submit">Envoyer le lien de réinitialisation</button>
            </div>
        </form>

        <div class="links">
            <a href="login.php">Retour à la connexion</a>
        </div>
    </div>
</body>
</html>


