<?php
// Fichier : migration.php (à supprimer après utilisation)

echo "<h1>Début du script de migration des codes parrains...</h1>";

require_once 'db_connection.php';

try {
    // 1. On récupère la liste distincte des parrains et leur code depuis la table `parrainage`
    // Cette requête récupère l'ID du parrain et le code qu'il a utilisé.
    // Si un parrain a plusieurs entrées, on prend la plus récente.
    $sql_select = "SELECT DISTINCT parrain_id, code_parrain FROM parrainage WHERE parrain_id IS NOT NULL";
    
    $stmt_select = $pdo->prepare($sql_select);
    $stmt_select->execute();
    $parrainages_existants = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

    if (empty($parrainages_existants)) {
        echo "<p>Aucun parrainage existant à migrer. L'opération est terminée.</p>";
        exit;
    }

    echo "<p>Found " . count($parrainages_existants) . " parrains à traiter.</p>";

    $pdo->beginTransaction();

    // 2. On prépare la requête pour mettre à jour la table `users`
    $sql_update = "UPDATE users SET code_parrain = :code WHERE id = :user_id AND code_parrain IS NULL";
    $stmt_update = $pdo->prepare($sql_update);

    $count = 0;
    foreach ($parrainages_existants as $parrainage) {
        $user_id = $parrainage['parrain_id'];
        $code = $parrainage['code_parrain'];

        if ($user_id && $code) {
            // On met à jour la table users SEULEMENT si la case `code_parrain` est vide
            $stmt_update->execute(['code' => $code, 'user_id' => $user_id]);
            
            // rowCount() nous dit si la ligne a bien été modifiée
            if ($stmt_update->rowCount() > 0) {
                echo "Utilisateur ID " . $user_id . " mis à jour avec le code : " . $code . "<br>";
                $count++;
            }
        }
    }

    $pdo->commit();

    echo "<h3>Migration terminée !</h3>";
    echo "<p>" . $count . " utilisateurs ont reçu leur code de parrainage personnel.</p>";

} catch (PDOException $e) {
    $pdo->rollBack();
    die("ERREUR LORS DE LA MIGRATION : " . $e->getMessage());
}
?>