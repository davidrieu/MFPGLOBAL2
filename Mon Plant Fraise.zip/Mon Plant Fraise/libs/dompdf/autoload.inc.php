/* ---------- 1) CHARGEMENT DOMPDF (multi-chemins + fallback) ---------- */
$loaded = false;

// A) Vendor isolé (composer) : htdocs/vendor_mpf/autoload.php
$vendorMpf = $baseDir . '/vendor_mpf/autoload.php';
if (file_exists($vendorMpf)) {
    require_once $vendorMpf;
    if (class_exists(\Dompdf\Options::class, false)) $loaded = true;
}

// B) Drop-in htdocs/libs/dompdf/ : autoload.inc.php si présent
if (!$loaded) {
    $dropIn = $baseDir . '/libs/dompdf/autoload.inc.php';
    if (file_exists($dropIn)) {
        require_once $dropIn;
        if (class_exists(\Dompdf\Options::class, false)) $loaded = true;
    } else {
        // Fallback si autoload.inc.php absent : utiliser directement src/Autoloader.php
        $auto = $baseDir . '/libs/dompdf/src/Autoloader.php';
        if (file_exists($auto)) {
            require_once $auto;
            if (class_exists(\Dompdf\Autoloader::class, false)) {
                \Dompdf\Autoloader::register();
                if (class_exists(\Dompdf\Options::class, false)) $loaded = true;
            }
        }
    }
}

// C) Vendor global (lecture seule)
if (!$loaded) {
    $globalCandidates = [
        $baseDir . '/vendor/autoload.php',
        __DIR__ . '/../vendor/autoload.php',
        __DIR__ . '/../../vendor/autoload.php',
        (isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : '') . '/vendor/autoload.php',
    ];
    foreach ($globalCandidates as $p) {
        if ($p && file_exists($p)) {
            require_once $p;
            if (class_exists(\Dompdf\Options::class, false)) { $loaded = true; break; }
        }
    }
}

if (!$loaded) {
    throw new RuntimeException(
        "Dompdf introuvable. Place soit libs/dompdf (avec src/), soit vendor_mpf/, ou assure le vendor global."
    );
}
