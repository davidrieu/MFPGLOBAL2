<?php
declare(strict_types=1);
session_start();

// Accès admin
if (!isset($_SESSION['admin_id'])) { header('Location: /admin/login.php'); exit(); }

require_once __DIR__ . '/../db_connection.php';
if (!isset($pdo) || !$pdo instanceof PDO) { http_response_code(500); echo 'PDO non initialisé.'; exit(); }
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$DEBUG = isset($_GET['debug']) && $_GET['debug'] === '1';
if ($DEBUG) { ini_set('display_errors','1'); error_reporting(E_ALL); }

/* ======================== Utils ======================== */
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function eur($n): string { return ($n === null || $n === '' || !is_numeric($n)) ? '-' : number_format((float)$n, 2, ',', ' ') . ' €'; }
function asDate(?string $s): ?DateTimeImmutable { if (!$s) return null; try { return new DateTimeImmutable($s); } catch(Throwable $e){ return null; } }
function tableExists(PDO $pdo, string $t): bool { try { $pdo->query("SELECT 1 FROM `$t` LIMIT 1"); return true; } catch(Throwable $e){ return false; } }
function columnExists(PDO $pdo, string $t, string $c): bool { try { $pdo->query("SELECT `$c` FROM `$t` LIMIT 1"); return true; } catch(Throwable $e){ return false; } }
function firstExistingTable(PDO $pdo, array $candidates): ?string { foreach ($candidates as $t) if (tableExists($pdo,$t)) return $t; return null; }
function firstExistingColumn(PDO $pdo, string $table, array $candidates): ?string { foreach ($candidates as $c) if (columnExists($pdo,$table,$c)) return $c; return null; }
function isAbonnement(?string $label): bool {
    if (!$label) return false;
    $label = mb_strtolower(trim($label));
    foreach (['abonnement','abonnements','abo','12x','mensuel','subscription','monthly','12 mois','mensualit'] as $p) {
        if (mb_stripos($label, $p) !== false) return true;
    }
    return false;
}

/* =================== Introspection ===================== */
if (!tableExists($pdo,'contrats')) { http_response_code(500); echo "Table 'contrats' introuvable."; exit(); }

$hasTPTable   = tableExists($pdo,'type_paiement');
$hasTPJoinCol = columnExists($pdo,'contrats','type_paiement_id');
$hasTPTextCol = columnExists($pdo,'contrats','type_paiement');

$hasUserId    = columnExists($pdo,'contrats','user_id');
$hasProduitId = columnExists($pdo,'contrats','produit_id');

$hasMontantBase  = columnExists($pdo,'contrats','montant_base');
$hasApport       = columnExists($pdo,'contrats','apport');

/* IMPORTANT: valeur réelle = `montant` (prioritaire), sinon `valeur_reelle` si présent */
$valeurColName   = firstExistingColumn($pdo, 'contrats', ['montant','valeur_reelle']);
$hasValeurReelle = $valeurColName !== null;

$hasDateDebut = columnExists($pdo,'contrats','date_debut');
$hasDateFin   = columnExists($pdo,'contrats','date_fin');
$hasDateSousc = columnExists($pdo,'contrats','date_souscription');
$hasCreatedAt = columnExists($pdo,'contrats','created_at');

/* Colonnes défaut & impayés (création si absentes) */
$hasDefaut = columnExists($pdo,'contrats','defaut_paiement');
if (!$hasDefaut) {
    try { $pdo->exec("ALTER TABLE `contrats` ADD COLUMN `defaut_paiement` TINYINT(1) NOT NULL DEFAULT 0"); $hasDefaut = true; } catch(Throwable $e){ $hasDefaut = false; }
}
$hasImp = columnExists($pdo,'contrats','defaut_impayes');
if (!$hasImp) {
    try { $pdo->exec("ALTER TABLE `contrats` ADD COLUMN `defaut_impayes` INT NOT NULL DEFAULT 0"); $hasImp = true; } catch(Throwable $e){ $hasImp = false; }
}

/* Tables users / produits (+ users.name support) */
$usersTable = $hasUserId ? firstExistingTable($pdo, ['users','utilisateurs','clients','client','user']) : null;
$userIdCol  = $usersTable ? (columnExists($pdo,$usersTable,'id') ? 'id' : null) : null;
$userFirst  = $usersTable ? firstExistingColumn($pdo,$usersTable,['prenom','first_name','firstname','firstName','given_name','name']) : null;
$userLast   = $usersTable ? firstExistingColumn($pdo,$usersTable,['nom','last_name','lastname','lastName','family_name','name']) : null;

$prodTable  = $hasProduitId ? firstExistingTable($pdo, ['produits','product','products','offres','plans']) : null;
$prodIdCol  = $prodTable ? (columnExists($pdo,$prodTable,'id') ? 'id' : null) : null;
$prodName   = $prodTable ? firstExistingColumn($pdo,$prodTable,['name','nom','titre','title','label']) : null;

/* ==================== AJAX ====================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['admin_id'])) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Accès refusé']); exit; }
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    if ($id <= 0) { echo json_encode(['ok'=>false,'error'=>'ID invalide']); exit; }

    // MAJ montants
    if ($_POST['action']==='update_amounts') {
        $mensu        = isset($_POST['mensualite']) ? trim((string)$_POST['mensualite']) : null;
        $montant_base = isset($_POST['montant_base']) ? trim((string)$_POST['montant_base']) : null;
        $apport       = isset($_POST['apport']) ? trim((string)$_POST['apport']) : null;
        $valeur       = isset($_POST['valeur_reelle']) ? trim((string)$_POST['valeur_reelle']) : null;

        $toUpdate = []; $params = [':id'=>$id];

        if ($hasMontantBase) {
            if ($montant_base !== null && $montant_base !== '' && is_numeric($montant_base)) {
                $toUpdate[] = 'montant_base = :mb'; $params[':mb'] = (float)$montant_base;
            } elseif ($mensu !== null && $mensu !== '' && is_numeric($mensu)) {
                $toUpdate[] = 'montant_base = :mb'; $params[':mb'] = round(((float)$mensu) * 12, 2);
            }
        }
        if ($hasApport && $apport !== null && $apport !== '' && is_numeric($apport)) {
            $toUpdate[] = 'apport = :apport'; $params[':apport'] = (float)$apport;
        }
        if ($hasValeurReelle && $valeur !== null && $valeur !== '' && is_numeric($valeur)) {
            $toUpdate[] = "`$valeurColName` = :valeur"; $params[':valeur'] = (float)$valeur;
        }

        if (!$toUpdate) { echo json_encode(['ok'=>false,'error'=>'Aucune valeur valide à mettre à jour']); exit; }
        try {
            $sqlU = "UPDATE contrats SET ".implode(', ',$toUpdate)." WHERE id = :id";
            $pdo->prepare($sqlU)->execute($params);

            // Refresh
            $cols = [];
            if ($hasMontantBase) $cols[] = 'montant_base';
            if ($hasApport)      $cols[] = 'apport';
            if ($hasValeurReelle)$cols[] = "`$valeurColName` AS valeur_reelle_db";
            $sqlR = "SELECT ".implode(', ', $cols ?: ['id'])." FROM contrats WHERE id=:id";
            $row  = $pdo->prepare($sqlR); $row->execute([':id'=>$id]);
            $fresh = $row->fetch(PDO::FETCH_ASSOC) ?: [];

            $mb = $hasMontantBase && isset($fresh['montant_base']) && is_numeric($fresh['montant_base']) ? (float)$fresh['montant_base'] : null;
            $mensuNew = $mb !== null ? round($mb / 12, 2) : (is_numeric($mensu) ? (float)$mensu : null);

            echo json_encode([
                'ok'=>true,
                'mensualite'   => $mensuNew,
                'montant_base' => $mb,
                'apport'       => $hasApport && isset($fresh['apport']) ? (float)$fresh['apport'] : null,
                'valeur_reelle'=> $hasValeurReelle && isset($fresh['valeur_reelle_db']) ? (float)$fresh['valeur_reelle_db'] : (is_numeric($valeur)?(float)$valeur:null),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok'=>false,'error'=>'Erreur SQL','detail'=>$e->getMessage()]);
        }
        exit;
    }

    // Marquer défaut / régulariser + impayés
    if (in_array($_POST['action'], ['set_defaut','clear_defaut'], true)) {
        if (!$hasDefaut || !$hasImp) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>"Colonnes 'defaut_paiement' / 'defaut_impayes' absentes."]); exit; }
        $val = $_POST['action']==='set_defaut' ? 1 : 0;

        $imp = 0;
        if ($val === 1) {
            $imp = isset($_POST['impayes']) ? (int)$_POST['impayes'] : 0;
            if ($imp < 1) { echo json_encode(['ok'=>false,'error'=>'Nombre d’impayés invalide']); exit; }
        }

        try {
            $stmt = $pdo->prepare("UPDATE contrats SET defaut_paiement = :v, defaut_impayes = :i WHERE id = :id");
            $stmt->execute([':v'=>$val, ':i'=>$imp, ':id'=>$id]);

            // Totaux défaut
            $join = ($hasTPTable && $hasTPJoinCol) ? " LEFT JOIN type_paiement tp ON tp.id=c.type_paiement_id " : "";
            $whereAbo = ($hasTPTable && $hasTPJoinCol)
                ? " (tp.name LIKE '%abon%' OR tp.name LIKE '%mensu%' OR tp.name LIKE '%subs%') "
                : ($hasTPTextCol ? " (c.type_paiement LIKE '%abon%' OR c.type_paiement LIKE '%mensu%' OR c.type_paiement LIKE '%subs%') " : " 1=1 ");

            $countDef = (int)$pdo->query("SELECT COUNT(*) FROM contrats c $join WHERE c.defaut_paiement=1 AND $whereAbo")->fetchColumn();
            $sumImp = (int)$pdo->query("SELECT COALESCE(SUM(c.defaut_impayes),0) FROM contrats c $join WHERE c.defaut_paiement=1 AND $whereAbo")->fetchColumn();

            $sumEuros = 0.0;
            if ($hasMontantBase) {
                $sumEuros = (float)$pdo->query("SELECT COALESCE(SUM( (c.montant_base/12.0) * c.defaut_impayes ),0) FROM contrats c $join WHERE c.defaut_paiement=1 AND $whereAbo")->fetchColumn();
            }

            echo json_encode(['ok'=>true, 'defaut'=> (int)$val, 'count_defaut'=>$countDef, 'sum_impayes'=>$sumImp, 'sum_euros'=>$sumEuros ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok'=>false,'error'=>'Erreur SQL','detail'=>$e->getMessage()]);
        }
        exit;
    }

    echo json_encode(['ok'=>false,'error'=>'Action inconnue']); exit;
}

/* ==================== Requête SQL ====================== */
$select = ['c.id AS id'];
if ($hasUserId)       $select[] = 'c.user_id';
if ($hasProduitId)    $select[] = 'c.produit_id';
if ($hasMontantBase)  $select[] = 'c.montant_base';
if ($hasApport)       $select[] = 'c.apport';
if ($hasValeurReelle) $select[] = "c.`$valeurColName` AS valeur_reelle_db";
if ($hasDefaut)       $select[] = 'c.defaut_paiement';
if ($hasImp)          $select[] = 'c.defaut_impayes';
if ($hasDateDebut)    $select[] = 'c.date_debut';
if ($hasDateFin)      $select[] = 'c.date_fin';
if ($hasDateSousc)    $select[] = 'c.date_souscription';
if ($hasCreatedAt)    $select[] = 'c.created_at';

$joins = [];
if ($hasTPTable && $hasTPJoinCol) {
    $joins[] = 'LEFT JOIN type_paiement tp ON tp.id = c.type_paiement_id';
    $select[] = 'tp.name AS type_paiement_label';
} elseif ($hasTPTextCol) {
    $select[] = 'c.type_paiement AS type_paiement_label';
} else {
    $select[] = 'NULL AS type_paiement_label';
}
if ($usersTable && $userIdCol) {
    $joins[] = "LEFT JOIN `$usersTable` u ON u.`$userIdCol` = c.user_id";
    if ($userFirst) $select[] = "u.`$userFirst` AS user_first";
    if ($userLast)  $select[] = "u.`$userLast`  AS user_last";
}
if ($prodTable && $prodIdCol) {
    $joins[] = "LEFT JOIN `$prodTable` p ON p.`$prodIdCol` = c.produit_id";
    if ($prodName) $select[] = "p.`$prodName` AS produit_name";
}

$sql = "SELECT " . implode(",\n       ", $select) . "\nFROM contrats c" . (count($joins)? "\n" . implode("\n",$joins) : "");

/* =================== Chargement brut =================== */
try {
    $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    echo $DEBUG ? "<pre>SQL ERROR:\n".$e->getMessage()."\n\n".$sql."</pre>" : "Chargement impossible.";
    exit();
}

/* ============= Normalisation + filtre abo ============== */
$today = new DateTimeImmutable('today');

function fullName(array $r): string {
    $first = trim((string)($r['user_first'] ?? ''));
    $last  = trim((string)($r['user_last']  ?? ''));
    $parts = array_filter([$first, $last], fn($s)=>$s!=='');
    $fn = trim(implode(' ', array_unique($parts)));
    if ($fn !== '') return $fn;
    if (!empty($r['user_id'])) return 'Utilisateur #'.$r['user_id'];
    return 'Utilisateur';
}
function productLabel(array $r): string {
    if (!empty($r['produit_name'])) return (string)$r['produit_name'];
    if (!empty($r['produit_id'])) return 'Produit #'.$r['produit_id'];
    return 'Produit';
}
function computeDates(array $r): array {
    $dateDebut = null;
    if (array_key_exists('date_debut',$r))                      $dateDebut = asDate($r['date_debut'] ?? null);
    if (!$dateDebut && array_key_exists('date_souscription',$r)) $dateDebut = asDate($r['date_souscription'] ?? null);
    if (!$dateDebut && array_key_exists('created_at',$r))         $dateDebut = asDate($r['created_at'] ?? null);

    $dateFin = null;
    if (array_key_exists('date_fin',$r)) $dateFin = asDate($r['date_fin'] ?? null);
    if (!$dateFin && $dateDebut) { try { $dateFin = $dateDebut->modify('+12 months'); } catch(Throwable $e){} }
    return [$dateDebut,$dateFin];
}
function statutAbo(?DateTimeImmutable $deb, ?DateTimeImmutable $fin, DateTimeImmutable $today): string {
    if ($deb && $fin) {
        if ($today < $deb) return 'À venir';
        if ($today < $fin) return 'En cours';
        return 'Terminé';
    }
    return 'Inconnu';
}
function remainingLabel(DateTimeImmutable $today, ?DateTimeImmutable $deb, ?DateTimeImmutable $fin, string $statut): array {
    if ($statut === 'En cours' && $fin) {
        $days = (int)$today->diff($fin)->format('%r%a');
        if ($days <= 0) return ['0 j', 0, 'j'];
        if ($days < 30) return [$days.' j', $days, 'j'];
        $months = (int)ceil($days / 30);
        return [$months.' mois', $months, 'mois'];
    } elseif ($statut === 'À venir' && $deb) {
        $days = (int)$today->diff($deb)->format('%r%a');
        if ($days <= 0) return ['0 j', 0, 'j'];
        if ($days < 30) return ['dans '.$days.' j', $days, 'j'];
        $months = (int)ceil($days / 30);
        return ['dans '.$months.' mois', $months, 'mois'];
    } elseif ($statut === 'Terminé') {
        return ['Terminé', 0, 'j'];
    }
    return ['—', 0, ''];
}

$rawAbos = [];
foreach ($rows as $r) {
    $typeLabel = $r['type_paiement_label'] ?? null;
    if (!isAbonnement($typeLabel)) continue;

    [$dateDebut,$dateFin] = computeDates($r);
    $statut = statutAbo($dateDebut,$dateFin,$today);

    $montantBase = $hasMontantBase ? ($r['montant_base'] ?? null) : null;
    $mensualite  = ($montantBase !== null && $montantBase !== '' && is_numeric($montantBase)) ? round(((float)$montantBase)/12, 2) : null;
    $valeurReelle = $hasValeurReelle ? ($r['valeur_reelle_db'] ?? null) : null;

    $defaut = $hasDefaut ? (int)($r['defaut_paiement'] ?? 0) : 0;
    $imp    = $hasImp ? (int)($r['defaut_impayes'] ?? 0) : 0;

    $rawAbos[] = [
        'id'            => $r['id'] ?? null,
        'client'        => fullName($r),
        'user_id'       => $r['user_id'] ?? null,
        'produit'       => productLabel($r),
        'produit_id'    => $r['produit_id'] ?? null,
        'type_label'    => $typeLabel,
        'montant_base'  => $montantBase,
        'apport'        => $hasApport ? ($r['apport'] ?? null) : null,
        'valeur_reelle' => $valeurReelle,
        'date_debut'    => $dateDebut,
        'date_fin'      => $dateFin,
        'date_sous'     => isset($r['date_souscription']) ? asDate($r['date_souscription']) : null,
        'created_at'    => isset($r['created_at']) ? asDate($r['created_at']) : null,
        'statut'        => $statut,
        'mensualite'    => $mensualite,
        'defaut'        => $defaut,
        'impayes'       => $imp,
    ];
}

/* ===== Totaux ===== */
$sumMensuelEnCours  = 0.0; $sumMensuelTermines = 0.0; $countEnCours = 0; $countTermines = 0; $countDefaut = 0;
$totalImpCount = 0; $totalImpEuros = 0.0;

foreach ($rawAbos as $a) {
    $m = is_numeric($a['mensualite'] ?? null) ? (float)$a['mensualite'] : 0.0;
    if ($a['statut'] === 'En cours') { $sumMensuelEnCours += $m; $countEnCours++; }
    if ($a['statut'] === 'Terminé')  { $sumMensuelTermines += $m; $countTermines++; }
    if ((int)$a['defaut'] === 1) {
        $countDefaut++;
        $imp = (int)($a['impayes'] ?? 0);
        if ($imp > 0) {
            $totalImpCount += $imp;
            $totalImpEuros += $m * $imp;
        }
    }
}

/* ===== Prévision 6 mois ===== */
$moisFr = ['janv.','févr.','mars','avr.','mai','juin','juil.','août','sept.','oct.','nov.','déc.'];
$firstMonth = (new DateTimeImmutable('first day of this month'))->setTime(0,0,0);
$forecastLabels = []; $forecastValues = []; $forecastList   = [];
for ($i = 0; $i < 6; $i++) {
    $monthStart = $firstMonth->modify("+{$i} months");
    $nextMonthStart = $firstMonth->modify("+".($i+1)." months");
    $labelTxt = $moisFr[(int)$monthStart->format('n')-1] . ' ' . $monthStart->format('Y');

    $sum = 0.0;
    foreach ($rawAbos as $a) {
        $m = is_numeric($a['mensualite'] ?? null) ? (float)$a['mensualite'] : 0.0;
        $deb = $a['date_debut'] ?? null;
        $fin = $a['date_fin'] ?? null;
        if (!$deb || !$fin) continue;
        if ($deb < $nextMonthStart && $fin > $monthStart) $sum += $m;
    }
    $forecastLabels[] = $labelTxt;
    $forecastValues[] = round($sum, 2);
    $forecastList[]   = ['label'=>$labelTxt, 'sum'=>$sum];
}

/* ================ Filtre / Tri =================== */
$filtre = $_GET['filtre'] ?? 'en_cours';
$filtre = in_array($filtre, ['en_cours','a_venir','passes','a_relancer','tous'], true) ? $filtre : 'en_cours';

$abos = array_values(array_filter($rawAbos, function($a) use ($filtre){
    if ($filtre==='tous')       return true;
    if ($filtre==='en_cours')   return $a['statut']==='En cours';
    if ($filtre==='a_venir')    return $a['statut']==='À venir';
    if ($filtre==='passes')     return $a['statut']==='Terminé';
    if ($filtre==='a_relancer') return (int)$a['defaut']===1;
    return true;
}));

/* Pré-calculs UI */
foreach ($abos as &$a) {
    $nbJours = 0;

    if ($a['date_fin'] instanceof DateTimeInterface) {
        $today   = new DateTimeImmutable('today');
        $nbJours = (int) $today->diff($a['date_fin'])->format('%r%a');
    }

    $a['_jours_restants'] = $nbJours;
    $a['_ts_fin'] = ($a['date_fin'] instanceof DateTimeInterface)
        ? $a['date_fin']->getTimestamp()
        : 0;
}
unset($a);


/* ================== Debug (opt) ================== */
$debugPanel = '';
if ($DEBUG) {
    ob_start();
    echo "<details style='margin:12px'><summary><b>[DEBUG] Abonnements — Cartographie & SQL</b></summary><pre>";
    echo "SQL:\n$sql\n\n";
    echo "Users table: ".($usersTable ?: '—')." | first: ".($userFirst?:'—')." | last: ".($userLast?:'—')."\n";
    echo "Produits table: ".($prodTable ?: '—')." | name: ".($prodName?:'—')."\n";
    echo "Col. valeur réelle: ".($valeurColName ?: '—')."\n";
    echo "Abonnements détectés: ".count($rawAbos)."\n";
    echo "Somme mensuelle En cours: ".number_format($sumMensuelEnCours,2,',',' ')." € (".$countEnCours." abos)\n";
    echo "Somme mensuelle Terminés: ".number_format($sumMensuelTermines,2,',',' ')." € (".$countTermines." abos)\n";
    echo "Défaut: ".$countDefaut." | Impayés: ".$totalImpCount." | € impayé: ".number_format($totalImpEuros,2,',',' ')." €\n";
    echo "Prévision 6 mois:\n";
    foreach ($forecastList as $f) { echo "- {$f['label']} : ".number_format($f['sum'],2,',',' ')." €\n"; }
    echo "Affichés (filtre={$filtre}): ".count($abos)."\n";
    echo "</pre></details>";
    $debugPanel = ob_get_clean();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Suivi récurrent — Abonnements</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    :root{--primary-color:#4CAF50;--primary-color-dark:#388E3C;--secondary-color:#6c757d;--text-color:#333;--text-color-light:#757575;--background-color:#f5f5f5;--card-background-color:#fff;--border-radius:12px;--box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.24);--danger:#ef4444;--warning:#f59e0b;--ok:#10b981}
    @media (prefers-color-scheme:dark){:root{--background-color:#0e1116;--card-background-color:#151922;--text-color:#e5e7eb;--text-color-light:#9ca3af;--box-shadow:0 1px 3px rgba(0,0,0,.6),0 1px 2px rgba(0,0,0,.4);--secondary-color:#94a3b8}}
    *{box-sizing:border-box}
    body{background:var(--background-color);font-family:'Roboto',Arial,sans-serif;margin:0;display:flex;color:var(--text-color)}
    .sidebar{background:var(--card-background-color);width:260px;height:100vh;padding:20px;position:fixed;top:0;left:0;box-shadow:0 2px 10px rgba(0,0,0,.1);display:flex;flex-direction:column;z-index:1000}
    .sidebar-header{margin-bottom:30px;text-align:center;font-size:1.5em;font-weight:700;color:var(--primary-color)}
    .sidebar ul{list-style:none;padding:0;margin:0}
    .sidebar ul li a{display:flex;align-items:center;padding:12px 10px;margin-bottom:8px;text-decoration:none;color:var(--text-color-light);border-radius:10px;font-weight:500;transition:background-color .2s ease,color .2s ease}
    .sidebar ul li a .material-symbols-outlined{margin-right:12px;font-size:22px}
    .sidebar ul li a:hover,.sidebar ul li a.active{background:var(--primary-color);color:#fff}
    .main-container{margin-left:280px;padding:20px;width:calc(100% - 320px)}
    @media (max-width:980px){.sidebar{transform:translateX(-100%);position:fixed}.main-container{margin:0;width:100%}}

    .header-row{display:flex;gap:12px;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap}
    .header-row h1{font-size:22px;font-weight:600;margin:0;display:flex;align-items:center;gap:8px}
    .filters{display:flex;gap:8px;flex-wrap:wrap}
    .chip{display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;border:1px solid #e5e7eb;background:#fafafa;color:#374151;font-size:13px;text-decoration:none;position:relative}
    .chip .material-symbols-outlined{font-size:18px}
    .chip.active{background:var(--primary-color);color:#fff;border-color:transparent}
    .badge{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 6px;border-radius:999px;background:#ef4444;color:#fff;font-size:11px;font-weight:700;margin-left:6px}
    @media (prefers-color-scheme:dark){.chip{background:#0b1220;border-color:#1f2937;color:#cbd5e1}}

    .action-bar{position:sticky;top:10px;z-index:50;margin-bottom:14px}
    .action-inner{display:grid;grid-template-columns:1fr auto auto auto;gap:8px}
    @media (max-width:720px){.action-inner{grid-template-columns:1fr 1fr}}
    .control{background:var(--card-background-color);border:1px solid #e5e7eb;border-radius:10px;padding:10px 12px;display:flex;align-items:center;gap:8px}
    .control input,.control select{border:none;outline:none;background:transparent;color:var(--text-color);width:100%;font-size:14px}
    .btn{background:var(--card-background-color);border:1px solid #e5e7eb;border-radius:10px;padding:10px 12px;display:inline-flex;align-items:center;gap:8px;cursor:pointer;text-decoration:none;color:var(--text-color)}
    .btn:hover{box-shadow:var(--box-shadow)}
    .btn.primary{background:var(--primary-color);color:#fff;border-color:transparent}
    .btn-mini{padding:6px 8px;border-radius:8px;font-size:12px;display:inline-flex;align-items:center;gap:6px;border:1px solid #e5e7eb;background:#fff}
    .btn-mini.danger{color:#ef4444;border-color:#fecaca;background:#fff5f5}
    .btn-mini.ok{color:#10b981;border-color:#bbf7d0;background:#f0fdf4}
    .btn-mini .material-symbols-outlined{font-size:16px}

    .kpis{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));margin-bottom:12px}
    .kpi-card{background:var(--card-background-color);border-radius:12px;box-shadow:var(--box-shadow);padding:16px 18px;display:flex;align-items:center;gap:14px;border:1px solid #e5e7eb}
    .kpi-card .icon{font-size:28px;color:var(--primary-color)}
    .kpi-card .value{font-size:20px;font-weight:700}
    .kpi-card .label{font-size:13px;color:var(--text-color-light)}
    .kpi-card .hint{font-size:12px;color:var(--text-color-light);margin-top:4px}

    .grid{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(280px,1fr))}
    .list{display:flex;flex-direction:column;gap:8px}
    .abo-card,.abo-row{background:var(--card-background-color);border-radius:12px;box-shadow:var(--box-shadow);border:1px solid #e5e7eb;transition:transform .06s ease,box-shadow .2s ease}
    .abo-card:hover,.abo-row:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(0,0,0,.08)}
    .abo-card{padding:14px;display:flex;flex-direction:column;gap:8px;cursor:pointer;position:relative}
    .abo-title{font-weight:600;font-size:16px;display:flex;align-items:center;gap:8px}
    .abo-title .material-symbols-outlined{color:var(--primary-color)}
    .abo-line{display:flex;justify-content:space-between;font-size:14px;align-items:center;gap:10px}
    .muted{color:var(--text-color-light)}
    .pill{background:#f7f7f7;border:1px solid #eee;border-radius:999px;padding:4px 8px;font-variant-numeric:tabular-nums}
    .status{font-size:12px;border-radius:999px;padding:4px 8px;border:1px solid #eee;background:#f7f7f7;display:inline-flex;align-items:center;gap:4px}
    .prog{height:6px;background:#e5e7eb;border-radius:999px;overflow:hidden}
    .prog>span{display:block;height:100%;background:linear-gradient(90deg,var(--primary-color),#86efac);width:0%}
    .row-actions{display:flex;gap:6px;flex-wrap:wrap}
    .abo-row{display:grid;grid-template-columns:1.2fr 1fr 1fr 1fr 0.8fr;gap:10px;padding:10px 12px;align-items:center;cursor:pointer}
    @media (max-width:880px){.abo-row{grid-template-columns:1.4fr 1fr 1fr}.abo-row .hide-md{display:none}}
    .empty{padding:18px;border:1px dashed #cbd5e1;border-radius:12px;text-align:center;color:var(--text-color-light)}

    .card{background:var(--card-background-color);border-radius:12px;box-shadow:var(--box-shadow);padding:16px 18px;border:1px solid #e5e7eb;margin-bottom:12px}
    .card h3{margin:0 0 8px;font-weight:600;font-size:18px;display:flex;align-items:center;gap:8px}
    .chart-container{position:relative;height:260px}
    .forecast-list{display:grid;gap:6px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-top:8px}
    .forecast-item{display:flex;justify-content:space-between;font-size:14px;border:1px dashed #eee;border-radius:10px;padding:6px 10px}

    .modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.4);display:none;align-items:flex-end;justify-content:center;z-index:2000}
    .modal{background:#fff;width:min(820px,96%);max-height:90vh;border-radius:10px 10px 0 0;box-shadow:0 10px 30px rgba(0,0,0,.2);overflow:auto}
    @media (min-width:900px){.modal-backdrop{align-items:center}.modal{border-radius:12px}}
    .modal header{position:sticky;top:0;background:#fff;padding:12px 14px;border-bottom:1px solid #eee;display:flex;align-items:center;justify-content:space-between;z-index:1}
    .modal header h3{margin:0;font-size:18px;display:flex;align-items:center;gap:8px}
    .modal .close{background:none;border:none;cursor:pointer;font-size:24px;line-height:1}
    .modal .content{padding:14px;display:grid;gap:12px}
    .details-grid{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
    .detail{background:#fafafa;border:1px solid #eee;border-radius:10px;padding:10px}
    .detail .label{font-size:12px;color:var(--text-color-light);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px}
    .detail .value{font-size:15px}
    .edit-grid{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
    .field{display:flex;flex-direction:column;gap:6px}
    .field label{font-size:12px;color:var(--text-color-light)}
    .field input{padding:9px 10px;border-radius:10px;border:1px solid #e5e7eb;background:#fff;font-size:14px}
    .modal .footer{display:flex;justify-content:flex-end;gap:8px;padding:8px 0 2px}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" aria-label="Menu latéral">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="gestion_documents.php"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="rendez_vous.php"><span class="material-symbols-outlined">event</span>Gestion RDV</a></li>
        <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="remboursement.php"><span class="material-symbols-outlined">payments</span>Remboursement</a></li>
        <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="codepromo.php"><span class="material-symbols-outlined">sell</span>Codes Promo</a></li>
        <li><a href="virements.php"><span class="material-symbols-outlined">paid</span>Gestion Virements</a></li>
        <li><a href="abonnements.php" class="active"><span class="material-symbols-outlined">paid</span>Suivi récurrent</a></li>
        <li><a href="parametres.php"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="main-container">
    <div class="header-row">
        <h1><span class="material-symbols-outlined">paid</span>Suivi récurrent — Abonnements</h1>
        <div class="filters" role="tablist" aria-label="Filtres d'état">
            <?php
              $base = strtok($_SERVER['REQUEST_URI'], '?') ?: 'abonnements.php';
              $mk = fn($f) => h($base.'?filtre='.$f.($DEBUG?'&debug=1':''));
              $active = fn($f) => (isset($_GET['filtre']) ? $_GET['filtre'] : 'en_cours') === $f ? 'chip active' : 'chip';
            ?>
            <a class="<?= $active('en_cours') ?>" href="<?= $mk('en_cours') ?>" role="tab"><span class="material-symbols-outlined">play_circle</span>En cours</a>
            <a class="<?= $active('a_venir')  ?>" href="<?= $mk('a_venir')  ?>" role="tab"><span class="material-symbols-outlined">schedule</span>À venir</a>
            <a class="<?= $active('passes')   ?>" href="<?= $mk('passes')   ?>" role="tab"><span class="material-symbols-outlined">flag</span>Terminés</a>
            <a class="<?= $active('a_relancer') ?>" href="<?= $mk('a_relancer') ?>" role="tab">
              <span class="material-symbols-outlined" style="color:#ef4444">priority_high</span>À relancer
              <span class="badge" id="badge-defaut" aria-label="en défaut"><?= (int)$countDefaut ?></span>
            </a>
            <a class="<?= $active('tous')     ?>" href="<?= $mk('tous')     ?>" role="tab"><span class="material-symbols-outlined">all_inclusive</span>Tous</a>
        </div>
    </div>

    <?php if ($DEBUG) echo $debugPanel; ?>

    <!-- KPI Totaux -->
    <div class="kpis" aria-label="Totaux mensuels">
      <div class="kpi-card">
        <span class="material-symbols-outlined icon">payments</span>
        <div>
          <div class="value"><?= eur($sumMensuelEnCours) ?></div>
          <div class="label">Total mensuel — <b>En cours</b></div>
          <div class="hint"><?= (int)$countEnCours ?> abonnement(s)</div>
        </div>
      </div>
      <div class="kpi-card">
        <span class="material-symbols-outlined icon">check_circle</span>
        <div>
          <div class="value"><?= eur($sumMensuelTermines) ?></div>
          <div class="label">Total mensuel — <b>Terminés</b></div>
          <div class="hint"><?= (int)$countTermines ?> abonnement(s)</div>
        </div>
      </div>
      <div class="kpi-card" title="Somme des mensualités impayées sur les contrats en défaut">
        <span class="material-symbols-outlined icon" style="color:#ef4444">report</span>
        <div>
          <div class="value"><?= eur($totalImpEuros) ?></div>
          <div class="label">Impayés — <b>À relancer</b></div>
          <div class="hint"><?= (int)$totalImpCount ?> mensualité(s) — <?= (int)$countDefaut ?> contrat(s)</div>
        </div>
      </div>
    </div>

    <!-- Prévision 6 mois -->
    <div class="card" aria-labelledby="forecast-title">
      <h3 id="forecast-title"><span class="material-symbols-outlined" style="color:var(--primary-color)">trending_up</span>Prévision des mensualités — 6 prochains mois</h3>
      <div class="chart-container"><canvas id="forecastChart"></canvas></div>
      <div class="forecast-list" aria-live="polite">
        <?php foreach ($forecastList as $f): ?>
          <div class="forecast-item"><span><?= h($f['label']) ?></span><strong><?= eur($f['sum']) ?></strong></div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- CARTES -->
    <div id="cardsView" class="grid" role="list">
      <?php if (!$abos): ?>
        <div class="empty">Aucun abonnement à afficher.</div>
      <?php else: ?>
        <?php foreach ($abos as $a):
          $statut = $a['statut'];
          [$remTxt] = remainingLabel($today, $a['date_debut'], $a['date_fin'], $statut);
          $icon = $statut==='En cours' ? 'play_circle' : ($statut==='À venir' ? 'schedule' : 'flag');
          $color = $statut==='En cours' ? '#10b981' : ($statut==='À venir' ? '#f59e0b' : '#ef4444');
          $deb = $a['date_debut'] instanceof DateTimeInterface ? $a['date_debut']->format('Y-m-d') : '';
          $fin = $a['date_fin']   instanceof DateTimeInterface ? $a['date_fin']->format('Y-m-d')   : '';
          $pct = 0;
          if ($a['date_debut'] instanceof DateTimeInterface && $a['date_fin'] instanceof DateTimeInterface) {
              $totalDays = max(1, (int)$a['date_debut']->diff($a['date_fin'])->format('%a'));
              $elapsed   = max(0, (int)$a['date_debut']->diff($today)->format('%a'));
              $pct = min(100, max(0, round(($elapsed / $totalDays) * 100)));
          }
          $mensu = is_numeric($a['mensualite'] ?? null) ? (float)$a['mensualite'] : 0.0;
          $joursRestants = (int)$a['_jours_restants'];
          $valeur = is_numeric($a['valeur_reelle'] ?? null) ? (float)$a['valeur_reelle'] : null;
          $mb     = is_numeric($a['montant_base'] ?? null) ? (float)$a['montant_base'] : null;
          $ap     = is_numeric($a['apport'] ?? null) ? (float)$a['apport'] : null;
          $defaut = (int)($a['defaut'] ?? 0) === 1;
          $imp    = (int)($a['impayes'] ?? 0);
        ?>
        <article class="abo-card" role="listitem" tabindex="0"
          data-id="<?= h((string)$a['id']) ?>"
          data-client="<?= h($a['client']) ?>"
          data-user-id="<?= h((string)($a['user_id'] ?? '')) ?>"
          data-produit="<?= h($a['produit']) ?>"
          data-produit-id="<?= h((string)($a['produit_id'] ?? '')) ?>"
          data-type="<?= h($a['type_label'] ?? '-') ?>"
          data-mensualite="<?= h((string)$mensu) ?>"
          data-montant-base="<?= h((string)($mb ?? '')) ?>"
          data-apport="<?= h((string)($ap ?? '')) ?>"
          data-valeur-reelle="<?= h((string)($valeur ?? '')) ?>"
          data-statut="<?= h($statut) ?>"
          data-debut="<?= h($deb) ?>"
          data-fin="<?= h($fin) ?>"
          data-remainingdays="<?= h((string)$joursRestants) ?>"
          data-tsfin="<?= h((string)$a['_ts_fin']) ?>"
          data-defaut="<?= $defaut ? '1':'0' ?>"
          data-impayes="<?= h((string)$imp) ?>"
        >
          <div class="abo-title"><span class="material-symbols-outlined"><?= $icon ?></span><span><?= h($a['produit']) ?></span></div>
          <div class="abo-line"><span class="muted">Client</span><strong><?= h($a['client']) ?></strong></div>
          <div class="abo-line"><span class="muted">Mensualité</span><span class="pill"><?= eur($mensu) ?></span></div>
          <div class="abo-line"><span class="muted">Durée restante</span><strong><?= h($remTxt) ?></strong></div>
          <div class="abo-line">
            <span class="muted">Statut</span>
            <span class="status" style="color:<?= $color ?>"><span class="material-symbols-outlined"><?= $icon ?></span><?= h($statut) ?></span>
          </div>
          <div class="prog" aria-label="Progression de l'abonnement"><span style="width:<?= (int)$pct ?>%"></span></div>
          <div class="row-actions" style="margin-top:6px">
            <?php if ($defaut): ?>
              <button type="button" class="btn-mini ok action-regularise" data-id="<?= h((string)$a['id']) ?>" title="Marquer comme régularisé">
                <span class="material-symbols-outlined">done_all</span>Régularisé
              </button>
            <?php else: ?>
              <button type="button" class="btn-mini danger action-defaut" data-id="<?= h((string)$a['id']) ?>" title="Déclarer défaut de paiement">
                <span class="material-symbols-outlined">report</span>Déclarer défaut
              </button>
            <?php endif; ?>
          </div>
        </article>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- LISTE -->
    <div id="listView" class="list" style="display:none" role="table" aria-label="Table des abonnements">
      <?php if (!$abos): ?>
        <div class="empty">Aucun abonnement à afficher.</div>
      <?php else: ?>
        <div class="abo-row" role="row" style="background:transparent;border:none;font-weight:600;">
          <div role="columnheader">Client</div>
          <div role="columnheader">Produit</div>
          <div role="columnheader">Mensualité</div>
          <div role="columnheader" class="hide-md">Fin</div>
          <div role="columnheader" class="hide-md">Actions</div>
        </div>
        <?php foreach ($abos as $a):
          $statut = $a['statut'];
          [$remTxt] = remainingLabel($today, $a['date_debut'], $a['date_fin'], $statut);
          $fin = $a['date_fin']   instanceof DateTimeInterface ? $a['date_fin']->format('Y-m-d')   : '';
          $mensu = is_numeric($a['mensualite'] ?? null) ? (float)$a['mensualite'] : 0.0;
          $defaut = (int)($a['defaut'] ?? 0) === 1;
          $imp    = (int)($a['impayes'] ?? 0);
        ?>
        <div class="abo-row" role="row" tabindex="0"
             data-id="<?= h((string)$a['id']) ?>"
             data-client="<?= h($a['client']) ?>"
             data-user-id="<?= h((string)($a['user_id'] ?? '')) ?>"
             data-produit="<?= h($a['produit']) ?>"
             data-produit-id="<?= h((string)($a['produit_id'] ?? '')) ?>"
             data-type="<?= h($a['type_label'] ?? '-') ?>"
             data-mensualite="<?= h((string)$mensu) ?>"
             data-montant-base="<?= h((string)($a['montant_base'] ?? '')) ?>"
             data-apport="<?= h((string)($a['apport'] ?? '')) ?>"
             data-valeur-reelle="<?= h((string)($a['valeur_reelle'] ?? '')) ?>"
             data-statut="<?= h($statut) ?>"
             data-debut="<?= h($a['date_debut'] instanceof DateTimeInterface ? $a['date_debut']->format('Y-m-d') : '') ?>"
             data-fin="<?= h($fin) ?>"
             data-remainingdays="<?= h((string)$a['_jours_restants']) ?>"
             data-tsfin="<?= h((string)$a['_ts_fin']) ?>"
             data-defaut="<?= $defaut ? '1':'0' ?>"
             data-impayes="<?= h((string)$imp) ?>"
        >
          <div><strong><?= h($a['client']) ?></strong><div class="muted" style="font-size:12px"><?= h($remTxt) ?></div></div>
          <div><?= h($a['produit']) ?></div>
          <div><?= eur($mensu) ?></div>
          <div class="hide-md"><?= $fin ? h($fin) : '—' ?></div>
          <div class="row-actions" style="justify-self:end">
            <?php if ($defaut): ?>
              <button type="button" class="btn-mini ok action-regularise" data-id="<?= h((string)$a['id']) ?>" title="Marquer comme régularisé">
                <span class="material-symbols-outlined">done_all</span>Régularisé
              </button>
            <?php else: ?>
              <button type="button" class="btn-mini danger action-defaut" data-id="<?= h((string)$a['id']) ?>" title="Déclarer défaut de paiement">
                <span class="material-symbols-outlined">report</span>Déclarer défaut
              </button>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
</div>

<!-- MODAL détail / édition -->
<div class="modal-backdrop" id="modalBackdrop" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="modal" role="document">
    <header>
      <h3><span class="material-symbols-outlined" style="color: var(--primary-color)">receipt_long</span><span id="m-title">Détails de l’abonnement</span></h3>
      <div style="display:flex; gap:6px; align-items:center;">
        <button class="btn" id="m-edit"><span class="material-symbols-outlined">edit</span>Modifier</button>
        <button class="close" id="m-close" aria-label="Fermer">&times;</button>
      </div>
    </header>

    <div class="content">
      <div class="detail" id="m-alert" style="display:none; border-left:4px solid var(--warning);">
        <div class="label">Alerte</div><div class="value" id="m-alert-text">—</div>
      </div>

      <div class="details-grid" id="m-summary">
        <div class="detail"><div class="label">Client</div><div class="value" id="m-client">—</div></div>
        <div class="detail"><div class="label">Produit</div><div class="value" id="m-produit">—</div></div>
        <div class="detail"><div class="label">Type de paiement</div><div class="value" id="m-type">—</div></div>
        <div class="detail"><div class="label">Statut</div><div class="value" id="m-statut">—</div></div>
        <div class="detail"><div class="label">Mensualité</div><div class="value" id="m-mensualite">—</div></div>
        <div class="detail"><div class="label">Montant base</div><div class="value" id="m-montant">—</div></div>
        <div class="detail"><div class="label">Apport</div><div class="value" id="m-apport">—</div></div>
        <div class="detail"><div class="label">Valeur réelle</div><div class="value" id="m-valeur">—</div></div>
        <div class="detail"><div class="label">Début</div><div class="value" id="m-debut">—</div></div>
        <div class="detail"><div class="label">Fin</div><div class="value" id="m-fin">—</div></div>
        <div class="detail"><div class="label">Durée restante</div><div class="value" id="m-remaining">—</div></div>
        <div class="detail"><div class="label">Prochaine échéance (≈)</div><div class="value" id="m-next">—</div></div>
        <div class="detail"><div class="label">IDs</div><div class="value" id="m-ids">—</div></div>
        <div class="detail"><div class="label">Liens rapides</div><div class="value" id="m-links">—</div></div>
      </div>

      <div id="m-edit-form" class="edit-grid" style="display:none">
        <div class="field"><label for="f-mensu">Mensualité (€)</label><input id="f-mensu" type="number" step="0.01" min="0" inputmode="decimal" placeholder="Ex: 30.75"></div>
        <div class="field"><label for="f-mb">Montant base (€)</label><input id="f-mb" type="number" step="0.01" min="0" inputmode="decimal" placeholder="Ex: 369.00"></div>
        <div class="field"><label for="f-apport">Apport (€)</label><input id="f-apport" type="number" step="0.01" min="0" inputmode="decimal"></div>
        <div class="field"><label for="f-valeur">Valeur réelle (€)</label><input id="f-valeur" type="number" step="0.01" min="0" inputmode="decimal"></div>
        <div class="footer" style="grid-column:1/-1">
          <button class="btn" id="m-cancel"><span class="material-symbols-outlined">close</span>Annuler</button>
          <button class="btn primary" id="m-save"><span class="material-symbols-outlined">save</span>Enregistrer</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
// Chart.js – Prévision
(function(){
  const labels = <?= json_encode($forecastLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const values = <?= json_encode($forecastValues, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const ctx = document.getElementById('forecastChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Mensualités estimées (€)', data: values, backgroundColor: 'rgba(76,175,80,0.5)', borderColor: 'rgba(76,175,80,1)', borderWidth: 1, borderRadius: 6 }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } }
  });
})();

// Utils
function eur(n){ if(n===null || n==='' || isNaN(parseFloat(n))) return '-'; return parseFloat(n).toLocaleString('fr-FR',{style:'currency', currency:'EUR'}); }
const qs = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
function parseNum(v){ const n = parseFloat((v||'').toString().replace(',','.')); return isNaN(n)?null:n; }
function approxNextDue(startISO, endISO){
  if(!endISO) return '—';
  const today = new Date(); today.setHours(0,0,0,0);
  const end = new Date(endISO); end.setHours(0,0,0,0);
  if (today >= end) return '—';
  const next = new Date(today.getFullYear(), today.getMonth()+1, 1);
  const y = next.getFullYear(); const m = (next.getMonth()+1).toString().padStart(2,'0'); const d='01';
  return `${y}-${m}-${d}`;
}

// -------- Modal
const backdrop = qs('#modalBackdrop');
const btnClose = qs('#m-close');
const btnEdit  = qs('#m-edit');
const frm      = qs('#m-edit-form');
const summary  = qs('#m-summary');
const btnSave  = qs('#m-save');
const btnCancel= qs('#m-cancel');
let currentEl = null;

function openModalFromEl(el){
  currentEl = el;
  const title = el.dataset.produit || 'Abonnement';
  qs('#m-title').textContent = title;
  qs('#m-client').textContent = el.dataset.client || '—';
  qs('#m-produit').textContent = `${title}${el.dataset.produitId? ' (#'+el.dataset.produitId+')':''}`;
  qs('#m-type').textContent = el.dataset.type || '—';
  qs('#m-statut').textContent = el.dataset.statut || '—';
  qs('#m-debut').textContent = el.dataset.debut || '—';
  qs('#m-fin').textContent = el.dataset.fin || '—';

  const mensu  = el.dataset.mensualite;
  const mb     = el.dataset.montantBase;
  const apport = el.dataset.apport;
  const valeur = el.dataset.valeurReelle;
  qs('#m-mensualite').textContent = mensu  != null && mensu  !== '' && !isNaN(mensu)  ? eur(mensu)  : '—';
  qs('#m-montant').textContent    = mb     != null && mb     !== '' && !isNaN(mb)     ? eur(mb)     : '—';
  qs('#m-apport').textContent     = apport != null && apport !== '' && !isNaN(apport) ? eur(apport) : '—';
  qs('#m-valeur').textContent     = valeur != null && valeur !== '' && !isNaN(valeur) ? eur(valeur) : '—';

  const d = parseInt(el.dataset.remainingdays||'0',10);
  qs('#m-remaining').textContent = (isNaN(d)?'—':(d<=0?'0 j':(d<30?`${d} j`:`${Math.ceil(d/30)} mois`)));
  qs('#m-next').textContent = approxNextDue(el.dataset.debut, el.dataset.fin);

  const ids = `Contrat #${el.dataset.id || '—'}${el.dataset.userId ? ' — User #'+el.dataset.userId : ''}${el.dataset.produitId ? ' — Produit #'+el.dataset.produitId : ''}`;
  qs('#m-ids').textContent = ids;
  const links = [];
  if (el.dataset.userId) links.push(`<a class="btn" href="gestion_users.php?id=${encodeURIComponent(el.dataset.userId)}"><span class="material-symbols-outlined">person</span>Fiche client</a>`);
  if (el.dataset.id)     links.push(`<a class="btn" href="gestion_contrats.php?id=${encodeURIComponent(el.dataset.id)}"><span class="material-symbols-outlined">description</span>Contrat</a>`);
  qs('#m-links').innerHTML = links.join(' ');

  const alertBox = qs('#m-alert'); const alertTxt = qs('#m-alert-text');
  if (!isNaN(d) && d > 0 && d <= 15 && (el.dataset.statut||'')==='En cours') {
    alertBox.style.display = ''; alertTxt.textContent = `Fin imminente : ${d} jour(s) restant(s).`;
  } else { alertBox.style.display = 'none'; alertTxt.textContent = '—'; }

  qs('#f-mensu').value  = mensu  || '';
  qs('#f-mb').value     = mb     || '';
  qs('#f-apport').value = apport || '';
  qs('#f-valeur').value = valeur || '';

  frm.style.display = 'none'; summary.style.display = '';
  btnEdit.dataset.mode = 'view';
  btnEdit.innerHTML = '<span class="material-symbols-outlined">edit</span>Modifier';

  backdrop.style.display = 'flex'; backdrop.setAttribute('aria-hidden','false'); document.body.style.overflow = 'hidden';
}
function closeModal(){ backdrop.style.display = 'none'; backdrop.setAttribute('aria-hidden','true'); document.body.style.overflow = ''; currentEl = null; }

btnEdit.addEventListener('click', ()=>{
  const mode = btnEdit.dataset.mode || 'view';
  if (mode==='view') { summary.style.display = 'none'; frm.style.display = ''; btnEdit.dataset.mode='edit'; btnEdit.innerHTML='<span class="material-symbols-outlined">visibility</span>Afficher'; }
  else { frm.style.display='none'; summary.style.display=''; btnEdit.dataset.mode='view'; btnEdit.innerHTML='<span class="material-symbols-outlined">edit</span>Modifier'; }
});
btnCancel.addEventListener('click', ()=>{ btnEdit.click(); });
qs('#m-close').addEventListener('click', closeModal);
backdrop.addEventListener('click', (e)=>{ if(e.target === e.currentTarget) closeModal(); });
document.addEventListener('keydown', (e)=>{ if(e.key === 'Escape') closeModal(); });

// -------- Defaut / régularisé + saisie impayés
function setBadgeCount(n){ const b = qs('#badge-defaut'); if (b) b.textContent = String(n); }
async function postDefaut(contractId, makeDefaut, impayes){
  const form = new FormData();
  form.append('action', makeDefaut ? 'set_defaut' : 'clear_defaut');
  form.append('id', String(contractId));
  if (makeDefaut) form.append('impayes', String(impayes||0));
  const res = await fetch(location.pathname + location.search, { method:'POST', body:form });
  const json = await res.json();
  if (!json.ok) throw new Error(json.error || 'Erreur inconnue');
  setBadgeCount(json.count_defaut ?? 0);
  return json;
}

document.addEventListener('click', async (e)=>{
  const defBtn = e.target.closest('.action-defaut');
  const okBtn  = e.target.closest('.action-regularise');
  if (!defBtn && !okBtn) return;
  e.stopPropagation(); // empêcher l'ouverture de la carte

  const btn = defBtn || okBtn;
  const id = btn.getAttribute('data-id');
  if (!id) return;

  // Récup carte/liste porteur des data
  const el = document.querySelector(`.abo-card[data-id="${CSS.escape(id)}"], .abo-row[data-id="${CSS.escape(id)}"]`);
  const mensu = parseFloat(el?.dataset.mensualite || '0') || 0;

  try {
    let json;
    if (defBtn) {
      alert('Mensualité de ce contrat : ' + (mensu ? mensu.toLocaleString('fr-FR',{style:'currency',currency:'EUR'}) : '—'));
      let nb = prompt('Nombre de mensualités impayées ? (entier ≥ 1)', '1');
      if (nb === null) return; // annule
      nb = parseInt(nb, 10);
      if (!Number.isInteger(nb) || nb < 1) { alert('Valeur invalide.'); return; }

      btn.disabled = true; const orig = btn.innerHTML; btn.innerHTML = '<span class="material-symbols-outlined">hourglass_top</span>…';
      json = await postDefaut(id, true, nb);
      btn.disabled = false; btn.innerHTML = orig;

      // Switch bouton + maj dataset
      el.dataset.defaut = '1'; el.dataset.impayes = String(nb);
      el.querySelectorAll('.row-actions').forEach(zone=>{
        zone.innerHTML = `<button type="button" class="btn-mini ok action-regularise" data-id="${id}" title="Marquer comme régularisé"><span class="material-symbols-outlined">done_all</span>Régularisé</button>`;
      });
    } else {
      btn.disabled = true; const orig = btn.innerHTML; btn.innerHTML = '<span class="material-symbols-outlined">hourglass_top</span>…';
      json = await postDefaut(id, false, 0);
      btn.disabled = false; btn.innerHTML = orig;

      el.dataset.defaut = '0'; el.dataset.impayes = '0';
      el.querySelectorAll('.row-actions').forEach(zone=>{
        zone.innerHTML = `<button type="button" class="btn-mini danger action-defaut" data-id="${id}" title="Déclarer défaut de paiement"><span class="material-symbols-outlined">report</span>Déclarer défaut</button>`;
      });

      // Si on est dans l'onglet À relancer, retirer l'élément régularisé
      const inRelancer = (new URLSearchParams(location.search).get('filtre') || 'en_cours') === 'a_relancer';
      if (inRelancer) {
        el.remove();
        const isCards = document.getElementById('cardsView').style.display !== 'none';
        const sel = isCards ? '#cardsView .abo-card' : '#listView .abo-row:not(:first-child)';
        if (!document.querySelector(sel)) {
          const container = isCards ? document.getElementById('cardsView') : document.getElementById('listView');
          container.innerHTML = '<div class="empty">Aucun abonnement à afficher.</div>';
        }
      }
    }

    // Mettre à jour KPI impayés (si renvoyés)
    if (json && typeof json.sum_euros !== 'undefined' && typeof json.sum_impayes !== 'undefined') {
      // On ne reconstruit pas tout le bloc, mais c’est possible si tu veux.
      // (Optionnel) À implémenter si nécessaire.
    }
  } catch (err) {
    alert('Action impossible: ' + (err?.message || err));
  }
});

// Save AJAX (montants)
qs('#m-save').addEventListener('click', async ()=>{
  if(!currentEl) return;
  const id = currentEl.dataset.id;
  const mensu  = parseNum(qs('#f-mensu').value);
  const mb     = parseNum(qs('#f-mb').value);
  const apport = parseNum(qs('#f-apport').value);
  const valeur = parseNum(qs('#f-valeur').value);

  if ([mensu,mb,apport,valeur].every(v=>v===null)) { alert('Veuillez saisir au moins une valeur numérique.'); return; }

  const form = new FormData();
  form.append('action','update_amounts'); form.append('id', id);
  if (mensu !== null)  form.append('mensualite', String(mensu));
  if (mb !== null)     form.append('montant_base', String(mb));
  if (apport !== null) form.append('apport', String(apport));
  if (valeur !== null) form.append('valeur_reelle', String(valeur));

  const btn = qs('#m-save'); btn.disabled = true; const orig = btn.innerHTML; btn.innerHTML = '<span class="material-symbols-outlined">hourglass_top</span>Enregistrement…';
  try {
    const res = await fetch(location.pathname + location.search, { method:'POST', body:form });
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'Erreur inconnue');

    const mensuNew = json.mensualite ?? mensu;
    const mbNew    = json.montant_base ?? mb;
    const apNew    = json.apport ?? apport;
    const valNew   = json.valeur_reelle ?? valeur;

    if (mensuNew!=null)  currentEl.dataset.mensualite   = String(mensuNew);
    if (mbNew!=null)     currentEl.dataset.montantBase  = String(mbNew);
    if (apNew!=null)     currentEl.dataset.apport       = String(apNew);
    if (valNew!=null)    currentEl.dataset.valeurReelle = String(valNew);

    const pill = currentEl.querySelector('.pill');
    if (pill && mensuNew!=null) pill.textContent = Number(mensuNew).toLocaleString('fr-FR',{style:'currency',currency:'EUR'});

    qs('#m-mensualite').textContent = mensuNew!=null ? eur(mensuNew) : qs('#m-mensualite').textContent;
    qs('#m-montant').textContent    = mbNew!=null ? eur(mbNew) : qs('#m-montant').textContent;
    qs('#m-apport').textContent     = apNew!=null ? eur(apNew) : qs('#m-apport').textContent;
    qs('#m-valeur').textContent     = valNew!=null ? eur(valNew) : qs('#m-valeur').textContent;

    btnEdit.click(); // retour lecture
  } catch (e) {
    alert('Échec de l’enregistrement: ' + (e?.message || e));
  } finally {
    btn.disabled = false; btn.innerHTML = orig;
  }
});

// Ouvrir modal depuis cartes / lignes (ignore les zones d’actions)
(function(){
  const attach = (el)=> {
    el.addEventListener('click', (ev)=>{ if (ev.target.closest('.row-actions') || ev.target.closest('.btn-mini')) return; if(!el.dataset.id) return; openModalFromEl(el); });
    el.addEventListener('keydown', (e)=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); if(!el.dataset.id) return; openModalFromEl(el); }});
  };
  $$('#cardsView .abo-card').forEach(attach);
  $$('#listView .abo-row').forEach((el,i)=>{ if(i===0) return; attach(el); }); // skip header row
})();

// Recherche / Tri / Vue
(function(){
  const q = document.getElementById('q');
  const sort = document.getElementById('sort');
  const toggleView = document.getElementById('toggleView');
  const reset = document.getElementById('reset');
  const labelToggle = toggleView.querySelector('.label');
  const countVisible = document.getElementById('countVisible');

  function currentViewEls(){
    const isCards = document.getElementById('cardsView').style.display !== 'none';
    return isCards ? $$('#cardsView .abo-card') : $$('#listView .abo-row').slice(1);
  }
  function applySearch(){
    const term = (q.value || '').trim().toLowerCase();
    const els = currentViewEls(); let visible = 0;
    els.forEach(el=>{
      const hay = (el.dataset.client + ' ' + el.dataset.produit + ' ' + (el.dataset.statut||'') + ' ' + (el.dataset.type||'')).toLowerCase();
      const show = term === '' || hay.includes(term);
      el.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    countVisible.textContent = visible.toString();
  }
  function applySort(){
    const els = currentViewEls();
    const container = document.getElementById(document.getElementById('cardsView').style.display !== 'none' ? 'cardsView' : 'listView');
    const value = sort.value;
    const arr = [...els];
    const byNum = (el, attr) => parseFloat(el.dataset[attr] || '0');
    const byInt = (el, attr) => parseInt(el.dataset[attr] || '0', 10);
    const cmp = {
      'fin_asc':  (a,b)=> byInt(a,'tsfin') - byInt(b,'tsfin'),
      'fin_desc': (a,b)=> byInt(b,'tsfin') - byInt(a,'tsfin'),
      'mensu_desc':(a,b)=> byNum(b,'mensualite') - byNum(a,'mensualite'),
      'mensu_asc': (a,b)=> byNum(a,'mensualite') - byNum(b,'mensualite'),
      'restant_asc':  (a,b)=> byInt(a,'remainingdays') - byInt(b,'remainingdays'),
      'restant_desc': (a,b)=> byInt(b,'remainingdays') - byInt(a,'remainingdays'),
    }[value] || (()=>0);
    arr.sort(cmp);
    arr.forEach(el=> container.appendChild(el));
  }
  function updateCountInitial(){ countVisible.textContent = currentViewEls().length.toString(); }

  toggleView.addEventListener('click', ()=>{
    const cards = document.getElementById('cardsView');
    const list  = document.getElementById('listView');
    const isCards = cards.style.display !== 'none';
    if (isCards) {
      cards.style.display = 'none'; list.style.display  = '';
      toggleView.setAttribute('aria-pressed','true'); labelToggle.textContent = 'Vue cartes';
      toggleView.querySelector('.material-symbols-outlined').textContent = 'view_module';
    } else {
      list.style.display  = 'none'; cards.style.display = '';
      toggleView.setAttribute('aria-pressed','false'); labelToggle.textContent = 'Vue liste';
      toggleView.querySelector('.material-symbols-outlined').textContent = 'view_list';
    }
    applySort(); applySearch();
  });

  q.addEventListener('input', applySearch);
  sort.addEventListener('change', ()=>{ applySort(); applySearch(); });
  reset.addEventListener('click', ()=>{ q.value = ''; sort.value = 'fin_asc'; const list = document.getElementById('listView'); if (list.style.display !== 'none') toggleView.click(); applySort(); applySearch(); });
  updateCountInitial(); applySort();
})();
</script>
</body>
</html>

