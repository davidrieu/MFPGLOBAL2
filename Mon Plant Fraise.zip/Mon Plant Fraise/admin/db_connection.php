<?php
// Fichier: /admin/db_connection.php

// --- Paramètres de connexion ---
$host_name = 'mpfgloqamo.mysql.db';
$database  = 'mpfgloqamo';
$user_name = 'mpfgloqamo';
$password  = '24021993Ab';
$charset   = 'utf8mb4'; // *** DÉFINIR LE CHARSET ***

// --- Chaîne de connexion (DSN) ---
// *** UTILISER LES BONNES VARIABLES ET AJOUTER LE PORT ***
$dsn = "mysql:host=$host_name;port=$port;dbname=$database;charset=$charset";

// --- Options PDO ---
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Lance des exceptions
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,     // Tableaux associatifs
    PDO::ATTR_EMULATE_PREPARES   => false,                // Vraies requêtes préparées
];

// --- Création de l'objet PDO ---
try {
    // *** UTILISER LES BONNES VARIABLES USER/PASSWORD ***
    $pdo = new PDO($dsn, $user_name, $password, $options);
} catch (\PDOException $e) {
    error_log("PDO Connection Error: " . $e->getMessage()); // Log l'erreur
    // Message générique pour l'utilisateur en production
    die("Erreur de connexion à la base de données. L'administrateur a été notifié.");
}

// Si on arrive ici, $pdo est prêt.
?>