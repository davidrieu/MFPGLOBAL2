<?php
/***********************************************************
 * remboursement.php — Admin MPF (compact, 1 écran)
 * - Urgence = jours écoulés depuis FIN DE CONTRAT (contrats.date_fin)
 *   fallback => dr.date_demande si date_fin manquante
 * - UI compacte, priorisation avancée + Recommandation IA
 * - Aucune création de table ici
 *
 * @version 3.2.2 - Par défaut: statut=all + placeholder vide
 ***********************************************************/
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Session & Auth (aligné sur index.php)
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}
$ADMIN_ID = (int)$_SESSION['admin_id'];

// DB
require_once '../db_connection.php';

// Initialisation robuste de $pdo
if (!isset($pdo) || !($pdo instanceof PDO)) {
    if (function_exists('getPdoConnection')) {
        $pdo = getPdoConnection();
    } else {
        http_response_code(500);
        die('Erreur: connexion PDO non initialisée.');
    }
}
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Constantes scoring
define('WEIGHT_URGENCY', 0.55);
define('WEIGHT_CASH_GAIN', 0.30);
define('WEIGHT_TAGS', 0.10);
define('WEIGHT_RISK', 0.05);
define('REINVEST_DISCOUNT_PER_DAY', 0.015);
define('BAYESIAN_PRIOR_SUCCESS', 1.0);
define('BAYESIAN_PRIOR_FAILURE', 1.0);
define('TAG_CRITICAL_SCORE_INCREMENT', 0.5);
define('TAG_CRITICAL_SCORE_MAX', 1.0);
define('IMMEDIATE_YIELD_MULTIPLIER', 1.5);

// Helpers
function J($ok, $data = [], $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => $ok] + $data);
    exit;
}
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function normalize01($x,$min,$max){ if($max<=$min) return 0.0; $n=($x-$min)/($max-$min); return max(0.0,min(1.0,$n)); }
function over_from_date($d){
    if(!$d) return 0;
    try{ $dt = new DateTimeImmutable($d); }
    catch(Throwable $e){ $dt = DateTimeImmutable::createFromFormat('Y-m-d', $d) ?: null; }
    if(!$dt) return 0;
    $t = new DateTimeImmutable('today');
    if($t <= $dt) return 0;
    return (int)$t->diff($dt)->format('%a');
}
function ensure_dir($p){ if(!is_dir($p)) @mkdir($p,0775,true); if(!is_writable($p)) @chmod($p,0775); }
function col_exists(PDO $pdo,$t,$c){
    try{
        $st=$pdo->prepare("SHOW COLUMNS FROM `$t` LIKE ?");
        $st->execute([$c]);
        return (bool)$st->fetch();
    }catch(Throwable $e){ return false; }
}
function calculateReinvestProbability($p_db, $p_rel) {
    if (!is_null($p_db) && !is_null($p_rel)) { return (0.6 * $p_db + 0.4 * $p_rel); }
    return $p_db ?? $p_rel;
}

// Colonnes optionnelles
$HAS_PREUVE       = col_exists($pdo,'demandes_retrait','preuve_virement');
$HAS_LAST_CONTACT = col_exists($pdo,'demandes_retrait','last_contact_at');

// ---------- ENDPOINTS AJAX ----------
$action = $_GET['action'] ?? $_POST['action'] ?? null;

/** Solde (KPI) */
if ($action==='get_solde'){
    try{
        $stmt = $pdo->query("SELECT solde FROM remboursement_solde ORDER BY updated_at DESC, id DESC LIMIT 1");
        $row  = $stmt->fetch(PDO::FETCH_ASSOC);
        J(true, ['solde' => $row ? (float)$row['solde'] : 0.0 ]);
    }catch(Throwable $e){
        J(true, ['solde' => 0.0]); // fallback silencieux
    }
}
if ($action==='set_solde'){
    try{
        $v=(float)$_POST['solde'];
        $pdo->prepare("INSERT INTO remboursement_solde (solde,updated_by) VALUES (?,?)")->execute([$v,$ADMIN_ID]);
        J(true,['solde'=>$v]);
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}

/** Liste paginée + score */
if ($action==='list'){
    try{
        $q = trim($_GET['q']??'');
        // Par défaut: ALL (pas de filtre)
        $statut = $_GET['statut'] ?? 'all';
        $tag = trim($_GET['tag']??'');
        $minScore = (int)($_GET['minScore']??0);
        $per = min(50, max(5,(int)($_GET['per']??12)));
        $page = max(1,(int)($_GET['page']??1));
        $off = ($page-1)*$per;

        $sqlBase = "FROM demandes_retrait dr
                    JOIN users u ON u.id=dr.user_id
                    LEFT JOIN client_reinvest cr ON cr.user_id=u.id
                    LEFT JOIN contrats c ON c.id = dr.contrat_id
                    WHERE 1";
        $params=[];
        if($statut!=='all'){ $sqlBase.=" AND dr.statut=? "; $params[]=$statut; }
        if($q!==''){ $sqlBase.=" AND (u.email LIKE ? OR u.name LIKE ? OR u.prenom LIKE ?) "; $params[]="%$q%"; $params[]="%$q%"; $params[]="%$q%"; }
        if($tag!==''){ $sqlBase.=" AND EXISTS(SELECT 1 FROM user_tags ut WHERE ut.user_id=u.id AND ut.tag=?) "; $params[]=$tag; }

        $stmt = $pdo->prepare("SELECT COUNT(*) ".$sqlBase);
        $stmt->execute($params);
        $total_rows = (int)$stmt->fetchColumn();

        $sql = "SELECT
                    dr.id AS demande_id,
                    dr.user_id,
                    COALESCE(dr.montant,0) AS montant,
                    COALESCE(c.date_fin, dr.date_demande) AS date_ref_urgence,
                    dr.iban,
                    dr.statut,
                    u.prenom,
                    u.name AS nom,
                    u.email,
                    cr.montant_reinvest_promis,
                    cr.proba_reinvest,
                    cr.delai_reinvest_jours
                ".$sqlBase."
                ORDER BY (dr.statut='en_attente') DESC, dr.id DESC
                LIMIT $per OFFSET $off";
        $stmt=$pdo->prepare($sql); $stmt->execute($params); $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);

        $userIds = array_values(array_unique(array_column($rows, 'user_id')));
        $tagsByUser=[]; $reliab=[];
        if($userIds){
            $in=implode(',', array_fill(0,count($userIds),'?'));
            $st=$pdo->prepare("SELECT user_id,tag FROM user_tags WHERE user_id IN ($in)");
            $st->execute($userIds);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $t){ $tagsByUser[(int)$t['user_id']][] = $t['tag']; }

            $sqlRel = "SELECT user_id,
                              SUM(CASE WHEN type='reinvest_confirme' THEN 1 ELSE 0 END) AS succ,
                              SUM(CASE WHEN type IN ('promesse_reinvest','reinvest_confirme') THEN 1 ELSE 0 END) AS tot
                       FROM user_interactions WHERE user_id IN ($in) GROUP BY user_id";
            $st=$pdo->prepare($sqlRel); $st->execute($userIds);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $rr){
                $uid=(int)$rr['user_id']; $succ=(int)$rr['succ']; $tot=max(0,(int)$rr['tot']);
                $reliab[$uid] = [
                    'succ'=>$succ,
                    'tot'=>$tot,
                    'p_eff'=> ($succ + BAYESIAN_PRIOR_SUCCESS) / ($tot + BAYESIAN_PRIOR_SUCCESS + BAYESIAN_PRIOR_FAILURE)
                ];
            }
        }

        $ibanToUsers=[];
        foreach($rows as $r){ if(trim($r['iban']??'')) { $ibanToUsers[trim($r['iban'])][] = (int)$r['user_id']; } }
        $anomalyIban = [];
        foreach($ibanToUsers as $iban=>$uids){ if(count(array_unique($uids))>=2) $anomalyIban[$iban]=true; }

        $overs = array_map(fn($r)=> over_from_date($r['date_ref_urgence']??null), $rows);
        $minOver = $overs?min($overs):0; $maxOver=$overs?max($overs):1; if($maxOver===$minOver) $maxOver=$minOver+1;

        $items=[];
        foreach($rows as $r){
            $uid=(int)$r['user_id'];
            $montant=(float)$r['montant'];
            $over = over_from_date($r['date_ref_urgence'] ?? null);
            $u01 = normalize01($over,$minOver,$maxOver);

            $p_db = is_null($r['proba_reinvest'])?null: max(0.0,min(1.0,(float)$r['proba_reinvest']));
            $p_rel = $reliab[$uid]['p_eff'] ?? null;
            $p = calculateReinvestProbability($p_db, $p_rel);

            $mrp = (float)($r['montant_reinvest_promis'] ?? 0);
            $dly = (int)($r['delai_reinvest_jours'] ?? 0);
            $eni = (!is_null($p) && $mrp>0) ? $p * $mrp * exp(-REINVEST_DISCOUNT_PER_DAY * max(0,$dly)) : 0.0;

            $delta = $eni - $montant;

            $tgs = $tagsByUser[$uid] ?? [];
            $critArr = ['mise en demeure','vip','fragile','litige','urgence'];
            $crit = 0.0; foreach($tgs as $t){ if(in_array(mb_strtolower($t),$critArr,true)) $crit += TAG_CRITICAL_SCORE_INCREMENT; }
            $crit=min(TAG_CRITICAL_SCORE_MAX,$crit);

            $risque = in_array('litige', array_map('mb_strtolower',$tgs), true) ? 1.0 : 0.0;

            $score = 100*(WEIGHT_URGENCY*$u01
                       + WEIGHT_CASH_GAIN*max(0, normalize01($delta,0,max(1.0,$eni)))
                       + WEIGHT_TAGS*$crit
                       - WEIGHT_RISK*$risque);

            if((int)round($score) < $minScore) continue;

            $items[]=[
                'demande_id'=>(int)$r['demande_id'],
                'user_id'=>$uid,
                'prenom'=>$r['prenom'],
                'nom'=>$r['nom'], // alias via u.name AS nom
                'email'=>$r['email'],
                'montant'=>round($montant,2),
                'date_ref_urgence'=>$r['date_ref_urgence'] ?? null,
                'overdue_days'=>$over,
                'eni'=>round($eni,2),
                'delta_cash'=>round($delta,2),
                'statut'=>$r['statut'],
                'tags'=>$tgs,
                'score'=>(int)round($score),
                'has_reliab'=>isset($reliab[$uid]),
                'p_eff'=> $reliab[$uid]['p_eff']??null,
                'reliab_succ'=>$reliab[$uid]['succ']??0,
                'reliab_tot'=>$reliab[$uid]['tot']??0,
                'anomaly_iban'=>($r['iban'] && isset($anomalyIban[$r['iban']]))
            ];
        }

        usort($items,fn($a,$b) => ($a['score']<=>$b['score'])* -1 ?: ($b['overdue_days']<=>$a['overdue_days']));
        $wait_items = array_filter($items, fn($it) => $it['statut']==='en_attente');

        J(true,[
            'items'=>$items,
            'page'=>$page,
            'per'=>$per,
            'total'=>$total_rows,
            'kpi_wait_count'=>count($wait_items),
            'kpi_wait_sum'=>round(array_sum(array_column($wait_items, 'montant')),2)
        ]);
    }catch (Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}

/** Priorisation / Simulation */
if ($action==='simulate'){
    try{
        $solde = (float)($_POST['solde']??0);
        $strategie = $_POST['strategie'] ?? 'urgence';
        $partial = (int)($_POST['partial_enabled']??0)===1;
        $partial_floor = max(0.3, min(1.0, (float)($_POST['partial_floor']??0.6)));
        $chain = (int)($_POST['chain_enabled']??0)===1;
        $horizon = max(1,min(30,(int)($_POST['horizon_days']??7)));
        $rule_min_days = max(0,(int)($_POST['rule_min_days']??0));
        $rule_vip_max = max(0,(int)($_POST['rule_vip_max']??0));
        $rule_excl_litige = (int)($_POST['rule_exclude_litige']??0)===1;
        $rule_cap_per_client = max(0.0,(float)($_POST['rule_cap_per_client']??0.0));

        $stmt=$pdo->query("SELECT
                               dr.id AS demande_id, dr.user_id,
                               COALESCE(dr.montant,0) AS montant,
                               COALESCE(c.date_fin, dr.date_demande) AS date_ref_urgence,
                               u.prenom, u.name AS nom,
                               cr.montant_reinvest_promis, cr.proba_reinvest, cr.delai_reinvest_jours
                           FROM demandes_retrait dr
                           JOIN users u ON u.id=dr.user_id
                           LEFT JOIN client_reinvest cr ON cr.user_id=u.id
                           LEFT JOIN contrats c ON c.id = dr.contrat_id
                           WHERE dr.statut='en_attente'");
        $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);

        $userIds = array_values(array_unique(array_column($rows, 'user_id')));
        $tagsByUser=[]; $reliab=[];
        if($userIds){
            $in=implode(',', array_fill(0,count($userIds),'?'));
            $st=$pdo->prepare("SELECT user_id,tag FROM user_tags WHERE user_id IN ($in)");
            $st->execute($userIds);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $t){ $tagsByUser[(int)$t['user_id']][]=$t['tag']; }

            $sqlRel="SELECT user_id,
                            SUM(CASE WHEN type='reinvest_confirme' THEN 1 ELSE 0 END) AS succ,
                            SUM(CASE WHEN type IN ('promesse_reinvest','reinvest_confirme') THEN 1 ELSE 0 END) AS tot
                     FROM user_interactions WHERE user_id IN ($in) GROUP BY user_id";
            $st=$pdo->prepare($sqlRel); $st->execute($userIds);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $rr){
                $uid=(int)$rr['user_id']; $succ=(int)$rr['succ']; $tot=(int)$rr['tot'];
                $reliab[$uid]=($succ+BAYESIAN_PRIOR_SUCCESS)/($tot+BAYESIAN_PRIOR_SUCCESS+BAYESIAN_PRIOR_FAILURE);
            }
        }

        $overs = array_map(fn($r)=> over_from_date($r['date_ref_urgence']??null), $rows);
        $minOver = $overs?min($overs):0; $maxOver=$overs?max($overs):1; if($maxOver===$minOver) $maxOver=$minOver+1;

        $cands=[];
        foreach($rows as $r){
            $uid=(int)$r['user_id']; $montant=(float)$r['montant']; $over=over_from_date($r['date_ref_urgence']??null);
            $tags=$tagsByUser[$uid]??[]; $tags_lower = array_map('mb_strtolower', $tags); $isLitige = in_array('litige', $tags_lower, true);
            if(($rule_excl_litige && $isLitige) || ($rule_min_days>0 && $over<$rule_min_days)) continue;
            $u01=normalize01($over,$minOver,$maxOver);
            $p_db = is_null($r['proba_reinvest'])?null: max(0.0,min(1.0,(float)$r['proba_reinvest']));
            $p_rel = $reliab[$uid] ?? null; $p = calculateReinvestProbability($p_db, $p_rel);
            $mrp=(float)($r['montant_reinvest_promis']??0); $dly=(int)($r['delai_reinvest_jours']??0);
            $eni = (!is_null($p) && $mrp>0)? $p*$mrp*exp(-REINVEST_DISCOUNT_PER_DAY*max(0,$dly)) : 0.0;
            $delta=$eni-$montant;
            $critArr = ['mise en demeure','vip','fragile','litige','urgence'];
            $crit=0.0; foreach($tags as $t){ if(in_array(mb_strtolower($t),$critArr,true)) $crit+=TAG_CRITICAL_SCORE_INCREMENT; }
            $crit=min(TAG_CRITICAL_SCORE_MAX,$crit); $risque=$isLitige?1.0:0.0;
            $score = 100*(WEIGHT_URGENCY*$u01 + WEIGHT_CASH_GAIN*max(0, normalize01($delta,0,max(1.0,$eni))) + WEIGHT_TAGS*$crit - WEIGHT_RISK*$risque);
            $rend = ($dly>0)? ($delta/$dly) : ($delta*IMMEDIATE_YIELD_MULTIPLIER);
            $cands[]=[
                'demande_id'=>(int)$r['demande_id'],
                'user_id'=>$uid,
                'nom'=>$r['nom'],
                'prenom'=>$r['prenom'],
                'montant'=>round(max(0,$montant),2),
                'over'=>$over,
                'eni'=>round($eni,2),
                'delta'=>round($delta,2),
                'dly'=>$dly,
                'score'=>(int)round($score),
                'rend'=>$rend,
                'p'=>$p,
                'mrp'=>$mrp,
                'vip'=>in_array('vip', $tags_lower, true),
                'mise_en_demeure'=>in_array('mise en demeure', $tags_lower, true)
            ];
        }

        if($strategie==='max_dossiers'){ usort($cands,fn($a,$b)=> $a['montant']<=>$b['montant']); }
        elseif($strategie==='max_delta_cash'){ usort($cands,fn($a,$b)=> $b['delta']<=>$a['delta']); }
        elseif($strategie==='cashflow_net'){ usort($cands,fn($a,$b)=> $b['rend']<=>$a['rend']); }
        elseif($strategie==='ia_recommandee'){
            usort($cands, function($a, $b) {
                if ($a['mise_en_demeure'] !== $b['mise_en_demeure']) return $b['mise_en_demeure'] <=> $a['mise_en_demeure'];
                $a_is_crisis = $a['score'] > 75; $b_is_crisis = $b['score'] > 75;
                if ($a_is_crisis !== $b_is_crisis) return $b_is_crisis <=> $a_is_crisis;
                $a_is_opp = $a['delta'] > 1000; $b_is_opp = $b['delta'] > 1000;
                if ($a_is_opp !== $b_is_opp) return $b_is_opp <=> $a_is_opp;
                if ($a['score'] === $b['score']) return $b['over'] <=> $a['over'];
                return $b['score'] <=> $a['score'];
            });
        } else {
            usort($cands,fn($a,$b)=> ($a['score']<=>$b['score']) * -1 ?: ($b['over']<=>$a['over']));
        }

        $vip_used=0; $sel=[]; $spent=0.0; $budget=$solde; $depense_par_client = [];
        $tryAdd=function($c) use (&$sel, &$spent, $budget, $partial, $partial_floor, $rule_cap_per_client, &$depense_par_client){
            $montant_deja_alloue = $depense_par_client[$c['user_id']] ?? 0.0; $montant_max_payable = $c['montant'];
            if ($rule_cap_per_client > 0) {
                $restant_sur_plafond = $rule_cap_per_client - $montant_deja_alloue;
                if ($restant_sur_plafond <= 0) return false;
                $montant_max_payable = min($c['montant'], $restant_sur_plafond);
            }
            $pay = $montant_max_payable;
            if ($pay > $budget - $spent) {
                if ($partial && ($minPay = max($partial_floor * $c['montant'], 0.01)) <= $budget - $spent) {
                    $pay = min($budget - $spent, $montant_max_payable);
                } else return false;
            }
            $c['pay']=round($pay,2); $sel[]=$c; $spent+=$pay; $depense_par_client[$c['user_id']] = $montant_deja_alloue + $pay;
            return true;
        };

        if(!$chain){
            foreach($cands as $c){
                if($rule_vip_max>0 && $c['vip'] && $vip_used>=$rule_vip_max) continue;
                if($tryAdd($c)){ if($c['vip']) $vip_used++; }
                if($spent>=$budget-1e-9) break;
            }
            $sumDelta=array_sum(array_column($sel, 'delta'));
            $sumEni  =array_sum(array_column($sel, 'eni'));
            J(true,[
                'selection'=>array_map(fn($x)=>[
                    'demande_id'=>$x['demande_id'],
                    'user_id'=>$x['user_id'],
                    'nom'=>$x['nom'],
                    'prenom'=>$x['prenom'],
                    'montant'=>$x['pay'],
                    'score'=>$x['score'],
                    'delta'=>$x['delta'],
                    'p'=>$x['p'],
                    'mrp'=>$x['mrp']
                ], $sel),
                'montant_total'=>round($spent,2),
                'eni_total'=>round($sumEni,2),
                'delta_total'=>round($sumDelta,2),
                'budget_restant'=>round(max(0,$budget-$spent),2),
                'explain'=>"Stratégie=$strategie"
            ]);
        } else {
            J(false, ['msg' => 'La logique de chaîne n\'est pas implémentée dans cette version simplifiée.']);
        }
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}

/** Validation du lot + notification */
if ($action==='validate'){
    try{
        $payload=json_decode($_POST['payload']??'[]',true);
        $solde_initial=(float)($_POST['solde_initial']??0);
        $strategie=$_POST['strategie']??'urgence';
        $explain=$_POST['explain']??'';
        if(!is_array($payload)||empty($payload)) J(false,['msg'=>'Lot vide'],400);

        $pdo->beginTransaction();
        $total=array_sum(array_column($payload, 'montant'));

        $pdo->prepare("INSERT INTO remboursement_lots (created_by, solde_initial, montant_total, strategie) VALUES (?,?,?,?)")
            ->execute([$ADMIN_ID, $solde_initial, $total, $strategie]);
        $lot_id=(int)$pdo->lastInsertId();

        $ins=$pdo->prepare("INSERT INTO remboursement_lot_items (lot_id,demande_id,user_id,montant,score_urgence,delta_cash,reinvest_p,reinvest_montant) VALUES (?,?,?,?,?,?,?,?)");
        $upd=$pdo->prepare("UPDATE demandes_retrait SET statut='valide' WHERE id=?");

        foreach($payload as $r){
            $ins->execute([
                $lot_id,
                (int)$r['demande_id'],
                (int)$r['user_id'],
                (float)$r['montant'],
                (int)($r['score']??0),
                (float)($r['delta']??0),
                (float)($r['p']??0),
                (float)($r['mrp']??0)
            ]);
            $upd->execute([(int)$r['demande_id']]);
        }

        $pdo->prepare("INSERT INTO remboursement_solde (solde,updated_by) VALUES (?,?)")
            ->execute([$solde_initial-$total,$ADMIN_ID]);

        $msg="Lot #$lot_id validé — total ".number_format($total,2,',',' ')." €. ".$explain;
        $pdo->prepare("INSERT INTO admin_notifications (type,message,created_at) VALUES ('remboursement',?,NOW())")
            ->execute([$msg]);

        $pdo->commit();
        J(true,['lot_id'=>$lot_id,'montant_total'=>$total]);
    }catch(Throwable $e){
        if($pdo->inTransaction()) $pdo->rollBack();
        J(false,['msg'=>$e->getMessage()],500);
    }
}

/** Upsert réinvest */
if ($action==='update_reinvest'){
    try{
        $uid=(int)($_POST['user_id']??0);
        $sr=$_POST['souhaite_reinvestir']??'indecis';
        $mrp=($_POST['montant_reinvest_promis']!=='')?(float)$_POST['montant_reinvest_promis']:null;
        $p=($_POST['proba_reinvest']!=='')?(float)$_POST['proba_reinvest']:null;
        $d=($_POST['delai_reinvest_jours']!=='')?(int)$_POST['delai_reinvest_jours']:null;
        if(!$uid) J(false,['msg'=>'user_id manquant'],400);

        $exists=$pdo->prepare("SELECT user_id FROM client_reinvest WHERE user_id=?");
        $exists->execute([$uid]);

        if($exists->fetch()){
            $pdo->prepare("UPDATE client_reinvest
                           SET souhaite_reinvestir=?, montant_reinvest_promis=?, proba_reinvest=?, delai_reinvest_jours=?, last_reinvest_signal_at=NOW()
                           WHERE user_id=?")
                ->execute([$sr,$mrp,$p,$d,$uid]);
        }else{
            $pdo->prepare("INSERT INTO client_reinvest (user_id, souhaite_reinvestir, montant_reinvest_promis, proba_reinvest, delai_reinvest_jours, last_reinvest_signal_at)
                           VALUES (?,?,?,?,?,NOW())")
                ->execute([$uid,$sr,$mrp,$p,$d]);
        }
        J(true);
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}

/** Tags */
if($action==='add_tag'){
    try{
        $uid=(int)($_POST['user_id']??0); $tag=trim($_POST['tag']??'');
        if($uid && $tag!==''){
            $pdo->prepare("INSERT INTO user_tags (user_id,tag) VALUES (?,?)")->execute([$uid,$tag]);
            J(true);
        } else { J(false,['msg'=>'Paramètres manquants'],400); }
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}
if($action==='remove_tag'){
    try{
        $uid=(int)($_POST['user_id']??0); $tag=trim($_POST['tag']??'');
        if($uid && $tag!==''){
            $pdo->prepare("DELETE FROM user_tags WHERE user_id=? AND tag=? LIMIT 1")->execute([$uid,$tag]);
            J(true);
        } else { J(false,['msg'=>'Paramètres manquants'],400); }
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}

/** Historique des interactions */
if ($action === 'get_interactions') {
    try {
        $uid = (int)($_GET['user_id'] ?? 0);
        if (!$uid) J(false, ['msg' => 'User ID manquant'], 400);
        $stmt = $pdo->prepare("SELECT type, contenu, source, created_at
                               FROM user_interactions
                               WHERE user_id = ?
                               ORDER BY created_at DESC
                               LIMIT 50");
        $stmt->execute([$uid]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $interactions = [];
        foreach ($rows as $row) {
            $contenu_data = json_decode($row['contenu'], true);
            $row['contenu_struct'] = is_array($contenu_data) ? $contenu_data : ['texte' => $row['contenu']];
            $interactions[] = $row;
        }
        J(true, ['interactions' => $interactions]);
    } catch(Throwable $e) { J(false, ['msg' => $e->getMessage()], 500); }
}

/** Enregistrer une interaction enrichie */
if($action==='add_interaction'){
    try{
        $uid = (int)($_POST['user_id']??0);
        $type = $_POST['type']??'note';
        $source = $_POST['source_contact'] ?? 'sortant';
        $texte = trim($_POST['contenu']??'');
        $etat_esprit = trim($_POST['etat_esprit']??'');
        $date_promesse = trim($_POST['date_paiement_promise']??'');

        if($uid && $texte !== ''){
            $contenu_struct = [
                'texte' => $texte,
                'etat_esprit' => $etat_esprit ?: null,
                'date_paiement_promise' => $date_promesse ?: null
            ];
            $contenu_json = json_encode($contenu_struct, JSON_UNESCAPED_UNICODE);

            $pdo->prepare("INSERT INTO user_interactions (user_id, type, contenu, source) VALUES (?, ?, ?, ?)")
                ->execute([$uid, $type, $contenu_json, $source]);

            if($HAS_LAST_CONTACT){
                $pdo->prepare("UPDATE demandes_retrait
                               SET last_contact_at=NOW()
                               WHERE user_id=? AND statut IN ('en_attente','valide','partiel','litige')")
                    ->execute([$uid]);
            }
            J(true);
        } else {
            J(false,['msg'=>'Paramètres manquants'],400);
        }
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}

/** Upload de preuve sécurisé */
if($action==='upload_preuve'){
    try{
        $did=(int)($_POST['demande_id']??0);
        if(!$did || empty($_FILES['preuve']['tmp_name'])) J(false,['msg'=>'Fichier manquant'],400);

        $preuve = $_FILES['preuve'];
        if ($preuve['error'] !== UPLOAD_ERR_OK) J(false, ['msg' => 'Erreur technique lors de l\'upload.'], 400);

        $max_size = 5 * 1024 * 1024; // 5 Mo
        if ($preuve['size'] > $max_size) J(false, ['msg' => 'Le fichier est trop volumineux (max 5 Mo).'], 400);

        $allowed_exts = ['pdf', 'png', 'jpg', 'jpeg'];
        $allowed_mimes = ['application/pdf', 'image/png', 'image/jpeg'];
        $ext = strtolower(pathinfo($preuve['name'], PATHINFO_EXTENSION));

        // Fallback MIME
        if (function_exists('mime_content_type')) {
            $mime = mime_content_type($preuve['tmp_name']);
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($preuve['tmp_name']);
        }

        if (!in_array($ext, $allowed_exts) || !in_array($mime, $allowed_mimes)) {
            J(false, ['msg' => 'Type de fichier non autorisé (PDF, PNG, JPG acceptés).'], 400);
        }

        $dir=__DIR__.'/uploads/preuves'; ensure_dir($dir);
        $name='preuve_'.$did.'_'.time().'.'.$ext; $dest=$dir.'/'.$name;

        if(!move_uploaded_file($preuve['tmp_name'],$dest)) J(false,['msg'=>'Échec de sauvegarde du fichier'],500);

        $rel='uploads/preuves/'.$name;
        if($HAS_PREUVE){
            $pdo->prepare("UPDATE demandes_retrait SET preuve_virement=? WHERE id=?")->execute([$rel,$did]);
        }
        J(true,['url'=>$rel]);
    }catch(Throwable $e){ J(false,['msg'=>$e->getMessage()],500); }
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Remboursements Stratégiques — Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
:root{--bg:#f5f5f5; --card:#fff; --text:#333; --muted:#757575; --pri:#4CAF50; --priD:#388E3C; --accent:#e91e63; --warn:#F57C00; --err:#d32f2f; --ok:#2e7d32; --br:8px; --shadow:0 1px 3px rgba(0,0,0,.12), 0 1px 2px rgba(0,0,0,.24); --pad:10px; --padlg:14px; --fs:14px; --fss:12px;}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;font:400 var(--fs)/1.35 'Roboto',Arial;background:var(--bg);color:var(--text);display:flex}
.sidebar{background:var(--card);width:260px;min-width:260px;height:100vh;padding:16px;position:sticky;top:0;box-shadow:var(--shadow)}
.sidebar-header{margin-bottom:12px;text-align:center;font-weight:700;color:var(--pri)}
.sidebar ul{list-style:none;padding:0;margin:0}
.sidebar a{display:flex;align-items:center;gap:10px;padding:8px;border-radius:8px;text-decoration:none;color:#666;margin-bottom:6px}
.sidebar a:hover,.sidebar a.active{background:var(--pri);color:#fff}
.container{flex:1;padding:12px 16px;min-width:0}
.card{background:var(--card);border-radius:var(--br);box-shadow:var(--shadow);padding:12px}
.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.toolbar .sp{flex:1}
input,select,button{font:inherit;border:1px solid #e0e0e0;border-radius:8px;padding:8px;background:#fff;color:var(--text)}
button{cursor:pointer}
.btn{border:0;border-radius:8px;padding:8px 10px;font-weight:600}
.btn.pri{background:var(--pri);color:#fff}
.btn.sec{background:#6c757d;color:#fff}
.btn.ghost{background:transparent;border:1px dashed #ccc;color:#555}
.badge{padding:3px 8px;border-radius:999px;border:1px solid #eee;background:#fafafa;font-size:11px;color:#666}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:8px 0}
.kpi{display:flex;gap:8px;align-items:center}
.kpi .value{font-weight:700}
.grid{display:grid;grid-template-columns: 1fr;gap:8px;height:calc(100vh - 140px)}
.tablewrap{height:100%;overflow:auto;border:1px solid #eee;border-radius:8px}
table{width:100%;border-collapse:collapse}
th,td{padding:8px;border-bottom:1px solid #f0f0f0;vertical-align:middle}
th{font-size:11px;color:#777;text-transform:uppercase;letter-spacing:.03em;text-align:left;position:sticky;top:0;background:#fff;z-index:1}
td.right{text-align:right}
.small{font-size:var(--fss);color:var(--muted)}
.status{padding:2px 6px;border-radius:999px;border:1px solid #eee;font-size:11px}
.status.wait{background:#fff7e6;color:#b36b00;border-color:#ffe0b2}
.status.ok{background:#e8f5e9;color:#1b5e20;border-color:#c8e6c9}
.status.warn{background:#fffde7;color:#827717;border-color:#fff59d}
.money-pos{color:var(--ok);font-weight:600}
.money-neg{color:var(--err);font-weight:600}
.pager{display:flex;gap:6px;align-items:center;justify-content:flex-end;margin-top:6px}
.pill{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:999px;background:#f3f4f6;border:1px solid #eee;font-size:12px}
.tooltip{position:relative;display:inline-block}
.tooltip:hover .tip{opacity:1;visibility:visible}
.tip{opacity:0;visibility:hidden;position:absolute;bottom:140%;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:6px 8px;border-radius:6px;font-size:11px;white-space:nowrap}
.drawer{position:fixed;top:0;right:-420px;width:380px;height:100vh;background:#fff;box-shadow:-2px 0 12px rgba(0,0,0,.15);transition:right .2s ease;padding:14px;z-index:9999; display: flex; flex-direction: column;}
.drawer.open{right:0}
.drawer-content{flex:1; overflow-y:auto; margin-top:10px;}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.hidden{display:none}
</style>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-header">La Serre</div>
  <ul>
    <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
    <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
    <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
    <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
    <li><a href="gestion_documents.php"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
    <li><a href="rendez_vous.php"><span class="material-symbols-outlined">event</span>Gestion RDV</a></li>
    <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
    <li><a href="remboursement.php" class="active"><span class="material-symbols-outlined">payments</span>Remboursement</a></li>
    <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
    <li><a href="codepromo.php"><span class="material-symbols-outlined">sell</span>Codes Promo</a></li>
    <li><a href="virements.php"><span class="material-symbols-outlined">account_balance</span>Gestion Virements</a></li>
    <li><a href="parametres.php"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
    <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
  </ul>
</div>
<div class="container">
  <div class="card toolbar">
    <span class="pill"><span class="material-symbols-outlined" style="font-size:18px;color:var(--pri)">info</span> Urgence=jours depuis <b>fin de contrat</b> · Δcash=(ENI - montant)</span>
    <div class="sp"></div>
    <input id="solde" class="w" type="number" step="0.01" placeholder="Solde (€)" style="width:120px">
    <button class="btn sec" onclick="saveSolde()">Enr. solde</button>
    <input id="q" placeholder="Nom/Email" style="width:140px">
    <select id="statut" style="width:140px">
      <option value="all" selected>Tous statuts</option>
      <option value="en_attente">En attente</option>
      <option value="valide">Validés</option>
      <option value="paye">Payés</option>
      <option value="partiel">Partiels</option>
      <option value="litige">Litiges</option>
    </select>
    <input id="tag" placeholder="Tag" style="width:110px">
    <input id="minScore" type="number" min="0" max="100" value="0" style="width:70px" title="Score min">
    <select id="per" style="width:80px"><option>10</option><option selected>12</option><option>15</option><option>20</option></select>
    <button class="btn" onclick="loadList()">Filtrer</button>
    <button class="btn ghost" onclick="resetFilters()">Reset</button>
  </div>

  <div class="kpis">
    <div class="card kpi"><span class="material-symbols-outlined" style="color:var(--pri)">savings</span><div><div class="value" id="kpi_solde">0,00 €</div><div class="small">Solde</div></div></div>
    <div class="card kpi"><span class="material-symbols-outlined">hourglass_top</span><div><div class="value" id="kpi_wait">0</div><div class="small">En attente</div></div></div>
    <div class="card kpi"><span class="material-symbols-outlined">euro</span><div><div class="value" id="kpi_wait_sum">0,00 €</div><div class="small">Total (page)</div></div></div>
    <div class="card kpi"><span class="material-symbols-outlined">checklist_rtl</span><div><div class="value" id="kpi_sel">0</div><div class="small">Sélection</div></div></div>
  </div>

  <div class="card toolbar" style="gap:10px">
    <select id="strategie" style="width:220px">
      <option value="urgence">Urgence d'abord</option>
      <option value="ia_recommandee">✨ Stratégie IA Recommandée</option>
      <option value="max_dossiers">Max dossiers</option>
      <option value="max_delta_cash">Max Δcash</option>
      <option value="cashflow_net">Rendement/jour</option>
    </select>
    <label class="small">Partiel<input id="partial" type="checkbox" style="margin-left:6px"></label>
    <label class="small">Min%<input id="partial_floor" type="number" step="0.05" min="0.3" max="1.0" value="0.6" style="width:70px;margin-left:6px"></label>
    <label class="small">Chaîne<input id="chain" type="checkbox" style="margin-left:6px"></label>
    <label class="small">Horizon<input id="horizon" type="number" min="1" max="30" value="7" style="width:70px;margin-left:6px"></label>
    <span class="sp"></span>
    <label class="small">Jours ≥<input id="rule_min_days" type="number" min="0" value="0" style="width:70px;margin-left:6px"></label>
    <label class="small">VIP max<input id="rule_vip_max" type="number" min="0" value="0" style="width:70px;margin-left:6px"></label>
    <label class="small">Excl. litige<input id="rule_excl_litige" type="checkbox" style="margin-left:6px"></label>
    <label class="small">Cap/Client €<input id="rule_cap" type="number" step="0.01" min="0" value="0" style="width:90px;margin-left:6px"></label>
    <button class="btn pri" onclick="prioriser()">Prioriser</button>
    <span id="simu_out" class="small"></span>
  </div>

  <div class="grid">
    <div class="card tablewrap">
      <table id="tbl">
        <thead>
          <tr>
            <th><input type="checkbox" id="chk_all" onclick="toggleAll(this)"></th>
            <th>Urgence</th>
            <th>Client</th>
            <th>Montant</th>
            <th>Δcash</th>
            <th>Réinvest</th>
            <th>Statut</th>
            <th class="right">Tags & Actions</th>
          </tr>
        </thead>
        <tbody id="tbody"><tr id="placeholder"><td colspan="8" class="small" style="text-align:center;color:#888;">Chargement…</td></tr></tbody>
      </table>
    </div>
    <div class="pager">
      <button class="btn ghost" onclick="prevPage()">«</button>
      <span class="small" id="page_info">Page 1</span>
      <button class="btn ghost" onclick="nextPage()">»</button>
      <button class="btn ok" id="btn_validate" style="margin-left:auto;background:var(--ok);color:#fff" onclick="validerLot()" disabled>Valider le lot</button>
      <span class="pill"><b id="sel_total">0,00 €</b></span>
      <span class="pill">Δ <b id="sel_delta">0,00 €</b></span>
    </div>
  </div>
</div>

<div id="drawer" class="drawer">
  <div class="row" style="justify-content:space-between">
    <h3 id="drawer_title" style="margin:0">Fiche client</h3>
    <button class="btn ghost" onclick="toggleDrawer(false)">Fermer</button>
  </div>
  <div class="small" id="drawer_sub"></div>
  <div class="drawer-content">
    <hr>
    <div class="row">
      <label class="small">Souhaite réinvestir</label>
      <select id="sr" style="width:160px">
        <option value="indecis">Indécis</option>
        <option value="oui">Oui</option>
        <option value="non">Non</option>
      </select>
    </div>
    <div class="row">
      <input id="mrp" type="number" step="0.01" placeholder="Montant promis (€)" style="width:160px">
      <input id="p"   type="number" step="0.01" placeholder="Proba (0-1)" style="width:100px">
      <input id="d"   type="number" step="1" placeholder="Délai (j)"  style="width:90px">
      <button class="btn sec" onclick="saveReinvest()">Enregistrer</button>
    </div>
    <hr>
    <div>
      <h4 style="margin:6px 0">Nouvelle Interaction</h4>
      <div class="row" style="margin-bottom:8px;">
        <select id="ia_type" style="flex:1;">
          <option value="appel">Appel</option>
          <option value="mail">Mail</option>
          <option value="sms">SMS</option>
          <option value="note" selected>Note interne</option>
        </select>
        <select id="ia_source_contact" style="flex:1;">
          <option value="entrant">Contact Entrant</option>
          <option value="sortant">Contact Sortant</option>
        </select>
      </div>
      <div class="row" style="margin-bottom:8px;">
        <select id="ia_etat_esprit" style="flex:1;">
          <option value="">-- État d'esprit --</option>
          <option value="Calme">Calme</option>
          <option value="Coopératif">Coopératif</option>
          <option value="Inquiet">Inquiet</option>
          <option value="Mécontent">Mécontent</option>
          <option value="Agressif">Agressif</option>
        </select>
        <div style="flex:1;">
          <label for="ia_date_promesse" class="small" style="display:block; margin-bottom:2px;">Paiement promis pour le :</label>
          <input type="date" id="ia_date_promesse" style="width:100%;">
        </div>
      </div>
      <textarea id="ia_text" rows="3" style="width:100%; margin-bottom:6px" placeholder="Détails de l'échange, résumé..."></textarea>
      <button class="btn" onclick="addInteraction()">Ajouter l'interaction</button>
    </div>
    <hr>
    <div>
      <h4 style="margin:6px 0">Historique des Interactions</h4>
      <div id="interactions_history" style="max-height: 250px; overflow-y: auto; border: 1px solid #eee; padding: 8px; border-radius: 8px;">
        <div class="small" style="text-align:center;">Sélectionnez un client</div>
      </div>
    </div>
    <hr>
    <div>
      <h4 style="margin:6px 0">Preuve de virement</h4>
      <input type="file" id="preuve" style="width:100%;margin-bottom:6px">
      <input type="hidden" id="preuve_demande_id">
      <button class="btn sec" onclick="uploadPreuve()">Uploader</button>
      <div class="small" id="preuve_out"></div>
    </div>
  </div>
</div>

<script>
let selection=new Map(); let page=1, per=12, total=0; let currentUser=null;

document.addEventListener('DOMContentLoaded', async ()=>{
  // ⚠️ Par défaut: "all"
  document.getElementById('statut').value='all';
  per=parseInt(document.getElementById('per').value||'12',10);
  await loadSolde();
  await loadList();
});

async function loadSolde(){
  const r=await fetch('remboursement.php?action=get_solde');
  const j=await r.json();
  if(j.ok){
    const v=j.solde||0;
    document.getElementById('solde').value=v.toFixed(2);
    document.getElementById('kpi_solde').innerText=eur(v);
  }
}
async function saveSolde(){
  const v=parseFloat(document.getElementById('solde').value||'0');
  const fd=new FormData();
  fd.append('action','set_solde');
  fd.append('solde',v);
  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok){ document.getElementById('kpi_solde').innerText=eur(j.solde||0); }
  else alert(j.msg||'Erreur set_solde');
}

async function loadList(){
  const qs=new URLSearchParams({
    action:'list',
    q:document.getElementById('q').value,
    statut:document.getElementById('statut').value,
    tag:document.getElementById('tag').value,
    minScore:document.getElementById('minScore').value||0,
    page:page,
    per:document.getElementById('per').value||12
  });
  const r=await fetch('remboursement.php?'+qs.toString());
  const j=await r.json();
  if(!j.ok){ alert(j.msg||'Erreur list'); return; }

  total=j.total||0; per=j.per||12;
  document.getElementById('page_info').innerText = `Page ${j.page} — ${total} lignes`;
  document.getElementById('kpi_wait').innerText = j.kpi_wait_count||0;
  document.getElementById('kpi_wait_sum').innerText = eur(j.kpi_wait_sum||0);

  selection.clear();
  refreshFooter();
  document.getElementById('chk_all').checked=false;

  const tb=document.getElementById('tbody');
  tb.innerHTML='';
  if(!j.items || j.items.length===0){
    const tr=document.createElement('tr');
    tr.innerHTML=`<td colspan="8" class="small" style="text-align:center;color:#888;">Aucune donnée à afficher avec les filtres actuels.</td>`;
    tb.appendChild(tr);
    return;
  }

  (j.items||[]).forEach(it=>{
    const urgBadge = `<span class="badge">${it.score}</span> <span class="small tooltip">${it.overdue_days||0} j<span class="tip">Depuis fin contrat : ${escapeHtml(it.date_ref_urgence || '-')}</span></span>`;
    const reinvDot = (it.eni>0)? `<span class="tooltip">●<span class="tip">ENI ${eur(it.eni)}</span></span>` : '○';
    const status=renderStatus(it.statut||'');
    const anomaly = it.anomaly_iban? `<span class="badge" style="border-color:#ffcdd2;background:#ffebee;color:#b71c1c">IBAN partagé</span>`:'';
    const rel = (it.has_reliab && it.p_eff!=null)? `<span class="badge">Fiab ${(it.p_eff*100).toFixed(0)}%</span>`:'';
    const tagsMini = (it.tags||[]).slice(0,2).map(t=>`<span class="badge">${escapeHtml(t)}</span>`).join(' ');
    const tagsMore = (it.tags||[]).length>2 ? `<span class="badge">+${(it.tags||[]).length-2}</span>`:'';
    const tr=document.createElement('tr');
    tr.dataset.id=it.demande_id;
    tr.dataset.user=it.user_id;
    tr.dataset.montant=it.montant;
    tr.dataset.delta=it.delta_cash||0;
    tr.dataset.score=it.score;
    tr.innerHTML=`
      <td><input type="checkbox" onchange="toggleOne(this,${it.demande_id})"></td>
      <td>${urgBadge}</td>
      <td>
        <div style="font-weight:700">${escapeHtml(it.prenom||'')} ${escapeHtml(it.nom||'')}</div>
        <div class="small">${escapeHtml(it.email)}</div>
        <div class="row">${anomaly}${rel}</div>
      </td>
      <td style="font-weight:700">${eur(it.montant)}</td>
      <td class="${it.delta_cash>=0?'money-pos':'money-neg'}">${eur(it.delta_cash)}</td>
      <td>${reinvDot}</td>
      <td>${status}</td>
      <td class="right">
        ${tagsMini} ${tagsMore}
        <button class="btn ghost" onclick="addTagPrompt(${it.user_id})">+ tag</button>
        <button class="btn ghost" onclick="openDrawer(${it.user_id}, ${it.demande_id}, '${js(it.prenom)} ${js(it.nom)}')">Voir</button>
      </td>`;
    tb.appendChild(tr);
  });
}

function renderStatus(s){
  s=s.trim();
  if(s==='en_attente') return '<span class="status wait">En attente</span>';
  if(s==='valide')     return '<span class="status ok">Validé</span>';
  if(s==='paye')       return '<span class="status ok">Payé</span>';
  if(s==='partiel')    return '<span class="status warn">Partiel</span>';
  if(s==='litige')     return '<span class="status warn">Litige</span>';
  return '<span class="status">-</span>';
}

function prevPage(){ if(page>1){ page--; loadList(); } }
function nextPage(){ const maxPage = Math.ceil(total / per); if(page<maxPage){ page++; loadList(); } }

function toggleOne(chk,id){
  const tr=chk.closest('tr');
  if(chk.checked){
    selection.set(id,{
      demande_id:id,
      user_id:parseInt(tr.dataset.user),
      montant:parseFloat(tr.dataset.montant||0),
      delta:parseFloat(tr.dataset.delta||0),
      score:parseInt(tr.dataset.score||0)
    });
  } else selection.delete(id);
  refreshFooter();
}
function toggleAll(master){
  document.querySelectorAll('#tbody input[type=checkbox]').forEach(ch=>{
    ch.checked=master.checked;
    ch.dispatchEvent(new Event('change'));
  });
}
function refreshFooter(){
  const arr=[...selection.values()];
  const total=arr.reduce((a,b)=>a+(b.montant||0),0);
  const delta=arr.reduce((a,b)=>a+(b.delta||0),0);
  document.getElementById('kpi_sel').innerText=arr.length;
  document.getElementById('sel_total').innerText=eur(total);
  document.getElementById('sel_delta').innerText=eur(delta);
  document.getElementById('btn_validate').disabled = arr.length===0;
}

async function prioriser(){
  const solde=parseFloat(document.getElementById('solde').value||'0');
  if(!(solde>0)){ alert('Renseignez un solde > 0'); return; }
  const fd=new FormData();
  fd.append('action','simulate');
  fd.append('solde',solde);
  fd.append('strategie', document.getElementById('strategie').value);
  fd.append('partial_enabled', document.getElementById('partial').checked?1:0);
  fd.append('partial_floor', document.getElementById('partial_floor').value||'0.6');
  fd.append('chain_enabled', document.getElementById('chain').checked?1:0);
  fd.append('horizon_days', document.getElementById('horizon').value||'7');
  fd.append('rule_min_days', document.getElementById('rule_min_days').value||'0');
  fd.append('rule_vip_max', document.getElementById('rule_vip_max').value||'0');
  fd.append('rule_exclude_litige', document.getElementById('rule_excl_litige').checked?1:0);
  fd.append('rule_cap_per_client', document.getElementById('rule_cap').value||'0');

  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(!j.ok){ alert(j.msg||'Erreur simulation'); return; }

  const selIds=new Set((j.selection||[]).map(x=>x.demande_id));
  selection.clear();

  document.querySelectorAll('#tbody tr').forEach(tr=>{
    const id=parseInt(tr.dataset.id);
    const chk=tr.querySelector('input[type=checkbox]');
    if(selIds.has(id)){
      chk.checked=true;
      tr.style.background='#f1f8e9';
    } else {
      chk.checked=false;
      tr.style.background='transparent';
    }
  });

  toggleAll({checked:false});
  document.querySelectorAll('#tbody input[type=checkbox]:checked').forEach(c=>c.dispatchEvent(new Event('change')));

  document.getElementById('simu_out').innerText =
    `Sélection: ${(j.selection||[]).length} · Total ${eur(j.montant_total||0)} · Δ ${eur(j.delta_total||0)} · Reste ${eur(j.budget_restant||0)}`;
}

async function validerLot(){
  if(!confirm(`Confirmez-vous la validation de ${selection.size} dossier(s) pour un total de ${document.getElementById('sel_total').innerText} ?`)) return;
  const payload=[...selection.values()];
  if(payload.length===0) return;

  const solde_initial=parseFloat(document.getElementById('solde').value||'0');
  const explain = document.getElementById('simu_out').innerText || '';

  const fd=new FormData();
  fd.append('action','validate');
  fd.append('payload', JSON.stringify(payload));
  fd.append('solde_initial', solde_initial);
  fd.append('strategie', document.getElementById('strategie').value);
  fd.append('explain', explain);

  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok){
    alert(`Lot #${j.lot_id} validé (${eur(j.montant_total)})`);
    selection.clear();
    refreshFooter();
    await loadSolde();
    await loadList();
  }else alert(j.msg||'Erreur validation');
}

function toggleDrawer(open){ document.getElementById('drawer').classList.toggle('open', !!open); }

function openDrawer(user_id, demande_id, titre){
  currentUser={user_id,demande_id};
  document.getElementById('drawer_title').innerText = titre;
  document.getElementById('drawer_sub').innerText = `Utilisateur #${user_id} — Demande #${demande_id}`;
  document.getElementById('preuve_demande_id').value = demande_id;
  document.getElementById('ia_text').value = '';
  document.getElementById('ia_date_promesse').value = '';
  document.getElementById('ia_etat_esprit').value = '';
  loadInteractions(user_id);
  toggleDrawer(true);
}

async function loadInteractions(userId) {
  const historyDiv = document.getElementById('interactions_history');
  historyDiv.innerHTML = 'Chargement...';
  try {
    const response = await fetch(`remboursement.php?action=get_interactions&user_id=${userId}`);
    const data = await response.json();
    if (!data.ok) { historyDiv.innerHTML = `<span style="color:var(--err);">${data.msg || 'Erreur'}</span>`; return; }
    if (!data.interactions || data.interactions.length === 0) {
      historyDiv.innerHTML = '<div class="small" style="text-align:center;">Aucune interaction.</div>'; return;
    }
    let html = '';
    data.interactions.forEach(inter => {
      const date = new Date(inter.created_at).toLocaleDateString('fr-FR', {day:'2-digit', month:'2-digit', year:'numeric'});
      const type = inter.type.charAt(0).toUpperCase() + inter.type.slice(1);
      const source = inter.source === 'entrant' ? 'Entrant' : 'Sortant';
      const contenu = inter.contenu_struct;
      html += `<div style="border-bottom: 1px dashed #e0e0e0; padding-bottom: 8px; margin-bottom: 8px;">`;
      html += `<strong>${escapeHtml(type)} (${source})</strong> - <span class="small">${date}</span>`;
      if (contenu.etat_esprit) { html += `<div class="small"><em>État d'esprit: ${escapeHtml(contenu.etat_esprit)}</em></div>`; }
      html += `<p style="margin:4px 0; white-space: pre-wrap;">${escapeHtml(contenu.texte)}</p>`;
      if (contenu.date_paiement_promise) {
        html += `<span class="badge" style="background:var(--warn); color:white; border:0;">Paiement promis pour: ${escapeHtml(contenu.date_paiement_promise)}</span>`;
      }
      html += `</div>`;
    });
    historyDiv.innerHTML = html;
  } catch (e) {
    historyDiv.innerHTML = `<span style="color:var(--err);">Erreur réseau.</span>`;
  }
}

async function addInteraction(){
  if(!currentUser) return;
  const txt=document.getElementById('ia_text').value.trim();
  if(!txt) { alert("Le champ de description ne peut pas être vide."); return; }

  const fd=new FormData();
  fd.append('action','add_interaction');
  fd.append('user_id', currentUser.user_id);
  fd.append('type', document.getElementById('ia_type').value);
  fd.append('contenu', txt);
  fd.append('source_contact', document.getElementById('ia_source_contact').value);
  fd.append('etat_esprit', document.getElementById('ia_etat_esprit').value);
  fd.append('date_paiement_promise', document.getElementById('ia_date_promesse').value);

  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok){
    loadInteractions(currentUser.user_id);
    document.getElementById('ia_text').value='';
    document.getElementById('ia_date_promesse').value='';
    document.getElementById('ia_etat_esprit').value='';
  } else { alert(j.msg||'Erreur'); }
}

async function saveReinvest(){
  if(!currentUser) return;
  const fd=new FormData();
  fd.append('action','update_reinvest');
  fd.append('user_id',currentUser.user_id);
  fd.append('souhaite_reinvestir', document.getElementById('sr').value);
  fd.append('montant_reinvest_promis', document.getElementById('mrp').value||'');
  fd.append('proba_reinvest', document.getElementById('p').value||'');
  fd.append('delai_reinvest_jours', document.getElementById('d').value||'');

  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok){ await loadList(); } else alert(j.msg||'Erreur');
}

async function uploadPreuve(){
  const dem=document.getElementById('preuve_demande_id').value;
  const f=document.getElementById('preuve').files[0];
  if(!dem||!f){ alert('Sélectionnez une demande et un fichier.'); return; }
  const fd=new FormData();
  fd.append('action','upload_preuve');
  fd.append('demande_id',dem);
  fd.append('preuve',f);

  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok){ document.getElementById('preuve_out').innerText='Preuve uploadée.'; }
  else alert(j.msg||'Erreur upload');
}

function addTagPrompt(uid){ const t=prompt('Nouveau tag'); if(!t) return; addTag(uid,t.trim()); }
async function addTag(uid,tag){
  const fd=new FormData();
  fd.append('action','add_tag');
  fd.append('user_id',uid);
  fd.append('tag',tag);
  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok) loadList(); else alert(j.msg||'Erreur');
}
async function removeTag(uid,tag){
  const fd=new FormData();
  fd.append('action','remove_tag');
  fd.append('user_id',uid);
  fd.append('tag',tag);
  const r=await fetch('remboursement.php',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok) loadList(); else alert(j.msg||'Erreur');
}

function eur(x){ return (parseFloat(x||0)).toLocaleString('fr-FR',{style:'currency',currency:'EUR'}); }
function escapeHtml(s){ return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }
function js(s){ return (s||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }
function resetFilters(){
  document.getElementById('q').value='';
  document.getElementById('statut').value='all';
  document.getElementById('tag').value='';
  document.getElementById('minScore').value=0;
  page=1;
  loadList();
}
document.getElementById('per').addEventListener('change',()=>{ page=1; loadList(); });
</script>
</body>
</html>
