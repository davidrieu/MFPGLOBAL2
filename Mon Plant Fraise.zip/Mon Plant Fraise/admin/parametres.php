<?php
// 1. Démarrage de la session et sécurité
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php';

// Helper pour mettre à jour un paramètre
function update_setting(PDO $pdo, $key, $value) {
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->execute([$key, $value, $value]);
}

// 3. Gestion de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sécurité CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Action non autorisée.');
    }

    try {
        // Mettre à jour les paramètres généraux
        update_setting($pdo, 'site_name', trim($_POST['site_name']));

        // Mettre à jour les paramètres SMTP
        update_setting($pdo, 'smtp_host', trim($_POST['smtp_host']));
        update_setting($pdo, 'smtp_port', (int)$_POST['smtp_port']);
        update_setting($pdo, 'smtp_username', trim($_POST['smtp_username']));
        // Ne met à jour le mot de passe que s'il n'est pas vide
        if (!empty($_POST['smtp_password'])) {
            update_setting($pdo, 'smtp_password', $_POST['smtp_password']);
        }
        update_setting($pdo, 'from_name', trim($_POST['from_name']));
        update_setting($pdo, 'from_email', trim($_POST['from_email']));

        // Mettre à jour les heures d'ouverture
        update_setting($pdo, 'business_hours_start', $_POST['business_hours_start']);
        update_setting($pdo, 'business_hours_end', $_POST['business_hours_end']);
        // Encoder les jours de la semaine en JSON pour le stockage
        $days = $_POST['business_hours_days'] ?? [];
        update_setting($pdo, 'business_hours_days', json_encode($days));

        $_SESSION['flash_message'] = "Les paramètres ont été enregistrés avec succès.";

    } catch (PDOException $e) {
        $_SESSION['flash_message'] = "Erreur lors de l'enregistrement des paramètres : " . $e->getMessage();
        $_SESSION['flash_type'] = 'error';
    }

    header('Location: parametres.php');
    exit();
}

// 4. Récupération des paramètres actuels pour affichage
try {
    $settings_raw = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    // Décoder les jours de la semaine
    $settings_raw['business_hours_days'] = json_decode($settings_raw['business_hours_days'] ?? '[]', true);
} catch (PDOException $e) {
    die("Erreur de chargement des paramètres : " . $e->getMessage());
}

// Génération du token CSRF
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paramètres - La Serre Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        *, *::before, *::after { box-sizing: border-box; }
        body { background: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0,0,0,.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color); }
        .sidebar ul { list-style: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: .2s; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background: var(--primary-color); color: #fff; }
        .container { margin-left: 280px; padding: 20px; width: calc(100% - 280px); }
        .page-header h1 { margin: 0 0 20px 0; font-size: 28px; font-weight: 700; }
        .card { background: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); margin-bottom: 20px; }
        .card-header { color: var(--text-color); margin-top: 0; font-size: 20px; font-weight: 500; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px; display: flex; align-items: center; gap: 12px; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 25px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        .form-group label { color: var(--text-color-light); font-size: 14px; font-weight: 500; }
        .form-group .input, .form-group select { width: 100%; padding: 12px; border-radius: var(--border-radius); border: 1px solid #ddd; }
        .form-group .description { font-size: 12px; color: #999; }
        .days-group { display: flex; flex-wrap: wrap; gap: 15px; margin-top: 5px;}
        .days-group label { font-size: 14px; display: flex; align-items: center; gap: 5px; cursor: pointer;}
        .form-actions { margin-top: 30px; }
        .btn { display: inline-flex; align-items: center; gap: 8px; background: var(--primary-color); color: #fff; padding: 12px 20px; border: none; border-radius: var(--border-radius); cursor: pointer; font-weight: 500; text-decoration: none; font-size: 16px; }
        .btn:hover { filter: brightness(90%); }
        .flash-message { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; text-align: center; }
        .flash-message.error { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb;}
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="parametres.php" class="active"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Paramètres</h1>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?= $_SESSION['flash_type'] ?? '' ?>">
            <?= htmlspecialchars($_SESSION['flash_message']); ?>
        </div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
    <?php endif; ?>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

        <div class="card">
            <h3 class="card-header"><span class="material-symbols-outlined">storefront</span>Paramètres Généraux</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label for="site_name">Nom du Site</label>
                    <input type="text" id="site_name" name="site_name" class="input" value="<?= htmlspecialchars($settings_raw['site_name'] ?? 'La Serre') ?>">
                </div>
            </div>
        </div>

        <div class="card">
            <h3 class="card-header"><span class="material-symbols-outlined">mail</span>Configuration Email (SMTP)</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label for="from_name">Nom de l'Expéditeur</label>
                    <input type="text" id="from_name" name="from_name" class="input" value="<?= htmlspecialchars($settings_raw['from_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="from_email">Email de l'Expéditeur</label>
                    <input type="email" id="from_email" name="from_email" class="input" value="<?= htmlspecialchars($settings_raw['from_email'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="smtp_host">Serveur SMTP</label>
                    <input type="text" id="smtp_host" name="smtp_host" class="input" value="<?= htmlspecialchars($settings_raw['smtp_host'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="smtp_port">Port SMTP</label>
                    <input type="number" id="smtp_port" name="smtp_port" class="input" value="<?= htmlspecialchars($settings_raw['smtp_port'] ?? '587') ?>">
                </div>
                <div class="form-group">
                    <label for="smtp_username">Nom d'utilisateur SMTP</label>
                    <input type="text" id="smtp_username" name="smtp_username" class="input" value="<?= htmlspecialchars($settings_raw['smtp_username'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="smtp_password">Mot de passe SMTP</label>
                    <input type="password" id="smtp_password" name="smtp_password" class="input" placeholder="Laisser vide pour ne pas changer">
                    <p class="description">Le mot de passe n'est pas affiché pour des raisons de sécurité.</p>
                </div>
            </div>
        </div>

        <div class="card">
            <h3 class="card-header"><span class="material-symbols-outlined">schedule</span>Heures d'Ouverture (Messagerie)</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label for="business_hours_start">Heure d'ouverture</label>
                    <input type="time" id="business_hours_start" name="business_hours_start" class="input" value="<?= htmlspecialchars($settings_raw['business_hours_start'] ?? '09:00') ?>">
                </div>
                <div class="form-group">
                    <label for="business_hours_end">Heure de fermeture</label>
                    <input type="time" id="business_hours_end" name="business_hours_end" class="input" value="<?= htmlspecialchars($settings_raw['business_hours_end'] ?? '18:00') ?>">
                </div>
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Jours d'ouverture</label>
                    <div class="days-group">
                        <?php 
                            $days_of_week = [1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi', 5 => 'Vendredi', 6 => 'Samedi', 7 => 'Dimanche'];
                            $selected_days = $settings_raw['business_hours_days'] ?? [];
                        ?>
                        <?php foreach ($days_of_week as $day_num => $day_name): ?>
                            <label>
                                <input type="checkbox" name="business_hours_days[]" value="<?= $day_num ?>" <?= in_array($day_num, $selected_days) ? 'checked' : '' ?>>
                                <?= $day_name ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn"><span class="material-symbols-outlined">save</span>Enregistrer les modifications</button>
        </div>
    </form>
</div>

</body>
</html>