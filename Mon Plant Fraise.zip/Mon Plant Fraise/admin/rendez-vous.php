<?php
ini_set('display_errors', 1); // Affiche les erreurs à l'écran
error_reporting(E_ALL);     // Affiche tous les types d'erreurs
// 1. Démarrer la session et sécuriser la page
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données et fonctions email
require_once '../db_connection.php'; 
require_once '../mail_functions.php'; // INCLUSION DE LA FONCTION D'ENVOI D'EMAIL

// 3. Logique de mise à jour du statut (MODIFIÉE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $rdv_id = $_POST['rdv_id'];
    $new_status = $_POST['new_status'];
    
    try {
        // NOUVEAU : On récupère les infos du RDV AVANT la mise à jour si le statut est "Confirmé"
        $rdv_info = null; // Initialiser la variable
        if ($new_status == 'Confirmé') {
            $stmt_info = $pdo->prepare("SELECT nom_complet, email, date_rdv, heure_rdv FROM rendez_vous WHERE id = ?");
            $stmt_info->execute([$rdv_id]);
            $rdv_info = $stmt_info->fetch(PDO::FETCH_ASSOC);
        }

        // Mise à jour du statut dans la base de données
        $stmt = $pdo->prepare("UPDATE rendez_vous SET statut = ? WHERE id = ?");
        $stmt->execute([$new_status, $rdv_id]);
        $_SESSION['status_message'] = "Le statut du rendez-vous #$rdv_id a été mis à jour.";

        // NOUVEAU : On envoie l'email de confirmation si le statut est "Confirmé" et qu'on a les infos
        if ($new_status == 'Confirmé' && $rdv_info) {
            $subject = "Votre rendez-vous téléphonique est confirmé !";
            // Formattage de la date en français pour l'email
            $date_rdv_formatted = (new DateTime($rdv_info['date_rdv']))->format('d/m/Y');

            $body = "
                <h2>Bonjour " . htmlspecialchars($rdv_info['nom_complet']) . ",</h2>
                <p>Excellente nouvelle ! Votre rendez-vous téléphonique avec un conseiller Mon Plant Fraise a été <strong>confirmé</strong>.</p>
                <p>Il aura lieu le :</p>
                <h3>" . $date_rdv_formatted . " à " . htmlspecialchars($rdv_info['heure_rdv']) . "</h3>
                <p>Un membre de notre équipe vous appellera à la date et l'heure convenues sur le numéro que vous nous avez communiqué.</p>
                <p>Cordialement,<br>L'équipe Mon Plant Fraise</p>
            ";
            
            // On appelle la fonction d'envoi
            send_appointment_email($rdv_info['email'], $subject, $body);
        }

    } catch (PDOException $e) {
        $_SESSION['status_message'] = "Erreur lors de la mise à jour du statut.";
        // Pour le débogage, vous pouvez décommenter la ligne suivante :
        // error_log('Erreur de mise à jour RDV: ' . $e->getMessage());
    }
    
    header('Location: rendez_vous.php');
    exit();
}


// 4. Récupérer tous les rendez-vous
try {
    // Trier par date de RDV puis par heure
    $stmt = $pdo->query("
        SELECT id, nom_complet, telephone, email, date_rdv, heure_rdv, date_soumission, statut 
        FROM rendez_vous 
        ORDER BY date_rdv DESC, heure_rdv ASC
    ");
    $rdvs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des rendez-vous : " . $e->getMessage());
}

// Fonction pour déterminer la couleur du statut
function getStatusClass($status) {
    switch (strtolower($status)) {
        case 'confirmé':
            return 'status-confirmed';
        case 'annulé':
            return 'status-cancelled';
        case 'effectué':
            return 'status-done';
        default:
            return 'status-pending'; // Pour 'en attente'
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Rendez-vous - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        :root {
            --primary-color: #4CAF50;
            --primary-color-dark: #388E3C;
            --secondary-color: #6c757d;
            --text-color: #333333;
            --text-color-light: #757575;
            --background-color: #f5f5f5;
            --card-background-color: #ffffff;
            --border-radius: 8px;
            --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .card h1 { color: var(--text-color); margin-top: 0; font-size: 24px; font-weight: 700; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        th { font-weight: 700; color: var(--text-color); font-size: 14px; text-transform: uppercase; }
        td { font-size: 14px; color: var(--text-color-light); }
        tr:last-child td { border-bottom: none; }
        
        .status-badge { padding: 4px 10px; border-radius: 12px; font-weight: 500; font-size: 12px; color: white; text-align: center; }
        .status-pending { background-color: #ff9800; } /* Orange pour 'en attente' */
        .status-confirmed { background-color: #4CAF50; } /* Vert pour 'confirmé' */
        .status-cancelled { background-color: #f44336; } /* Rouge pour 'annulé' */
        .status-done { background-color: #607d8b; }    /* Gris pour 'effectué' */
        
        .action-form select {
            padding: 5px 8px;
            border-radius: var(--border-radius);
            border: 1px solid #ccc;
            margin-right: 5px;
        }
        .action-form button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 6px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.2s;
        }
        .action-form button:hover { background-color: var(--primary-color-dark); }

        .notification { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        
        .toggle-btn { display: none; }
         @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease-in-out; }
            .sidebar.open { transform: translateX(0); }
            .container { margin-left: 20px; width: calc(100% - 40px); }
            .toggle-btn { display: flex; align-items: center; justify-content: center; position: fixed; top: 15px; left: 15px; background-color: var(--primary-color); color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 1001; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size: 24px; }
            table, thead, tbody, th, td, tr { display: block; }
            thead tr { position: absolute; top: -9999px; left: -9999px; }
            tr { border: 1px solid #ccc; margin-bottom: 10px; }
            td { border: none; border-bottom: 1px solid #eee; position: relative; padding-left: 50%; }
            td:before { position: absolute; top: 6px; left: 6px; width: 45%; padding-right: 10px; white-space: nowrap; font-weight: bold; }
            td:nth-of-type(1):before { content: "RDV"; }
            td:nth-of-type(2):before { content: "Client"; }
            td:nth-of-type(3):before { content: "Contact"; }
            td:nth-of-type(4):before { content: "Statut"; }
            td:nth-of-type(5):before { content: "Action"; }
        }
    </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()"><span class="material-symbols-outlined">menu</span></button>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="gestion_documents.php"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="rendez_vous.php" class="active"><span class="material-symbols-outlined">event</span>Gestion RDV</a></li>
        <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="parametres.php"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="card">
        <h1>Gestion des Rendez-vous</h1>
        
        <?php if (isset($_SESSION['status_message'])): ?>
            <div class="notification">
                <?= htmlspecialchars($_SESSION['status_message']); ?>
            </div>
            <?php unset($_SESSION['status_message']); ?>
        <?php endif; ?>

        <?php if (empty($rdvs)): ?>
            <p>Aucune demande de rendez-vous pour le moment.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Date du RDV</th>
                        <th>Client</th>
                        <th>Contact</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rdvs as $rdv): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars(date('d/m/Y', strtotime($rdv['date_rdv']))) ?></strong><br>
                                <small><?= htmlspecialchars($rdv['heure_rdv']) ?></small>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($rdv['nom_complet']) ?></strong><br>
                                <small>Soumis le <?= htmlspecialchars(date('d/m/Y', strtotime($rdv['date_soumission']))) ?></small>
                            </td>
                            <td>
                                <?= htmlspecialchars($rdv['telephone']) ?><br>
                                <a href="mailto:<?= htmlspecialchars($rdv['email']) ?>"><?= htmlspecialchars($rdv['email']) ?></a>
                            </td>
                            <td>
                                <span class="status-badge <?= getStatusClass($rdv['statut']) ?>">
                                    <?= htmlspecialchars($rdv['statut']) ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" action="" class="action-form">
                                    <input type="hidden" name="rdv_id" value="<?= $rdv['id'] ?>">
                                    <select name="new_status">
                                        <option value="En attente" <?= $rdv['statut'] == 'En attente' ? 'selected' : '' ?>>En attente</option>
                                        <option value="Confirmé" <?= $rdv['statut'] == 'Confirmé' ? 'selected' : '' ?>>Confirmé</option>
                                        <option value="Effectué" <?= $rdv['statut'] == 'Effectué' ? 'selected' : '' ?>>Effectué</option>
                                        <option value="Annulé" <?= $rdv['statut'] == 'Annulé' ? 'selected' : '' ?>>Annulé</option>
                                    </select>
                                    <button type="submit" name="update_status">OK</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<script>
    function toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('open');
    }
</script>

</body>
</html>