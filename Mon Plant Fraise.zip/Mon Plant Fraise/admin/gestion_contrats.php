<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../admin/db_connection.php';

// ===================================================================
// GESTION DES ACTIONS (CHANGEMENT DE STATUT, SUPPRESSION, EXPORT CSV)
// ===================================================================

// --- EXPORT CSV ---
if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {
    // On récupère tous les paramètres de filtre pour que l'export corresponde à la vue
    $search_query_csv = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status_filter_csv = isset($_GET['statut']) ? $_GET['statut'] : '';
    $date_from_csv = isset($_GET['date_from']) ? $_GET['date_from'] : '';
    $date_to_csv = isset($_GET['date_to']) ? $_GET['date_to'] : '';
    $quick_view_csv = isset($_GET['view']) ? $_GET['view'] : '';

    $sql_base_csv = "FROM contrats c LEFT JOIN users u ON c.user_id = u.id";
    $where_clauses_csv = [];
    $params_csv = [];

    if ($quick_view_csv === 'expiring') {
        $where_clauses_csv[] = "c.statut = 'en_cours' AND c.created_at <= DATE_SUB(NOW(), INTERVAL 11 MONTH) AND c.created_at > DATE_SUB(NOW(), INTERVAL 12 MONTH)";
    } elseif ($quick_view_csv === 'pending') {
        $where_clauses_csv[] = "c.statut = 'en_attente'";
    }

    if (!empty($search_query_csv)) {
        $where_clauses_csv[] = "(CONCAT(u.prenom, ' ', u.name) LIKE ? OR c.email LIKE ? OR c.id = ?)";
        $params_csv = array_merge($params_csv, ["%$search_query_csv%", "%$search_query_csv%", $search_query_csv]);
    }
    if (!empty($status_filter_csv)) {
        $where_clauses_csv[] = "c.statut = ?";
        $params_csv[] = $status_filter_csv;
    }
    if (!empty($date_from_csv)) {
        $where_clauses_csv[] = "c.date_souscription >= ?";
        $params_csv[] = $date_from_csv;
    }
    if (!empty($date_to_csv)) {
        $where_clauses_csv[] = "c.date_souscription <= ?";
        $params_csv[] = $date_to_csv;
    }
    
    $sql_where_csv = !empty($where_clauses_csv) ? " WHERE " . implode(" AND ", $where_clauses_csv) : "";
    
    $export_stmt = $pdo->prepare("SELECT c.*, CONCAT(u.prenom, ' ', u.name) as user_full_name " . $sql_base_csv . $sql_where_csv . " ORDER BY c.id DESC");
    $export_stmt->execute($params_csv);
    $contrats_to_export = $export_stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=\"export_contrats_'.date('Y-m-d').'.csv\"');
    $output = fopen('php://output', 'w');
    fputcsv($output, array('ID Contrat', 'Client', 'Email', 'Date Souscription', 'Montant', 'Apport', 'Statut', 'Code Promo', 'Code Parrain'), ';');
    foreach ($contrats_to_export as $contrat) {
        fputcsv($output, [$contrat['id'], $contrat['user_full_name'], $contrat['email'], $contrat['date_souscription'], $contrat['montant'], $contrat['apport'], $contrat['statut'], $contrat['promo_code'], $contrat['code_parrain']], ';');
    }
    fclose($output);
    exit();
}


// --- AUTRES ACTIONS ---
if (isset($_GET['action'])) {
    if (!isset($_GET['token']) || !hash_equals($_SESSION['csrf_token'], $_GET['token'])) {
        die('Action non autorisée (jeton de sécurité invalide).');
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $contrat_id = filter_input(INPUT_POST, 'contrat_id', FILTER_VALIDATE_INT);
    if ($contrat_id) {
        try {
            if ($action === 'change_status') {
                $new_status = $_POST['statut'];
                $allowed_statuses = ['en_attente', 'en_cours', 'termine', 'annule'];
                if (in_array($new_status, $allowed_statuses)) {
                    $stmt = $pdo->prepare("UPDATE contrats SET statut = ? WHERE id = ?");
                    $stmt->execute([$new_status, $contrat_id]);
                    $_SESSION['flash_message'] = "Le statut du contrat #{$contrat_id} a été mis à jour.";
                }
            }
        } catch (PDOException $e) { $_SESSION['flash_message'] = "Erreur..."; $_SESSION['flash_type'] = 'error'; }
    }
    header('Location: gestion_contrats.php' . '?' . $_SERVER['QUERY_STRING']);
    exit();
}
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $contrat_id_to_delete = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if ($contrat_id_to_delete) {
        try {
            $stmt = $pdo->prepare("DELETE FROM contrats WHERE id = ?");
            $stmt->execute([$contrat_id_to_delete]);
            $_SESSION['flash_message'] = "Le contrat #{$contrat_id_to_delete} a été supprimé.";
        } catch (PDOException $e) {
             $_SESSION['flash_message'] = "Erreur: Impossible de supprimer le contrat.";
             $_SESSION['flash_type'] = 'error';
        }
    }
    header('Location: gestion_contrats.php');
    exit();
}
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));


// ===================================================================
// LOGIQUE D'AFFICHAGE (RECHERCHE, FILTRE, PAGINATION, TRI)
// ===================================================================
$limit = 15;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['statut']) ? $_GET['statut'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$quick_view = isset($_GET['view']) ? $_GET['view'] : ''; 

$sql_base = "FROM contrats c LEFT JOIN users u ON c.user_id = u.id";
$where_clauses = [];
$params = [];

if ($quick_view === 'expiring') {
    $where_clauses[] = "c.statut = 'en_cours' AND c.created_at <= DATE_SUB(NOW(), INTERVAL 11 MONTH) AND c.created_at > DATE_SUB(NOW(), INTERVAL 12 MONTH)";
} elseif ($quick_view === 'pending') {
    $where_clauses[] = "c.statut = 'en_attente'";
}

if (!empty($search_query)) {
    $where_clauses[] = "(CONCAT(u.prenom, ' ', u.name) LIKE ? OR c.email LIKE ? OR c.id = ?)";
    $params = array_merge($params, ["%$search_query%", "%$search_query%", $search_query]);
}
if (!empty($status_filter)) {
    $where_clauses[] = "c.statut = ?";
    $params[] = $status_filter;
}
if (!empty($date_from)) {
    $where_clauses[] = "c.date_souscription >= ?";
    $params[] = $date_from;
}
if (!empty($date_to)) {
    $where_clauses[] = "c.date_souscription <= ?";
    $params[] = $date_to;
}
$sql_where = !empty($where_clauses) ? " WHERE " . implode(" AND ", $where_clauses) : "";

$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'date_souscription';
$sort_order = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$allowed_columns = ['id', 'user_full_name', 'date_souscription', 'montant', 'statut'];
if (!in_array($sort_column, $allowed_columns)) { $sort_column = 'date_souscription'; }
$allowed_orders = ['ASC', 'DESC'];
if (!in_array($sort_order, $allowed_orders)) { $sort_order = 'DESC'; }

$kpi_sql = "SELECT COUNT(c.id) as nb_contrats, SUM(c.montant) as total_montant, SUM(c.apport) as total_apport FROM contrats c LEFT JOIN users u ON c.user_id = u.id " . $sql_where;
$kpi_stmt = $pdo->prepare($kpi_sql);
$kpi_stmt->execute($params);
$kpis = $kpi_stmt->fetch(PDO::FETCH_ASSOC);

$conversion_rate_stmt = $pdo->query("SELECT AVG(CASE WHEN statut = 'en_cours' THEN 1 ELSE 0 END) * 100 as rate FROM contrats WHERE statut IN ('en_cours', 'annule')");
$kpi_conversion_rate = $conversion_rate_stmt->fetchColumn();
$total_contrats = $kpis['nb_contrats'];
$total_pages = ceil($total_contrats / $limit);

$contrats_sql = "SELECT c.id, c.user_id, CONCAT(u.prenom, ' ', u.name) as user_full_name, c.date_souscription, c.montant, c.statut, c.mensualites_payees FROM contrats c LEFT JOIN users u ON c.user_id = u.id " . $sql_where . " ORDER BY {$sort_column} {$sort_order} LIMIT {$limit} OFFSET {$offset}";
$contrats_stmt = $pdo->prepare($contrats_sql);
$contrats_stmt->execute($params);
$contrats = $contrats_stmt->fetchAll(PDO::FETCH_ASSOC);

$query_params = ['search' => $search_query, 'statut' => $status_filter, 'date_from' => $date_from, 'date_to' => $date_to, 'view' => $quick_view];
$base_query_string = http_build_query(array_filter($query_params));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Contrats - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
    <style>
        /* CSS identique à la version précédente */
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --danger-color: #d32f2f; --danger-color-dark: #c62828;
            --warning-color: #F57C00; --info-color: #0288d1;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
            --status-en-cours: #28a745; --status-en-attente: #ffc107; --status-termine: #6c757d; --status-annule: #dc3545;
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .page-header h1 { margin: 0; font-size: 28px; font-weight: 700; }
        .header-actions { display: flex; flex-wrap: wrap; gap: 10px; }
        .btn { display: inline-flex; align-items: center; padding: 10px 15px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .btn-secondary { background-color: var(--secondary-color); color: white;}
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); margin-bottom: 20px;}
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .kpi-card-simple { background-color: var(--card-background-color); padding: 20px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); text-align: center; }
        .kpi-card-simple .label { font-size: 14px; color: var(--text-color-light); margin-bottom: 8px; }
        .kpi-card-simple .value { font-size: 24px; font-weight: 700; color: var(--primary-color); }
        .filters { display: flex; flex-wrap: wrap; gap: 15px; align-items: center; }
        .filters input, .filters select { padding: 10px; border: 1px solid #ddd; border-radius: var(--border-radius); font-size: 14px; }
        .quick-views { margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap; }
        .quick-views a { color: var(--primary-color); text-decoration: none; font-weight: 500; padding: 8px 12px; border-radius: var(--border-radius); background-color: #e8f5e9; transition: background-color 0.2s ease; font-size: 14px; }
        .quick-views a.active, .quick-views a:hover { background-color: var(--primary-color); color: white; }
        .contrats-table { width: 100%; border-collapse: collapse; }
        .contrats-table th, .contrats-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
        .contrats-table th { background-color: #fafafa; font-weight: 500; font-size: 14px; color: var(--text-color-light); }
        .contrats-table th a { color: inherit; text-decoration: none; }
        .contrats-table th a:hover { color: var(--primary-color); }
        .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: 500; color: white; text-transform: capitalize; }
        .status-en_cours { background-color: var(--status-en-cours); }
        .status-en_attente { background-color: var(--status-en-attente); color: #333; }
        .status-termine { background-color: var(--status-termine); }
        .status-annule { background-color: var(--status-annule); }
        .actions { display: flex; align-items: center; gap: 5px; white-space: nowrap; }
        .actions-form select { padding: 6px; font-size: 12px; border-radius: 4px; border: 1px solid #ccc;}
        .actions a { color: var(--text-color-light); text-decoration: none; display: inline-flex; align-items: center; }
        .actions a:hover { color: var(--primary-color); }
        .payment-progress { font-size: 12px; color: var(--text-color-light); }
        .pagination { margin-top: 20px; text-align: center; }
        .pagination a, .pagination span { margin: 0 5px; padding: 8px 12px; text-decoration: none; color: var(--text-color); border: 1px solid #ddd; border-radius: var(--border-radius); }
        .pagination a:hover { background-color: #f0f0f0; }
        .pagination .current { background-color: var(--primary-color); color: white; border-color: var(--primary-color); }
        .flash-message { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; text-align: center; }
        .flash-message.error { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb;}
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php" class="active"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
      	<li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Gestion des Contrats</h1>
        <div class="header-actions">
            <a href="?<?= $base_query_string ?>&action=export_csv" class="btn btn-secondary"><span class="material-symbols-outlined">download</span>Exporter en CSV</a>
            <a href="add_contrat.php" class="btn btn-primary"><span class="material-symbols-outlined">add</span>Nouveau Contrat</a>
        </div>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?= $_SESSION['flash_type'] ?? '' ?>"><?= htmlspecialchars($_SESSION['flash_message']); ?></div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
    <?php endif; ?>

    <div class="kpi-grid">
        <div class="kpi-card-simple"><div class="label">Contrats (Filtre)</div><div class="value"><?= $kpis['nb_contrats'] ?? 0 ?></div></div>
        <div class="kpi-card-simple"><div class="label">Montant Total</div><div class="value"><?= number_format($kpis['total_montant'] ?? 0, 2, ',', ' ') ?> €</div></div>
        <div class="kpi-card-simple"><div class="label">Apport Total</div><div class="value"><?= number_format($kpis['total_apport'] ?? 0, 2, ',', ' ') ?> €</div></div>
        <div class="kpi-card-simple"><div class="label">Taux de Conversion</div><div class="value"><?= number_format($kpi_conversion_rate ?? 0, 1) ?> %</div></div>
    </div>
    
    <div class="card">
        <div class="quick-views">
            <a href="?" class="<?= empty($quick_view) && empty($status_filter) && empty($search_query) ? 'active' : '' ?>">Tout voir</a>
            <a href="?view=pending" class="<?= $quick_view == 'pending' ? 'active' : '' ?>">En attente de validation</a>
            <a href="?view=expiring" class="<?= $quick_view == 'expiring' ? 'active' : '' ?>">Expirant bientôt</a>
        </div>
        <form method="GET" action="gestion_contrats.php">
            <div class="filters">
                <input type="text" name="search" placeholder="Rechercher..." value="<?= htmlspecialchars($search_query) ?>">
                <select name="statut">
                    <option value="">Tous les statuts</option>
                    <option value="en_attente" <?= $status_filter == 'en_attente' ? 'selected' : '' ?>>En attente</option>
                    <option value="en_cours" <?= $status_filter == 'en_cours' ? 'selected' : '' ?>>En cours</option>
                    <option value="termine" <?= $status_filter == 'termine' ? 'selected' : '' ?>>Terminé</option>
                    <option value="annule" <?= $status_filter == 'annule' ? 'selected' : '' ?>>Annulé</option>
                </select>
                <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>" title="Date de début">
                <input type="date" name="date_to" value="<?= htmlspecialchars($date_to) ?>" title="Date de fin">
                <button type="submit" class="btn btn-primary">Filtrer</button>
            </div>
        </form>
    </div>
    
    <div class="card" style="overflow-x: auto;">
        <table class="contrats-table">
            <thead>
                <tr>
                    <?php function sort_link($column, $title, $current_column, $current_order, $base_query) {
                        $order = ($current_column == $column && $current_order == 'ASC') ? 'DESC' : 'ASC';
                        echo "<th><a href=\"?sort={$column}&order={$order}&{$base_query}\">{$title}</a></th>";
                    } ?>
                    <?= sort_link('id', 'ID', $sort_column, $sort_order, $base_query_string) ?>
                    <?= sort_link('user_full_name', 'Client', $sort_column, $sort_order, $base_query_string) ?>
                    <?= sort_link('date_souscription', 'Date Sous.', $sort_column, $sort_order, $base_query_string) ?>
                    <?= sort_link('montant', 'Montant', $sort_column, $sort_order, $base_query_string) ?>
                    <?= sort_link('statut', 'Statut', $sort_column, $sort_order, $base_query_string) ?>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($contrats)): ?>
                    <tr><td colspan="6" style="text-align: center; padding: 20px;">Aucun contrat trouvé.</td></tr>
                <?php else: ?>
                    <?php foreach ($contrats as $contrat): ?>
                        <tr>
                            <td><?= $contrat['id'] ?></td>
                            <td>
                                <a href="edit_user.php?id=<?= $contrat['user_id'] ?>"><?= htmlspecialchars($contrat['user_full_name']) ?></a>
                                <div class="payment-progress">Paiements: <?= $contrat['mensualites_payees'] ?? 0 ?> / 12</div>
                            </td>
                            <td><?= (new DateTime($contrat['date_souscription']))->format('d/m/Y') ?></td>
                            <td><?= number_format($contrat['montant'], 2, ',', ' ') ?> €</td>
                            <td><span class="status-badge status-<?= str_replace(' ', '_', $contrat['statut']) ?>"><?= str_replace('_', ' ', $contrat['statut']) ?></span></td>
                            <td>
                                <div class="actions">
                                    <form method="POST" class="actions-form" action="?<?= $base_query_string ?>">
                                        <input type="hidden" name="action" value="change_status">
                                        <input type="hidden" name="contrat_id" value="<?= $contrat['id'] ?>">
                                        <select name="statut" onchange="this.form.submit()" title="Changer le statut">
                                            <option value="en_attente" <?= $contrat['statut'] == 'en_attente' ? 'selected' : '' ?>>En attente</option>
                                            <option value="en_cours" <?= $contrat['statut'] == 'en_cours' ? 'selected' : '' ?>>En cours</option>
                                            <option value="termine" <?= $contrat['statut'] == 'termine' ? 'selected' : '' ?>>Terminé</option>
                                            <option value="annule" <?= $contrat['statut'] == 'annule' ? 'selected' : '' ?>>Annulé</option>
                                        </select>
                                    </form>
                                    <a href="details_contrat.php?id=<?= $contrat['id'] ?>" title="Voir les détails"><span class="material-symbols-outlined">visibility</span></a>
                                    <a href="generate_invoice.php?id=<?= $contrat['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" title="Générer Facture PDF"><span class="material-symbols-outlined">receipt_long</span></a>
                                    <a href="?action=delete&id=<?= $contrat['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" title="Supprimer" onclick="return confirm('Êtes-vous sûr ?');"><span class="material-symbols-outlined">delete</span></a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?= $i ?>&<?= $base_query_string ?>" class="<?= ($i == $page) ? 'current' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
</div>

</body>
</html>