<?php
session_start();
// SÉCURITÉ : Vérifier si l'admin est connecté
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// --- CONNEXION BDD ---
require '../db_connection.php'; 

// --- GESTION DES MESSAGES ---
$success_message = null;
$error_message = null;
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success_message = "Modifications enregistrées avec succès ! 👍";
}
if (isset($_GET['error']) && $_GET['error'] == 1) {
    $error_message = "Une erreur est survenue lors de la sauvegarde. Veuillez réessayer. 😥";
}

// --- LOGIQUE DE ROUTAGE DU CRM ---
$vue_detail = false;
$client_id = null;
$client_data = []; 
$client_contrats = [];
$client_produits_contrats = [];
$client_retraits = [];
$client_documents = [];
$client_notes = [];
$client_conversations = [];
$liste_clients = []; 

if (isset($_GET['client_id']) && !empty($_GET['client_id'])) {
    // --- VUE FICHE CLIENT (DÉTAIL) ---
    $vue_detail = true;
    $client_id = (int)$_GET['client_id'];

    // 1. Récupérer les infos principales du client (table: users)
    $stmt = $pdo->prepare("
        SELECT id, email, code_parrain, sponsorship_code, name, prenom, date_naissance, 
               nationalite, lieu_naissance, adresse, adresse_l1, adresse_l2, code_postal, 
               ville, pays, telephone, iban, last_activity, parrain, registration_date, 
               cagnotte, statut, verifie 
        FROM users 
        WHERE id = ?
    ");
    $stmt->execute([$client_id]);
    $client_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$client_data) {
        header('Location: crm.php');
        exit;
    }

    // 2. Récupérer les contrats du client (table: contrats)
    $stmt = $pdo->prepare("SELECT * FROM contrats WHERE user_id = ? ORDER BY date_souscription DESC");
    $stmt->execute([$client_id]);
    $client_contrats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 2b. Récupérer les noms ET TAUX des produits associés (table: produits)
    if (!empty($client_contrats)) {
        $produit_ids = array_unique(array_column($client_contrats, 'produit_id'));
        if (!empty($produit_ids)) {
            $produit_ids = array_values(array_filter($produit_ids));
            if (!empty($produit_ids)) {
                $in_query = implode(',', array_fill(0, count($produit_ids), '?'));
                $stmt = $pdo->prepare("SELECT id, name, taux FROM produits WHERE id IN ($in_query)");
                $stmt->execute($produit_ids);
                $produits_data_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($produits_data_raw as $prod) {
                    $client_produits_contrats[$prod['id']] = $prod;
                }
            }
        }
    }

    // 3. Récupérer les demandes de retrait (table: demandes_retrait)
    $stmt = $pdo->prepare("SELECT * FROM demandes_retrait WHERE user_id = ? ORDER BY date_demande DESC");
    $stmt->execute([$client_id]);
    $client_retraits = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Récupérer les documents (table: documents)
    $stmt = $pdo->prepare("SELECT * FROM documents WHERE user_id = ? ORDER BY upload_date DESC");
    $stmt->execute([$client_id]);
    $client_documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 5. Récupérer les notes admin (table: user_interactions)
    $stmt = $pdo->prepare("SELECT * FROM user_interactions WHERE user_id = ? AND type = 'admin_note' ORDER BY created_at DESC");
    $stmt->execute([$client_id]);
    $client_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 6. Récupérer les conversations et messages (tables: conversations, messages)
    $stmt = $pdo->prepare("
        SELECT 
            c.id as conversation_id, c.subject, c.status, c.created_at as conversation_date,
            m.body, m.created_at as message_date, m.sender_type, m.admin_id
        FROM conversations c
        LEFT JOIN messages m ON c.id = m.conversation_id
        WHERE c.user_id = ?
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$client_id]);
    $client_conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} else {
    // --- VUE LISTE CLIENTS ---
    $search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    if (!empty($search_query)) {
        $sql = "SELECT id, name, prenom, email, telephone, ville, statut 
                FROM users 
                WHERE name LIKE ? OR prenom LIKE ? OR email LIKE ? OR telephone LIKE ?
                ORDER BY name, prenom
                LIMIT 50";
        $stmt = $pdo->prepare($sql);
        $search_term = "%$search_query%";
        $stmt->execute([$search_term, $search_term, $search_term, $search_term]);
    } else {
        $sql = "SELECT id, name, prenom, email, telephone, ville, statut 
                FROM users 
                ORDER BY registration_date DESC 
                LIMIT 50";
        $stmt = $pdo->query($sql);
    }
    $liste_clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $vue_detail ? 'Fiche Client - ' . htmlspecialchars($client_data['prenom'] ?? '') . ' ' . htmlspecialchars($client_data['name'] ?? '') : 'CRM Clients'; ?> - La Serre</title>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/litepicker.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/plugins/ranges.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/litepicker/dist/css/litepicker.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <style>
        :root {
            --primary-color: #4CAF50;
            --primary-color-dark: #388E3C;
            --secondary-color: #6c757d;
            --text-color: #333333;
            --text-color-light: #757575;
            --background-color: #f5f5f5;
            --card-background-color: #ffffff;
            --border-radius: 8px;
            --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
            --box-shadow-hover: 0 4px 10px rgba(0,0,0,0.15), 0 2px 5px rgba(0,0,0,0.20);
            --status-pending: #FFC107;
            --status-approved: #4CAF50;
            --status-denied: #F44336;
            --alert-success-bg: #e8f5e9;
            --alert-success-border: #a5d6a7;
            --alert-success-text: #2e7d32;
            --alert-error-bg: #ffebee;
            --alert-error-border: #ef9a9a;
            --alert-error-text: #c62828;
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 999; transition: transform 0.3s ease-in-out; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .main-container { margin-left: 280px; padding: 20px; width: calc(100% - 320px); transition: margin-left 0.3s ease-in-out; }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); transition: box-shadow 0.2s ease; }
        .card:hover { box-shadow: var(--box-shadow-hover); }
        .card h3 { color: var(--text-color); margin-top: 0; font-size: 18px; font-weight: 500; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px; display: flex; align-items: center; }
        .card h3 .material-symbols-outlined { margin-right: 8px; font-size: 22px; color: var(--primary-color); }
        .dashboard-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .dashboard-header h1 { font-size: 24px; font-weight: 500; margin: 0; }
        
        /* === STYLES CRM === */
        .btn { padding: 10px 18px; font-size: 14px; font-weight: 500; border-radius: var(--border-radius); text-decoration: none; cursor: pointer; border: none; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease-in-out; }
        .btn:hover { transform: translateY(-1px); }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .btn-secondary { background-color: var(--secondary-color); color: white; }
        .btn-secondary:hover { background-color: #5a6268; }
        .btn-sm { padding: 6px 12px; font-size: 13px; }
        .btn-icon { padding: 6px; min-width: auto; }
        .btn-danger { background-color: var(--status-denied); color: white; }
        .btn-danger:hover { background-color: #c0392b; }

        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 6px; font-size: 14px; font-weight: 500; color: var(--text-color); }
        .form-control { width: 100%; padding: 10px 12px; font-size: 14px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; transition: border-color 0.2s ease, box-shadow 0.2s ease; }
        .form-control[readonly] { background-color: #f5f5f5; cursor: not-allowed; }
        .form-control:focus { border-color: var(--primary-color); outline: none; box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.15); }
        textarea.form-control { min-height: 100px; font-family: 'Roboto', sans-serif; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 0 20px; }

        .styled-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .styled-table thead tr { background-color: #f8f8f8; text-align: left; font-weight: 500; }
        .styled-table th, .styled-table td { padding: 12px 15px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
        .styled-table tbody tr { transition: background-color 0.15s ease; }
        .styled-table tbody tr:hover { background-color: #f5f5f5; }
        .styled-table .actions { white-space: nowrap; text-align: right; }
        .styled-table .status-badge { padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; color: white; white-space: nowrap; }
        .status-badge.pending { background-color: var(--status-pending); color: #333; }
        .status-badge.approved { background-color: var(--status-approved); }
        .status-badge.denied { background-color: var(--status-denied); }
        .status-badge.active { background-color: var(--status-approved); }
        .status-badge.suspended { background-color: var(--status-denied); }

        .nav-tabs { display: flex; list-style: none; padding: 0; margin: 0 0 -1px 0; border-bottom: 1px solid #ddd; }
        .nav-tabs .nav-link { padding: 12px 20px; cursor: pointer; border: 1px solid transparent; border-bottom: none; margin-right: 5px; border-radius: var(--border-radius) var(--border-radius) 0 0; font-weight: 500; color: var(--text-color-light); background-color: #f9f9f9; display: flex; align-items: center; gap: 8px; transition: color 0.2s ease, background-color 0.2s ease; }
        .nav-tabs .nav-link:hover { color: var(--primary-color); }
        .nav-tabs .nav-link.active { color: var(--primary-color-dark); background-color: var(--card-background-color); border-color: #ddd; border-bottom-color: var(--card-background-color); }
        .tab-content .tab-pane { display: none; }
        .tab-content .tab-pane.active { display: block; }
        .card-tabs { padding-top: 25px; border-top-left-radius: 0; border: 1px solid #ddd; border-top: none; }
        
        .sub-card { background-color: #fdfdfd; border: 1px solid #eee; border-radius: var(--border-radius); padding: 20px; margin-bottom: 15px; transition: box-shadow 0.2s ease; }
        .sub-card:hover { box-shadow: 0 2px 5px rgba(0,0,0,0.08); }
        .info-p { font-size: 14px; color: var(--text-color-light); }
        .info-p strong { color: var(--text-color); }
        .note-item { border-bottom: 1px solid #f0f0f0; padding: 15px 0; }
        .note-item:last-child { border-bottom: none; }
        .note-meta { font-size: 13px; color: var(--text-color-light); margin-bottom: 5px; }
        .note-body { font-size: 14px; white-space: pre-wrap; }

        .collapsible-header { cursor: pointer; transition: color 0.2s ease; padding-bottom: 10px; margin-bottom: 15px; display: flex; align-items: center; } 
        .collapsible-header:hover { color: var(--primary-color-dark); }
        .collapsible-header .collapse-icon { margin-left: auto; transition: transform 0.2s ease-in-out; }
        .collapsible-header.active .collapse-icon { transform: rotate(180deg); }
        .collapsible-content { padding-top: 15px; border-top: 1px solid #f0f0f0; animation: fadeIn 0.3s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

        .alert {
            padding: 15px 20px; margin-bottom: 20px; border: 1px solid transparent;
            border-radius: var(--border-radius); display: flex; align-items: center;
            gap: 10px; font-weight: 500; animation: fadeInDown 0.4s ease-out;
        }
        .alert .material-symbols-outlined { font-size: 24px; }
        .alert-success {
            color: var(--alert-success-text); background-color: var(--alert-success-bg);
            border-color: var(--alert-success-border);
        }
        .alert-error {
            color: var(--alert-error-text); background-color: var(--alert-error-bg);
            border-color: var(--alert-error-border);
        }
        @keyframes fadeInDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }

        /* --- CORRECTION IBAN --- */
        #requests .styled-table td, 
        #requests .styled-table th {
            padding: 8px 10px; 
            vertical-align: middle; 
        }
        #requests .styled-table td.iban-cell {
            white-space: nowrap; 
            overflow: hidden; 
            text-overflow: ellipsis; 
            max-width: 150px; /* Ajustez si besoin */
            cursor: help; 
        }
        #requests .styled-table input[type="date"],
        #requests .styled-table input[type="text"],
        #requests .styled-table select {
             padding: 6px 8px; 
             font-size: 13px;
        }
        /* --- FIN CORRECTION IBAN --- */
        
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">La Serre</div>
        <ul>
            <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
            <li><a href="crm.php" class="active"><span class="material-symbols-outlined">account_box</span>CRM Clients</a></li> <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
            <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
            <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
            <li><a href="gestion_documents.php"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
            <li><a href="rendez_vous.php"><span class="material-symbols-outlined">event</span>Gestion RDV</a></li>
            <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
            <li><a href="remboursement.php"><span class="material-symbols-outlined">payments</span>Remboursement</a></li>
            <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
            <li><a href="codepromo.php"><span class="material-symbols-outlined">sell</span>Codes Promo</a></li>
            <li><a href="virements.php"><span class="material-symbols-outlined">paid</span>Gestion Virements</a></li>
            <li><a href="abonnements.php"><span class="material-symbols-outlined">paid</span>Suivi récurrent</a></li>
            <li><a href="parametres.php"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
            <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
        </ul>
    </div>

    <div class="main-container">

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <span class="material-symbols-outlined">check_circle</span>
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <span class="material-symbols-outlined">error</span>
                 <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <?php if ($vue_detail): ?>
        
            <form action="actions/update_client.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="client_id" value="<?php echo htmlspecialchars($client_data['id'] ?? ''); ?>">
                
                <div class="dashboard-header">
                    <h1>
                        <span class="material-symbols-outlined" style="font-size: 28px; vertical-align: bottom; margin-right: 5px;">person</span>
                        Fiche Client : <?php echo htmlspecialchars($client_data['prenom'] ?? ''); ?> <?php echo htmlspecialchars($client_data['name'] ?? ''); ?>
                    </h1>
                    <div>
                        <a href="crm.php" class="btn btn-secondary btn-sm">
                            <span class="material-symbols-outlined">arrow_back</span> Retour Liste
                        </a>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <span class="material-symbols-outlined">save</span> Enregistrer Modifications
                        </button>
                    </div>
                </div>

                <ul class="nav-tabs" id="clientTab">
                    <li class="nav-link active" data-tab="info"><span class="material-symbols-outlined">badge</span>Infos Générales</li>
                    <li class="nav-link" data-tab="security"><span class="material-symbols-outlined">security</span>Compte & Sécurité</li>
                    <li class="nav-link" data-tab="contracts"><span class="material-symbols-outlined">description</span>Contrats & Docs</li>
                    <li class="nav-link" data-tab="requests"><span class="material-symbols-outlined">request_quote</span>Demandes & Actions</li>
                    <li class="nav-link" data-tab="notes"><span class="material-symbols-outlined">note_add</span>Notes Admin</li>
                    <li class="nav-link" data-tab="messages"><span class="material-symbols-outlined">forum</span>Messagerie</li>
                </ul>

                <div class="tab-content">
                    <div id="info" class="tab-pane active">
                        <div class="card card-tabs">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="client_id_display">ID Client</label>
                                    <input type="text" id="client_id_display" class="form-control" value="<?php echo htmlspecialchars($client_data['id'] ?? ''); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="prenom">Prénom</label>
                                    <input type="text" id="prenom" name="prenom" class="form-control" value="<?php echo htmlspecialchars($client_data['prenom'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nom">Nom</label>
                                    <input type="text" id="nom" name="nom" class="form-control" value="<?php echo htmlspecialchars($client_data['name'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($client_data['email'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="telephone">Téléphone</label>
                                    <input type="text" id="telephone" name="telephone" class="form-control" value="<?php echo htmlspecialchars($client_data['telephone'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="date_naissance">Date de Naissance</label>
                                    <input type="date" id="date_naissance" name="date_naissance" class="form-control" value="<?php echo htmlspecialchars($client_data['date_naissance'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nationalite">Nationalité</label>
                                    <input type="text" id="nationalite" name="nationalite" class="form-control" value="<?php echo htmlspecialchars($client_data['nationalite'] ?? ''); ?>">
                                </div>
                            </div>
                            <hr style="border-top: 1px solid #eee; margin: 10px 0 25px 0;">
                            <h3><span class="material-symbols-outlined">home_pin</span>Adresse</h3>
                            <div class="form-grid" style="grid-template-columns: 2fr 1fr;">
                                <div class="form-group">
                                    <label for="adresse">Adresse Ligne 1 (adresse)</label>
                                    <input type="text" id="adresse" name="adresse" class="form-control" value="<?php echo htmlspecialchars($client_data['adresse'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="adresse_l1">Adresse Ligne 2 (adresse_l1)</label>
                                    <input type="text" id="adresse_l1" name="adresse_l1" class="form-control" value="<?php echo htmlspecialchars($client_data['adresse_l1'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="code_postal">Code Postal</label>
                                    <input type="text" id="code_postal" name="code_postal" class="form-control" value="<?php echo htmlspecialchars($client_data['code_postal'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="ville">Ville</label>
                                    <input type="text" id="ville" name="ville" class="form-control" value="<?php echo htmlspecialchars($client_data['ville'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="pays">Pays</label>
                                    <input type="text" id="pays" name="pays" class="form-control" value="<?php echo htmlspecialchars($client_data['pays'] ?? ''); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="security" class="tab-pane">
                        <div class="card card-tabs">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="statut">Statut du Compte</label>
                                    <select id="statut" name="statut" class="form-control">
                                        <option value="pending" <?php if(($client_data['statut'] ?? '') == 'pending') echo 'selected'; ?>>En attente</option>
                                        <option value="active" <?php if(($client_data['statut'] ?? '') == 'active') echo 'selected'; ?>>Actif</option>
                                        <option value="suspended" <?php if(($client_data['statut'] ?? '') == 'suspended') echo 'selected'; ?>>Suspendu</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="verifie">Compte Vérifié (KYC)</label>
                                    <select id="verifie" name="verifie" class="form-control">
                                         <?php 
                                        $is_verified = (strtolower($client_data['verifie'] ?? '') === 'oui' || ($client_data['verifie'] ?? 0) == 1); 
                                        ?>
                                        <option value="0" <?php if (!$is_verified) echo 'selected'; ?>>Non Vérifié</option>
                                        <option value="1" <?php if ($is_verified) echo 'selected'; ?>>Vérifié</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="new_password">Nouveau Mot de Passe</label>
                                    <input type="password" id="new_password" name="new_password" class="form-control" placeholder="Laisser vide pour ne pas changer">
                                </div>
                            </div>
                            <hr style="border-top: 1px solid #eee; margin: 10px 0 25px 0;">
                            <h3><span class="material-symbols-outlined">account_balance_wallet</span>Finances & Parrainage</h3>
                             <div class="form-grid">
                                <div class="form-group">
                                    <label for="iban">IBAN</label>
                                    <input type="text" id="iban" name="iban" class="form-control" value="<?php echo htmlspecialchars($client_data['iban'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="cagnotte">Cagnotte</label>
                                    <input type="text" id="cagnotte" name="cagnotte" class="form-control" value="<?php echo htmlspecialchars($client_data['cagnotte'] ?? ''); ?> €">
                                </div>
                                <div class="form-group">
                                    <label for="code_parrain">Son Code Parrain (code_parrain)</label>
                                    <input type="text" id="code_parrain" class="form-control" value="<?php echo htmlspecialchars($client_data['code_parrain'] ?? ''); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="parrain">ID de son Parrain (parrain)</label>
                                    <input type="text" id="parrain" name="parrain" class="form-control" value="<?php echo htmlspecialchars($client_data['parrain'] ?? ''); ?>">
                                </div>
                            </div>
                            <hr style="border-top: 1px solid #eee; margin: 10px 0 25px 0;">
                            <h3><span class="material-symbols-outlined">history_toggle_off</span>Activité</h3>
                            <p class="info-p"><strong>Compte créé le :</strong> <?php echo htmlspecialchars($client_data['registration_date'] ?? ''); ?></p>
                            <p class="info-p"><strong>Dernière activité :</strong> <?php echo htmlspecialchars($client_data['last_activity'] ?? ''); ?></p>
                        </div>
                    </div>

                    <div id="contracts" class="tab-pane">
                        <div class="card card-tabs">
                            
                            <h3 class="collapsible-header active" data-collapse="contrats-content">
                                <span class="material-symbols-outlined">description</span>
                                Contrats (<?php echo count($client_contrats); ?>)
                                <span class="material-symbols-outlined collapse-icon">expand_less</span>
                            </h3>
                            
                            <div id="contrats-content" class="collapsible-content" style="display: block;">
                                <?php if (empty($client_contrats)): ?>
                                    <p class="info-p">Aucun contrat trouvé pour ce client.</p>
                                <?php else: ?>
                                    <?php foreach ($client_contrats as $contrat): ?>
                                        <?php $current_prod = $client_produits_contrats[$contrat['produit_id']] ?? null; ?>
                                        <div class="sub-card">
                                            <div class="form-grid" style="grid-template-columns: repeat(5, 1fr); gap: 15px;">
                                                <div class="form-group">
                                                    <label>ID Contrat</label>
                                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($contrat['id'] ?? ''); ?>" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label>Produit (ID: <?php echo htmlspecialchars($contrat['produit_id'] ?? ''); ?>)</label>
                                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($current_prod ? $current_prod['name'] : 'Produit Inconnu'); ?>" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label>Taux Produit</label>
                                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($current_prod ? ($current_prod['taux'] ?? 'N/A') : 'N/A'); ?> %" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label>Date Souscription</label>
                                                    <input type="date" class="form-control" value="<?php echo htmlspecialchars(date('Y-m-d', strtotime($contrat['date_souscription'] ?? ''))); ?>" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label>Date de Fin (auto)</label>
                                                    <input type="date" class="form-control" value="<?php echo htmlspecialchars(date('Y-m-d', strtotime($contrat['date_fin'] ?? ''))); ?>" readonly> 
                                                </div>
                                            </div> 
                                            <div class="form-grid" style="grid-template-columns: repeat(4, 1fr); gap: 15px;"> 
                                                <div class="form-group">
                                                    <label>Montant (€)</label>
                                                    <input type="text" name="contrat[<?php echo $contrat['id']; ?>][montant]" class="form-control" value="<?php echo htmlspecialchars($contrat['montant'] ?? ''); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Statut</label>
                                                    <select class="form-control" name="contrat[<?php echo $contrat['id']; ?>][statut]">
                                                        <option value="en_cours" <?php if(($contrat['statut'] ?? '') == 'en_cours') echo 'selected'; ?>>En cours</option>
                                                        <option value="termine" <?php if(($contrat['statut'] ?? '') == 'termine') echo 'selected'; ?>>Terminé</option>
                                                        <option value="annule" <?php if(($contrat['statut'] ?? '') == 'annule') echo 'selected'; ?>>Annulé</option>
                                                    </select>
                                                </div>
                                                 <div class="form-group">
                                                    <label>Mensualités Payées</label>
                                                    <input type="number" name="contrat[<?php echo $contrat['id']; ?>][mensualites_payees]" class="form-control" value="<?php echo htmlspecialchars($contrat['mensualites_payees'] ?? ''); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Défaut Paiement</label>
                                                    <input type="number" name="contrat[<?php echo $contrat['id']; ?>][defaut_paiement]" class="form-control" value="<?php echo htmlspecialchars($contrat['defaut_paiement'] ?? ''); ?>">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Note admin sur ce contrat</label>
                                                <textarea class="form-control" name="contrat[<?php echo $contrat['id']; ?>][note]"><?php echo htmlspecialchars($contrat['note'] ?? ''); ?></textarea>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            
                            <hr style="border-top: 1px solid #eee; margin: 10px 0 25px 0;">

                            <h3 class="collapsible-header" data-collapse="docs-content">
                                <span class="material-symbols-outlined">folder_zip</span>
                                Documents (<?php echo count($client_documents); ?>)
                                <span class="material-symbols-outlined collapse-icon">expand_more</span>
                            </h3>
                            
                            <div id="docs-content" class="collapsible-content" style="display: none;">
                                <table class="styled-table" style="font-size: 13px;">
                                    <thead>
                                        <tr>
                                            <th>Date Upload</th>
                                            <th>Catégorie</th>
                                            <th>Nom Fichier</th>
                                            <th>Statut</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($client_documents)): ?>
                                            <tr><td colspan="5" style="text-align: center;">Aucun document.</td></tr>
                                        <?php else: ?>
                                            <?php foreach ($client_documents as $doc): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars(date('d/m/Y', strtotime($doc['upload_date'] ?? ''))); ?></td>
                                                <td>
                                                    <input type="text" name="document[<?php echo $doc['id']; ?>][category]" class="form-control" value="<?php echo htmlspecialchars($doc['category'] ?? ''); ?>">
                                                </td>
                                                <td><?php echo htmlspecialchars($doc['filename'] ?: $doc['file_name'] ?? ''); ?></td>
                                                <td>
                                                    <select name="document[<?php echo $doc['id']; ?>][status]" class="form-control">
                                                        <option value="pending" <?php if(($doc['status'] ?? '') == 'pending') echo 'selected'; ?>>En attente</option>
                                                        <option value="validated" <?php if(($doc['status'] ?? '') == 'validated') echo 'selected'; ?>>Validé</option>
                                                        <option value="rejected" <?php if(($doc['status'] ?? '') == 'rejected') echo 'selected'; ?>>Rejeté</option>
                                                    </select>
                                                </td>
                                                <td class="actions">
                                                    <a href="<?php echo htmlspecialchars($doc['file_path'] ?? '#'); ?>" target="_blank" class="btn btn-secondary btn-sm btn-icon" title="Voir">
                                                        <span class="material-symbols-outlined">visibility</span>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="form-group" style="margin-top: 20px;">
                                    <label>Ajouter un nouveau document</label>
                                    <input type="file" name="new_document" class="form-control">
                                    <input type="text" name="new_document_category" class="form-control" placeholder="Catégorie du document (ex: RIB, CNI...)" style="margin-top: 8px;">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="requests" class="tab-pane">
                        <div class="card card-tabs">
                            <h3><span class="material-symbols-outlined">request_quote</span>Demandes de retrait (<?php echo count($client_retraits); ?>)</h3>
                            <table class="styled-table" style="font-size: 13px;">
                                <thead>
                                    <tr>
                                        <th>Date Demande</th>
                                        <th>Contrat ID</th>
                                        <th>Montant</th>
                                        <th>IBAN</th>
                                        <th>Statut</th>
                                        <th>Date Virement</th>
                                        <th>Réf. Virement</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($client_retraits)): ?>
                                        <tr><td colspan="7" style="text-align: center;">Aucune demande de retrait.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($client_retraits as $retrait): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars(date('d/m/Y', strtotime($retrait['date_demande'] ?? ''))); ?></td>
                                                <td><?php echo htmlspecialchars($retrait['contrat_id'] ?? ''); ?></td>
                                                <td>
                                                    <input type="text" name="retrait[<?php echo $retrait['id']; ?>][montant]" class="form-control" value="<?php echo htmlspecialchars($retrait['montant'] ?? '0.00'); ?>">
                                                </td>
                                                <td class="iban-cell" title="<?php echo htmlspecialchars($retrait['iban'] ?? ''); ?>">
                                                    <?php echo htmlspecialchars($retrait['iban'] ?? ''); ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                    $known_statuses = ['pending', 'approved', 'denied'];
                                                    $current_status = $retrait['statut'] ?? '';
                                                    ?>
                                                    <select name="retrait[<?php echo $retrait['id']; ?>][statut]" class="form-control">
                                                        <option value="pending" <?php if($current_status == 'pending') echo 'selected'; ?>>En attente</option>
                                                        <option value="approved" <?php if($current_status == 'approved') echo 'selected'; ?>>Approuvée</option>
                                                        <option value="denied" <?php if($current_status == 'denied') echo 'selected'; ?>>Refusée</option>
                                                        
                                                        <?php if(!in_array($current_status, $known_statuses) && !empty($current_status)): ?>
                                                            <option value="<?php echo htmlspecialchars($current_status); ?>" selected>
                                                                <?php echo htmlspecialchars(ucfirst($current_status)); ?> (Actuel)
                                                            </option>
                                                        <?php endif; ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="date" name="retrait[<?php echo $retrait['id']; ?>][date_virement]" class="form-control" value="<?php echo htmlspecialchars($retrait['date_virement'] ?? ''); ?>">
                                                </td>
                                                <td>
                                                    <input type="text" name="retrait[<?php echo $retrait['id']; ?>][reference_virement]" class="form-control" value="<?php echo htmlspecialchars($retrait['reference_virement'] ?? ''); ?>">
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div id="notes" class="tab-pane">
                         <div class="card card-tabs">
                            <h3><span class="material-symbols-outlined">note_add</span>Ajouter une note (user_interactions)</h3>
                            <div class="form-group">
                                <label>Note (visible par les admins uniquement)</label>
                                <textarea name="new_admin_note" class="form-control" rows="4" placeholder="Note sur l'appel du 23/10, plainte sur contrat X..."></textarea>
                                <input type="hidden" name="new_admin_note_type" value="admin_note"> </div>
                            <button type="submit" name="action_add_note" value="1" class="btn btn-secondary btn-sm">
                                <span class="material-symbols-outlined">add_comment</span> Ajouter la note
                            </button>
                            
                            <hr style="border-top: 1px solid #eee; margin: 25px 0;">
                            
                            <h3><span class="material-symbols-outlined">speaker_notes</span>Historique des notes</h3>
                            <div style="max-height: 400px; overflow-y: auto;">
                                <?php if (empty($client_notes)): ?>
                                    <p class="info-p">Aucune note pour ce client.</p>
                                <?php else: ?>
                                    <?php foreach ($client_notes as $note): ?>
                                        <div class="note-item">
                                            <div class="note-meta">
                                                Le <?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($note['created_at'] ?? ''))); ?>
                                                (Source: <?php echo htmlspecialchars($note['source'] ?? ''); ?>)
                                            </div>
                                            <div class="note-body"><?php echo nl2br(htmlspecialchars($note['contenu'] ?? '')); ?></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div id="messages" class="tab-pane">
                         <div class="card card-tabs">
                            <h3><span class="material-symbols-outlined">forum</span>Historique Messagerie</h3>
                            <div style="max-height: 500px; overflow-y: auto;">
                                <?php if (empty($client_conversations)): ?>
                                    <p class="info-p">Aucune conversation trouvée.</p>
                                <?php else: ?>
                                    <?php $current_conv_id = null; ?>
                                    <?php foreach ($client_conversations as $msg): ?>
                                        <?php if (($msg['conversation_id'] ?? '') != $current_conv_id): ?>
                                            <?php $current_conv_id = $msg['conversation_id']; ?>
                                            <h4 style="background: #f5f5f5; padding: 8px; border-radius: 6px; margin-top: 20px;">
                                                Conversation: "<?php echo htmlspecialchars($msg['subject'] ?? ''); ?>" 
                                                (Statut: <?php echo htmlspecialchars($msg['status'] ?? ''); ?>)
                                            </h4>
                                        <?php endif; ?>
                                        
                                        <div class="sub-card" style="border-left: 3px solid <?php echo ($msg['sender_type'] ?? '') == 'admin' ? 'var(--primary-color)' : 'var(--secondary-color)'; ?>; margin-bottom: 10px; padding: 10px;">
                                            <div class="note-meta">
                                                <?php if (($msg['sender_type'] ?? '') == 'admin'): ?>
                                                    <strong>Admin (ID: <?php echo htmlspecialchars($msg['admin_id'] ?? ''); ?>)</strong>
                                                <?php else: ?>
                                                    <strong>Client (ID: <?php echo $client_id; ?>)</strong>
                                                <?php endif; ?>
                                                - le <?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($msg['message_date'] ?? ''))); ?>
                                            </div>
                                            <div class="note-body"><?php echo nl2br(htmlspecialchars($msg['body'] ?? '')); ?></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                         </div>
                    </div>


                </div> </form>


        <?php else: ?>

            <div class="dashboard-header">
                <h1>CRM - Liste des Clients</h1>
                <form method="GET" action="crm.php" style="display: flex; gap: 8px;">
                    <input type="text" name="search" class="form-control" placeholder="Rechercher (Nom, Email, Tél...)" 
                           value="<?php echo htmlspecialchars($search_query); ?>"
                           style="width: 300px;">
                    <button type="submit" class="btn btn-primary">
                        <span class="material-symbols-outlined">search</span> Rechercher
                    </button>
                </form>
            </div>

            <div class="card">
                <div class="table-responsive">
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Ville</th>
                                <th>Statut</th>
                                <th class="actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($liste_clients)): ?>
                                <?php foreach ($liste_clients as $client): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($client['id'] ?? ''); ?></td>
                                    <td><strong><?php echo htmlspecialchars($client['name'] ?? ''); ?></strong></td>
                                    <td><?php echo htmlspecialchars($client['prenom'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($client['email'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($client['telephone'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($client['ville'] ?? ''); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo htmlspecialchars($client['statut'] ?? ''); ?>">
                                            <?php echo htmlspecialchars($client['statut'] ?? ''); ?>
                                        </span>
                                    </td>
                                    <td class="actions">
                                        <a href="crm.php?client_id=<?php echo htmlspecialchars($client['id'] ?? ''); ?>" class="btn btn-primary btn-sm">
                                            <span class="material-symbols-outlined">visibility</span> Voir Fiche
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" style="text-align: center; padding: 20px;">
                                        Aucun client trouvé<?php echo !empty($search_query) ? ' pour "' . htmlspecialchars($search_query) . '"' : ''; ?>.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php endif; ?>

    </div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    
    // --- Gestion des Onglets ---
    const tabs = document.querySelectorAll('.nav-tabs .nav-link');
    const panes = document.querySelectorAll('.tab-content .tab-pane');

    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            const targetId = this.getAttribute('data-tab');
            
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            panes.forEach(pane => {
                if (pane.id === targetId) {
                    pane.classList.add('active');
                } else {
                    pane.classList.remove('active');
                }
            });
        });
    });

    // --- Gestion des Cartes Pliantes ---
    document.querySelectorAll('.collapsible-header').forEach(header => {
        header.addEventListener('click', function() {
            const contentId = this.getAttribute('data-collapse');
            const content = document.getElementById(contentId);
            const icon = this.querySelector('.collapse-icon');
            
            if (content.style.display === 'block') {
                content.style.display = 'none';
                icon.textContent = 'expand_more'; // Icône "fermé"
                this.classList.remove('active');
            } else {
                content.style.display = 'block';
                icon.textContent = 'expand_less'; // Icône "ouvert"
                this.classList.add('active');
            }
        });
    });

    // --- Fermeture automatique des alertes après 5 secondes ---
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500); 
        }, 5000); 
    });

});
</script>
</body>
</html>