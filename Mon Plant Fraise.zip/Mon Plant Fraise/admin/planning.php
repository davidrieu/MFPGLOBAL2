<?php
// ================== DEBUG DEV (désactive display_errors en prod) ==================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/planning_error.log');

// ================== SESSION & AUTH ==================
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: /admin/login.php'); exit; }
$ADMIN_ID = (int)$_SESSION['admin_id'];
$ADMIN_USERNAME = $_SESSION['username'] ?? 'Moi';

// ================== DB ==================
require_once __DIR__ . '/db_connection.php'; // attend $bdd (PDO)
if (!isset($bdd) && isset($pdo) && $pdo instanceof PDO) { $bdd = $pdo; } // adaptateur si ton projet expose $pdo
if (!isset($bdd) || !($bdd instanceof PDO)) {
  throw new Exception('PDO $bdd non défini par db_connection.php');
}
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ================== HELPERS JSON ==================
function json_ok($data, $code=200){
  if (ob_get_length()) ob_clean();
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok'=>true,'data'=>$data], JSON_UNESCAPED_UNICODE);
  exit;
}
function json_err($msg, $code=500){
  if (ob_get_length()) ob_clean();
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok'=>false,'error'=>$msg], JSON_UNESCAPED_UNICODE);
  exit;
}

// ================== OUTILS CALENDRIER ==================
function clamp_color($c){
  return (is_string($c) && preg_match('/^#[0-9A-Fa-f]{6}$/',$c)) ? strtoupper($c) : null;
}
function expand_recurrences_for_range(array $rows, DateTime $from, DateTime $to){
  $out = [];
  foreach ($rows as $e) {
    $rule  = $e['recur_rule'] ?? 'NONE';
    $s     = new DateTime($e['starts_at']);
    $eEnd  = new DateTime($e['ends_at']);
    $until = !empty($e['recur_until']) ? new DateTime($e['recur_until'].' 23:59:59') : null;

    $push = function($dS,$dE,$src) use (&$out){
      $x = $src; $x['starts_at'] = $dS->format('Y-m-d H:i:s'); $x['ends_at'] = $dE->format('Y-m-d H:i:s'); $out[] = $x;
    };

    if ($rule === 'NONE') {
      if ($eEnd >= $from && $s <= $to) $push($s,$eEnd,$e);
      continue;
    }
    $iterS = clone $s; $iterE = clone $eEnd;
    while ($iterS <= $to && (!$until || $iterS <= $until)) {
      if ($iterE >= $from) $push($iterS,$iterE,$e);
      switch ($rule){
        case 'DAILY':   $iterS->modify('+1 day');   $iterE->modify('+1 day');   break;
        case 'WEEKLY':  $iterS->modify('+1 week');  $iterE->modify('+1 week');  break;
        case 'MONTHLY': $iterS->modify('+1 month'); $iterE->modify('+1 month'); break;
      }
    }
  }
  return $out;
}

// ================== ROUTEUR AJAX UNIQUE ==================
$action = $_GET['action'] ?? null;

if ($action) {
  // pas d'HTML d'erreur dans les endpoints
  ini_set('display_errors', 0);
  error_reporting(E_ALL);

  try {
    switch ($action) {

      case 'list': {
        $from = DateTime::createFromFormat('Y-m-d', $_GET['from'] ?? '') ?: new DateTime('first day of this month 00:00:00');
        $to   = DateTime::createFromFormat('Y-m-d', $_GET['to']   ?? '') ?: (new DateTime('last day of this month 23:59:59'));
        $to->setTime(23,59,59);
        $scope = $_GET['scope'] ?? 'all';

        $params = [];
        $sql = "SELECT e.*, a.username AS owner_name
                FROM planning_events e
                LEFT JOIN admin a ON a.id = e.admin_id
                WHERE (
                  (e.recur_rule='NONE'  AND e.starts_at <= :to AND e.ends_at >= :from)
                  OR
                  (e.recur_rule<>'NONE' AND (e.recur_until IS NULL OR e.recur_until >= :from_date))
                )";
        if ($scope === 'mine') { $sql .= " AND e.admin_id = :me"; $params[':me'] = $ADMIN_ID; }
        $sql .= " ORDER BY e.starts_at";

        $stmt = $bdd->prepare($sql);
        $params[':from'] = $from->format('Y-m-d H:i:s');
        $params[':to']   = $to->format('Y-m-d H:i:s');
        $params[':from_date'] = $from->format('Y-m-d');
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $expanded = expand_recurrences_for_range($rows, $from, $to);
        json_ok($expanded);
      }

      case 'create': {
        $p = json_decode(file_get_contents('php://input'), true) ?? [];
        $title = trim($p['title'] ?? '');
        $starts= $p['starts_at'] ?? null;
        $ends  = $p['ends_at'] ?? null;
        if ($title==='' || !$starts || !$ends) json_err('Champs manquants', 400);

        $stmt = $bdd->prepare("INSERT INTO planning_events
          (admin_id, title, starts_at, ends_at, color, notes, recur_rule, recur_until)
          VALUES (:admin_id,:title,:starts_at,:ends_at,:color,:notes,:recur_rule,:recur_until)");
        $stmt->execute([
          ':admin_id'=>$ADMIN_ID,
          ':title'=>$title,
          ':starts_at'=>$starts,
          ':ends_at'=>$ends,
          ':color'=> clamp_color($p['color'] ?? null),
          ':notes'=> trim($p['notes'] ?? ''),
          ':recur_rule'=> in_array(($p['recur_rule']??'NONE'),['NONE','DAILY','WEEKLY','MONTHLY']) ? $p['recur_rule'] : 'NONE',
          ':recur_until'=> $p['recur_until'] ?: null
        ]);
        json_ok(['id'=>$bdd->lastInsertId()], 201);
      }

      case 'update': {
        $p = json_decode(file_get_contents('php://input'), true) ?? [];
        $id = (int)($p['id'] ?? 0);
        if ($id<=0) json_err('ID manquant', 400);

        $own = $bdd->prepare("SELECT admin_id FROM planning_events WHERE id=?");
        $own->execute([$id]);
        $owner = $own->fetchColumn();
        if (!$owner) json_err('Introuvable', 404);
        if ((int)$owner !== $ADMIN_ID) json_err('Interdit', 403);

        $fields=[]; $params=[':id'=>$id];
        foreach (['title','starts_at','ends_at','notes','recur_rule','recur_until'] as $k){
          if (array_key_exists($k,$p)){ $fields[]="$k=:$k"; $params[":$k"] = ($p[$k]===''? null : $p[$k]); }
        }
        if (array_key_exists('color',$p)){ $fields[]="color=:color"; $params[':color'] = clamp_color($p['color']) ?: null; }
        if (!$fields) json_ok('Rien à mettre à jour');
        $bdd->prepare("UPDATE planning_events SET ".implode(',', $fields)." WHERE id=:id")->execute($params);
        json_ok('ok');
      }

      case 'delete': {
        $id = (int)($_GET['id'] ?? 0);
        if ($id<=0) json_err('ID manquant', 400);

        $own = $bdd->prepare("SELECT admin_id FROM planning_events WHERE id=?");
        $own->execute([$id]);
        $owner = $own->fetchColumn();
        if (!$owner) json_err('Introuvable', 404);
        if ((int)$owner !== $ADMIN_ID) json_err('Interdit', 403);

        $bdd->prepare("DELETE FROM planning_events WHERE id=?")->execute([$id]);
        json_ok('ok');
      }

      default:
        json_err('Action inconnue: '.$action, 400);
    }
  } catch (Throwable $e) {
    json_err($e->getMessage(), 500);
  }
  // Sécurité
  json_err('Fin non atteinte', 500);
}
// ================== FIN API — le HTML ci-dessous ne s'exécute que sans ?action=... ==================
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Planning — Samia & Amaury</title>
<style>
  :root{
    --bg:#f6f7fb; --card:#fff; --txt:#1f2430; --muted:#6b7280; --pri:#2f6fed;
    --rose:#e91e63; --blue:#3f51b5; --border:#e6e8ef;
    --radius:14px; --shadow:0 1px 2px rgba(0,0,0,.05);
    --space:clamp(10px,2vw,16px);
    --touch:44px;
  }
  *{ box-sizing:border-box; }
  html,body{ height:100%; }
  body{
    margin:0; font:clamp(13px, 1.8vw, 15px)/1.45 system-ui,-apple-system,Segoe UI,Roboto,Arial;
    color:var(--txt); background:var(--bg);
  }
  header{ position:sticky; top:0; background:var(--card); border-bottom:1px solid var(--border); z-index:10; }
  .wrap{ max-width:min(1200px, 100% - 2*var(--space)); margin:0 auto; padding:var(--space); }
  .row{ display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
  .grow{ flex:1 1 200px; min-width:160px; }
  .btn{ padding:8px 12px; min-height:var(--touch); border:1px solid var(--border); background:#fff; border-radius:10px; cursor:pointer; font-weight:600; }
  .btn.primary{ background:var(--pri); color:#fff; border-color:var(--pri); }
  .btn:active{ transform:translateY(1px); }
  .seg{ display:inline-flex; border:1px solid var(--border); border-radius:10px; overflow:hidden; }
  .seg button{ border:0; background:#fff; padding:8px 12px; min-height:var(--touch); }
  .seg button.active{ background:var(--pri); color:#fff; }

  .board{ display:grid; grid-template-columns: 1fr 340px; gap:var(--space); padding:var(--space); }
  .card{ background:var(--card); border:1px solid var(--border); border-radius:var(--radius); box-shadow:var(--shadow); }

  /* Mois */
  #monthGrid{ display:grid; grid-template-columns:repeat(7, 1fr); gap:1px; background:var(--border); border-radius:12px; overflow:hidden; }
  .cell{ background:#fff; min-height:clamp(76px, 14vw, 140px); padding:6px; position:relative; }
  .cell .d{ position:absolute; top:6px; right:8px; font-size:.9em; color:var(--muted); }
  .chip{ display:inline-block; font-size:.92em; padding:2px 6px; border-radius:8px; margin:2px 0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; border:1px solid rgba(0,0,0,.06); max-width:100%; }

  /* Vues colonnes */
  #cols{ display:none; }
  .listcol{ display:grid; grid-template-columns: repeat(var(--cols,3), 1fr); gap:8px; }
  .daycol{ border:1px solid var(--border); border-radius:10px; padding:8px; background:#fff; min-height:280px; }
  .daycol .title{ font-weight:700; margin-bottom:6px; }

  .side{ padding:var(--space); }
  .field{ display:flex; flex-direction:column; gap:6px; margin:8px 0; }
  input, select, textarea{ border:1px solid var(--border); border-radius:10px; padding:10px 12px; font:inherit; width:100%; min-height:var(--touch); }

  @media (max-width: 980px){ .board{ grid-template-columns:1fr; } .side{ order:2; } #mainCard{ order:1; } }
  @media (max-width: 640px){
    .seg button{ padding:6px 10px; }
    .cell{ min-height:clamp(64px, 16vw, 110px); }
    details[role="accordion"] summary{ list-style:none; cursor:pointer; padding:10px 12px; border:1px solid var(--border); border-radius:10px; background:#fff; font-weight:700; }
    details[role="accordion"] > .content{ padding:10px 0 0; }
    .side.card{ padding:10px; }
  }
  @media (max-width: 420px){ #monthGrid{ font-size: .88em; } }

  @media (prefers-color-scheme: dark){
    :root{ --bg:#0f1116; --card:#141722; --txt:#e6e6ea; --muted:#9aa0aa; --border:#23283a; }
    .btn{ background:#1a1f2b; color:var(--txt); border-color:var(--border); }
    .btn.primary{ color:#fff; }
    .cell{ background:#161b28; }
    .daycol{ background:#161b28; }
    .chip{ background:#1a2030; border-color:#2a324a; }
  }
</style>
</head>
<body>
<header>
  <div class="wrap row">
    <div class="row">
      <button class="btn" id="prevBtn" aria-label="Période précédente">◀</button>
      <button class="btn" id="todayBtn">Aujourd’hui</button>
      <button class="btn" id="nextBtn" aria-label="Période suivante">▶</button>
    </div>
    <div class="grow" id="rangeLabel" style="font-weight:700;"></div>
    <div class="seg" id="viewSeg" role="tablist" aria-label="Vue">
      <button data-v="month" class="active" role="tab">Mois</button>
      <button data-v="week" role="tab">Semaine</button>
      <button data-v="3days" role="tab">3 jours</button>
      <button data-v="day" role="tab">Jour</button>
    </div>
    <div class="seg" id="scopeSeg" title="Filtre">
      <button data-s="all" class="active">Tous</button>
      <button data-s="mine">Moi</button>
    </div>
    <button class="btn primary" id="newBtn">+ Événement</button>
  </div>
</header>

<main class="wrap board" id="gestureArea">
  <section class="card" id="mainCard">
    <div style="padding:var(--space);">
      <div id="cols"><div class="listcol" id="colsGrid"></div></div>
      <div id="monthGrid"></div>
    </div>
  </section>

  <aside class="side card">
    <details role="accordion" open>
      <summary>Journée sélectionnée</summary>
      <div class="content">
        <div class="muted" id="sideDate" style="margin-top:6px;"></div>
        <div id="sideList" style="margin-top:8px;"></div>
      </div>
    </details>
    <hr style="margin:12px 0;">
    <details role="accordion" open>
      <summary>Créer / éditer</summary>
      <div class="content">
        <form id="evtForm">
          <input type="hidden" name="id" id="f_id">
          <div class="field"><label>Titre<input name="title" id="f_title" required></label></div>
          <div class="field"><label>Début<input type="datetime-local" name="starts_at" id="f_starts" required></label></div>
          <div class="field"><label>Fin<input type="datetime-local" name="ends_at" id="f_ends" required></label></div>
          <div class="field"><label>Couleur (optionnel)<input name="color" id="f_color" placeholder="#E91E63"></label></div>
          <div class="field"><label>Récurrence
            <select name="recur_rule" id="f_recur">
              <option value="NONE">Aucune</option>
              <option value="DAILY">Quotidien</option>
              <option value="WEEKLY">Hebdomadaire</option>
              <option value="MONTHLY">Mensuelle</option>
            </select></label>
          </div>
          <div class="field"><label>Jusqu’au (si récurrence)<input type="date" name="recur_until" id="f_until"></label></div>
          <div class="field"><label>Notes<textarea name="notes" id="f_notes" rows="3"></textarea></label></div>
          <div class="row">
            <button type="submit" class="btn primary" style="flex:1">Enregistrer</button>
            <button type="button" class="btn" id="resetBtn">Annuler</button>
            <button type="button" class="btn" id="deleteBtn" style="margin-left:auto;display:none;">Supprimer</button>
          </div>
        </form>
      </div>
    </details>
  </aside>
</main>

<script>
// ==== State ====
let currentView = (matchMedia("(max-width:640px)").matches ? 'week' : 'month');
let scope = 'all';
let anchor = new Date();
let selectedDay = new Date();
let cacheEvents = [];

// ==== Dates ====
function ymd(d){ return d.toISOString().slice(0,10); }
function startOfMonth(d){ const x=new Date(d); x.setDate(1); x.setHours(0,0,0,0); return x; }
function endOfMonth(d){ const x=new Date(d); x.setMonth(x.getMonth()+1,0); x.setHours(23,59,59,999); return x; }
function addDays(d,n){ const x=new Date(d); x.setDate(x.getDate()+n); return x; }
function startOfWeek(d){ const x=new Date(d); const day=(x.getDay()+6)%7; x.setDate(x.getDate()-day); x.setHours(0,0,0,0); return x; }
function formatHuman(d){ return d.toLocaleDateString('fr-FR',{weekday:'long', year:'numeric', month:'long', day:'numeric'}); }
function clampColor(v){ return /^#[0-9A-Fa-f]{6}$/.test(v||'') ? v.toUpperCase() : ''; }

// ==== API ====
async function fetchJSON(url, options){
  const r = await fetch(url, options);
  const text = await r.text();
  let data;
  try { data = JSON.parse(text); } catch(e) {
    throw new Error(`Réponse non-JSON (${r.status}) : ${text.slice(0,500)}`);
  }
  if (!r.ok || !data.ok) { throw new Error(data?.error || `HTTP ${r.status}`); }
  return data.data;
}
async function apiList(from,to){
  const u = new URL(location.href);
  u.searchParams.set('action','list');
  u.searchParams.set('from',from);
  u.searchParams.set('to',to);
  u.searchParams.set('scope',scope);
  return fetchJSON(u, {headers:{'Accept':'application/json'}});
}
async function apiCreate(payload){
  const u = new URL(location.href); u.searchParams.set('action','create');
  return fetchJSON(u, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
}
async function apiUpdate(payload){
  const u = new URL(location.href); u.searchParams.set('action','update');
  return fetchJSON(u, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
}
async function apiDelete(id){
  const u = new URL(location.href); u.searchParams.set('action','delete'); u.searchParams.set('id',id);
  return fetchJSON(u, {headers:{'Accept':'application/json'}});
}

// ==== DOM ====
const rangeLabel = document.getElementById('rangeLabel');
const monthGrid  = document.getElementById('monthGrid');
const colsWrap   = document.getElementById('cols');
const colsGrid   = document.getElementById('colsGrid');
const sideDate   = document.getElementById('sideDate');
const sideList   = document.getElementById('sideList');

function setRangeLabel(text){ rangeLabel.textContent = text; }
function setSelectedDay(d){ selectedDay = d; sideDate.textContent = formatHuman(d); renderSideList(); }

function chipColor(ev){
  return clampColor(ev.color) || (ev.owner_name && ev.owner_name.toLowerCase().includes('samia') ? '#3F51B5' : '#E91E63');
}

function renderSideList(){
  const day = ymd(selectedDay);
  const list = cacheEvents.filter(e => e.starts_at.slice(0,10) === day);
  sideList.innerHTML = list.length ? '' : '<div class="muted">Aucun événement.</div>';
  list.sort((a,b)=>a.starts_at.localeCompare(b.starts_at));
  for(const e of list){
    const div = document.createElement('div');
    div.className='chip';
    div.style.background = '#fff';
    div.style.borderColor = chipColor(e);
    div.textContent = `${e.title} • ${e.starts_at.slice(11,16)}–${e.ends_at.slice(11,16)}`;
    div.title = e.notes || '';
    div.onclick = () => fillForm(e);
    sideList.appendChild(div);
  }
}

async function render(){
  monthGrid.style.display = 'none';
  colsWrap.style.display  = 'none';

  if (currentView==='month'){
    const s = startOfMonth(anchor), e = endOfMonth(anchor);
    setRangeLabel(s.toLocaleDateString('fr-FR',{month:'long', year:'numeric'}));
    cacheEvents = await apiList(ymd(s), ymd(e));
    renderMonth(s);
  } else if (currentView==='week'){
    const s = startOfWeek(anchor), e = addDays(s,6);
    setRangeLabel(`Semaine du ${s.toLocaleDateString('fr-FR')} au ${e.toLocaleDateString('fr-FR')}`);
    cacheEvents = await apiList(ymd(s), ymd(e));
    renderCols(s,7);
  } else if (currentView==='3days'){
    const s = new Date(anchor); s.setHours(0,0,0,0);
    const e = addDays(s,2);
    setRangeLabel(`${s.toLocaleDateString('fr-FR')} → ${e.toLocaleDateString('fr-FR')}`);
    cacheEvents = await apiList(ymd(s), ymd(e));
    renderCols(s,3);
  } else {
    const s = new Date(anchor); s.setHours(0,0,0,0);
    const e = new Date(anchor); e.setHours(23,59,59,999);
    setRangeLabel(formatHuman(s));
    cacheEvents = await apiList(ymd(s), ymd(e));
    renderCols(s,1);
  }
  renderSideList();
}

function renderMonth(first){
  monthGrid.innerHTML=''; monthGrid.style.display='grid';
  const headers = ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
  for(let i=0;i<7;i++){
    const h=document.createElement('div'); h.className='cell'; h.style.background='#fafbff'; h.style.minHeight='auto';
    h.innerHTML = `<strong>${headers[i]}</strong>`;
    monthGrid.appendChild(h);
  }
  const startIdx = (first.getDay()+6)%7;
  const totalCells = 42;
  const startDate = addDays(first, -startIdx);
  let day = new Date(startDate);
  for (let i=0;i<totalCells;i++){
    const c = document.createElement('div'); c.className='cell';
    const inMonth = (day.getMonth()===first.getMonth());
    if (!inMonth) c.style.opacity = .5;
    c.innerHTML = `<div class="d">${day.getDate()}</div>`;
    c.onclick = ()=>{ anchor = new Date(day); setSelectedDay(day); if (matchMedia("(max-width:640px)").matches) { currentView='day'; } render(); };
    const dstr = ymd(day);
    const items = cacheEvents.filter(e => e.starts_at.slice(0,10)===dstr);
    items.sort((a,b)=>a.starts_at.localeCompare(b.starts_at));
    for (const ev of items.slice(0,3)){
      const chip = document.createElement('div');
      chip.className='chip';
      chip.style.background = chipColor(ev)+'20';
      chip.style.borderColor = chipColor(ev);
      chip.textContent = `${ev.title} ${ev.starts_at.slice(11,16)}`;
      chip.title = ev.notes || '';
      chip.onclick = (evnt)=>{ evnt.stopPropagation(); fillForm(ev); };
      c.appendChild(chip);
    }
    if (items.length>3){
      const more = document.createElement('div'); more.className='muted'; more.textContent = `+${items.length-3}`;
      c.appendChild(more);
    }
    monthGrid.appendChild(c);
    day = addDays(day,1);
  }
}

function renderCols(start, cols){
  colsGrid.innerHTML=''; colsWrap.style.display='block';
  colsGrid.style.setProperty('--cols', String(cols));
  colsGrid.style.gridTemplateColumns = `repeat(${cols}, minmax(0,1fr))`;
  for (let i=0;i<cols;i++){
    const d = addDays(start,i);
    const box = document.createElement('div'); box.className='daycol';
    const title = document.createElement('div'); title.className='title';
    title.textContent = d.toLocaleDateString('fr-FR',{weekday:'short', day:'numeric', month:'short'});
    box.appendChild(title);

    const list = cacheEvents.filter(e => e.starts_at.slice(0,10)===ymd(d));
    list.sort((a,b)=>a.starts_at.localeCompare(b.starts_at));
    if (!list.length){
      const p=document.createElement('div'); p.className='muted'; p.textContent='—';
      box.appendChild(p);
    } else {
      for (const ev of list){
        const card=document.createElement('div'); card.className='chip';
        card.style.display='block';
        card.style.background = chipColor(ev)+'20';
        card.style.borderColor = chipColor(ev);
        card.style.margin='6px 0';
        card.textContent = `${ev.starts_at.slice(11,16)}–${ev.ends_at.slice(11,16)} • ${ev.title}`;
        card.title = ev.notes || '';
        card.onclick = ()=> fillForm(ev);
        box.appendChild(card);
      }
    }
    box.onclick = ()=>{ setSelectedDay(d); if (cols>1 && matchMedia("(max-width:640px)").matches) { currentView='day'; anchor=d; render(); }};
    colsGrid.appendChild(box);
  }
}

// ==== Form ====
const f = document.getElementById('evtForm');
const delBtn = document.getElementById('deleteBtn');
const resetBtn = document.getElementById('resetBtn');
document.getElementById('newBtn').onclick = ()=>resetForm();

function fillForm(ev){
  f.f_id.value    = ev.id || '';
  f.f_title.value = ev.title || '';
  f.f_starts.value= (ev.starts_at||'').replace(' ','T').slice(0,16);
  f.f_ends.value  = (ev.ends_at||'').replace(' ','T').slice(0,16);
  f.f_color.value = ev.color || '';
  f.f_recur.value = ev.recur_rule || 'NONE';
  f.f_until.value = ev.recur_until || '';
  f.f_notes.value = ev.notes || '';
  delBtn.style.display = ev.id ? 'inline-block' : 'none';
}
function resetForm(){
  f.reset(); f.f_id.value=''; delBtn.style.display='none';
  const d = new Date(selectedDay); const s = new Date(d); s.setHours(14,0,0,0);
  const e = new Date(d); e.setHours(15,0,0,0);
  f.f_starts.value = s.toISOString().slice(0,16);
  f.f_ends.value   = e.toISOString().slice(0,16);
}
resetBtn.onclick = resetForm;

f.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const payload = {
    id: f.f_id.value? Number(f.f_id.value): undefined,
    title: f.f_title.value.trim(),
    starts_at: f.f_starts.value.replace('T',' ') + ':00',
    ends_at:   f.f_ends.value.replace('T',' ') + ':00',
    color: f.f_color.value.trim(),
    notes: f.f_notes.value.trim(),
    recur_rule: f.f_recur.value,
    recur_until: f.f_until.value || null
  };
  if (payload.id){ await apiUpdate(payload); } else { await apiCreate(payload); }
  await render();
  resetForm();
});

delBtn.addEventListener('click', async ()=>{
  const id = Number(f.f_id.value||0);
  if (id && confirm('Supprimer cet événement ?')){ await apiDelete(id); await render(); resetForm(); }
});

// ==== Navigation / vues ====
document.getElementById('prevBtn').onclick = ()=>{ 
  if (currentView==='month'){ anchor.setMonth(anchor.getMonth()-1); }
  else if (currentView==='week'){ anchor = addDays(anchor,-7); }
  else if (currentView==='3days'){ anchor = addDays(anchor,-3); }
  else { anchor = addDays(anchor,-1); }
  render();
};
document.getElementById('nextBtn').onclick = ()=>{ 
  if (currentView==='month'){ anchor.setMonth(anchor.getMonth()+1); }
  else if (currentView==='week'){ anchor = addDays(anchor,7); }
  else if (currentView==='3days'){ anchor = addDays(anchor,3); }
  else { anchor = addDays(anchor,1); }
  render();
};
document.getElementById('todayBtn').onclick = ()=>{ anchor = new Date(); setSelectedDay(new Date()); render(); };

document.getElementById('viewSeg').addEventListener('click',(e)=>{
  if (e.target.tagName!=='BUTTON') return;
  [...e.currentTarget.children].forEach(b=>b.classList.remove('active'));
  e.target.classList.add('active');
  currentView = e.target.dataset.v;
  render();
});
document.getElementById('scopeSeg').addEventListener('click',(e)=>{
  if (e.target.tagName!=='BUTTON') return;
  [...e.currentTarget.children].forEach(b=>b.classList.remove('active'));
  e.target.classList.add('active');
  scope = e.target.dataset.s;
  render();
});

// ==== Swipe navigation (mobile) ====
(function(){
  const area = document.getElementById('gestureArea');
  let x0=null, y0=null, t0=0;
  area.addEventListener('touchstart', (e)=>{ const t=e.changedTouches[0]; x0=t.clientX; y0=t.clientY; t0=Date.now(); }, {passive:true});
  area.addEventListener('touchend', (e)=>{
    if (x0===null) return;
    const t=e.changedTouches[0]; const dx=t.clientX-x0; const dy=t.clientY-y0; const dt=Date.now()-t0;
    const absx=Math.abs(dx), absy=Math.abs(dy);
    x0=null; y0=null;
    if (absx>60 && absx>absy && dt<600){
      if (dx<0) document.getElementById('nextBtn').click();
      else document.getElementById('prevBtn').click();
    }
  }, {passive:true});
})();

// ==== Init ====
setSelectedDay(new Date());
render();
</script>
</body>
</html>


