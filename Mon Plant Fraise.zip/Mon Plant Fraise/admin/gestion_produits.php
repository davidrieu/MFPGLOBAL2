<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php';

// ===================================================================
// GESTION DES ACTIONS (MISE A JOUR STOCK, SUPPRESSION)
// ===================================================================

// Protection CSRF pour les actions GET (suppression)
if (isset($_GET['action'])) {
    if (!isset($_GET['token']) || !hash_equals($_SESSION['csrf_token'], $_GET['token'])) {
        die('Action non autorisée (jeton de sécurité invalide).');
    }
}

// Action de mise à jour du stock (formulaire POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_stock') {
    $produit_id = filter_input(INPUT_POST, 'produit_id', FILTER_VALIDATE_INT);
    $stock_restant = filter_input(INPUT_POST, 'stock_restant', FILTER_VALIDATE_INT);

    if ($produit_id && is_numeric($stock_restant)) {
        try {
            $stmt = $pdo->prepare("UPDATE produits SET stock_restant = ? WHERE id = ?");
            $stmt->execute([$stock_restant, $produit_id]);
            $_SESSION['flash_message'] = "Le stock du produit #{$produit_id} a été mis à jour.";
        } catch (PDOException $e) {
            $_SESSION['flash_message'] = "Erreur lors de la mise à jour du stock.";
            $_SESSION['flash_type'] = 'error';
        }
    }
    header('Location: gestion_produits.php');
    exit();
}

// Action de suppression (lien GET)
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $produit_id_to_delete = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if ($produit_id_to_delete) {
        try {
            // On vérifie si le produit n'est pas lié à des contrats avant de supprimer
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM contrats WHERE produit_id = ?");
            $check_stmt->execute([$produit_id_to_delete]);
            if ($check_stmt->fetchColumn() > 0) {
                $_SESSION['flash_message'] = "Impossible de supprimer le produit car il est lié à un ou plusieurs contrats.";
                $_SESSION['flash_type'] = 'error';
            } else {
                $stmt = $pdo->prepare("DELETE FROM produits WHERE id = ?");
                $stmt->execute([$produit_id_to_delete]);
                $_SESSION['flash_message'] = "Le produit #{$produit_id_to_delete} a été supprimé.";
            }
        } catch (PDOException $e) {
            $_SESSION['flash_message'] = "Erreur : Impossible de supprimer le produit.";
            $_SESSION['flash_type'] = 'error';
        }
    }
    header('Location: gestion_produits.php');
    exit();
}

// Génération du jeton CSRF
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// ===================================================================
// LOGIQUE D'AFFICHAGE
// ===================================================================
try {
    $produits = $pdo->query("SELECT id, name, prix, stock_restant FROM produits ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur de chargement des produits : " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Produits - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --danger-color: #d32f2f; --danger-color-dark: #c62828;
            --warning-color: #F57C00;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .page-header h1 { margin: 0; font-size: 28px; font-weight: 700; }
        .btn { display: inline-flex; align-items: center; padding: 10px 15px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); overflow-x: auto;}
        .produits-table { width: 100%; border-collapse: collapse; }
        .produits-table th, .produits-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        .produits-table th { background-color: #fafafa; font-weight: 500; font-size: 14px; color: var(--text-color-light); }
        .stock-form { display: flex; align-items: center; gap: 8px; }
        .stock-input { padding: 6px 8px; border: 1px solid #ccc; border-radius: 4px; width: 60px; }
        .stock-btn { padding: 6px 10px; font-size: 12px; }
        .stock-low { color: var(--warning-color); font-weight: bold; }
        .stock-out { color: var(--danger-color); font-weight: bold; }
        .actions { white-space: nowrap; }
        .actions a { color: var(--text-color-light); margin: 0 8px; text-decoration: none; transition: color 0.2s ease; vertical-align: middle; }
        .actions a:hover { color: var(--primary-color); }
        .actions a.delete:hover { color: var(--danger-color); }
        .flash-message { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; text-align: center; }
        .flash-message.error { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb;}
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php" class="active"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="#"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Gestion des Produits</h1>
        <a href="add_produit.php" class="btn btn-primary"><span class="material-symbols-outlined" style="margin-right: 8px;">add</span>Nouveau Produit</a>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?= $_SESSION['flash_type'] ?? '' ?>">
            <?= htmlspecialchars($_SESSION['flash_message']); ?>
        </div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
    <?php endif; ?>
    
    <div class="card">
        <table class="produits-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom du Produit</th>
                    <th>Prix</th>
                    <th>Stock Restant</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($produits)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 20px;">Aucun produit trouvé. <a href="add_produit.php">Ajoutez-en un !</a></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($produits as $produit): ?>
                        <tr>
                            <td><?= $produit['id'] ?></td>
                            <td><strong><?= htmlspecialchars($produit['name']) ?></strong></td>
                            <td><?= number_format($produit['prix'], 2, ',', ' ') ?> €</td>
                            <td>
                                <form method="POST" class="stock-form">
                                    <input type="hidden" name="action" value="update_stock">
                                    <input type="hidden" name="produit_id" value="<?= $produit['id'] ?>">
                                    <input type="number" name="stock_restant" class="stock-input" value="<?= $produit['stock_restant'] ?>">
                                    <button type="submit" class="btn btn-primary stock-btn">OK</button>
                                </form>
                            </td>
                            <td class="actions">
                                <a href="edit_produit.php?id=<?= $produit['id'] ?>" title="Modifier"><span class="material-symbols-outlined">edit</span></a>
                                <a href="?action=delete&id=<?= $produit['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" class="delete" title="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.');">
                                    <span class="material-symbols-outlined">delete</span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>