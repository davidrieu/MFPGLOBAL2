<?php
// Debug (à commenter ou retirer en prod)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Démarrer la session
session_start();

// Si un administrateur est déjà connecté, on le redirige
if (isset($_SESSION['admin_id'])) {
    header('Location: /admin/index.php');
    exit;
}

// 2. Inclure la connexion à la base de données (PDO)
require_once 'db_connection.php';

$loginErrorMessage = '';

// --- 3. TRAITEMENT DU FORMULAIRE DE CONNEXION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $loginErrorMessage = 'Veuillez remplir tous les champs.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_username'] = $user['username'];
            header("Location: /admin/index.php");
            exit;
        } else {
            $loginErrorMessage = 'Nom d\'utilisateur ou mot de passe incorrect.';
        }
    }
}

// La section "change_password" a été entièrement supprimée.
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Connexion</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

    <style>
        *, *::before, *::after { box-sizing: border-box; }

        :root {
            --primary-color: #2E7D32;
            --primary-gradient: linear-gradient(135deg, #4CAF50, #2E7D32);
            --background-color: #F4F6F8;
            --card-background-color: #ffffff;
            --text-color: #212121;
            --text-color-light: #757575;
            --error-color: #c62828;
            --error-bg-color: #ffebee;
            --border-radius: 12px;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--background-color);
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
            background-color: var(--card-background-color);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .logo-container {
            margin-bottom: 20px;
        }
        .logo-container img {
            max-width: 100px;
        }

        h1 {
            font-family: 'Poppins', sans-serif;
            font-size: 26px;
            color: var(--text-color);
            margin-top: 0;
            margin-bottom: 10px;
        }

        p {
            color: var(--text-color-light);
            margin-bottom: 30px;
        }

        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-color);
            font-weight: 500;
        }
        
        .input-wrapper { position: relative; }
        .input-wrapper .material-symbols-outlined {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-color-light);
        }
        
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px 12px 12px 45px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        input[type="text"]:focus, input[type="password"]:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px var(--primary-color-light);
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background: var(--primary-gradient);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .btn-submit:hover {
            box-shadow: 0 4px 12px rgba(46, 125, 50, 0.4);
            transform: translateY(-2px);
        }

        .message.error {
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: var(--error-bg-color);
            color: var(--error-color);
            padding: 12px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            border: 1px solid var(--error-color);
            text-align: left;
        }
        
        @media (max-width: 480px) {
            .login-container {
                padding: 25px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise">
        </div>
        <h1>Espace Admin</h1>
        <p>Connectez-vous pour accéder au tableau de bord.</p>

        <?php if (!empty($loginErrorMessage)): ?>
            <div class="message error">
                <span class="material-symbols-outlined">warning</span>
                <span><?= htmlspecialchars($loginErrorMessage) ?></span>
            </div>
        <?php endif; ?>
        
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="login-username">Nom d'utilisateur</label>
                <div class="input-wrapper">
                    <span class="material-symbols-outlined">person</span>
                    <input type="text" id="login-username" name="username" required>
                </div>
            </div>
            <div class="form-group">
                <label for="login-password">Mot de passe</label>
                 <div class="input-wrapper">
                    <span class="material-symbols-outlined">lock</span>
                    <input type="password" id="login-password" name="password" required>
                </div>
            </div>
            <button type="submit" name="login" class="btn-submit">Se connecter</button>
        </form>
    </div>
</body>
</html>

