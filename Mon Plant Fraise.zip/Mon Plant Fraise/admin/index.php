<?php
session_start();
// SÉCURITÉ : Vérifier si l'admin est connecté
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}
// La logique de mise à jour manuelle des statuts peut rester ici si vous en avez l'utilité.
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Stratégique - La Serre</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/litepicker.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/plugins/ranges.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/litepicker/dist/css/litepicker.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        :root {
            --primary-color: #4CAF50;
            --primary-color-dark: #388E3C;
            --secondary-color: #6c757d;
            --text-color: #333333;
            --text-color-light: #757575;
            --background-color: #f5f5f5;
            --card-background-color: #ffffff;
            --border-radius: 8px;
            --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top: 0; left: 0; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; transition: transform 0.3s ease-in-out; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .main-container { margin-left: 280px; padding: 20px; width: calc(100% - 320px); transition: margin-left 0.3s ease-in-out; }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .card h3 { color: var(--text-color); margin-top: 0; font-size: 18px; font-weight: 500; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px; display: flex; align-items: center; }
        .card h3 .material-symbols-outlined { margin-right: 8px; font-size: 22px; color: var(--primary-color); }
        .kpi-card { display: flex; align-items: center; }
        .kpi-card .icon-bg { font-size: 40px; color: var(--primary-color); margin-right: 20px; }
        .kpi-card-info .value { font-size: 24px; font-weight: 700; color: var(--text-color); }
        .kpi-card-info .label { font-size: 14px; color: var(--text-color-light); }
        .chart-container { position: relative; height: 300px; }
        .list-card ul { list-style: none; padding: 0; margin: 0; }
        .list-card li { display: flex; justify-content: space-between; align-items: center; padding: 12px 5px; border-bottom: 1px solid #f0f0f0; font-size: 14px; }
        .list-card li:last-child { border-bottom: none; }
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .dashboard-header h1 {
            font-size: 24px;
            font-weight: 500;
            margin: 0;
        }
        #date-range-picker {
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
            min-width: 240px;
            text-align: center;
            cursor: pointer;
        }
        .kpi-card-info .comparison {
            font-size: 13px;
            font-weight: 500;
            margin-top: 4px;
            display: flex;
            align-items: center;
        }
        .comparison .material-symbols-outlined { font-size: 16px; margin-right: 4px; }
        .comparison.positive { color: var(--primary-color-dark); }
        .comparison.negative { color: #d32f2f; }
        .dashboard-grid { position: relative; display: grid; gap: 20px; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));}
        .dashboard-loader {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.7);
            z-index: 100;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: opacity 0.3s ease;
            border-radius: var(--border-radius);
        }
        .loader {
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--primary-color);
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">La Serre</div>
        <ul>
            <li><a href="index.php" class="active"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
            <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
            <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
            <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
            <li><a href="gestion_documents.php"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
            <li><a href="rendez_vous.php"><span class="material-symbols-outlined">event</span>Gestion RDV</a></li>
            <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
            <li><a href="remboursement.php"><span class="material-symbols-outlined">payments</span>Remboursement</a></li>
            <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
            <li><a href="codepromo.php"><span class="material-symbols-outlined">sell</span>Codes Promo</a></li>
            <li><a href="virements.php"><span class="material-symbols-outlined">paid</span>Gestion Virements</a></li>
          	<li><a href="abonnements.php"><span class="material-symbols-outlined">paid</span>Suivi récurrent</a></li>
          	<li><a href="crm.php"><span class="material-symbols-outlined">paid</span>Fiches Clients</a></li>
            <li><a href="parametres.php"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
            <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
        </ul>
    </div>

    <div class="main-container">
        <div class="dashboard-header">
            <h1>Pilotage Stratégique</h1>
            <input id="date-range-picker" />
        </div>

        <div id="dashboard-grid" class="dashboard-grid">
            <div class="dashboard-loader" style="display: none;"><div class="loader"></div></div>

            <div class="card kpi-card">
                <span class="material-symbols-outlined icon-bg">euro</span>
                <div class="kpi-card-info">
                    <div class="value" id="kpi-total-investi">...</div>
                    <div class="label">Total investi sur la période</div>
                    <div class="comparison" id="kpi-total-investi-comp"></div>
                </div>
            </div>
             <div class="card kpi-card">
                <span class="material-symbols-outlined icon-bg">shopping_cart</span>
                <div class="kpi-card-info">
                    <div class="value" id="kpi-panier-moyen">...</div>
                    <div class="label">Montant moyen / contrat</div>
                    <div class="comparison" id="kpi-panier-moyen-comp"></div>
                </div>
            </div>
            <div class="card kpi-card">
                <span class="material-symbols-outlined icon-bg">description</span>
                <div class="kpi-card-info">
                    <div class="value" id="kpi-nouveaux-contrats">...</div>
                    <div class="label">Nouveaux contrats signés</div>
                    <div class="comparison" id="kpi-nouveaux-contrats-comp"></div>
                </div>
            </div>
             <div class="card kpi-card">
                <span class="material-symbols-outlined icon-bg">person_add</span>
                <div class="kpi-card-info">
                    <div class="value" id="kpi-nouveaux-utilisateurs">...</div>
                    <div class="label">Nouveaux utilisateurs inscrits</div>
                </div>
            </div>
             <div class="card kpi-card">
                <span class="material-symbols-outlined icon-bg">trending_up</span>
                <div class="kpi-card-info">
                    <div class="value" id="kpi-taux-conversion">...</div>
                    <div class="label">Taux de conversion (Inscrit > Client)</div>
                </div>
            </div>

            <div class="card" style="grid-column: 1 / -1; @media(min-width: 1200px){grid-column: 1 / 4;}">
                <h3><span class="material-symbols-outlined">bar_chart</span>Évolution des investissements</h3>
                <div class="chart-container">
                    <canvas id="investmentsChart"></canvas>
                </div>
            </div>
             <div class="card" style="@media(min-width: 1200px){grid-column: 4 / 6;}">
                <h3><span class="material-symbols-outlined">pie_chart</span>Statuts des contrats</h3>
                <div class="chart-container">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>

            <div class="card list-card" style="@media(min-width: 768px){grid-column: span 3;} @media(min-width: 1200px){grid-column: 1 / 4;}">
                <h3><span class="material-symbols-outlined">workspace_premium</span>Top 5 Investisseurs sur la période</h3>
                <ul id="list-top-investisseurs"></ul>
            </div>
            <div class="card list-card" style="@media(min-width: 768px){grid-column: span 2;} @media(min-width: 1200px){grid-column: 4 / 6;}">
                <h3><span class="material-symbols-outlined">star</span>Top 5 Produits (par CA)</h3>
                <ul id="list-top-produits"></ul>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const loader = document.querySelector('.dashboard-loader');
    
    // --- Initialisation des graphiques (vides) ---
    let investmentsChart = new Chart(document.getElementById('investmentsChart'), {
        type: 'bar',
        data: { labels: [], datasets: [{ label: 'Montant Investi (€)', data: [], backgroundColor: 'rgba(76, 175, 80, 0.5)', borderRadius: 4 }] },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } } }
    });
    let statusChart = new Chart(document.getElementById('statusChart'), {
        type: 'doughnut',
        data: { labels: [], datasets: [{ data: [], backgroundColor: ['#4CAF50', '#FFC107', '#2196F3', '#F44336', '#9E9E9E'], borderWidth: 2 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
    });

    // --- Fonction de mise à jour du tableau de bord ---
    async function updateDashboard(startDate, endDate) {
        loader.style.display = 'flex';
        try {
            const response = await fetch(`dashboard_data.php?start=${startDate}&end=${endDate}`);
            if (!response.ok) {
                // On essaie de lire le message d'erreur du serveur s'il y en a un
                const errorText = await response.text();
                throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
            }
            const data = await response.json();

            // 1. Mettre à jour les KPIs
            document.getElementById('kpi-total-investi').textContent = parseFloat(data.kpis.total_investi).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
            document.getElementById('kpi-panier-moyen').textContent = parseFloat(data.kpis.panier_moyen).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
            document.getElementById('kpi-nouveaux-contrats').textContent = data.kpis.nouveaux_contrats;
            document.getElementById('kpi-nouveaux-utilisateurs').textContent = data.kpis.nouveaux_utilisateurs;
            document.getElementById('kpi-taux-conversion').textContent = parseFloat(data.kpis.taux_conversion).toFixed(1) + '%';
            
            // Mettre à jour les comparaisons
            updateComparison('kpi-total-investi-comp', data.kpis.total_investi_comp);
            updateComparison('kpi-panier-moyen-comp', data.kpis.panier_moyen_comp);
            updateComparison('kpi-nouveaux-contrats-comp', data.kpis.nouveaux_contrats_comp);
            
            // 2. Mettre à jour les graphiques
            investmentsChart.data.labels = data.charts.investissements.labels;
            investmentsChart.data.datasets[0].data = data.charts.investissements.values;
            investmentsChart.update();

            statusChart.data.labels = data.charts.statuts.labels;
            statusChart.data.datasets[0].data = data.charts.statuts.values;
            statusChart.update();

            // 3. Mettre à jour les listes
            updateList('list-top-investisseurs', data.lists.top_investisseurs, item => `<span>${item.prenom} ${item.name}</span><strong>${parseFloat(item.total_investi).toLocaleString('fr-FR', {style:'currency', currency:'EUR'})}</strong>`);
            updateList('list-top-produits', data.lists.top_produits, item => `<span>${item.name}</span><strong>${parseFloat(item.total_ca).toLocaleString('fr-FR', {style:'currency', currency:'EUR'})}</strong>`);

        } catch (error) {
            console.error("Impossible de charger les données du tableau de bord:", error);
            alert("Une erreur est survenue lors de la mise à jour des données. Vérifiez la console pour les détails (F12).");
        } finally {
            loader.style.display = 'none';
        }
    }

    // --- Fonctions utilitaires pour l'affichage ---
    function updateComparison(elementId, value) {
        const el = document.getElementById(elementId);
        const roundedValue = Math.round(value);
        el.className = 'comparison'; // Reset classes
        if (roundedValue > 0) {
            el.classList.add('positive');
            el.innerHTML = `<span class="material-symbols-outlined">arrow_upward</span> ${roundedValue}%`;
        } else if (roundedValue < 0) {
            el.classList.add('negative');
            el.innerHTML = `<span class="material-symbols-outlined">arrow_downward</span> ${Math.abs(roundedValue)}%`;
        } else {
            el.innerHTML = `~ 0%`;
        }
    }

    function updateList(elementId, data, formatter) {
        const ul = document.getElementById(elementId);
        ul.innerHTML = ''; // Vider la liste
        if (data.length === 0) {
            ul.innerHTML = '<li>Aucune donnée pour cette période.</li>';
            return;
        }
        data.forEach(item => {
            const li = document.createElement('li');
            li.innerHTML = formatter(item);
            ul.appendChild(li);
        });
    }

    // --- Initialisation du sélecteur de dates (Litepicker) ---
    const picker = new Litepicker({
        element: document.getElementById('date-range-picker'),
        singleMode: false,
        format: 'DD/MM/YYYY',
        lang: 'fr-FR',
        startDate: new Date(new Date().setDate(new Date().getDate() - 29)),
        endDate: new Date(),
        plugins: ['ranges'],
        ranges: {
            'Aujourd\'hui': [new Date(), new Date()],
            'Derniers 7 jours': [new Date(new Date().setDate(new Date().getDate() - 6)), new Date()],
            'Derniers 30 jours': [new Date(new Date().setDate(new Date().getDate() - 29)), new Date()],
            'Ce mois-ci': [new Date(new Date().getFullYear(), new Date().getMonth(), 1), new Date()],
            'Mois dernier': [new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1), new Date(new Date().getFullYear(), new Date().getMonth(), 0)],
        },
        setup: (picker) => {
            picker.on('selected', (date1, date2) => {
                const startDate = date1.format('YYYY-MM-DD');
                const endDate = date2.format('YYYY-MM-DD');
                updateDashboard(startDate, endDate);
            });
        },
    });

    // --- Chargement initial des données ---
    const initialStartDate = picker.getStartDate().format('YYYY-MM-DD');
    const initialEndDate = picker.getEndDate().format('YYYY-MM-DD');
    updateDashboard(initialStartDate, initialEndDate);
});
</script>
</body>
</html>