<?php
// 1) Sécurité & Session
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// --- INTÉGRATION DE PHPMailer ---
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Chemins vers les fichiers PHPMailer que vous avez uploadés
require '../vendor/phpmailer/src/Exception.php';
require '../vendor/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/src/SMTP.php';


// 2) Dépendances et Configuration
require_once '../db_connection.php';
$FROM_NAME_DEFAULT  = 'Mon Plant Fraise';
$FROM_EMAIL_DEFAULT = 'info@monplantfraise.com'; // Mettez un email valide ici

// 3) Initialisation des variables
$feedback = null;
$errors = [];
$users = $templates = $mailing_lists = $history = [];

// 4) Chargement des données initiales
try {
    $users = $pdo->query("SELECT id, prenom, name, email FROM users WHERE statut = 'actif' AND email IS NOT NULL AND email <> '' ORDER BY prenom, name")->fetchAll(PDO::FETCH_ASSOC);
    $templates = $pdo->query("SELECT id, title FROM email_templates ORDER BY updated_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    $mailing_lists = $pdo->query("SELECT id, name, description FROM mailing_lists ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    $history = $pdo->query("SELECT id, subject, send_mode, list_id, total_sent, total_failed, created_at FROM email_logs ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur de chargement des données initiales : " . $e->getMessage();
}

// 5) Gestion des actions POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sécurité : Vérification du jeton CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Action non autorisée.');
    }

    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'save_template':
            $tpl_id = !empty($_POST['tpl_id']) ? (int)$_POST['tpl_id'] : null;
            $title = trim($_POST['tpl_title'] ?? '');
            $subject = trim($_POST['tpl_subject'] ?? '');
            $prehead = trim($_POST['tpl_preheader'] ?? '');
            $html = $_POST['tpl_html'] ?? '';
            if (empty($title)) $errors[] = "Le titre du template est obligatoire.";
            if (empty($subject)) $errors[] = "Le sujet par défaut est obligatoire.";
            
            if (empty($errors)) {
                if ($tpl_id) {
                    $stmt = $pdo->prepare("UPDATE email_templates SET title=?, default_subject=?, default_preheader=?, html=?, updated_at=NOW() WHERE id=?");
                    $stmt->execute([$title, $subject, $prehead, $html, $tpl_id]);
                    $feedback = "✅ Template mis à jour avec succès.";
                } else {
                    $stmt = $pdo->prepare("INSERT INTO email_templates (title, default_subject, default_preheader, html, created_at, updated_at) VALUES (?,?,?,?,NOW(),NOW())");
                    $stmt->execute([$title, $subject, $prehead, $html]);
                    $feedback = "✅ Template créé avec succès.";
                }
            }
            break;

        case 'create_list':
            $name = trim($_POST['list_name'] ?? '');
            $desc = trim($_POST['list_desc'] ?? '');
            if (empty($name)) $errors[] = "Le nom de la liste est obligatoire.";
            if (empty($errors)) {
                $stmt = $pdo->prepare("INSERT INTO mailing_lists (name, description, created_at) VALUES (?,?,NOW())");
                $stmt->execute([$name, $desc]);
                $feedback = "✅ Liste créée avec succès.";
            }
            break;

        case 'add_members':
            $list_id = (int)($_POST['list_id'] ?? 0);
            $selected_users = $_POST['selected_users'] ?? [];
            if (!$list_id) $errors[] = "Aucune liste sélectionnée.";
            if (empty($selected_users)) $errors[] = "Sélectionnez au moins un utilisateur.";
            if (empty($errors)) {
                $stmt = $pdo->prepare("INSERT IGNORE INTO mailing_list_members (list_id, user_id, added_at) VALUES (?,?,NOW())");
                foreach ($selected_users as $uid) {
                    $stmt->execute([$list_id, (int)$uid]);
                }
                $feedback = "✅ Membres ajoutés à la liste.";
            }
            break;

        case 'send_email':
            $from_name = trim($_POST['from_name'] ?? $FROM_NAME_DEFAULT);
            $from_email = trim($_POST['from_email'] ?? $FROM_EMAIL_DEFAULT);
            $subject = trim($_POST['subject'] ?? '');
            $preheader = trim($_POST['preheader'] ?? '');
            $body_html = $_POST['body_html'] ?? '';
            $send_mode = $_POST['send_mode'] ?? 'selected';
            $test_email = trim($_POST['test_email'] ?? '');
            $sel_emails = $_POST['recipients'] ?? [];
            $list_id = !empty($_POST['list_id']) ? (int)$_POST['list_id'] : 0;
            
            // Validation
            if (empty($subject)) $errors[] = "Le sujet est obligatoire.";
            if (!filter_var($from_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email expéditeur invalide.";
            if ($send_mode === 'test' && !filter_var($test_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email de test invalide.";

            // Construction de la liste des destinataires
            $target_emails = [];
            if ($send_mode === 'test') {
                $target_emails = [$test_email];
            } elseif ($send_mode === 'all') {
                $target_emails = array_column($users, 'email');
            } elseif ($send_mode === 'list') {
                if (!$list_id) $errors[] = "Veuillez sélectionner une liste de diffusion.";
                else {
                    $stmt = $pdo->prepare("SELECT u.email FROM mailing_list_members m JOIN users u ON u.id = m.user_id WHERE m.list_id = ? AND u.email IS NOT NULL AND u.email <> ''");
                    $stmt->execute([$list_id]);
                    $target_emails = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'email');
                }
            } else { // 'selected'
                if (empty($sel_emails)) $errors[] = "Sélectionnez au moins un destinataire.";
                else $target_emails = array_values(array_unique(array_filter($sel_emails, fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL))));
            }
            
            if (empty($errors)) {
                $sent = 0; $failed = 0; $failed_list = [];
                $final_html = render_email_template($body_html, $preheader, $from_name);
                
                // --- LOGIQUE D'ENVOI AVEC PHPMailer ---
                $mail = new PHPMailer(true);
                try {
                    // Configuration du serveur SMTP de IONOS
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.ionos.fr';                  // Serveur SMTP de IONOS
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'info@monplantfraise.com';           // VOTRE EMAIL IONOS COMPLET
                    $mail->Password   = 'Lavieestbelle24/*';       // LE MOT DE PASSE DE CET EMAIL
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port       = 587;
                    $mail->CharSet    = 'UTF-8';

                    // Expéditeur
                    $mail->setFrom($from_email, $from_name);
                    
                    // Contenu de l'email
                    $mail->isHTML(true);
                    $mail->Subject = $subject;
                    $mail->Body    = $final_html;
                    $mail->AltBody = strip_tags($body_html);

                    // Boucle d'envoi
                    foreach ($target_emails as $to) {
                        try {
                            $mail->addAddress($to);
                            $mail->send();
                            $sent++;
                        } catch (Exception $e) {
                            $failed++;
                            $failed_list[] = $to;
                        }
                        $mail->clearAddresses();
                    }
                    
                    $feedback = "✅ Campagne terminée : {$sent} email(s) envoyé(s).";
                    if ($failed > 0) {
                        $feedback = "⚠️ Campagne terminée : {$sent} envoyé(s), {$failed} échec(s).";
                    }

                } catch (Exception $e) {
                    $errors[] = "Erreur fatale de l'expéditeur : Le message n'a pas pu être envoyé. Erreur : {$mail->ErrorInfo}";
                }
                // --- FIN DE LA LOGIQUE D'ENVOI ---
                
                // Logging
                try {
                    $stmt = $pdo->prepare("INSERT INTO email_logs (subject, from_name, from_email, preheader, body_html, send_mode, list_id, total_sent, total_failed, failed_list, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,NOW())");
                    $stmt->execute([$subject, $from_name, $from_email, $preheader, $body_html, $send_mode, ($list_id ?: null), $sent, $failed, $failed ? json_encode($failed_list, JSON_UNESCAPED_UNICODE) : null]);
                } catch (PDOException $e) {
                    error_log('email_logs insert: ' . $e->getMessage());
                }
            }
            break;
    }

    // Refresh data after actions
    try {
        $templates = $pdo->query("SELECT id, title FROM email_templates ORDER BY updated_at DESC")->fetchAll(PDO::FETCH_ASSOC);
        $mailing_lists = $pdo->query("SELECT id, name, description FROM mailing_lists ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {}
}

// Génération du token CSRF pour la sécurité des formulaires
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

function render_email_template($contentHtml, $preheader, $brandName) {
    $pre = htmlspecialchars($preheader ?? '', ENT_QUOTES, 'UTF-8');
    $brand = htmlspecialchars($brandName, ENT_QUOTES, 'UTF-8');
    return "<!DOCTYPE html><html><head><meta charset='UTF-8'><style>body{margin:0;background:#f5f5f5;color:#333;font-family:Roboto,Arial,sans-serif}a{color:#4CAF50}.wrap{max-width:720px;margin:0 auto;background:#fff}.head{padding:24px;border-bottom:3px solid #4CAF50;text-align:center}.brand{margin:0;font-size:22px;color:#4CAF50}.content{padding:24px;line-height:1.6}.foot{padding:18px;text-align:center;color:#757575;border-top:1px solid #eee;font-size:12px}.pre{display:none!important;opacity:0;color:transparent;height:0;width:0}</style></head><body>"
         . "<span class='pre'>".$pre."</span>"
         . "<div class='wrap'><div class='head'><h1 class='brand'>".$brand."</h1></div><div class='content'>".$contentHtml."</div><div class='foot'>© ".date('Y')." ".$brand."</div></div>"
         . "</body></html>";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emailing — La Serre Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
    <style>
        :root {
            --primary-color:#4CAF50; --primary-color-dark:#388E3C;
            --secondary-color:#6c757d; --secondary-color-dark:#5a6268;
            --text-color:#333; --text-color-light:#757575;
            --background-color:#f5f5f5; --card-background-color:#fff;
            --border-radius:8px; --box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.24);
            --danger-color: #d32f2f; --danger-bg: #f8d7da;
            --success-color: #155724; --success-bg: #d4edda;
        }
        *, *::before, *::after { box-sizing: border-box; }
        body { background: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; top:0; left:0; box-shadow: 0 2px 10px rgba(0,0,0,.1); display: flex; flex-direction: column; z-index: 1000; transition: transform .3s; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color); }
        .sidebar ul { list-style: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: .2s; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background: var(--primary-color); color: #fff; }
        .container { margin-left: 280px; padding: 20px; width: calc(100% - 280px); }
        .card { background: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); margin-bottom: 20px; }
        .card-header { color: var(--text-color); margin-top: 0; font-size: 20px; font-weight: 500; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px; display: flex; align-items: center; gap: 12px; }
        .grid { display: grid; gap: 20px; }
        .grid-2-col { grid-template-columns: 1fr 1fr; }
        .grid-4-col { grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); }
        .full-width { grid-column: 1 / -1; }
        .btn { display: inline-flex; align-items: center; gap: 8px; background: var(--primary-color); color: #fff; padding: 10px 14px; border: none; border-radius: var(--border-radius); cursor: pointer; font-weight: 500; text-decoration: none; }
        .btn.secondary { background: var(--secondary-color); }
        .btn:hover { filter: brightness(90%); }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        .form-group label { color: var(--text-color-light); font-size: 14px; }
        .input, textarea, select { width: 100%; padding: 12px; border-radius: var(--border-radius); border: 1px solid #ddd; }
        .chips-group { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .chip { border: 1px solid #ddd; border-radius: 999px; padding: 6px 10px; font-size: 13px; color: #555; background: #fafafa; cursor: pointer; }
        .chip input[type="radio"] { margin-right: 6px; }
        .feedback { padding: 15px; border-left: 4px solid var(--success-color); background: var(--success-bg); color: var(--success-color); }
        .feedback.error { border-left-color: var(--danger-color); background: var(--danger-bg); color: var(--danger-color); }
        .feedback ul { margin: 8px 0 0 20px; padding: 0; }
        .modal { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: none; align-items: center; justify-content: center; z-index: 2000; padding: 20px; }
        .modal.open { display: flex; }
        .modal-card { background: #fff; max-width: 900px; width: 100%; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.2); display: flex; flex-direction: column; max-height: 90vh; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 20px; border-bottom: 1px solid #eee; }
        .modal-header h4 { margin: 0; font-weight: 600; font-size: 18px; }
        .modal-body { padding: 20px; overflow-y: auto; }
        .modal-body iframe { width: 100%; height: 65vh; border: 1px solid #eee; border-radius: 8px; }
        .table-wrapper { overflow-x: auto; }
        .styled-table { width: 100%; border-collapse: collapse; }
        .styled-table th, .styled-table td { padding: 12px; border-bottom: 1px solid #eee; text-align: left; }
        .styled-table th { background: #fafafa; color: var(--text-color-light); font-weight: 500; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="emailing.php" class="active"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <?php if ($feedback || !empty($errors)): ?>
        <div class="card feedback <?= !empty($errors) ? 'error' : '' ?>">
            <?= htmlspecialchars($feedback ?? 'Veuillez corriger les erreurs ci-dessous.') ?>
            <?php if (!empty($errors)): ?>
                <ul><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form method="post" id="composeForm">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <input type="hidden" name="action" value="send_email">
        <div class="card">
            <h3 class="card-header"><span class="material-symbols-outlined">edit</span>Composer un email</h3>
            <div class="grid grid-4-col">
                <div class="form-group"><label for="from_name">Nom de l'expéditeur</label><input class="input" type="text" id="from_name" name="from_name" value="<?= htmlspecialchars($FROM_NAME_DEFAULT) ?>"></div>
                <div class="form-group"><label for="from_email">Email de l'expéditeur</label><input class="input" type="email" id="from_email" name="from_email" value="<?= htmlspecialchars($FROM_EMAIL_DEFAULT) ?>"></div>
                <div class="form-group"><label for="subject">Sujet</label><input class="input" type="text" id="subject" name="subject" required></div>
                <div class="form-group"><label for="preheader">Pré-en-tête (preheader)</label><input class="input" type="text" id="preheader" name="preheader"></div>
                <div class="form-group full-width">
                    <label for="body_html">Contenu (HTML autorisé)</label>
                    <textarea class="input" name="body_html" id="body_html" rows="12"></textarea>
                    <div class="chips-group" style="margin-top: 10px;">
                        <button type="button" class="btn secondary" id="btnCTA"><span class="material-symbols-outlined">add_link</span>Insérer un bouton (CTA)</button>
                        <button type="button" class="btn secondary" id="btnTwoCols"><span class="material-symbols-outlined">view_column</span>Insérer 2 colonnes</button>
                        <button type="button" class="btn secondary" id="btnPreview"><span class="material-symbols-outlined">visibility</span>Aperçu</button>
                    </div>
                </div>
            </div>
            
            <fieldset style="border:1px dashed #ddd; padding: 20px; margin-top: 20px; border-radius: var(--border-radius);">
                <legend style="padding: 0 10px; font-weight: 500;">Templates</legend>
                <div class="grid grid-2-col">
                    <div class="form-group">
                        <label for="selectTemplate">Charger un template existant</label>
                        <select class="input" id="selectTemplate">
                            <option value="">— Sélectionner —</option>
                            <?php foreach($templates as $t): ?><option value="<?= (int)$t['id'] ?>">#<?= (int)$t['id'] ?> — <?= htmlspecialchars($t['title']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Créer ou modifier un template</label>
                        <button type="button" class="btn secondary" id="openTemplateEditor"><span class="material-symbols-outlined">edit_document</span>Ouvrir l'éditeur de templates</button>
                    </div>
                </div>
            </fieldset>

            <fieldset style="border:1px dashed #ddd; padding: 20px; margin-top: 20px; border-radius: var(--border-radius);">
                <legend style="padding: 0 10px; font-weight: 500;">Destinataires</legend>
                <div class="chips-group">
                    <label class="chip"><input type="radio" name="send_mode" value="selected" checked> Sélection manuelle</label>
                    <label class="chip"><input type="radio" name="send_mode" value="all"> Tous les utilisateurs (<?= count($users) ?>)</label>
                    <label class="chip"><input type="radio" name="send_mode" value="list"> Liste de diffusion</label>
                    <select class="input" name="list_id" style="width: auto; flex-grow: 1; max-width: 250px;"><option value="0">— Choisir une liste —</option><?php foreach($mailing_lists as $ml): ?><option value="<?= (int)$ml['id'] ?>">#<?= (int)$ml['id'] ?> — <?= htmlspecialchars($ml['name']) ?></option><?php endforeach; ?></select>
                    <label class="chip"><input type="radio" name="send_mode" value="test"> Email de test</label>
                    <input class="input" style="width: auto; flex-grow: 1; max-width: 250px;" type="email" name="test_email" placeholder="votre.email@test.fr">
                </div>
                <div style="max-height:260px; overflow:auto; border:1px solid #eee; border-radius:8px; padding:10px; margin-top:15px;">
                    <div class="grid grid-4-col">
                        <?php foreach($users as $u): ?>
                            <label style="font-size: 14px; display:flex; align-items:center; gap:8px;">
                                <input type="checkbox" name="recipients[]" value="<?= htmlspecialchars($u['email']) ?>">
                                <span><?= htmlspecialchars(trim($u['prenom'].' '.$u['name'])) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </fieldset>

            <div style="margin-top: 20px;">
                <button type="submit" class="btn"><span class="material-symbols-outlined">send</span>Envoyer la campagne</button>
                <button type="button" class="btn secondary" id="btnOpenLists"><span class="material-symbols-outlined">group_add</span>Gérer les listes</button>
            </div>
        </div>
    </form>

    <div class="card">
        <h3 class="card-header"><span class="material-symbols-outlined">history</span>Historique des 20 derniers envois</h3>
        <div class="table-wrapper">
            <table class="styled-table">
                <thead><tr><th>Date</th><th>Sujet</th><th>Mode</th><th>Envoyés</th><th>Échecs</th></tr></thead>
                <tbody>
                    <?php if(empty($history)): ?><tr><td colspan="5" style="text-align:center;">Aucun envoi enregistré.</td></tr><?php endif; ?>
                    <?php foreach($history as $h): ?>
                    <tr>
                        <td><?= (new DateTime($h['created_at']))->format('d/m/Y H:i') ?></td>
                        <td><?= htmlspecialchars($h['subject']) ?></td>
                        <td><?= htmlspecialchars($h['send_mode']) ?><?= $h['list_id'] ? ' (#' . (int)$h['list_id'] . ')' : '' ?></td>
                        <td style="color:var(--success-color);"><?= (int)$h['total_sent'] ?></td>
                        <td style="color:var(--danger-color);"><?= (int)$h['total_failed'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div> <div class="modal" id="previewModal">
    <div class="modal-card"><div class="modal-header"><h4>Aperçu de l'email</h4><button type="button" class="btn secondary" id="closePreview">Fermer</button></div><div class="modal-body"><iframe id="previewFrame"></iframe></div></div>
</div>

<div class="modal" id="tplModal">
    <div class="modal-card">
        <div class="modal-header"><h4>Éditeur de templates</h4><button type="button" class="btn secondary" id="closeTpl">Fermer</button></div>
        <div class="modal-body">
            <form method="post" id="tplForm">
                <input type="hidden" name="action" value="save_template"><input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>"><input type="hidden" name="tpl_id" id="tpl_id">
                <div class="grid grid-2-col">
                    <div class="form-group"><label for="tpl_title">Titre du template</label><input class="input" type="text" name="tpl_title" id="tpl_title" required></div>
                    <div class="form-group"><label for="tpl_subject">Sujet par défaut</label><input class="input" type="text" name="tpl_subject" id="tpl_subject" required></div>
                    <div class="form-group full-width"><label for="tpl_preheader">Preheader par défaut</label><input class="input" type="text" name="tpl_preheader" id="tpl_preheader"></div>
                    <div class="form-group full-width"><label for="tpl_html">Contenu HTML du template</label><textarea class="input" name="tpl_html" id="tpl_html" rows="10"></textarea></div>
                </div>
                <div style="margin-top: 20px;"><button type="submit" class="btn"><span class="material-symbols-outlined">save</span>Enregistrer le template</button></div>
            </form>
        </div>
    </div>
</div>

<div class="modal" id="listsModal">
    <div class="modal-card">
        <div class="modal-header"><h4>Gestion des listes de diffusion</h4><button type="button" class="btn secondary" id="closeLists">Fermer</button></div>
        <div class="modal-body">
            <form method="post">
                <input type="hidden" name="action" value="create_list"><input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <fieldset style="border:1px dashed #ddd; padding: 20px; border-radius: var(--border-radius);"><legend style="padding: 0 10px; font-weight: 500;">Créer une nouvelle liste</legend>
                <div class="grid grid-2-col">
                    <div class="form-group"><label for="list_name">Nom de la liste</label><input class="input" type="text" id="list_name" name="list_name" required></div>
                    <div class="form-group"><label for="list_desc">Description</label><input class="input" type="text" id="list_desc" name="list_desc"></div>
                </div><div style="margin-top:15px;"><button type="submit" class="btn"><span class="material-symbols-outlined">playlist_add</span>Créer</button></div></fieldset>
            </form>
            <form method="post" style="margin-top:20px;">
                <input type="hidden" name="action" value="add_members"><input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <fieldset style="border:1px dashed #ddd; padding: 20px; border-radius: var(--border-radius);"><legend style="padding: 0 10px; font-weight: 500;">Ajouter des membres à une liste</legend>
                <div class="form-group">
                    <label for="list_id_add">Sélectionner la liste</label>
                    <select class="input" name="list_id" id="list_id_add" required><option value="">— Choisir —</option><?php foreach($mailing_lists as $ml): ?><option value="<?= (int)$ml['id'] ?>">#<?= (int)$ml['id'] ?> — <?= htmlspecialchars($ml['name']) ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group" style="margin-top:15px;">
                    <label>Sélectionner les utilisateurs à ajouter</label>
                    <div style="max-height:240px; overflow:auto; border:1px solid #eee; border-radius:8px; padding:10px;">
                        <div class="grid grid-2-col">
                        <?php foreach($users as $u): ?><label style="font-size: 14px; display:flex; align-items:center; gap:8px;"><input type="checkbox" name="selected_users[]" value="<?= (int)$u['id'] ?>"><span><?= htmlspecialchars(trim($u['prenom'].' '.$u['name'])) ?></span></label><?php endforeach; ?>
                        </div>
                    </div>
                </div><div style="margin-top:15px;"><button type="submit" class="btn"><span class="material-symbols-outlined">person_add</span>Ajouter les membres</button></div></fieldset>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Toggle Sidebar
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.toggle-btn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => sidebar.classList.toggle('open'));
    }
    
    // Snippets pour l'éditeur de contenu
    const bodyField = document.getElementById('body_html');
    if(bodyField) {
        document.getElementById('btnCTA')?.addEventListener('click', () => {
            const s = `<p style="text-align: center; margin: 20px 0;"><a href="#" style="display: inline-block; padding: 12px 24px; border-radius: 6px; background: #4CAF50; color: #fff; text-decoration: none; font-weight: bold;">Accéder à mon compte</a></p>`;
            bodyField.value += (bodyField.value ? "\n\n" : "") + s;
        });
        document.getElementById('btnTwoCols')?.addEventListener('click', () => {
            const s = `<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse; margin: 20px 0;"><tr><td style="width:50%; padding-right:10px; vertical-align:top;"><h3 style="margin:0 0 8px 0;">Titre Colonne 1</h3><p style="margin:0;">Contenu de la première colonne.</p></td><td style="width:50%; padding-left:10px; vertical-align:top;"><h3 style="margin:0 0 8px 0;">Titre Colonne 2</h3><p style="margin:0;">Contenu de la seconde colonne.</p></td></tr></table>`;
            bodyField.value += (bodyField.value ? "\n\n" : "") + s;
        });
    }

    // Gestion des Modals
    const setupModal = (modalId, openBtnId, closeBtnId) => {
        const modal = document.getElementById(modalId);
        const openBtn = document.getElementById(openBtnId);
        const closeBtn = document.getElementById(closeBtnId);
        if(modal && openBtn && closeBtn) {
            openBtn.addEventListener('click', () => modal.classList.add('open'));
            closeBtn.addEventListener('click', () => modal.classList.remove('open'));
        }
    };
    setupModal('previewModal', 'btnPreview', 'closePreview');
    setupModal('tplModal', 'openTemplateEditor', 'closeTpl');
    setupModal('listsModal', 'btnOpenLists', 'closeLists');
    
    // Aperçu Email
    const previewFrame = document.getElementById('previewFrame');
    document.getElementById('btnPreview')?.addEventListener('click', () => {
        const preheader = document.querySelector('input[name=preheader]').value || '';
        const fromName = document.querySelector('input[name=from_name]').value || '';
        const bodyHtml = bodyField.value || '';
        const finalHtml = `<!DOCTYPE html><html><head><meta charset='UTF-8'><style>body{margin:0;background:#f5f5f5;color:#333;font-family:Roboto,Arial,sans-serif}a{color:#4CAF50}.wrap{max-width:720px;margin:0 auto;background:#fff}.head{padding:24px;border-bottom:3px solid #4CAF50;text-align:center}.brand{margin:0;font-size:22px;color:#4CAF50}.content{padding:24px;line-height:1.6}.foot{padding:18px;text-align:center;color:#757575;border-top:1px solid #eee;font-size:12px}.pre{display:none!important}</style></head><body><span class='pre'>${preheader.replace(/</g, '&lt;')}</span><div class='wrap'><div class='head'><h1 class='brand'>${fromName.replace(/</g, '&lt;')}</h1></div><div class='content'>${bodyHtml}</div><div class='foot'>Ceci est un aperçu.</div></div></body></html>`;
        if (previewFrame) previewFrame.srcdoc = finalHtml;
    });

    // Chargement des données des templates en JS
    const templatesData = <?= json_encode(
        array_column(
            $pdo->query("SELECT id,title,default_subject,default_preheader,html FROM email_templates")->fetchAll(PDO::FETCH_ASSOC),
            null, 'id'
        )
    ); ?>;

    document.getElementById('selectTemplate')?.addEventListener('change', function() {
        const id = this.value;
        if (!id || !templatesData[id]) return;
        const t = templatesData[id];
        document.querySelector('input[name=subject]').value = t.default_subject || '';
        document.querySelector('input[name=preheader]').value = t.default_preheader || '';
        bodyField.value = t.html || '';
    });
});
</script>

</body>
</html>
