<?php
// --- DÉBUT DU DÉBOGAGE ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --- FIN DU DÉBOGAGE ---

session_start();
// SÉCURITÉ : Vérifier si l'admin est connecté
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    exit('Accès interdit.');
}

// CONNEXION BDD
require '../../db_connection.php'; 

// !! IMPORTANT !! Ajustez ce chemin. 
define('UPLOAD_DIR', '/homepages/17/d4299143973/htdocs/uploads/documents/');
// Assurez-vous que le dossier /htdocs/uploads/documents/ existe !

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../crm.php'); 
    exit;
}

if (!isset($_POST['client_id']) || empty($_POST['client_id'])) {
    die("Erreur : ID client manquant.");
}
$client_id = (int)$_POST['client_id'];

$pdo->beginTransaction();

try {

    // ===============================================
    // 1. MISE À JOUR DE L'UTILISATEUR (table: users)
    // ===============================================
    
    if (!empty($_POST['new_password'])) {
        $hashed_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $client_id]);
    }

    $sql_users = "UPDATE users SET 
        prenom = ?, name = ?, email = ?, telephone = ?, date_naissance = ?, 
        nationalite = ?, adresse = ?, adresse_l1 = ?, code_postal = ?, 
        ville = ?, pays = ?, statut = ?, verifie = ?, iban = ?, 
        cagnotte = ?, parrain = ?
        WHERE id = ?";
        
    $stmt_users = $pdo->prepare($sql_users);
    $stmt_users->execute([
        $_POST['prenom'] ?? null,
        $_POST['nom'] ?? null,
        $_POST['email'] ?? null,
        $_POST['telephone'] ?? null,
        empty($_POST['date_naissance']) ? null : $_POST['date_naissance'],
        $_POST['nationalite'] ?? null,
        $_POST['adresse'] ?? null,
        $_POST['adresse_l1'] ?? null,
        $_POST['code_postal'] ?? null,
        $_POST['ville'] ?? null,
        $_POST['pays'] ?? null,
        $_POST['statut'] ?? 'pending',
        $_POST['verifie'] ?? 0,
        $_POST['iban'] ?? null,
        $_POST['cagnotte'] ?? 0,
        empty($_POST['parrain']) ? null : $_POST['parrain'],
        $client_id
    ]);

    // ===============================================
// 2. MISE À JOUR DES CONTRATS (boucle) - CORRIGÉ
// ===============================================
if (isset($_POST['contrat']) && is_array($_POST['contrat'])) {
    $stmt_contrat = $pdo->prepare(
        "UPDATE contrats SET
         montant = ?,
         statut = ?,
         mensualites_payees = ?,
         defaut_paiement = ?,
         note = ?
         WHERE id = ? AND user_id = ?" // date_fin removed from SET
    );
    foreach ($_POST['contrat'] as $id_contrat => $data) {
        $stmt_contrat->execute([
            // date_fin parameter removed
            $data['montant'] ?? 0,
            $data['statut'] ?? null,
            $data['mensualites_payees'] ?? 0,
            $data['defaut_paiement'] ?? 0,
            $data['note'] ?? null,
            $id_contrat,
            $client_id
        ]);
    }
}
    
    // ===============================================
    // 3. MISE À JOUR DES DEMANDES DE RETRAIT (boucle)
    // ===============================================
    if (isset($_POST['retrait']) && is_array($_POST['retrait'])) {
        $stmt_retrait = $pdo->prepare(
            "UPDATE demandes_retrait SET 
             montant = ?, statut = ?, date_virement = ?, reference_virement = ? 
             WHERE id = ? AND user_id = ?"
        );
        foreach ($_POST['retrait'] as $id_retrait => $data) {
            $stmt_retrait->execute([
                $data['montant'] ?? 0,
                $data['statut'] ?? 'pending',
                empty($data['date_virement']) ? null : $data['date_virement'],
                $data['reference_virement'] ?? null,
                $id_retrait,
                $client_id
            ]);
        }
    }
    
    // ===============================================
    // 4. MISE À JOUR DES DOCUMENTS (boucle)
    // ===============================================
    if (isset($_POST['document']) && is_array($_POST['document'])) {
        $stmt_doc = $pdo->prepare(
            "UPDATE documents SET 
             category = ?, status = ? 
             WHERE id = ? AND user_id = ?"
        );
        foreach ($_POST['document'] as $id_doc => $data) {
            $stmt_doc->execute([
                $data['category'] ?? null,
                $data['status'] ?? 'pending',
                $id_doc,
                $client_id
            ]);
        }
    }
    
    // ===============================================
    // 5. AJOUT D'UNE NOTE ADMIN
    // ===============================================
    if (!empty($_POST['action_add_note']) && !empty($_POST['new_admin_note'])) {
        $stmt_note = $pdo->prepare(
            "INSERT INTO user_interactions (user_id, type, contenu, source, created_at) 
             VALUES (?, ?, ?, 'admin_crm', NOW())"
        );
        $stmt_note->execute([
            $client_id,
            $_POST['new_admin_note_type'] ?? 'admin_note',
            $_POST['new_admin_note']
        ]);
    }
    
    // ===============================================
    // 6. UPLOAD D'UN NOUVEAU DOCUMENT
    // ===============================================
    if (isset($_FILES['new_document']) && $_FILES['new_document']['error'] == 0) {
        $file = $_FILES['new_document'];
        $category = $_POST['new_document_category'] ?? 'Inconnu';
        
        // Vérification du dossier d'upload
        if (!is_dir(UPLOAD_DIR) || !is_writable(UPLOAD_DIR)) {
             throw new Exception("Erreur de configuration serveur : Le dossier d'upload n'existe pas ou n'est pas inscriptible. Chemin vérifié : " . UPLOAD_DIR);
        }
        
        $filename = preg_replace("/[^a-zA-Z0-9-_\.]/", "", basename($file['name']));
        $file_path_rel = $client_id . '_' . time() . '_' . $filename;
        $destination = UPLOAD_DIR . $file_path_rel;

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            $stmt_upload = $pdo->prepare(
                "INSERT INTO documents (user_id, category, filename, file_name, file_path, upload_date, status) 
                 VALUES (?, ?, ?, ?, ?, NOW(), 'pending')"
            );
            $stmt_upload->execute([
                $client_id,
                $category,
                $file_path_rel, 
                $file_path_rel,
                $destination 
            ]);
        } else {
            throw new Exception("Échec de l'upload du fichier. Erreur PHP : " . $file['error']);
        }
    }

    $pdo->commit();

    header('Location: ../crm.php?client_id=' . $client_id . '&success=1');
    exit;

} catch (Exception $e) {
    // --- BLOC DE DÉBOGAGE MODIFIÉ ---
    // Une erreur est survenue, on annule tout
    $pdo->rollBack();
    
    // On AFFICHE l'erreur au lieu de rediriger
    die("ERREUR LORS DE LA SAUVEGARDE : " . $e->getMessage());
    // --- FIN DU BLOC DE DÉBOGAGE ---
}
?>