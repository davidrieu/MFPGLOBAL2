<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php'; // Assurez-vous que ce chemin est correct

$users = [];
$produits = [];

try {
    // 3. Récupérer les utilisateurs et les produits pour les listes déroulantes
    $users_stmt = $pdo->query("SELECT id, prenom, name FROM users ORDER BY name ASC, prenom ASC");
    $users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);

    $produits_stmt = $pdo->query("SELECT id, name, prix, taux FROM produits ORDER BY name ASC");
    $produits = $produits_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}

// 4. Traitement du formulaire lors de sa soumission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données
    $user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
    $produit_id = filter_input(INPUT_POST, 'produit_id', FILTER_VALIDATE_INT);
    $montant = filter_input(INPUT_POST, 'montant', FILTER_VALIDATE_FLOAT);
    $apport = filter_input(INPUT_POST, 'apport', FILTER_VALIDATE_FLOAT);
    $date_souscription = filter_input(INPUT_POST, 'date_souscription', FILTER_SANITIZE_STRING);
    $type_paiement = filter_input(INPUT_POST, 'type_paiement', FILTER_SANITIZE_STRING);
    $statut = filter_input(INPUT_POST, 'statut', FILTER_SANITIZE_STRING);
    $promo_code = filter_input(INPUT_POST, 'promo_code', FILTER_SANITIZE_STRING);
    $code_parrain = filter_input(INPUT_POST, 'code_parrain', FILTER_SANITIZE_STRING);

    // Vérification des champs obligatoires
    if ($user_id && $produit_id && $montant !== false && $apport !== false && !empty($date_souscription) && !empty($statut)) {
        try {
            // Récupérer les détails de l'utilisateur et du produit sélectionnés
            $user_info_stmt = $pdo->prepare("SELECT prenom, email FROM users WHERE id = ?");
            $user_info_stmt->execute([$user_id]);
            $user_info = $user_info_stmt->fetch(PDO::FETCH_ASSOC);

            $produit_info_stmt = $pdo->prepare("SELECT taux FROM produits WHERE id = ?");
            $produit_info_stmt->execute([$produit_id]);
            $produit_info = $produit_info_stmt->fetch(PDO::FETCH_ASSOC);

            if ($user_info && $produit_info) {
                // Préparation de la requête d'insertion
                $sql = "INSERT INTO contrats (user_id, user_prenom, email, date_souscription, created_at, montant, apport, taux_moyen, produit_id, type_paiement, statut, promo_code, code_parrain) 
                        VALUES (:user_id, :user_prenom, :email, :date_souscription, NOW(), :montant, :apport, :taux_moyen, :produit_id, :type_paiement, :statut, :promo_code, :code_parrain)";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':user_id' => $user_id,
                    ':user_prenom' => $user_info['prenom'],
                    ':email' => $user_info['email'],
                    ':date_souscription' => $date_souscription,
                    ':montant' => $montant,
                    ':apport' => $apport,
                    ':taux_moyen' => $produit_info['taux'],
                    ':produit_id' => $produit_id,
                    ':type_paiement' => $type_paiement,
                    ':statut' => $statut,
                    ':promo_code' => !empty($promo_code) ? $promo_code : null,
                    ':code_parrain' => !empty($code_parrain) ? $code_parrain : null
                ]);

                $_SESSION['flash_message'] = "Le contrat a été ajouté avec succès.";
                header('Location: gestion_contrats.php');
                exit();
            } else {
                 $_SESSION['flash_message'] = "Erreur : Utilisateur ou produit non trouvé.";
                 $_SESSION['flash_type'] = 'error';
            }
        } catch (PDOException $e) {
            $_SESSION['flash_message'] = "Erreur lors de l'ajout du contrat : " . $e->getMessage();
            $_SESSION['flash_type'] = 'error';
        }
    } else {
        $_SESSION['flash_message'] = "Veuillez remplir tous les champs obligatoires.";
        $_SESSION['flash_type'] = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Contrat - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .page-header h1 { margin: 0; font-size: 28px; font-weight: 700; }
        .btn { display: inline-flex; align-items: center; padding: 10px 15px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .btn-secondary { background-color: var(--secondary-color); color: white; }
        .btn-secondary:hover { background-color: var(--secondary-color-dark); }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { margin-bottom: 8px; font-weight: 500; font-size: 14px; color: var(--text-color-light); }
        .form-group input, .form-group select { padding: 12px; border: 1px solid #ddd; border-radius: var(--border-radius); font-size: 16px; }
        .form-actions { margin-top: 25px; display: flex; justify-content: flex-end; }
        .flash-message { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; text-align: center; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php" class="active"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Ajouter un Nouveau Contrat</h1>
        <a href="gestion_contrats.php" class="btn btn-secondary"><span class="material-symbols-outlined">arrow_back</span>Retour</a>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?= $_SESSION['flash_type'] ?? 'error' ?>"><?= htmlspecialchars($_SESSION['flash_message']); ?></div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="add_contrat.php">
            <div class="form-grid">
                <div class="form-group">
                    <label for="user_id">Utilisateur *</label>
                    <select id="user_id" name="user_id" required>
                        <option value="">-- Choisir un utilisateur --</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['prenom'] . ' ' . $user['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="produit_id">Produit *</label>
                    <select id="produit_id" name="produit_id" required>
                        <option value="">-- Choisir un produit --</option>
                        <?php foreach ($produits as $produit): ?>
                            <option value="<?= $produit['id'] ?>" data-prix="<?= $produit['prix'] ?>"><?= htmlspecialchars($produit['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="montant">Montant du contrat (€) *</label>
                    <input type="number" id="montant" name="montant" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="apport">Apport initial (€) *</label>
                    <input type="number" id="apport" name="apport" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="date_souscription">Date de souscription *</label>
                    <input type="date" id="date_souscription" name="date_souscription" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="form-group">
                    <label for="statut">Statut *</label>
                    <select id="statut" name="statut" required>
                        <option value="en_attente">En attente</option>
                        <option value="en_cours" selected>En cours</option>
                        <option value="termine">Terminé</option>
                        <option value="annule">Annulé</option>
                    </select>
                </div>
                 <div class="form-group">
                    <label for="type_paiement">Type de Paiement</label>
                    <select id="type_paiement" name="type_paiement">
                        <option value="unique" selected>Unique</option>
                        <option value="mensuel">Mensuel</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="promo_code">Code Promo (optionnel)</label>
                    <input type="text" id="promo_code" name="promo_code">
                </div>
                 <div class="form-group">
                    <label for="code_parrain">Code Parrain (optionnel)</label>
                    <input type="text" id="code_parrain" name="code_parrain">
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Ajouter le Contrat</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Petit script pour pré-remplir le montant et l'apport
    // lorsque l'administrateur sélectionne un produit.
    document.getElementById('produit_id').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const prix = selectedOption.getAttribute('data-prix');
        if (prix) {
            document.getElementById('montant').value = prix;
            document.getElementById('apport').value = prix;
        }
    });
</script>

</body>
</html>