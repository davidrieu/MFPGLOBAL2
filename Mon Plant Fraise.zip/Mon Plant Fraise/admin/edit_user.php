<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php';

// 3. Récupération de l'ID de l'utilisateur depuis l'URL
$user_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$user_id) {
    header('Location: gestion_users.php');
    exit();
}

// ===================================================================
// GESTION DE LA SOUMISSION DU FORMULAIRE (METHODE POST)
// ===================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sécurité CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Action non autorisée.');
    }

    // Récupération et nettoyage des données
    $prenom = trim($_POST['prenom']);
    $name = trim($_POST['name']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $telephone = trim($_POST['telephone']);
    $cagnotte = filter_var($_POST['cagnotte'], FILTER_VALIDATE_FLOAT);
    $parrain_id = !empty($_POST['parrain']) ? filter_var($_POST['parrain'], FILTER_VALIDATE_INT) : null;
    $statut = $_POST['statut'];

    try {
        // On utilise une transaction pour s'assurer que les deux opérations réussissent
        $pdo->beginTransaction();

        // ÉTAPE 1 : Mettre à jour la fiche de l'utilisateur dans la table `users` (comme avant)
        $sql_update_user = "UPDATE users SET 
                                prenom = ?, 
                                name = ?, 
                                email = ?, 
                                telephone = ?, 
                                cagnotte = ?, 
                                parrain = ?,
                                statut = ?
                            WHERE id = ?";
        
        $stmt_update_user = $pdo->prepare($sql_update_user);
        $stmt_update_user->execute([$prenom, $name, $email, $telephone, $cagnotte, $parrain_id, $statut, $user_id]);

        // NOUVEAU : ÉTAPE 2 : Créer une entrée correspondante dans la table `parrainage`
        if ($parrain_id) {
            // On vérifie s'il n'existe pas déjà une entrée pour ce parrainage pour éviter les doublons
            $stmt_check = $pdo->prepare("SELECT id FROM parrainage WHERE parrain_id = ? AND email_utilisateur = ?");
            $stmt_check->execute([$parrain_id, $email]);
            
            if ($stmt_check->fetch() === false) {
                // Il n'y a pas d'entrée, on la crée

                // On récupère le code du parrain pour l'insérer
                $stmt_code = $pdo->prepare("SELECT code_parrain FROM users WHERE id = ?");
                $stmt_code->execute([$parrain_id]);
                $code_parrain = $stmt_code->fetchColumn();

                $sql_insert_parrainage = "INSERT INTO parrainage 
                                            (parrain_id, email_utilisateur, code_parrain, gain_parrain, date_demande, statut_demande) 
                                        VALUES (?, ?, ?, ?, NOW(), ?)";
                
                $stmt_insert_parrainage = $pdo->prepare($sql_insert_parrainage);
                // On met un gain de 0 par défaut pour un parrainage ajouté manuellement
                $stmt_insert_parrainage->execute([$parrain_id, $email, $code_parrain, 0.00, 'approuvé']);
            }
        }

        // Si tout est OK, on valide les changements
        $pdo->commit();

        $_SESSION['flash_message'] = "Les informations de l'utilisateur et du parrainage ont été mises à jour.";
        header('Location: gestion_users.php');
        exit();

    } catch (PDOException $e) {
        // En cas d'erreur, on annule tout
        $pdo->rollBack();
        $error_message = "Erreur lors de la mise à jour : " . $e->getMessage();
    }
}

// ===================================================================
// RÉCUPÉRATION DES DONNÉES POUR L'AFFICHAGE (METHODE GET)
// ===================================================================
try {
    // ... (Le reste du fichier est identique)
    // Récupérer les informations de l'utilisateur à modifier
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        header('Location: gestion_users.php');
        exit();
    }

    // Récupérer tous les autres utilisateurs pour les proposer comme parrains
    $sponsors_stmt = $pdo->prepare("SELECT id, prenom, name FROM users WHERE id != ? ORDER BY prenom, name ASC");
    $sponsors_stmt->execute([$user_id]);
    $potential_sponsors = $sponsors_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur de chargement des données : " . $e->getMessage());
}

// Génération du token CSRF pour le formulaire
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier l'Utilisateur - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header h1 { margin: 0 0 20px 0; font-size: 28px; font-weight: 700; }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { margin-bottom: 8px; font-weight: 500; color: var(--text-color-light); font-size: 14px; }
        .form-group input, .form-group select { padding: 12px; border: 1px solid #ddd; border-radius: var(--border-radius); font-size: 16px; }
        .form-actions { margin-top: 30px; display: flex; gap: 15px; }
        .btn { display: inline-flex; align-items: center; padding: 12px 20px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 16px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .btn-secondary { background-color: var(--secondary-color); color: white; }
        .btn-secondary:hover { background-color: var(--secondary-color-dark); }
        .error-message { color: #d32f2f; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: var(--border-radius); margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php" class="active"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Modifier l'utilisateur : <?= htmlspecialchars($user['prenom'] . ' ' . $user['name']) ?></h1>
    </div>

    <?php if (isset($error_message)): ?>
        <div class="error-message"><?= $error_message ?></div>
    <?php endif; ?>
    
    <div class="card">
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <div class="form-grid">
                <div class="form-group">
                    <label for="prenom">Prénom</label>
                    <input type="text" id="prenom" name="prenom" value="<?= htmlspecialchars($user['prenom'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label for="name">Nom</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label for="telephone">Téléphone</label>
                    <input type="tel" id="telephone" name="telephone" value="<?= htmlspecialchars($user['telephone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="cagnotte">Cagnotte (€)</label>
                    <input type="number" step="0.01" id="cagnotte" name="cagnotte" value="<?= htmlspecialchars($user['cagnotte'] ?? '0.00') ?>" required>
                </div>
                <div class="form-group">
                    <label for="parrain">Parrain</label>
                    <select id="parrain" name="parrain">
                        <option value="">-- Aucun --</option>
                        <?php foreach ($potential_sponsors as $sponsor): ?>
                            <option value="<?= $sponsor['id'] ?>" <?= ($sponsor['id'] == $user['parrain']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sponsor['prenom'] . ' ' . $sponsor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                 <div class="form-group">
                    <label for="statut">Statut</label>
                    <select id="statut" name="statut" required>
                        <option value="actif" <?= $user['statut'] == 'actif' ? 'selected' : '' ?>>Actif</option>
                        <option value="inactif" <?= $user['statut'] == 'inactif' ? 'selected' : '' ?>>Inactif</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                <a href="gestion_users.php" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>