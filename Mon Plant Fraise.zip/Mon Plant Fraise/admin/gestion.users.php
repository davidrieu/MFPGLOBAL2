<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php';

// ===================================================================
// GESTION DES ACTIONS (ACTIVER, DÉSACTIVER, SUPPRIMER)
// ===================================================================
if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $user_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

    // Sécurité CSRF basique
    if (!isset($_GET['token']) || !hash_equals($_SESSION['csrf_token'], $_GET['token'])) {
        die('Action non autorisée.');
    }

    if ($user_id) {
        try {
            if ($action === 'toggle_status') {
                $stmt = $pdo->prepare("UPDATE users SET statut = IF(statut='actif', 'inactif', 'actif') WHERE id = ?");
                $stmt->execute([$user_id]);
                $_SESSION['flash_message'] = "Le statut de l'utilisateur a été mis à jour.";
            } elseif ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $_SESSION['flash_message'] = "L'utilisateur a été supprimé avec succès.";
            }
        } catch (PDOException $e) {
            $_SESSION['flash_message'] = "Erreur : Impossible de réaliser l'action. L'utilisateur est peut-être lié à des contrats.";
            $_SESSION['flash_type'] = 'error';
        }
    }
    header('Location: gestion_users.php');
    exit();
}
// Génération du token CSRF
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));


// ===================================================================
// LOGIQUE D'AFFICHAGE (RECHERCHE, FILTRE, PAGINATION)
// ===================================================================
// Paramètres
$limit = 15;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Recherche et filtre
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['statut']) ? $_GET['statut'] : '';

// Construction de la requête SQL
$sql_base = "FROM users u LEFT JOIN users p ON u.parrain = p.id";
$where_clauses = [];
$params = [];

if (!empty($search_query)) {
    $where_clauses[] = "(u.name LIKE ? OR u.prenom LIKE ? OR u.email LIKE ? OR CONCAT(p.prenom, ' ', p.name) LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
}

if (!empty($status_filter)) {
    $where_clauses[] = "u.statut = ?";
    $params[] = $status_filter;
}

$sql_where = "";
if (!empty($where_clauses)) {
    $sql_where = " WHERE " . implode(" AND ", $where_clauses);
}

// Compter le nombre total d'utilisateurs
$total_users_stmt = $pdo->prepare("SELECT COUNT(u.id) " . $sql_base . $sql_where);
$total_users_stmt->execute($params);
$total_users = $total_users_stmt->fetchColumn();
$total_pages = ceil($total_users / $limit);

// Récupérer les utilisateurs pour la page actuelle
$users_sql = "SELECT u.id, u.name, u.prenom, u.email, u.telephone, u.registration_date, u.statut, u.cagnotte, CONCAT(p.prenom, ' ', p.name) as parrain_nom " 
           . $sql_base . $sql_where . " ORDER BY u.registration_date DESC LIMIT $limit OFFSET $offset";
$users_stmt = $pdo->prepare($users_sql);
$users_stmt->execute($params);
$users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Utilisateurs - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        /* CSS identique au précédent */
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --danger-color: #d32f2f; --danger-color-dark: #c62828;
            --warning-color: #F57C00; --warning-color-dark: #ef6c00;
            --info-color: #0288d1;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;}
        .page-header h1 { margin: 0; font-size: 28px; font-weight: 700; }
        .btn { display: inline-flex; align-items: center; padding: 10px 15px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); overflow-x: auto; }
        .filters { display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;}
        .filters input, .filters select { padding: 10px; border: 1px solid #ddd; border-radius: var(--border-radius); font-size: 14px; flex-grow: 1; min-width: 150px; }
        .users-table { width: 100%; border-collapse: collapse; min-width: 800px; }
        .users-table th, .users-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #f0f0f0; }
        .users-table th { background-color: #fafafa; font-weight: 500; font-size: 14px; color: var(--text-color-light); }
        .status-badge { padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; color: white; }
        .status-actif { background-color: var(--primary-color); }
        .status-inactif { background-color: var(--secondary-color); }
        .actions { white-space: nowrap; }
        .actions a { color: var(--text-color-light); margin: 0 8px; text-decoration: none; transition: color 0.2s ease; vertical-align: middle; }
        .actions a:hover { color: var(--primary-color); }
        .actions a.delete:hover { color: var(--danger-color); }
        .pagination { margin-top: 20px; display: flex; justify-content: center; flex-wrap: wrap; gap: 5px; }
        .pagination a, .pagination span { padding: 8px 12px; text-decoration: none; color: var(--text-color); border: 1px solid #ddd; border-radius: var(--border-radius); }
        .pagination a:hover { background-color: #f0f0f0; }
        .pagination .current { background-color: var(--primary-color); color: white; border-color: var(--primary-color); }
        .flash-message { padding: 15px; margin-bottom: 20px; border-radius: var(--border-radius); background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; text-align: center; }
        .flash-message.error { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb;}
        .cagnotte { font-weight: bold; color: var(--info-color); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php" class="active"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
      	<li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Gestion des Utilisateurs</h1>
        <a href="add_user.php" class="btn btn-primary"><span class="material-symbols-outlined" style="margin-right: 8px;">add</span>Ajouter un utilisateur</a>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?= $_SESSION['flash_type'] ?? '' ?>">
            <?= htmlspecialchars($_SESSION['flash_message'] ?? ''); ?>
        </div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
    <?php endif; ?>
    
    <div class="card">
        <form method="GET" action="gestion_users.php">
            <div class="filters">
                <input type="text" name="search" placeholder="Rechercher par nom, email, parrain..." value="<?= htmlspecialchars($search_query ?? '') ?>">
                <select name="statut" onchange="this.form.submit()">
                    <option value="">Tous les statuts</option>
                    <option value="actif" <?= $status_filter == 'actif' ? 'selected' : '' ?>>Actif</option>
                    <option value="inactif" <?= $status_filter == 'inactif' ? 'selected' : '' ?>>Inactif</option>
                </select>
                <button type="submit" class="btn btn-primary">Rechercher</button>
            </div>
        </form>

        <table class="users-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom Complet</th>
                    <th>Email & Téléphone</th>
                    <th>Date d'inscription</th>
                    <th>Cagnotte</th>
                    <th>Parrain</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    <?php if (empty($users)): ?>
        <tr>
            <td colspan="8" style="text-align: center; padding: 20px;">Aucun utilisateur trouvé.</td>
        </tr>
    <?php else: ?>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['prenom'] . ' ' . $user['name']) ?></td>
                <td>
                    <?= htmlspecialchars($user['email'] ?? '') ?><br>
                    <small style="color: var(--text-color-light)"><?= htmlspecialchars($user['telephone'] ?? '') ?></small>
                </td>
                <td><?= (new DateTime($user['registration_date']))->format('d/m/Y') ?></td>
                <td class="cagnotte"><?= number_format($user['cagnotte'], 2, ',', ' ') ?> €</td>
                <td><?= htmlspecialchars($user['parrain_nom'] ?? 'Aucun') ?></td>
                <td>
                    <span class="status-badge status-<?= htmlspecialchars($user['statut'] ?? 'inactif') ?>">
                        <?= ucfirst(htmlspecialchars($user['statut'] ?? 'inactif')) ?>
                    </span>
                </td>
                <td class="actions">
                    <a href="messagerie.php?action=start&user_id=<?= $user['id'] ?>" title="Envoyer un message"><span class="material-symbols-outlined">forward_to_inbox</span></a>

                    <a href="edit_user.php?id=<?= $user['id'] ?>" title="Modifier"><span class="material-symbols-outlined">edit</span></a>
                    <a href="?action=toggle_status&id=<?= $user['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" title="<?= ($user['statut'] ?? '') == 'actif' ? 'Désactiver' : 'Activer' ?>">
                        <span class="material-symbols-outlined"><?= ($user['statut'] ?? '') == 'actif' ? 'toggle_off' : 'toggle_on' ?></span>
                    </a>
                    <a href="?action=delete&id=<?= $user['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" class="delete" title="Supprimer" onclick="return confirm('Êtes-vous sûr ?');">
                        <span class="material-symbols-outlined">delete</span>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
</tbody>
        </table>

        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?= $i ?>&search=<?= htmlspecialchars($search_query) ?>&statut=<?= $status_filter ?>" class="<?= ($i == $page) ? 'current' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
</div>

</body>
</html>