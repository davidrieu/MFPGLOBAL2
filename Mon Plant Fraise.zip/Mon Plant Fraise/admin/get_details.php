<?php
session_start();
// SÉCURITÉ : Indispensable pour protéger l'accès aux données
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403); // Forbidden
    die("Accès non autorisé.");
}

require_once '../db_connection.php';

// On récupère le type de données demandé
$type = $_GET['type'] ?? '';

if (empty($type)) {
    http_response_code(400); // Bad Request
    die("Aucun type de données spécifié.");
}

try {
    $html = '<div class="table-container"><table class="details-table"><thead><tr>';
    $query = "";
    
    // On utilise un switch pour préparer la requête et les en-têtes du tableau
    switch ($type) {
        case 'total_contrats':
            $html .= '<th>Utilisateur</th><th>Montant</th><th>Statut</th><th>Date de souscription</th>';
            $query = "SELECT u.prenom, u.name as user_nom, c.montant, c.statut, c.date_souscription 
                      FROM contrats c JOIN users u ON c.user_id = u.id 
                      ORDER BY c.date_souscription DESC";
            break;

        case 'utilisateurs_actifs':
            $html .= '<th>Prénom</th><th>Nom</th><th>Email</th><th>Date d\'inscription</th>';
            $query = "SELECT DISTINCT u.prenom, u.name, u.email, u.created_at 
                      FROM users u JOIN contrats c ON u.id = c.user_id 
                      WHERE TRIM(c.statut) = 'en cours' 
                      ORDER BY u.name ASC";
            break;

        case 'contrats_en_cours':
            $html .= '<th>Utilisateur</th><th>Montant</th><th>Produit</th><th>Date de souscription</th>';
            $query = "SELECT u.prenom, u.name as user_nom, c.montant, p.name as produit_nom, c.date_souscription 
                      FROM contrats c 
                      JOIN users u ON c.user_id = u.id 
                      LEFT JOIN produits p ON c.produit_id = p.id
                      WHERE TRIM(c.statut) = 'en cours' 
                      ORDER BY c.date_souscription DESC";
            break;

        case 'investissements_30j':
            $html .= '<th>Utilisateur</th><th>Apport</th><th>Date</th>';
            $query = "SELECT u.prenom, u.name as user_nom, c.apport, c.created_at
                      FROM contrats c JOIN users u ON c.user_id = u.id
                      WHERE c.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                      ORDER BY c.created_at DESC";
            break;

        case 'nouveaux_contrats_24h':
            $html .= '<th>Utilisateur</th><th>Montant</th><th>Heure de souscription</th>';
            $query = "SELECT u.prenom, u.name as user_nom, c.montant, c.created_at
                      FROM contrats c JOIN users u ON c.user_id = u.id
                      WHERE c.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                      ORDER BY c.created_at DESC";
            break;

        default:
            http_response_code(400);
            die("Type de données non valide.");
    }
    
    $html .= '</tr></thead><tbody>';
    
    $stmt = $pdo->query($query);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($results)) {
        $html .= '<tr><td colspan="100%">Aucune donnée à afficher.</td></tr>';
    } else {
        foreach ($results as $row) {
            $html .= '<tr>';
            foreach ($row as $key => $value) {
                // Formattage spécial pour les dates/montants
                if (preg_match('/montant|apport/i', $key)) {
                    $html .= '<td>' . htmlspecialchars(number_format((float)$value, 2, ',', ' ')) . ' €</td>';
                } elseif (preg_match('/date|created_at/i', $key)) {
                    $html .= '<td>' . htmlspecialchars((new DateTime($value))->format('d/m/Y H:i')) . '</td>';
                } else {
                    $html .= '<td>' . htmlspecialchars($value) . '</td>';
                }
            }
            $html .= '</tr>';
        }
    }

    $html .= '</tbody></table></div>';
    echo $html;

} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    error_log("Erreur AJAX Details: " . $e->getMessage());
    die("Erreur lors de la récupération des données.");
}
?>