<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php';

// 3. Récupération et validation de l'ID du contrat depuis l'URL
$contrat_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$contrat_id) {
    $_SESSION['flash_message'] = "ID de contrat non valide.";
    $_SESSION['flash_type'] = 'error';
    header('Location: gestion_contrats.php');
    exit();
}

// 4. Récupération de toutes les informations du contrat
try {
    $sql = "SELECT 
                c.*, 
                u.name as user_nom, 
                u.prenom as user_prenom,
                p.name as produit_nom
            FROM contrats c
            LEFT JOIN users u ON c.user_id = u.id
            LEFT JOIN produits p ON c.produit_id = p.id
            WHERE c.id = ?";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$contrat_id]);
    $contrat = $stmt->fetch(PDO::FETCH_ASSOC);

    // Si aucun contrat n'est trouvé, rediriger
    if (!$contrat) {
        $_SESSION['flash_message'] = "Aucun contrat trouvé avec cet ID.";
        $_SESSION['flash_type'] = 'error';
        header('Location: gestion_contrats.php');
        exit();
    }

} catch (PDOException $e) {
    die("Erreur de chargement des données du contrat : " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du Contrat #<?= htmlspecialchars($contrat['id']) ?> - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
            --status-en-cours: #28a745; --status-en-attente: #ffc107; --status-termine: #6c757d; --status-annule: #dc3545;
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .header-title { display: flex; align-items: center; gap: 15px; }
        .header-title h1 { margin: 0; font-size: 28px; font-weight: 700; }
        .header-actions { display: flex; gap: 10px; }
        .btn { display: inline-flex; align-items: center; padding: 10px 15px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn .material-symbols-outlined { margin-right: 8px; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .btn-secondary { background-color: var(--secondary-color); color: white; }
        .btn-secondary:hover { background-color: var(--secondary-color-dark); }
        .status-badge { padding: 6px 12px; border-radius: 15px; font-size: 14px; font-weight: 500; color: white; text-transform: capitalize; }
        .status-en_cours { background-color: var(--status-en-cours); }
        .status-en_attente { background-color: var(--status-en-attente); color: #333; }
        .status-termine { background-color: var(--status-termine); }
        .status-annule { background-color: var(--status-annule); }
        .details-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .detail-card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .detail-card h3 { margin-top: 0; font-size: 18px; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
        .detail-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f5f5f5; }
        .detail-item:last-child { border-bottom: none; }
        .detail-item .label { color: var(--text-color-light); }
        .detail-item .value { font-weight: 500; text-align: right; }
        .detail-item .value a { color: var(--primary-color); text-decoration: none; font-weight: 500; }
        .detail-item .value a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php" class="active"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="#"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <div class="header-title">
            <h1>Détails du Contrat #<?= htmlspecialchars($contrat['id']) ?></h1>
            <span class="status-badge status-<?= str_replace(' ', '_', $contrat['statut']) ?>"><?= htmlspecialchars(str_replace('_', ' ', $contrat['statut'])) ?></span>
        </div>
        <div class="header-actions">
            <a href="gestion_contrats.php" class="btn btn-secondary"><span class="material-symbols-outlined">arrow_back</span>Retour</a>
            <a href="#" class="btn btn-secondary"><span class="material-symbols-outlined">print</span>Imprimer (PDF)</a>
            <a href="edit_contrat.php?id=<?= $contrat['id'] ?>" class="btn btn-primary"><span class="material-symbols-outlined">edit</span>Modifier</a>
        </div>
    </div>

    <div class="details-grid">
        <div class="detail-card">
            <h3><span class="material-symbols-outlined">euro</span>Informations Financières</h3>
            <div class="detail-item">
                <span class="label">Montant Total</span>
                <span class="value"><?= number_format($contrat['montant'], 2, ',', ' ') ?> €</span>
            </div>
            <div class="detail-item">
                <span class="label">Apport Initial</span>
                <span class="value"><?= number_format($contrat['apport'], 2, ',', ' ') ?> €</span>
            </div>
             <div class="detail-item">
                <span class="label">Taux Moyen</span>
                <span class="value"><?= htmlspecialchars($contrat['taux_moyen']) ?> %</span>
            </div>
            <div class="detail-item">
                <span class="label">Mensualités Payées</span>
                <span class="value"><?= htmlspecialchars($contrat['mensualites_payees']) ?></span>
            </div>
            <div class="detail-item">
                <span class="label">Type de Paiement</span>
                <span class="value"><?= htmlspecialchars(ucfirst($contrat['type_paiement'])) ?></span>
            </div>
        </div>

        <div class="detail-card">
            <h3><span class="material-symbols-outlined">person</span>Client & Produit</h3>
            <div class="detail-item">
                <span class="label">Client</span>
                <span class="value">
                    <a href="edit_user.php?id=<?= $contrat['user_id'] ?>">
                        <?= htmlspecialchars(($contrat['user_prenom'] ?? '') . ' ' . ($contrat['user_nom'] ?? 'Utilisateur Inconnu')) ?>
                    </a>
                </span>
            </div>
            <div class="detail-item">
                <span class="label">Email Client</span>
                <span class="value"><?= htmlspecialchars($contrat['email']) ?></span>
            </div>
            <div class="detail-item">
                <span class="label">Produit Associé</span>
                <span class="value">
                     <a href="edit_produit.php?id=<?= $contrat['produit_id'] ?>">
                        <?= htmlspecialchars($contrat['produit_nom'] ?? 'Produit Inconnu') ?> (ID: <?= $contrat['produit_id'] ?>)
                    </a>
                </span>
            </div>
        </div>

        <div class="detail-card">
            <h3><span class="material-symbols-outlined">sell</span>Détails Promotionnels</h3>
            <div class="detail-item">
                <span class="label">Code Promo</span>
                <span class="value"><?= htmlspecialchars($contrat['promo_code'] ?? 'Aucun') ?></span>
            </div>
            <div class="detail-item">
                <span class="label">Réduction Appliquée</span>
                <span class="value"><?= !empty($contrat['promo_percentage']) ? htmlspecialchars($contrat['promo_percentage']) . ' %' : 'Aucune' ?></span>
            </div>
             <div class="detail-item">
                <span class="label">Code Parrain</span>
                <span class="value"><?= htmlspecialchars($contrat['code_parrain'] ?? 'Aucun') ?></span>
            </div>
        </div>
        
        <div class="detail-card">
            <h3><span class="material-symbols-outlined">calendar_month</span>Historique & Suivi</h3>
            <div class="detail-item">
                <span class="label">Date de Souscription</span>
                <span class="value"><?= (new DateTime($contrat['date_souscription']))->format('d/m/Y') ?></span>
            </div>
            <div class="detail-item">
                <span class="label">Date de Création (Système)</span>
                <span class="value"><?= (new DateTime($contrat['created_at']))->format('d/m/Y à H:i') ?></span>
            </div>
        </div>
    </div>
</div>

</body>
</html>