<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json');

// --- SÉCURITÉ ---
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Accès non autorisé']);
    exit();
}

require_once '../db_connection.php';

try {
    // --- GESTION DES DATES ---
    $startDateStr = $_GET['start'] ?? date('Y-m-d', strtotime('-29 days'));
    $endDateStr = $_GET['end'] ?? date('Y-m-d');

    $startDate = new DateTime($startDateStr);
    $endDate = new DateTime($endDateStr);
    $endDate->setTime(23, 59, 59);

    $interval = $startDate->diff($endDate);
    $daysCount = $interval->days + 1;

    $prevEndDate = (clone $startDate)->modify('-1 day');
    $prevStartDate = (clone $prevEndDate)->modify('-' . ($daysCount - 1) . ' days');
    
    $data = [
        'kpis' => [],
        'charts' => [],
        'lists' => [],
    ];

    // --- FONCTION UTILITAIRE ---
    function calculate_comparison($current, $previous) {
        if ($previous == 0) {
            return ($current > 0) ? 100 : 0;
        }
        return (($current - $previous) / $previous) * 100;
    }

    // --- 1. KPIs ---
    $stmtKpiTotal = $pdo->prepare("SELECT COALESCE(SUM(montant), 0) FROM contrats WHERE created_at BETWEEN ? AND ?");
    $stmtKpiTotal->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $data['kpis']['total_investi'] = $stmtKpiTotal->fetchColumn();
    $stmtKpiTotal->execute([$prevStartDate->format('Y-m-d H:i:s'), $prevEndDate->format('Y-m-d H:i:s')]);
    $data['kpis']['total_investi_prev'] = $stmtKpiTotal->fetchColumn();
    $data['kpis']['total_investi_comp'] = calculate_comparison($data['kpis']['total_investi'], $data['kpis']['total_investi_prev']);

    $stmtKpiAvg = $pdo->prepare("SELECT COALESCE(AVG(montant), 0) FROM contrats WHERE created_at BETWEEN ? AND ?");
    $stmtKpiAvg->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $data['kpis']['panier_moyen'] = $stmtKpiAvg->fetchColumn();
    $stmtKpiAvg->execute([$prevStartDate->format('Y-m-d H:i:s'), $prevEndDate->format('Y-m-d H:i:s')]);
    $data['kpis']['panier_moyen_prev'] = $stmtKpiAvg->fetchColumn();
    $data['kpis']['panier_moyen_comp'] = calculate_comparison($data['kpis']['panier_moyen'], $data['kpis']['panier_moyen_prev']);

    $stmtKpiCount = $pdo->prepare("SELECT COUNT(id) FROM contrats WHERE created_at BETWEEN ? AND ?");
    $stmtKpiCount->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $data['kpis']['nouveaux_contrats'] = $stmtKpiCount->fetchColumn();
    $stmtKpiCount->execute([$prevStartDate->format('Y-m-d H:i:s'), $prevEndDate->format('Y-m-d H:i:s')]);
    $data['kpis']['nouveaux_contrats_prev'] = $stmtKpiCount->fetchColumn();
    $data['kpis']['nouveaux_contrats_comp'] = calculate_comparison($data['kpis']['nouveaux_contrats'], $data['kpis']['nouveaux_contrats_prev']);

    // CORRIGÉ : Utilisation de `registration_date` au lieu de `created_at` pour la table `users`
    $stmtKpiUsers = $pdo->prepare("SELECT COUNT(id) FROM users WHERE registration_date BETWEEN ? AND ?");
    $stmtKpiUsers->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $nouveaux_utilisateurs = $stmtKpiUsers->fetchColumn();
    $data['kpis']['nouveaux_utilisateurs'] = $nouveaux_utilisateurs;

    $stmtKpiClients = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM contrats WHERE created_at BETWEEN ? AND ?");
    $stmtKpiClients->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $nouveaux_clients = $stmtKpiClients->fetchColumn();
    $data['kpis']['nouveaux_clients'] = $nouveaux_clients;
    $data['kpis']['taux_conversion'] = ($nouveaux_utilisateurs > 0) ? ($nouveaux_clients / $nouveaux_utilisateurs) * 100 : 0;

    // --- 2. GRAPHIQUES ---
    $stmtChartInvest = $pdo->prepare("SELECT DATE(created_at) as jour, SUM(montant) as total FROM contrats WHERE created_at BETWEEN ? AND ? GROUP BY jour ORDER BY jour ASC");
    $stmtChartInvest->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $invest_par_jour = $stmtChartInvest->fetchAll(PDO::FETCH_ASSOC);
    $data['charts']['investissements'] = ['labels' => [], 'values' => []];
    foreach($invest_par_jour as $row) {
        $data['charts']['investissements']['labels'][] = (new DateTime($row['jour']))->format('d/m');
        $data['charts']['investissements']['values'][] = $row['total'];
    }

    $stmtChartStatus = $pdo->prepare("SELECT statut, COUNT(id) as count FROM contrats WHERE created_at BETWEEN ? AND ? GROUP BY statut");
    $stmtChartStatus->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $statuts = $stmtChartStatus->fetchAll(PDO::FETCH_ASSOC);
    $data['charts']['statuts'] = ['labels' => [], 'values' => []];
    foreach($statuts as $row) {
        $data['charts']['statuts']['labels'][] = ucfirst($row['statut']);
        $data['charts']['statuts']['values'][] = $row['count'];
    }

    // --- 3. LISTES ---
    $stmtListInvest = $pdo->prepare("
        SELECT 
            COALESCE(u.prenom, 'Utilisateur') as prenom, 
            COALESCE(u.name, 'Supprimé') as name, 
            SUM(c.montant) as total_investi 
        FROM contrats c 
        LEFT JOIN users u ON c.user_id = u.id 
        WHERE c.created_at BETWEEN ? AND ? 
        GROUP BY c.user_id 
        ORDER BY total_investi DESC 
        LIMIT 5");
    $stmtListInvest->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $data['lists']['top_investisseurs'] = $stmtListInvest->fetchAll(PDO::FETCH_ASSOC);

    /* // List: Top 5 Produits (par CA) - Section toujours en attente de vos noms de colonnes
    $stmtListProducts = $pdo->prepare("SELECT p.name, SUM(c.montant) as total_ca 
        FROM contrats c JOIN produits p ON c.produit_id = p.id 
        WHERE c.created_at BETWEEN ? AND ? 
        GROUP BY c.produit_id ORDER BY total_ca DESC LIMIT 5");
    $stmtListProducts->execute([$startDate->format('Y-m-d H:i:s'), $endDate->format('Y-m-d H:i:s')]);
    $data['lists']['top_produits'] = $stmtListProducts->fetchAll(PDO::FETCH_ASSOC);
    */
    $data['lists']['top_produits'] = []; // On initialise la liste à vide en attendant la correction

    echo json_encode($data);

} catch (Exception $e) {
    http_response_code(500);
    error_log("Dashboard API Error: " . $e->getMessage());
    // On renvoie maintenant le message d'erreur détaillé dans le JSON pour faciliter le futur débogage
    echo json_encode(['error' => 'Erreur interne du serveur.', 'details' => $e->getMessage()]);
}