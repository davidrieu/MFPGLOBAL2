<?php
// codepromo.php — Version finale, complète et sécurisée
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: /admin/login.php'); exit(); }
require_once '../db_connection.php';

// CORRECTIF : Forcer l'encodage de la connexion en UTF-8 pour éviter les erreurs de caractères spéciaux
try {
    $pdo->exec('SET NAMES utf8mb4');
} catch (PDOException $e) {
    die("Erreur critique lors de la configuration de l'encodage : " . $e->getMessage());
}

$error = ''; $success = '';

// ===== CSRF =====
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
function csrf_ok(): bool {
    return ($_SERVER['REQUEST_METHOD'] !== 'POST')
        || (isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf_token']));
}

// ===== Helpers =====
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function normalizeCodeInput(string $s): string {
    $s = strtoupper(trim($s));
    $s = str_replace(["\xE2\x80\x93","\xE2\x80\x94","\xE2\x88\x92"], '-', $s);
    $s = preg_replace('/[\pZ\pC]+/u', '', $s);
    $s = preg_replace('/[^A-Z0-9\-]/u', '', $s);
    $s = preg_replace('/-+/', '-', $s);
    return $s;
}

function generateCode(int $len = 10): string {
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $bytes = random_bytes($len); $out = '';
    for ($i=0; $i<$len; $i++) $out .= $alphabet[ord($bytes[$i]) % strlen($alphabet)];
    if ($len >= 10) $out = substr($out,0,5) . '-' . substr($out,5);
    return $out;
}

function parseDateTimeLocal(?string $v): ?string {
    if (!$v) return null;
    $dt = DateTime::createFromFormat('Y-m-d\TH:i', $v);
    return $dt ? $dt->format('Y-m-d H:i:00') : null;
}

function promoCodeExists(PDO $pdo, string $code): bool {
    $st = $pdo->prepare("SELECT 1 FROM promo_codes WHERE code = :c LIMIT 1");
    $st->execute([':c' => $code]);
    return (bool)$st->fetchColumn();
}

function isActiveRow(array $row): bool {
    if (empty($row['is_active'])) return false;
    try {
        $now = new DateTime();
        if (empty($row['starts_at']) || $row['starts_at'] === '0000-00-00 00:00:00' || $now < new DateTime($row['starts_at'])) {
            return false;
        }
        if (!empty($row['ends_at']) && $row['ends_at'] !== '0000-00-00 00:00:00' && $now > new DateTime($row['ends_at'])) {
            return false;
        }
    } catch (Exception $e) {
        return false;
    }
    if (!is_null($row['usage_limit']) && (int)$row['usage_count'] >= (int)$row['usage_limit']) return false;
    return true;
}

// ===== Actions POST (adapté à votre table) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) { $error = "Session expirée. Veuillez réessayer."; }
    else {
        // Création
        if (isset($_POST['create_promo'])) {
            try {
                $code_mode  = $_POST['code_mode'] ?? 'auto';
                $code_input = $_POST['code'] ?? '';
                $discount   = (int)($_POST['discount_percent'] ?? 0);
                $limit_type = $_POST['limit_type'] ?? 'infinite';
                $limit_val  = isset($_POST['usage_limit']) ? (int)$_POST['usage_limit'] : null;
                $starts_at  = parseDateTimeLocal($_POST['starts_at'] ?? null) ?? (new DateTime())->format('Y-m-d H:i:00');
                $ends_at    = parseDateTimeLocal($_POST['ends_at'] ?? null);
                $assigned   = $_POST['assigned_users'] ?? [];

                if ($discount < 1 || $discount > 100) throw new Exception("Le pourcentage de remise doit être entre 1 et 100.");
                $usage_limit = null;
                if ($limit_type === 'finite') {
                    if ($limit_val < 1 || $limit_val > 200) throw new Exception("La limite d’utilisations doit être entre 1 et 200.");
                    $usage_limit = $limit_val;
                }
                if ($ends_at !== null && $ends_at <= $starts_at) throw new Exception("La fin doit être postérieure au début.");

                if ($code_mode === 'manual') {
                    $code = normalizeCodeInput($code_input);
                    if (strlen($code) < 4 || strlen($code) > 64) throw new Exception("Code manuel : 4 à 64 caractères (A-Z, 0-9, -).");
                    if (promoCodeExists($pdo, $code)) throw new Exception("Ce code existe déjà : ".$code);
                } else {
                    $len = (int)($_POST['auto_length'] ?? 10);
                    $len = max(6, min(20, $len));
                    $attempts = 0;
                    do { $code = generateCode($len); $attempts++; }
                    while (promoCodeExists($pdo, $code) && $attempts < 5);
                    if (promoCodeExists($pdo, $code)) throw new Exception("Impossible de générer un code unique.");
                }

                $assigned_ids = [];
                if (is_array($assigned)) {
                    foreach ($assigned as $uid) { $uid = (int)$uid; if ($uid > 0) $assigned_ids[] = $uid; }
                    $assigned_ids = array_values(array_unique($assigned_ids));
                }
                
                $now_datetime = (new DateTime())->format('Y-m-d H:i:s');

                $pdo->beginTransaction();
                $ins = $pdo->prepare(
                    "INSERT INTO promo_codes (
                        user_id, code, discount_percent, usage_limit, usage_count, 
                        starts_at, ends_at, montant_reduction, date_creation, 
                        est_utilise, is_active, created_by, created_at
                    ) VALUES (
                        NULL, :code, :discount_percent, :usage_limit, 0, 
                        :starts_at, :ends_at, NULL, :now_date, 
                        0, 1, :created_by, :now_date
                    )"
                );
                $ins->execute([
                    ':code'               => $code,
                    ':discount_percent'   => $discount,
                    ':usage_limit'        => $usage_limit,
                    ':starts_at'          => $starts_at,
                    ':ends_at'            => $ends_at,
                    ':now_date'           => $now_datetime,
                    ':created_by'         => ($_SESSION['admin_id'] ?? null)
                ]);
                $promo_id = (int)$pdo->lastInsertId();

                if (!empty($assigned_ids)) {
                    $ins2 = $pdo->prepare("INSERT INTO promo_code_users (promo_code_id, user_id) VALUES (:pid, :uid)");
                    foreach ($assigned_ids as $uid) $ins2->execute([':pid'=>$promo_id, ':uid'=>$uid]);
                }
                $pdo->commit();
                $success = "Code promo créé : <strong>" . h($code) . "</strong>";

            } catch (PDOException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                if ($e->getCode()==='23000' && strpos($e->getMessage(), '1062') !== false) {
                     $error = "Ce code promo existe déjà.";
                } else {
                     $error = "Erreur base de données : " . $e->getMessage();
                }
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = $e->getMessage();
            }
        }

        // Toggle activation
        if (isset($_POST['toggle_active'], $_POST['promo_id'])) {
            try {
                $pid = (int)$_POST['promo_id'];
                $newState = (int)($_POST['toggle_active'] === '1' ? 1 : 0);
                $upd = $pdo->prepare("UPDATE promo_codes SET is_active = :s WHERE id = :id");
                $upd->execute([':s'=>$newState, ':id'=>$pid]);
                $success = $newState ? "Code réactivé." : "Code désactivé.";
            } catch (Throwable $e) {
                $error = "Impossible de changer l'état du code.";
            }
        }
    }
}

// ===== Données =====
$users = [];
try {
    $q = $pdo->query("SELECT id, prenom, name, email FROM users ORDER BY prenom, name LIMIT 400");
    if ($q) $users = $q->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log("Erreur de lecture des utilisateurs : " . $e->getMessage());
}

$codes = [];
try {
    $stmt = $pdo->query("
        SELECT pc.*,
               GROUP_CONCAT(DISTINCT u.email ORDER BY u.email SEPARATOR ', ') AS assigned_emails
        FROM promo_codes pc
        LEFT JOIN promo_code_users pcu ON pcu.promo_code_id = pc.id
        LEFT JOIN users u ON u.id = pcu.user_id
        GROUP BY pc.id
        ORDER BY pc.created_at DESC
        LIMIT 200
    ");
    if ($stmt) $codes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $error = "Erreur critique: Impossible de lire la table 'promo_codes'.";
    error_log("Erreur de lecture des codes promo : " . $e->getMessage());
}

$totalCount = count($codes);
$activeCount = 0;
if (is_array($codes)) {
    foreach ($codes as $r) { if (isActiveRow($r)) $activeCount++; }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Codes Promo — Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,600,0,0" />
<style>
:root{
  --bg:#F6F7FB; --card:#fff; --text:#111827; --muted:#6B7280;
  --primary:#4CAF50; --primary-600:#43A047; --primary-700:#388E3C;
  --ok:#2E7D32; --ring:rgba(76,175,80,.22);
  --radius:12px; --shadow:0 12px 34px rgba(0,0,0,.08);
  --stripe:#FAFAFD;
}
*{box-sizing:border-box} html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);font-family:Roboto,system-ui,-apple-system,Segoe UI,Arial,sans-serif;color:var(--text);line-height:1.5}
a{text-decoration:none;color:inherit}
.toolbar{position:sticky;top:0;z-index:10;background:rgba(255,255,255,.9);backdrop-filter:saturate(180%) blur(8px);border-bottom:1px solid #eee}
.toolbar-inner{max-width:1200px;margin:0 auto;padding:12px clamp(12px,2vw,24px);display:flex;align-items:center;gap:12px}
.title{font-size:clamp(16px,2vw,20px);font-weight:700}
.spacer{flex:1}
.btn{background:var(--primary);color:#fff;border:0;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer;box-shadow:0 6px 18px rgba(76,175,80,.25);transition:.18s}
.btn:hover{background:var(--primary-600);transform:translateY(-1px)}
.btn.ghost{background:#fff;color:var(--text);border:1px solid #e5e7eb;box-shadow:none}
.wrap{max-width:1200px;margin:20px auto;padding:0 clamp(12px,2.5vw,24px);display:grid;gap:20px}
.card{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:clamp(16px,2vw,24px)}
h1{margin:.2em 0;font-size:clamp(20px,2.4vw,28px)} h2{margin:.2em 0;font-size:clamp(18px,2.1vw,22px)}
.subtitle{color:var(--muted);margin-bottom:8px}
.grid{display:grid;gap:16px}
@media (min-width:980px){ .grid-2{grid-template-columns:1fr 1fr;} }
label{font-weight:600;font-size:14px;margin-bottom:6px;display:block}
input[type="text"],input[type="number"],input[type="datetime-local"],select{
  width:100%;padding:12px;border:1px solid #E5E7EB;border-radius:10px;font-size:14px;background:#fff;
  transition:border .15s, box-shadow .15s
}
input:focus,select:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 4px var(--ring)}
.inline{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.hint{font-size:12px;color:var(--muted)}
.seg{display:flex;gap:8px;flex-wrap:wrap}
.seg label{margin:0}
.seg .chip{padding:8px 12px;border:1px solid #E5E7EB;border-radius:999px;cursor:pointer;display:inline-flex;align-items:center;gap:8px}
.seg input{display:none}
.seg input:checked + .chip{background:#EBFFF0;border-color:var(--primary);color:var(--primary-700)}
.toast{display:none;align-items:center;gap:10px;padding:12px;border-radius:12px;border:1px solid;margin:0 auto;width:100%;max-width:1200px}
.toast.show{display:flex} .toast.success{background:#F0FFF4;color:#166534;border-color:#86EFAC}
.toast.error{background:#FEF2F2;color:#991B1B;border-color:#FCA5A5}
.badge{display:inline-flex;align-items:center;gap:8px;background:#EEF7EE;color:#2E7D32;padding:6px 10px;border-radius:999px;font-weight:700}

table{width:100%;border-collapse:collapse;border-radius:12px;overflow:hidden}
thead th{background:#F9FAFB;font-size:12px;letter-spacing:.04em;color:#6B7280;padding:12px;border-bottom:1px solid #EEE;text-transform:uppercase}
tbody td{padding:12px;border-bottom:1px solid #F3F4F6;vertical-align:top}
tbody tr:nth-child(odd){background:var(--stripe)}
tbody tr:hover{background:#F2FFF6}
.inline-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.copy{cursor:pointer;border:1px dashed #d1d5db;border-radius:8px;padding:6px 10px;background:#fff}
.status{display:inline-flex;align-items:center;gap:8px}
.dot{width:10px;height:10px;border-radius:50%} .dot.ok{background:var(--ok)} .dot.no{background:#9CA3AF}
.progress{height:8px;background:#E5E7EB;border-radius:999px;overflow:hidden;width:120px}
.progress > span{display:block;height:100%;background:var(--primary);width:0%}
.filter{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.pill{padding:8px 12px;border-radius:999px;border:1px solid #e5e7eb;background:#fff;color:#374151;font-size:13px;cursor:pointer}

/* Switch Actif/Inactif */
.switch{position:relative;display:inline-block;width:48px;height:26px}
.switch input{opacity:0;width:0;height:0}
.slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:#d1d5db;transition:.2s;border-radius:999px}
.slider:before{position:absolute;content:"";height:20px;width:20px;left:3px;bottom:3px;background:white;transition:.2s;border-radius:50%}
input:checked + .slider{background:#22c55e}
input:checked + .slider:before{transform:translateX(22px)}

/* Details (section repliée) */
details.promo-details{border:1px solid #e5e7eb;border-radius:12px;background:#fff;box-shadow:var(--shadow)}
details.promo-details > summary{list-style:none;cursor:pointer;user-select:none;display:flex;align-items:center;gap:10px;padding:14px 18px;font-weight:700}
details.promo-details > summary::-webkit-details-marker{display:none}
details.promo-details > summary .chev{transition:.2s}
details.promo-details[open] > summary .chev{transform:rotate(90deg)}
details.promo-details .content{padding:0 18px 18px 18px}

@media (max-width: 820px){
  /* Table -> cartes */
  table, thead, tbody, th, tr { display:block; width:100% }
  thead{ position:absolute; top:-9999px; left:-9999px }
  tbody tr{ background:#fff; border-radius:12px; box-shadow:var(--shadow); margin-bottom:14px; padding:6px }
  tbody td{ display:flex; justify-content:space-between; gap:12px; border-bottom:1px solid #eee; padding:12px 10px }
  tbody td:last-child{ border-bottom:none }
  tbody td::before{ content:attr(data-label); font-weight:700; color:#6B7280; flex:1; max-width:48% }
  tbody td > *:not(.mini):not(.progress){ max-width:52%; text-align:right }
  .progress{ width:50% }
  .toolbar-inner{padding:10px 14px}
  .btn{padding:10px 14px}
  select[multiple]{ height: 260px }
}
@media (max-width: 420px){
  .inline{flex-direction:column; align-items:stretch}
  .progress{ width:100% }
  .copy{ width:100%; text-align:center }
}
</style>
</head>
<body>

<div class="toolbar">
  <div class="toolbar-inner">
    <div class="title">Codes Promo</div>
    <div class="spacer"></div>
    <a class="btn ghost" href="index.php"><span class="material-symbols-outlined">arrow_back</span>&nbsp;Tableau de bord</a>
  </div>
</div>

<div class="wrap">

  <?php if ($error): ?><div class="toast error show"><span class="material-symbols-outlined">error</span><?= $error ?></div><?php endif; ?>
  <?php if ($success): ?><div class="toast success show"><span class="material-symbols-outlined">check_circle</span><?= $success ?></div><?php endif; ?>

  <div class="card">
    <h1>Créer un code promo</h1>
    <p class="subtitle">Remise en %, période d’activation, limite d’utilisations et attribution à des clients spécifiques.</p>

    <form method="post" id="promoForm">
      <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
      <input type="hidden" name="create_promo" value="1">

      <div class="grid grid-2">
        <div class="card" style="padding:18px">
          <h2>Code</h2>
          <div class="seg" style="margin:8px 0 10px">
            <label><input type="radio" name="code_mode" value="auto" checked><span class="chip"><span class="material-symbols-outlined">auto_fix_high</span>Générer</span></label>
            <label><input type="radio" name="code_mode" value="manual"><span class="chip"><span class="material-symbols-outlined">edit</span>Saisir</span></label>
          </div>

          <div id="autoLenWrap">
            <label>Longueur (auto)</label>
            <div class="inline">
              <input type="number" name="auto_length" min="6" max="20" value="10" style="max-width:120px">
              <button type="button" class="btn ghost" id="previewAutoBtn"><span class="material-symbols-outlined">visibility</span>&nbsp;Aperçu</button>
            </div>
            <div class="hint">Format aléatoire en MAJUSCULES (ex: ABCDE-12345).</div>
          </div>

          <div id="manualCodeWrap" style="display:none; margin-top:10px">
            <label>Code (manuel)</label>
            <div class="inline">
              <input type="text" name="code" id="codeManual" placeholder="EX: VIP2025" pattern="[A-Z0-9\-]{4,64}">
              <button type="button" class="btn ghost" id="genManualBtn"><span class="material-symbols-outlined">bolt</span>&nbsp;Générer</button>
              <button type="button" class="copy" id="copyManualBtn"><span class="material-symbols-outlined">content_copy</span> Copier</button>
            </div>
            <div class="hint">Caractères autorisés : A-Z, 0-9, tiret — 4 à 64 caractères.</div>
          </div>

          <label style="margin-top:12px">Pourcentage de remise</label>
          <div class="inline">
            <input type="number" name="discount_percent" min="1" max="100" value="10" required style="max-width:120px">
            <span class="badge"><span class="material-symbols-outlined">local_offer</span><span id="discountBadge">10%</span></span>
          </div>

          <label style="margin-top:12px">Limite d’utilisations</label>
          <div class="seg">
            <label><input type="radio" name="limit_type" value="infinite" checked><span class="chip"><span class="material-symbols-outlined">all_inclusive</span>Infini</span></label>
            <label><input type="radio" name="limit_type" value="finite"><span class="chip"><span class="material-symbols-outlined">counter_1</span>Limité</span></label>
          </div>
          <div class="inline" style="margin-top:6px">
            <input type="number" name="usage_limit" min="1" max="200" value="1" style="max-width:120px">
            <span class="hint">Entre 1 et 200.</span>
          </div>

          <label style="margin-top:12px">Période d’activation</label>
          <div class="grid" style="grid-template-columns:1fr 1fr; gap:10px">
            <div>
              <span class="hint">Début</span>
              <input type="datetime-local" name="starts_at" value="<?= h((new DateTime())->format('Y-m-d\TH:i')) ?>">
            </div>
            <div>
              <span class="hint">Fin (optionnel)</span>
              <input type="datetime-local" name="ends_at" id="endsAt">
              <div class="inline" style="margin-top:6px">
                <button type="button" class="pill" data-plus="7">+7 jours</button>
                <button type="button" class="pill" data-plus="30">+30 jours</button>
                <button type="button" class="pill" id="clearEnd">Sans fin</button>
              </div>
            </div>
          </div>
        </div>

        <div class="card" style="padding:18px">
          <h2>Attribuer à des clients (optionnel)</h2>
          <p class="hint">Si vous sélectionnez des clients, <strong>eux seuls</strong> pourront utiliser ce code. Sans sélection, le code est utilisable par <strong>tous</strong>.</p>

          <label>Rechercher</label>
          <input type="text" id="userSearch" placeholder="Filtrer par nom ou email…">

          <label style="margin-top:8px">Sélection</label>
          <select name="assigned_users[]" id="usersSelect" multiple size="14" style="height: 340px;">
            <?php foreach ($users as $u): ?>
              <option value="<?= (int)$u['id'] ?>">
                <?= h(trim(($u['prenom'] ?? '').' '.($u['name'] ?? ''))) ?> — <?= h($u['email']) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="hint">Astuce : Ctrl/Cmd + clic pour multi-sélection.</div>
          <div class="inline" id="selectedChips" style="margin-top:8px;flex-wrap:wrap"></div>
        </div>
      </div>

      <div class="inline" style="margin-top:10px">
        <button class="btn" type="submit"><span class="material-symbols-outlined">add_circle</span>&nbsp;Créer le code</button>
        <button class="btn ghost" type="reset" id="resetForm"><span class="material-symbols-outlined">settings_backup_restore</span>&nbsp;Réinitialiser</button>
      </div>
    </form>
  </div>

  <details class="promo-details" id="codesPanel" open>
    <summary>
      <span class="material-symbols-outlined chev">chevron_right</span>
      Derniers codes créés
      <span class="hint" style="margin-left:6px">(<?= (int)$activeCount ?> actifs / <?= (int)$totalCount ?> total)</span>
    </summary>
    <div class="content">
      <div class="filter" style="margin:8px 0 12px">
        <input type="text" id="filterCodes" placeholder="Rechercher un code ou un email…" style="flex:1; min-width:220px">
        <button class="pill" id="showActive">Actifs</button>
        <button class="pill" id="showAll">Tous</button>
      </div>

      <?php if (empty($codes)): ?>
        <p class="hint">Aucun code pour le moment.</p>
      <?php else: ?>
        <table id="codesTable" aria-live="polite">
          <thead>
            <tr>
              <th>Code</th>
              <th>Remise</th>
              <th>Utilisations</th>
              <th>Validité</th>
              <th>Attribué à</th>
              <th>Statut</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($codes as $index => $c): ?>
                <?php try { // Filet de sécurité pour ne pas planter toute la page si une ligne est corrompue ?>
                    <?php
                    $active = isActiveRow($c);
                    $validity = 'Date invalide';
                    if (!empty($c['starts_at']) && $c['starts_at'] !== '0000-00-00 00:00:00') {
                        $dt_start = new DateTime($c['starts_at']);
                        $validity = "du ".$dt_start->format('d/m/Y H:i');
                        if (!empty($c['ends_at']) && $c['ends_at'] !== '0000-00-00 00:00:00') {
                           $dt_end = new DateTime($c['ends_at']);
                           $validity .= " au ".$dt_end->format('d/m/Y H:i');
                        } else {
                           $validity .= " (sans fin)";
                        }
                    }
                    $useText = is_null($c['usage_limit']) ? $c['usage_count']." / ∞" : $c['usage_count']." / ".$c['usage_limit'];
                    $pct = (!is_null($c['usage_limit']) && (int)$c['usage_limit']>0) ? min(100, round((int)$c['usage_count']*100/(int)$c['usage_limit'])) : 0;
                    ?>
                    <tr data-active="<?= $active ? '1' : '0' ?>">
                        <td data-label="Code">
                            <div class="inline-actions">
                                <strong><?= h($c['code']) ?></strong>
                                <button class="copy" data-copy="<?= h($c['code']) ?>"><span class="material-symbols-outlined">content_copy</span></button>
                            </div>
                        </td>
                        <td data-label="Remise"><?= (int)$c['discount_percent'] ?>%</td>
                        <td data-label="Utilisations">
                            <div class="inline" style="gap:8px">
                                <div class="progress"><span style="width: <?= (int)$pct ?>%"></span></div>
                                <span class="hint"><?= h($useText) ?></span>
                            </div>
                        </td>
                        <td data-label="Validité"><?= h($validity) ?></td>
                        <td data-label="Attribué à"><?= h($c['assigned_emails'] ?: '—') ?></td>
                        <td data-label="Statut">
                            <span class="status"><?= $active ? '<span class="dot ok"></span>Actif' : '<span class="dot no"></span>Inactif' ?></span>
                        </td>
                        <td data-label="Actions">
                            <div class="inline-actions">
                                <form method="post" action="">
                                    <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
                                    <input type="hidden" name="promo_id" value="<?= (int)$c['id'] ?>">
                                    <label class="switch" title="<?= $active ? 'Désactiver' : 'Activer' ?>">
                                        <input type="checkbox" onchange="this.form.querySelector('[name=toggle_active]').value = this.checked ? 1 : 0; this.form.submit();" <?= $active ? 'checked' : '' ?>>
                                        <span class="slider"></span>
                                    </label>
                                    <input type="hidden" name="toggle_active" value="<?= $active ? 0 : 1 ?>">
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php } catch (Throwable $e) { ?>
                    <tr><td colspan="7" style="color:red; background: #fff0f0;">Erreur : Impossible d'afficher la ligne <?= (int)$index ?> (ID: <?= h($c['id'] ?? 'inconnu') ?>). Problème de données.</td></tr>
                <?php } ?>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </details>
</div>

<script>
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
function copyText(t){ navigator.clipboard?.writeText(t).then(()=>toast('Code copié !')); }
function toast(msg, ok=true){
  let box=document.createElement('div'); box.className='toast ' + (ok?'success':'error') + ' show';
  box.innerHTML='<span class="material-symbols-outlined">'+(ok?'check_circle':'error')+'</span>'+msg;
  document.body.prepend(box); setTimeout(()=>box.remove(),2200);
}
// Mode code auto / manuel
const modeRadios=$$('input[name="code_mode"]'), autoWrap=$('#autoLenWrap'), manualWrap=$('#manualCodeWrap');
modeRadios.forEach(r=>r.addEventListener('change', ()=>{
  const manual=document.querySelector('input[name="code_mode"]:checked').value==='manual';
  manualWrap.style.display=manual?'':'none'; autoWrap.style.display=manual?'none':'';
}));
// Limite usage
const limitRadios=$$('input[name="limit_type"]'), limitInput=document.querySelector('input[name="usage_limit"]');
function updateLimit(){ const t=document.querySelector('input[name="limit_type"]:checked')?.value;
  if (t==='infinite'){ limitInput.disabled=true; limitInput.style.opacity=.5; } else { limitInput.disabled=false; limitInput.style.opacity=1; } }
limitRadios.forEach(r=>r.addEventListener('change',updateLimit)); updateLimit();
// Badge remise
const discountInput=document.querySelector('input[name="discount_percent"]'); const discountBadge=$('#discountBadge');
discountInput?.addEventListener('input', ()=> discountBadge.textContent=(discountInput.value||0)+'%');
// Fin rapide +7/+30
const endsAt=$('#endsAt'); $$('.pill[data-plus]').forEach(b=>b.addEventListener('click', ()=>{
  const days=parseInt(b.dataset.plus,10), now=new Date(); now.setDate(now.getDate()+days);
  const pad=n=>String(n).padStart(2,'0');
  endsAt.value=`${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`;
})); $('#clearEnd')?.addEventListener('click', ()=> endsAt.value='');
// Recherche utilisateurs & chips sélection
const searchInput=$('#userSearch'), usersSelect=$('#usersSelect'), chips=$('#selectedChips');
if (searchInput && usersSelect){
  searchInput.addEventListener('input', ()=>{
    const q=searchInput.value.toLowerCase();
    Array.from(usersSelect.options).forEach(opt=> opt.hidden=!opt.textContent.toLowerCase().includes(q));
  });
  usersSelect.addEventListener('change', ()=>{
    chips.innerHTML=''; Array.from(usersSelect.selectedOptions).forEach(opt=>{
      const span=document.createElement('span'); span.className='badge'; span.style.background='#F3F4F6'; span.style.color='#374151';
      span.textContent=opt.textContent; chips.appendChild(span);
    });
  });
}
// Génération locale (aperçu / manuel)
function localGenerate(len=10){
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out=''; const crypto=window.crypto||window.msCrypto;
  if (crypto && crypto.getRandomValues){ const arr=new Uint8Array(len); crypto.getRandomValues(arr);
    for (let i=0;i<len;i++) out+=alphabet[arr[i]%alphabet.length];
  } else { for (let i=0;i<len;i++) out+=alphabet[Math.floor(Math.random()*alphabet.length)]; }
  if (len>=10) out=out.slice(0,5)+'-'+out.slice(5); return out;
}
$('#previewAutoBtn')?.addEventListener('click', ()=>{
  const len=parseInt(document.querySelector('input[name="auto_length"]')?.value||'10',10);
  toast('Exemple : '+ localGenerate(Math.min(20,Math.max(6,len))));
});
$('#genManualBtn')?.addEventListener('click', ()=>{
  const f=$('#codeManual'); f.value=localGenerate(10); f.focus(); f.select();
});
$('#copyManualBtn')?.addEventListener('click', ()=>{ const v=$('#codeManual').value||''; if(v) copyText(v); });
// Table : copier & filtres
$$('[data-copy]').forEach(b=>b.addEventListener('click', ()=> copyText(b.dataset.copy)));
const filterInput=$('#filterCodes'), showActive=$('#showActive'), showAll=$('#showAll');
function applyFilter(){
  const q=(filterInput?.value||'').toLowerCase(); const onlyActive=showActive?.classList.contains('on')||false;
  $$('#codesTable tbody tr').forEach(tr=>{
    const text=tr.textContent.toLowerCase(); const active=tr.dataset.active==='1';
    tr.style.display=(text.includes(q) && (!onlyActive || active)) ? '' : 'none';
  });
}
filterInput?.addEventListener('input', applyFilter);
showActive?.addEventListener('click', ()=>{ showActive.classList.add('on'); showAll.classList.remove('on'); applyFilter(); });
showAll?.addEventListener('click', ()=>{ showAll.classList.add('on'); showActive.classList.remove('on'); applyFilter(); });
showAll?.classList.add('on');
// Mémoriser l'état de la section repliée (optionnel)
const panel=$('#codesPanel');
if (panel){
  const key='promo_codes_panel_open';
  panel.open = localStorage.getItem(key)==='1' ? true : false;
  panel.addEventListener('toggle', ()=> localStorage.setItem(key, panel.open ? '1' : '0'));
}
// Reset visuel
$('#resetForm')?.addEventListener('click', ()=> setTimeout(()=>{ discountBadge.textContent=(discountInput?.value||0)+'%'; updateLimit(); chips && (chips.innerHTML=''); }, 0));
</script>

</body>
</html>