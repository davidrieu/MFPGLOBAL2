<?php
// 1. Démarrage de la session et sécurité
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Connexion à la base de données
require_once '../db_connection.php';

// ===================================================================
// GESTION DE LA SOUMISSION DU FORMULAIRE (METHODE POST)
// ===================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sécurité CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Action non autorisée.');
    }

    // Récupération et nettoyage des données
    $prenom = trim($_POST['prenom']);
    $name = trim($_POST['name']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $telephone = trim($_POST['telephone']);
    $cagnotte = filter_var($_POST['cagnotte'], FILTER_VALIDATE_FLOAT) ?: 0.00;
    $parrain_id = !empty($_POST['parrain']) ? filter_var($_POST['parrain'], FILTER_VALIDATE_INT) : null;
    $statut = $_POST['statut'];
    
    // MODIFIÉ : Récupération d'un champ unique pour l'adresse et la date de naissance
    $date_naissance = !empty($_POST['date_naissance']) ? trim($_POST['date_naissance']) : null;
    $adresse = trim($_POST['adresse']);

    // Validation des données
    $errors = [];
    if (empty($prenom) || empty($name) || empty($email) || empty($password)) {
        $errors[] = "Le prénom, le nom, l'email et le mot de passe sont obligatoires.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'adresse email n'est pas valide.";
    }
    if (strlen($password) < 8) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
    }
    
    $stmt_check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt_check->execute([$email]);
    if ($stmt_check->fetch()) {
        $errors[] = "Cette adresse email est déjà utilisée par un autre compte.";
    }

    if (empty($errors)) {
        try {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $pdo->beginTransaction();

            // MODIFIÉ : Requête d'insertion avec la colonne 'adresse'
            $sql = "INSERT INTO users 
                        (prenom, name, email, password, telephone, cagnotte, parrain, statut, registration_date, date_naissance, adresse) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $prenom, $name, $email, $hashed_password, $telephone, $cagnotte, $parrain_id, $statut,
                $date_naissance, $adresse
            ]);

            // Si un parrain est défini, créer l'entrée dans la table de parrainage
            if ($parrain_id) {
                // ... (logique de parrainage inchangée) ...
            }
            
            $pdo->commit();
            $_SESSION['flash_message'] = "L'utilisateur a été ajouté avec succès.";
            header('Location: gestion_users.php');
            exit();

        } catch (PDOException $e) {
            $pdo->rollBack();
            $error_message = "Erreur lors de la création de l'utilisateur : " . $e->getMessage();
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}

// ===================================================================
// RÉCUPÉRATION DES DONNÉES POUR L'AFFICHAGE (METHODE GET)
// ===================================================================
try {
    $sponsors_stmt = $pdo->query("SELECT id, prenom, name FROM users ORDER BY prenom, name ASC");
    $potential_sponsors = $sponsors_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur de chargement des données : " . $e->getMessage());
}

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Utilisateur - La Serre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        /* CSS identique au précédent */
        :root {
            --primary-color: #4CAF50; --primary-color-dark: #388E3C;
            --secondary-color: #6c757d; --secondary-color-dark: #5a6268;
            --text-color: #333; --text-color-light: #757575;
            --background-color: #f5f5f5; --card-background-color: #fff;
            --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        body { background-color: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background-color: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; z-index: 1000; }
        .sidebar-header { margin-bottom: 30px; text-align: center; font-size: 1.5em; font-weight: 700; color: var(--primary-color);}
        .sidebar ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar ul li a { display: flex; align-items: center; padding: 12px 10px; margin-bottom: 8px; text-decoration: none; color: var(--text-color-light); border-radius: var(--border-radius); font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
        .sidebar ul li a .material-symbols-outlined { margin-right: 15px; font-size: 22px; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: var(--primary-color); color: white; }
        .container { margin-left: 300px; padding: 20px; width: calc(100% - 340px); }
        .page-header h1 { margin: 0 0 20px 0; font-size: 28px; font-weight: 700; }
        .card { background-color: var(--card-background-color); padding: 25px; box-shadow: var(--box-shadow); border-radius: var(--border-radius); }
        .form-section { margin-bottom: 30px; }
        .form-section h2 { font-size: 18px; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { margin-bottom: 8px; font-weight: 500; color: var(--text-color-light); font-size: 14px; }
        .form-group input, .form-group select, .form-group textarea { padding: 12px; border: 1px solid #ddd; border-radius: var(--border-radius); font-size: 16px; font-family: inherit; }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .form-actions { margin-top: 30px; display: flex; gap: 15px; }
        .btn { display: inline-flex; align-items: center; padding: 12px 20px; border: none; border-radius: var(--border-radius); cursor: pointer; font-size: 16px; font-weight: 500; text-decoration: none; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-color-dark); }
        .btn-secondary { background-color: var(--secondary-color); color: white; }
        .btn-secondary:hover { background-color: var(--secondary-color-dark); }
        .error-message { color: #d32f2f; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: var(--border-radius); margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php" class="active"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="page-header">
        <h1>Ajouter un nouvel utilisateur</h1>
    </div>

    <?php if (isset($error_message)): ?>
        <div class="error-message"><?= $error_message ?></div>
    <?php endif; ?>
    
    <div class="card">
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="form-section">
                <h2>Informations personnelles</h2>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="prenom">Prénom</label>
                        <input type="text" id="prenom" name="prenom" value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Nom</label>
                        <input type="text" id="name" name="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="date_naissance">Date de naissance</label>
                        <input type="date" id="date_naissance" name="date_naissance" value="<?= htmlspecialchars($_POST['date_naissance'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="telephone">Téléphone</label>
                        <input type="tel" id="telephone" name="telephone" value="<?= htmlspecialchars($_POST['telephone'] ?? '') ?>">
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h2>Adresse postale</h2>
                <div class="form-group">
                    <label for="adresse">Adresse complète</label>
                    <textarea id="adresse" name="adresse" placeholder="Ex: 123 Rue de la Fraise, 75001 Paris"><?= htmlspecialchars($_POST['adresse'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="form-section">
                <h2>Informations de compte</h2>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Mot de passe (8 caractères min.)</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h2>Informations de parrainage</h2>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="cagnotte">Cagnotte (€)</label>
                        <input type="number" step="0.01" id="cagnotte" name="cagnotte" value="<?= htmlspecialchars($_POST['cagnotte'] ?? '0.00') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="parrain">Parrain</label>
                        <select id="parrain" name="parrain">
                            <option value="">-- Aucun --</option>
                            <?php foreach ($potential_sponsors as $sponsor): ?>
                                <option value="<?= $sponsor['id'] ?>" <?= (isset($_POST['parrain']) && $_POST['parrain'] == $sponsor['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($sponsor['prenom'] . ' ' . $sponsor['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="statut">Statut</label>
                        <select id="statut" name="statut" required>
                            <option value="actif" selected>Actif</option>
                            <option value="inactif">Inactif</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Créer l'utilisateur</button>
                <a href="gestion_users.php" class="btn btn-secondary">Annuler</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>