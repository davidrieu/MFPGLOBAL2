<?php
// 1. Démarrage de la session et sécurité
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

// 2. Dépendances et Configuration
require_once '../db_connection.php';
$admin_id = $_SESSION['admin_id'];

// Définition des heures d'ouverture (CEST/Paris Time)
date_default_timezone_set('Europe/Paris');
$business_hours = [
    'start' => '09:00',
    'end'   => '18:00',
    'days'  => [1, 2, 3, 4, 5] // Lundi à Vendredi
];

function is_business_hours($config) {
    $now = new DateTime();
    $day_of_week = (int)$now->format('N'); // 1 (Lundi) à 7 (Dimanche)
    if (!in_array($day_of_week, $config['days'])) {
        return false;
    }
    $time = $now->format('H:i');
    return ($time >= $config['start'] && $time <= $config['end']);
}
$is_live = is_business_hours($business_hours);

// GESTION DE L'ACTION "LANCER UNE CONVERSATION"
if (isset($_GET['action']) && $_GET['action'] === 'start' && isset($_GET['user_id'])) {
    $user_id_to_start = filter_var($_GET['user_id'], FILTER_VALIDATE_INT);
    if ($user_id_to_start) {
        // Vérifier si une conversation existe déjà
        $stmt = $pdo->prepare("SELECT id FROM conversations WHERE user_id = ?");
        $stmt->execute([$user_id_to_start]);
        $existing_conv = $stmt->fetch();

        if ($existing_conv) {
            header('Location: messagerie.php?conversation_id=' . $existing_conv['id']);
        } else {
            // Sinon, créer une nouvelle conversation
            $stmt_user = $pdo->prepare("SELECT prenom, name FROM users WHERE id = ?");
            $stmt_user->execute([$user_id_to_start]);
            $user_info = $stmt_user->fetch();
            $subject = "Conversation avec " . htmlspecialchars($user_info['prenom'] . ' ' . $user_info['name']);

            $insert_stmt = $pdo->prepare("INSERT INTO conversations (user_id, subject, is_read_by_admin) VALUES (?, ?, TRUE)");
            $insert_stmt->execute([$user_id_to_start, $subject]);
            $new_conv_id = $pdo->lastInsertId();
            header('Location: messagerie.php?conversation_id=' . $new_conv_id);
        }
        exit();
    }
}


// GESTION DES ACTIONS (RÉPONDRE, CLORE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $conversation_id = filter_input(INPUT_POST, 'conversation_id', FILTER_VALIDATE_INT);

    if ($conversation_id) {
        if ($_POST['action'] === 'reply') {
            $reply_body = trim($_POST['reply_body'] ?? '');
            if (!empty($reply_body)) {
                $stmt = $pdo->prepare("INSERT INTO messages (conversation_id, sender_type, admin_id, body) VALUES (?, 'admin', ?, ?)");
                $stmt->execute([$conversation_id, $admin_id, $reply_body]);
                // Marquer la conversation comme non lue par l'utilisateur
                $pdo->prepare("UPDATE conversations SET is_read_by_admin = TRUE, is_read_by_user = FALSE WHERE id = ?")->execute([$conversation_id]);
            }
        } elseif ($_POST['action'] === 'toggle_status') {
            $stmt = $pdo->prepare("UPDATE conversations SET status = IF(status='ouverte', 'fermee', 'ouverte') WHERE id = ?");
            $stmt->execute([$conversation_id]);
        }
    }
    header('Location: messagerie.php?conversation_id=' . $conversation_id);
    exit();
}

// LOGIQUE D'AFFICHAGE
$conv_stmt = $pdo->query("
    SELECT c.id, c.subject, c.status, c.updated_at, c.is_read_by_admin, u.prenom, u.name 
    FROM conversations c 
    JOIN users u ON c.user_id = u.id 
    ORDER BY c.updated_at DESC
");
$conversations = $conv_stmt->fetchAll(PDO::FETCH_ASSOC);

$selected_conversation_id = filter_input(INPUT_GET, 'conversation_id', FILTER_VALIDATE_INT);
$messages = [];
$selected_conversation = null;

if ($selected_conversation_id) {
    $stmt = $pdo->prepare("SELECT c.*, u.prenom, u.name FROM conversations c JOIN users u ON c.user_id = u.id WHERE c.id = ?");
    $stmt->execute([$selected_conversation_id]);
    $selected_conversation = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($selected_conversation) {
        $msg_stmt = $pdo->prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC");
        $msg_stmt->execute([$selected_conversation_id]);
        $messages = $msg_stmt->fetchAll(PDO::FETCH_ASSOC);
        $pdo->prepare("UPDATE conversations SET is_read_by_admin = TRUE WHERE id = ?")->execute([$selected_conversation_id]);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messagerie - La Serre Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
    <style>
        /* CORRECTION AJOUTÉE ICI */
        *, *::before, *::after {
            box-sizing: border-box;
        }

        :root {
            --primary-color: #4CAF50; --text-color: #333; --background-color: #f5f5f5;
            --card-background-color: #fff; --border-radius: 8px; --box-shadow: 0 1px 3px rgba(0,0,0,0.12);
            --admin-msg-bg: #e8f5e9; --client-msg-bg: #f1f1f1;
            --text-color-light: #757575;
        }
        body { background: var(--background-color); font-family: 'Roboto', Arial, sans-serif; margin: 0; display: flex; color: var(--text-color); }
        .sidebar { background: var(--card-background-color); width: 260px; height: 100vh; padding: 20px; position: fixed; display: flex; flex-direction: column; z-index: 1000; border-right: 1px solid #eee;}
        .sidebar-header{margin-bottom:30px;text-align:center;font-size:1.5em;font-weight:700;color:var(--primary-color)}
        .sidebar ul{list-style:none;padding:0;margin:0}
        .sidebar ul li a{display:flex;align-items:center;padding:12px 10px;margin-bottom:8px;text-decoration:none;color:var(--text-color-light);border-radius:var(--border-radius);font-weight:500;transition:.2s}
        .sidebar ul li a .material-symbols-outlined{margin-right:15px;font-size:22px}
        .sidebar ul li a:hover,.sidebar ul li a.active{background:var(--primary-color);color:#fff}
        
        .container { margin-left: 260px; width: calc(100% - 260px); height: 100vh; display: flex; flex-direction: column; }
        .messaging-layout { display: grid; grid-template-columns: 320px 1fr; height: 100%; overflow: hidden; }
        
        .conversations-list { background: #fff; border-right: 1px solid #e0e0e0; display: flex; flex-direction: column; }
        .conv-header { padding: 20px; border-bottom: 1px solid #e0e0e0; }
        .conv-header h2 { margin: 0; font-size: 20px; }
        .live-status { display: flex; align-items: center; gap: 8px; margin-top: 10px; font-size: 14px; }
        .live-status .dot { width: 10px; height: 10px; border-radius: 50%; background-color: <?= $is_live ? '#4CAF50' : '#f44336' ?>; }
        .conv-scroll { overflow-y: auto; flex-grow: 1; }
        .conv-item { display: block; padding: 15px 20px; border-bottom: 1px solid #f0f0f0; text-decoration: none; color: var(--text-color); }
        .conv-item:hover { background: #f9f9f9; }
        .conv-item.active { background: var(--admin-msg-bg); }
        .conv-item.unread .conv-name { font-weight: bold; color: var(--primary-color); }
        .conv-name { display: flex; justify-content: space-between; align-items: center; font-size: 15px; margin-bottom: 4px; }
        .conv-name .status { font-size: 11px; text-transform: uppercase; color: #999; }
        .conv-subject { font-size: 14px; color: #757575; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

        .chat-view { display: flex; flex-direction: column; height: 100%; }
        .chat-header { background: #fff; padding: 15px 20px; border-bottom: 1px solid #e0e0e0; display: flex; justify-content: space-between; align-items: center; }
        .chat-header h3 { margin: 0; font-size: 18px; }
        .chat-messages { flex-grow: 1; overflow-y: auto; padding: 20px; }
        .message { margin-bottom: 15px; max-width: 75%; display: flex; flex-direction: column; }
        .message .body { padding: 10px 15px; border-radius: 18px; line-height: 1.5; word-break: break-word; }
        .message .meta { font-size: 11px; color: #999; margin-top: 4px; }
        .message-client { align-items: flex-start; }
        .message-client .body { background: var(--client-msg-bg); border-top-left-radius: 0; }
        .message-admin { align-items: flex-end; margin-left: auto; }
        .message-admin .body { background: var(--admin-msg-bg); border-top-right-radius: 0; }
        .chat-reply-form { background: #fff; padding: 20px; border-top: 1px solid #e0e0e0; }
        .chat-reply-form textarea { width: 100%; border: 1px solid #ccc; border-radius: 8px; padding: 10px; font-family: inherit; font-size: 15px; resize: vertical; }
        .btn { display: inline-flex; align-items: center; gap: 8px; background: var(--primary-color); color: #fff; padding: 10px 14px; border: none; border-radius:var(--border-radius); cursor: pointer; font-weight: 500; text-decoration: none; }
        .btn.secondary { background-color: #6c757d; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">La Serre</div>
    <ul>
        <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
        <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
        <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
        <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
        <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
        <li><a href="#"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
        <li><a href="messagerie.php" class="active"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
        <li><a href="#"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
        <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
    </ul>
</div>

<div class="container">
    <div class="messaging-layout">
        <div class="conversations-list" id="conversations-list-container">
            <div class="conv-header">
                <h2>Messagerie</h2>
                <div class="live-status">
                    <span class="dot"></span>
                    <span>Support <?= $is_live ? 'en direct' : 'hors ligne' ?></span>
                </div>
            </div>
            <div class="conv-scroll">
                <?php foreach ($conversations as $conv): ?>
                    <a href="?conversation_id=<?= $conv['id'] ?>" class="conv-item <?= ($selected_conversation_id == $conv['id']) ? 'active' : '' ?> <?= !$conv['is_read_by_admin'] ? 'unread' : '' ?>">
                        <div class="conv-name">
                            <span><?= htmlspecialchars($conv['prenom'] . ' ' . $conv['name']) ?></span>
                            <span class="status"><?= $conv['status'] ?></span>
                        </div>
                        <div class="conv-subject"><?= htmlspecialchars($conv['subject']) ?></div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="chat-view">
            <?php if ($selected_conversation): ?>
                <div class="chat-header">
                    <h3><?= htmlspecialchars($selected_conversation['subject']) ?></h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="toggle_status">
                        <input type="hidden" name="conversation_id" value="<?= $selected_conversation_id ?>">
                        <button type="submit" class="btn secondary" style="padding: 6px 10px; font-size: 12px;">
                            <?= $selected_conversation['status'] === 'ouverte' ? 'Clore la conversation' : 'Rouvrir la conversation' ?>
                        </button>
                    </form>
                </div>
                <div class="chat-messages" id="message-container">
                    <?php foreach ($messages as $message): ?>
                        <div class="message <?= 'message-' . $message['sender_type'] ?>">
                            <div class="body"><?= nl2br(htmlspecialchars($message['body'])) ?></div>
                            <div class="meta"><?= (new DateTime($message['created_at']))->format('d/m/Y H:i') ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="chat-reply-form">
                    <form method="POST">
                        <input type="hidden" name="action" value="reply">
                        <input type="hidden" name="conversation_id" value="<?= $selected_conversation_id ?>">
                        <textarea name="reply_body" rows="3" placeholder="Tapez votre réponse ici..." required></textarea>
                        <button type="submit" class="btn" style="margin-top: 10px;">Envoyer</button>
                    </form>
                </div>
            <?php else: ?>
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; flex-direction: column; color: #999; text-align: center;">
                    <span class="material-symbols-outlined" style="font-size: 60px;">chat</span>
                    <p style="margin-top: 10px;">Sélectionnez une conversation pour l'afficher ou <a href="gestion_users.php">lancez-en une nouvelle</a> depuis la liste des utilisateurs.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const messageContainer = document.getElementById('message-container');
    if (messageContainer) {
        messageContainer.scrollTop = messageContainer.scrollHeight;
    }

    // Rafraîchissement automatique de la liste des conversations
    setInterval(function() {
        const convListContainer = document.getElementById('conversations-list-container');
        // On ne rafraîchit que si l'admin n'est pas en train de taper un message
        if (document.activeElement.tagName.toLowerCase() !== 'textarea') {
            // On conserve les paramètres de l'URL actuelle (pour garder la conversation active)
            fetch(window.location.href) 
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newConvList = doc.getElementById('conversations-list-container');
                    if (newConvList) {
                        convListContainer.innerHTML = newConvList.innerHTML;
                    }
                })
                .catch(err => console.error('Failed to refresh conversations:', err));
        }
    }, 15000); // Rafraîchit toutes les 15 secondes
});
</script>

</body>
</html>