<?php
// Mettez le mot de passe que vous voulez utiliser ici
$passwordToHash = 'Lavieestbelle24/*'; 

// Hachage du mot de passe
$hashedPassword = password_hash($passwordToHash, PASSWORD_DEFAULT);

// Affichage du résultat
echo "Copiez cette chaîne de caractères dans votre base de données : <br><br>";
echo "<strong>" . $hashedPassword . "</strong>";
?>