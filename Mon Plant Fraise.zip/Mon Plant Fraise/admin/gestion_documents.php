<?php
// admin/gestion_documents.php — Console Admin Documents & Contrats
// — Responsive et accessible
// — “Contrats à générer” : tri par date/montant/#, recherche, “Tous de ce client”
// — Flux : Générer -> Prévisualiser -> Signer (admin) manuellement, retour à la liste avec état restauré
// — Signatures admin :
//     * Upload PNG/JPG -> converti en PNG fond blanc -> documents/signatures/admin-1.png (remplace l’ancienne)
//     * Génération de tampons aléatoires par thème (y compris “noir”) avec “Mon Plant Fraise” + SIRET + site
//       -> Galerie de variantes -> “Valider” (fond blanc) -> admin-1.png (écrase l’ancienne)
// — Anti multi-sauvegarde : verrou fichier (flock) + désactivation bouton côté client

session_start();

// Auth admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/login.php');
    exit();
}

require_once __DIR__ . '/../db_connection.php';

/* ===== Include générateur de contrats (Dompdf v2 via vendor_mpf) ===== */
$tryPaths = [
    __DIR__ . '/../lib/contracts_pdf_draft.php', // recommandé
    __DIR__ . '/lib/contracts_pdf_draft.php',    // fallback
];
$GENERATE_CONTRACTS_AVAILABLE = false;
foreach ($tryPaths as $p) {
    if (file_exists($p)) { require_once $p; $GENERATE_CONTRACTS_AVAILABLE = true; break; }
}

/* ========================= Helpers ========================= */
function gd_h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function gd_money($x){ return ($x === null || $x === '') ? '—' : number_format((float)$x, 2, ',', ' ') . ' €'; }
function gd_normalize_cat($raw){
    $k = mb_strtolower(trim((string)$raw), 'UTF-8');
    if (in_array($k, ['contrat','contrats','contract','contracts'], true)) return 'Contrats';
    if (in_array($k, ["pièce d'identité","pièces d'identité","piece d'identite","pieces d'identite","id","identité","identite"], true)) return "Pièce d'identité";
    return 'Autre';
}
function gd_documents_has_contract_id(PDO $pdo): bool {
    try { $pdo->query("SELECT contract_id FROM documents WHERE 1=0"); return true; }
    catch (Throwable $e) { return false; }
}
function gd_doc_matches_contract(array $doc, int $contract_id): bool {
    $hay = mb_strtolower(trim(($doc['filename'] ?? '') . ' ' . ($doc['file_path'] ?? '')), 'UTF-8');
    if ($hay === '') return false;
    $id = (int)$contract_id;
    $needles = [
        'contrat-' . $id, 'contrats-' . $id, 'contract-' . $id,
        'contrat_' . $id, 'contrats_' . $id, 'contract_' . $id,
        '/'.$id.'.', '_'.$id.'.', '-'.$id.'.', ' '.$id.' ', '_'.$id.'_', '-'.$id.'-', '/'.$id.'/'
    ];
    foreach ($needles as $n) if (strpos($hay, $n) !== false) return true;
    return false;
}
function gd_column_exists(PDO $pdo, string $table, string $col): bool {
    try { $pdo->query("SELECT {$col} FROM {$table} WHERE 1=0"); return true; }
    catch (Throwable $e) { return false; }
}

/* ========================= Contexte ========================= */
define('GD_UPLOAD_DIR', realpath(__DIR__ . '/../') . '/documents/contrats/');
define('GD_SIG_DIR',    realpath(__DIR__ . '/../') . '/documents/signatures/');
define('GD_SIG_TMP_DIR', GD_SIG_DIR . '/tmp/'); // stockage des variantes générées (galerie)
define('GD_ADMIN_SIG_FILENAME', 'admin-1.png'); // nom final demandé
define('GD_SIG_LOCKFILE', GD_SIG_DIR . '/admin-1.lock'); // verrou anti multi-save
if (!is_dir(GD_UPLOAD_DIR)) { @mkdir(GD_UPLOAD_DIR, 0775, true); }
if (!is_dir(GD_SIG_DIR))    { @mkdir(GD_SIG_DIR,    0775, true); }
if (!is_dir(GD_SIG_TMP_DIR)){ @mkdir(GD_SIG_TMP_DIR,0775, true); }

// --- Identité entreprise (à personnaliser) ---
define('GD_COMPANY_SIRET', '123 456 789 00012'); // ← mets ton vrai SIRET ici
define('GD_COMPANY_SITE',  'www.monplantfraise.com');

// CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$HAS_CONTRACT_ID      = gd_documents_has_contract_id($pdo);
$HAS_ADMIN_SIGNED_AT  = gd_column_exists($pdo, 'documents', 'admin_signed_at');
$HAS_ADMIN_SIGN_ADMIN = gd_column_exists($pdo, 'documents', 'admin_sign_admin_id');
$HAS_CLIENT_SIGNED_AT = gd_column_exists($pdo, 'documents', 'client_signed_at');

/* ========================= Utils : Signature (tampon) ========================= */

/** Police TTF optionnelle */
function gd_find_ttf_font(): ?string {
    $candidates = [
        __DIR__ . '/../assets/fonts/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
        '/Library/Fonts/Arial.ttf',
        'C:\\Windows\\Fonts\\arial.ttf',
    ];
    foreach ($candidates as $f) if (is_file($f)) return $f;
    return null;
}

/** Aplatit une image (avec alpha) sur un fond blanc et retourne une resource GD */
function flatten_to_white($src) {
    $w = imagesx($src); $h = imagesy($src);
    $dst = imagecreatetruecolor($w, $h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefilledrectangle($dst, 0, 0, $w, $h, $white);
    imagealphablending($dst, true);
    imagesavealpha($src, true);
    imagecopy($dst, $src, 0, 0, 0, 0, $w, $h);
    return $dst;
}

/** Sauvegarde en PNG après aplat sur blanc */
function save_png_white_bg($im, string $path): bool {
    $flat = flatten_to_white($im);
    $ok = imagepng($flat, $path);
    imagedestroy($flat);
    return (bool)$ok;
}

/** Verrou exclusif pour empêcher les doubles enregistrements */
function sig_lock_begin() {
    $fh = @fopen(GD_SIG_LOCKFILE, 'c+');
    if (!$fh) return null;
    if (!flock($fh, LOCK_EX | LOCK_NB)) { fclose($fh); return null; }
    ftruncate($fh, 0); fwrite($fh, (string)time());
    return $fh;
}
function sig_lock_end($fh) {
    if ($fh) { fflush($fh); flock($fh, LOCK_UN); fclose($fh); }
}

/** Génère le “tampon” (fond + cercles + confettis + texte) */
function make_stamp_base(string $theme = 'aucun') {
    $w = 900; $h = 300;
    $img = imagecreatetruecolor($w, $h);
    imagesavealpha($img, true);
    $trans = imagecolorallocatealpha($img, 0, 0, 0, 127);
    imagefill($img, 0, 0, $trans);

    $themeKey = strtolower(trim($theme));
    switch ($themeKey) {
        case 'noel':
            $bg = [250, 255, 250]; $stroke = [180, 20, 20]; $accent = [20, 120, 30];
            $confetti = [[220,0,0],[0,130,30],[240,240,240]];
            break;
        case 'vacances toussaint':
        case 'vacances':
        case 'toussaint':
            $bg = [255, 252, 245]; $stroke = [180, 90, 0]; $accent = [230, 120, 20];
            $confetti = [[255,165,0],[205,133,63],[255,215,0]];
            break;
        case 'paques':
            $bg = [252, 255, 252]; $stroke = [160, 120, 220]; $accent = [120, 180, 220];
            $confetti = [[255,182,193],[176,224,230],[152,251,152],[221,160,221]];
            break;
        case 'noir':
            $bg = [255,255,255]; $stroke = [20,20,20]; $accent = [15,15,15];
            $confetti = [[0,0,0],[70,70,70],[140,140,140]];
            break;
        default:
            $bg = [252, 255, 252]; $stroke = [46, 125, 50]; $accent = [27, 94, 32];
            $confetti = [[76,175,80],[139,195,74],[200,230,201]];
    }
    $colStroke = imagecolorallocate($img, $stroke[0], $stroke[1], $stroke[2]);
    $colAccent = imagecolorallocate($img, $accent[0], $accent[1], $accent[2]);
    $colBgLite = imagecolorallocatealpha($img, $bg[0], $bg[1], $bg[2], 100);
    $colTextDark = imagecolorallocate($img, 40, 40, 40);

    for ($i=0; $i<120; $i++) {
        $r = random_int(6, 18);
        $x = random_int(0, $w); $y = random_int(0, $h);
        imagefilledellipse($img, $x, $y, $r, $r, $colBgLite);
    }

    $cx = (int)($w/2); $cy = (int)($h/2);
    $R  = min($w, $h) * 0.9 / 2;
    imagesetthickness($img, 10);
    imagearc($img, $cx, $cy, (int)($R*2), (int)($R*2), 0, 360, $colStroke);
    imagesetthickness($img, 4);
    imagearc($img, $cx, $cy, (int)($R*1.7), (int)($R*1.7), 0, 360, $colStroke);

    for ($i=0; $i<50; $i++) {
        $c = $confetti[array_rand($confetti)];
        $cc = imagecolorallocatealpha($img, $c[0], $c[1], $c[2], random_int(40,85));
        $x = random_int($cx-$R+20, $cx+$R-20);
        $y = random_int($cy-$R+20, $cy+$R-20);
        if (hypot($x-$cx, $y-$cy) < $R*0.5) { $i--; continue; }
        if ($themeKey === 'noel') {
            imageline($img,$x-6,$y,$x+6,$y,$cc);
            imageline($img,$x,$y-6,$x,$y+6,$cc);
            imageline($img,$x-5,$y-5,$x+5,$y+5,$cc);
            imageline($img,$x-5,$y+5,$x+5,$y-5,$cc);
        } elseif ($themeKey === 'paques') {
            imageellipse($img, $x, $y, 10, 14, $cc);
        } elseif (in_array($themeKey, ['vacances toussaint','vacances','toussaint'], true)) {
            imagefilledellipse($img,$x,$y,10,6,$cc);
            imagefilledellipse($img,$x+2,$y-2,8,4,$cc);
        } else {
            imagefilledellipse($img,$x,$y,4,4,$cc);
        }
    }

    $title = "Mon Plant Fraise";
    $siret = "SIRET : " . (defined('GD_COMPANY_SIRET') ? GD_COMPANY_SIRET : '—');
    $site  = defined('GD_COMPANY_SITE') ? GD_COMPANY_SITE : 'www.monplantfraise.com';

    $font  = gd_find_ttf_font();
    $angle = 0;

    if ($font) {
        $sizeTitle = 56;
        for ($try=0; $try<10; $try++) {
            $bbox = imagettfbbox($sizeTitle, $angle, $font, $title);
            $tw = abs($bbox[2] - $bbox[0]);
            if ($tw <= $R*1.6) break;
            $sizeTitle -= 2;
        }
        $bbox = imagettfbbox($sizeTitle, $angle, $font, $title);
        $tw = abs($bbox[2] - $bbox[0]); $th = abs($bbox[7] - $bbox[1]);
        $shadow = imagecolorallocatealpha($img, 0,0,0,100);
        imagettftext($img, $sizeTitle, $angle, $cx - (int)($tw/2)+2, $cy - 10 + (int)($th/2)+2, $shadow,  $font, $title);
        imagettftext($img, $sizeTitle, $angle, $cx - (int)($tw/2),    $cy - 10 + (int)($th/2),    $colAccent, $font, $title);

        $sizeSiret = 24;
        $bbox = imagettfbbox($sizeSiret, 0, $font, $siret);
        $twS = abs($bbox[2] - $bbox[0]); $thS = abs($bbox[7] - $bbox[1]);
        imagettftext($img, $sizeSiret, 0, $cx - (int)($twS/2), $cy + (int)($th/2) + 24, $colTextDark, $font, $siret);

        $sizeSite = 24;
        $bbox = imagettfbbox($sizeSite, 0, $font, $site);
        $twW = abs($bbox[2] - $bbox[0]); $thW = abs($bbox[7] - $bbox[1]);
        $colSite = imagecolorallocate($img, max(0,$accent[0]-30), max(0,$accent[1]-30), max(0,$accent[2]-30));
        imagettftext($img, $sizeSite, 0, $cx - (int)($twW/2), $cy + (int)($th/2) + 24 + $thS + 8, $colSite, $font, $site);
    } else {
        $fw = imagefontwidth(5); $fh = imagefontheight(5);
        $tw = $fw * strlen($title);
        imagestring($img, 5, $cx - (int)($tw/2), $cy-10 - (int)($fh/2), $title, $colAccent);

        $fw2 = imagefontwidth(3); $fh2 = imagefontheight(3);
        $twS = $fw2 * strlen($siret);
        imagestring($img, 3, $cx - (int)($twS/2), $cy + 10, $siret, $colTextDark);

        $twW = $fw2 * strlen($site);
        $colSite = imagecolorallocate($img, max(0,$accent[0]-30), max(0,$accent[1]-30), max(0,$accent[2]-30));
        imagestring($img, 3, $cx - (int)($twW/2), $cy + 10 + $fh2 + 6, $site, $colSite);
    }

    imagesetthickness($img, 2);
    foreach ([-1,1] as $sign) {
        $sx = $cx + $sign*(int)($R*0.78); $sy = $cy;
        imageline($img,$sx-8,$sy,$sx+8,$sy,$colStroke);
        imageline($img,$sx,$sy-8,$sx,$sy+8,$colStroke);
    }

    return $img;
}

/** Génère N variantes PNG dans GD_SIG_TMP_DIR */
function generate_stamp_variants(string $theme, int $count = 6): array {
    if ($count < 1) $count = 1;
    if ($count > 12) $count = 12;

    foreach (glob(GD_SIG_TMP_DIR.'*.png') as $old) @unlink($old);

    $out = [];
    for ($i=0; $i<$count; $i++){
        $im = make_stamp_base($theme);
        $name = 'preview_' . preg_replace('/[^a-z0-9]+/i','_', $theme) . '_' . bin2hex(random_bytes(4)) . '.png';
        $path = GD_SIG_TMP_DIR . $name;
        save_png_white_bg($im, $path);
        imagedestroy($im);
        $out[] = '/documents/signatures/tmp/' . $name;
    }
    return $out;
}

/** Copie une preview choisie vers admin-1.png (fond blanc) */
function promote_preview_to_final(string $webRelative): void {
    $lock = sig_lock_begin();
    if ($lock === null) { throw new RuntimeException('Une sauvegarde de signature est déjà en cours.'); }
    try {
        $base = realpath(__DIR__ . '/..');
        if (!$base) throw new RuntimeException('Base path introuvable.');
        $absSrc = $base . $webRelative;
        if (!is_file($absSrc)) throw new RuntimeException('Fichier preview introuvable.');
        foreach (glob(GD_SIG_DIR . 'admin-1.*') as $old) @unlink($old);
        $dst = GD_SIG_DIR . GD_ADMIN_SIG_FILENAME;

        $srcIm = imagecreatefrompng($absSrc);
        if (!$srcIm) throw new RuntimeException('Lecture de la preview échouée.');
        if (!save_png_white_bg($srcIm, $dst)) {
            imagedestroy($srcIm);
            throw new RuntimeException("Impossible d'écrire la signature finale.");
        }
        imagedestroy($srcIm);
    } finally {
        sig_lock_end($lock);
    }
}

/* ========================= ROUTES / ACTIONS ========================= */

// 0) STREAM inline d’un PDF
if (isset($_GET['action'], $_GET['doc_id']) && $_GET['action'] === 'stream') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) {
        http_response_code(403); die('Jeton CSRF invalide.');
    }
    $doc_id = (int)($_GET['doc_id'] ?? 0);
    try {
        $stmt = $pdo->prepare("SELECT filename, file_path FROM documents WHERE id = ?");
        $stmt->execute([$doc_id]);
        $doc = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$doc || empty($doc['file_path'])) { http_response_code(404); die('Document introuvable.'); }
        $absBase = realpath(__DIR__ . '/..');
        if ($absBase === false) { http_response_code(500); die('Chemin invalide.'); }
        $abs = $absBase . $doc['file_path'];
        if (!file_exists($abs)) { http_response_code(404); die('Fichier non trouvé.'); }

        header('Content-Type: application/pdf');
        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $doc['filename'] ?: ('document_'.$doc_id.'.pdf'));
        header('Content-Disposition: inline; filename="'.$safeName.'"');
        header('Content-Length: ' . filesize($abs));
        while (ob_get_level()) { ob_end_clean(); }
        readfile($abs);
        exit;
    } catch (Throwable $e) {
        http_response_code(500); die('Erreur interne.');
    }
}

// 1) Autocomplete clients
if (isset($_GET['action']) && $_GET['action'] === 'search_users') {
    header('Content-Type: application/json; charset=utf-8');
    $term = trim($_GET['term'] ?? '');
    $out = [];
    if (mb_strlen($term) >= 2) {
        try {
            $stmt = $pdo->prepare("
              SELECT id, prenom, name, email
              FROM users
              WHERE CONCAT(prenom, ' ', name, ' ', email) LIKE ?
              ORDER BY prenom ASC, name ASC
              LIMIT 10
            ");
            $stmt->execute(['%'.$term.'%']);
            $out = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { /* silence */ }
    }
    echo json_encode($out);
    exit;
}

// 2) Upload manuel d’un document (PDF)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_doc') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        if (!isset($_POST['csrf_token']) || !hash_equals($csrf_token, $_POST['csrf_token'])) {
            throw new Exception('Jeton CSRF invalide.', 403);
        }

        $user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        if (!$user_id) throw new Exception("Veuillez sélectionner un client valide.", 400);

        $contract_id = null;
        if ($HAS_CONTRACT_ID) {
            $contract_id = filter_input(INPUT_POST, 'contract_id', FILTER_VALIDATE_INT);
            if ($contract_id) {
                $chk = $pdo->prepare("SELECT COUNT(*) FROM contrats WHERE id = ? AND user_id = ?");
                $chk->execute([$contract_id, $user_id]);
                if ((int)$chk->fetchColumn() === 0) throw new Exception("Le contrat indiqué n'appartient pas à ce client.", 400);
            } else {
                $contract_id = null;
            }
        }

        $category = gd_normalize_cat($_POST['category'] ?? 'Contrat');
        if (!in_array($category, ['Contrats', "Pièce d'identité", 'Autre'], true)) $category = 'Autre';

        if (empty($_FILES['document']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Veuillez sélectionner un fichier PDF valide.", 400);
        }
        $file = $_FILES['document'];

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($file['tmp_name']);
        if ($mime !== 'application/pdf') throw new Exception("Seuls les fichiers PDF sont autorisés.", 400);

        if (!is_writable(GD_UPLOAD_DIR)) throw new Exception("Dossier d'upload non inscriptible : " . GD_UPLOAD_DIR, 500);

        $stored_filename = uniqid('contrat_', true) . '.pdf';
        $target_disk_path = rtrim(GD_UPLOAD_DIR, '/').'/'.$stored_filename;
        if (!move_uploaded_file($file['tmp_name'], $target_disk_path)) {
            throw new Exception("Erreur interne lors de l'enregistrement du fichier.", 500);
        }

        $db_path = '/documents/contrats/' . $stored_filename;

        if ($HAS_CONTRACT_ID && $contract_id) {
            $stmt = $pdo->prepare("
                INSERT INTO documents (user_id, contract_id, filename, file_path, category, upload_date, is_visible, status)
                VALUES (?, ?, ?, ?, ?, NOW(), 1, 'approved')
            ");
            $stmt->execute([$user_id, $contract_id, basename($file['name']), $db_path, $category]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO documents (user_id, filename, file_path, category, upload_date, is_visible, status)
                VALUES (?, ?, ?, ?, NOW(), 1, 'approved')
            ");
            $stmt->execute([$user_id, basename($file['name']), $db_path, $category]);
        }

        echo json_encode(['success' => true, 'message' => 'Document uploadé avec succès.']);
    } catch (Throwable $e) {
        http_response_code((int)($e->getCode() ?: 400));
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

/* ───────── AJOUT : Génération avec gestion profil incomplet (double choix) ───────── */

// 2.ter) GÉNÉRER (ADMIN) : si profil incomplet → modal choix (forcer / relance)
if (isset($_GET['action']) && $_GET['action'] === 'generate_preview_admin') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    if (empty($GENERATE_CONTRACTS_AVAILABLE)) {
        $_SESSION['flash_message'] = "Module de génération indisponible.";
        header('Location: gestion_documents.php'); exit;
    }
    $contract_id = (int)($_GET['contract_id'] ?? 0);
    try {
        if ($contract_id <= 0) throw new InvalidArgumentException('Contrat invalide.');

        // tente de générer normalement (contrôle profil via lib/)
        $res = generate_contract_draft($pdo, $contract_id);

        // Cas 1 : profil incomplet → ouvrir un modal avec double choix
        if (!empty($res['status']) && $res['status'] === 'needs_profile') {
            $_SESSION['profile_missing_contract_id'] = $contract_id;
            $_SESSION['profile_missing_fields']      = $res['missing'] ?? [];
            $_SESSION['flash_message'] = "Profil incomplet : veuillez choisir une action.";
            header('Location: gestion_documents.php'); exit;
        }

        // Cas 2 : brouillon créé → on prévisualise et propose signature admin
        if (!empty($res['status']) && $res['status'] === 'draft_created' && !empty($res['doc_id'])) {
            $doc_id = (int)$res['doc_id'];
            // On garde le PDF en DRAFT non visible pour prévisualisation + signature manuelle
            $_SESSION['open_admin_preview_doc_id'] = $doc_id;
            $_SESSION['flash_message'] = "Contrat généré. Vérifiez le PDF puis signez en tant qu'administrateur.";
            header('Location: gestion_documents.php'); exit;
        }

        // Fallback : s’il existe déjà un contrat lié
        $exists = $pdo->prepare("
            SELECT id FROM documents
            WHERE contract_id = ? AND LOWER(category) IN ('contrat','contrats','contract','contracts')
            ORDER BY id DESC
            LIMIT 1
        ");
        $exists->execute([$contract_id]);
        $existing = $exists->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $_SESSION['open_admin_preview_doc_id'] = (int)$existing['id'];
            $_SESSION['flash_message'] = "Contrat existant chargé.";
            header('Location: gestion_documents.php'); exit;
        }

        throw new RuntimeException("Génération : état inattendu.");
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur génération : " . $e->getMessage();
        header('Location: gestion_documents.php'); exit;
    }
}

// 2.ter.bis) Forcer la génération malgré profil incomplet
if (isset($_GET['action']) && $_GET['action'] === 'force_generate') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    $contract_id = (int)($_GET['contract_id'] ?? 0);
    try {
        if ($contract_id <= 0) throw new InvalidArgumentException('Contrat invalide.');
        $res = generate_contract_draft($pdo, $contract_id, ['force' => true]);
        if (!empty($res['status']) && $res['status'] === 'draft_created' && !empty($res['doc_id'])) {
            $_SESSION['open_admin_preview_doc_id'] = (int)$res['doc_id'];
            $_SESSION['flash_message'] = "Contrat généré malgré profil incomplet. Vérifiez puis signez en tant qu'admin.";
        } else {
            $_SESSION['flash_message'] = "Génération forcée : état inattendu.";
        }
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur génération forcée : " . $e->getMessage();
    }
    // Nettoyage état modal
    unset($_SESSION['profile_missing_contract_id'], $_SESSION['profile_missing_fields']);
    header('Location: gestion_documents.php'); exit;
}

// 2.ter.ter) Envoyer une relance email au client (profil incomplet)
if (isset($_GET['action']) && $_GET['action'] === 'send_profile_reminder') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    $contract_id = (int)($_GET['contract_id'] ?? 0);
    try {
        if ($contract_id <= 0) throw new InvalidArgumentException('Contrat invalide.');
        $res = generate_contract_draft($pdo, $contract_id, ['send_reminder' => true]);
        if (!empty($res['status']) && $res['status'] === 'reminder_sent') {
            $_SESSION['flash_message'] = "Relance envoyée au client pour compléter son profil.";
        } else {
            $_SESSION['flash_message'] = "Relance non envoyée (erreur ou mail indisponible).";
        }
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur lors de l'envoi de relance : " . $e->getMessage();
    }
    // Nettoyage état modal
    unset($_SESSION['profile_missing_contract_id'], $_SESSION['profile_missing_fields']);
    header('Location: gestion_documents.php'); exit;
}

// 2.quater) SIGNATURE MANUELLE (ADMIN) depuis l’aperçu
if (isset($_GET['action']) && $_GET['action'] === 'admin_sign' && isset($_GET['doc_id'])) {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    $doc_id = (int)$_GET['doc_id'];
    try {
        $row = $pdo->prepare("
            SELECT id, user_id, contract_id
            FROM documents 
            WHERE id = ? AND LOWER(category) IN ('contrat','contrats','contract','contracts')
        ");
        $row->execute([$doc_id]);
        $doc = $row->fetch(PDO::FETCH_ASSOC);
        if (!$doc) throw new RuntimeException('Document introuvable.');

        $sets = ["is_visible=1", "status='approved'", "validated_at=NOW()"];
        $params = [];
        if ($HAS_ADMIN_SIGNED_AT)  { $sets[] = "admin_signed_at = NOW()"; }
        if ($HAS_ADMIN_SIGN_ADMIN) { $sets[] = "admin_sign_admin_id = ?"; $params[] = (int)$_SESSION['admin_id']; }
        $params[] = $doc_id;

        $pdo->prepare("UPDATE documents SET ".implode(', ', $sets)." WHERE id = ?")->execute($params);

        $_SESSION['flash_message'] = "Contrat signé (admin). Il est désormais visible et signable par le client.";
        header('Location: gestion_documents.php'); exit;
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur signature admin : " . $e->getMessage();
        header('Location: gestion_documents.php'); exit;
    }
}

// 3) Suppression d’un document
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    $doc_id = (int)($_GET['id'] ?? 0);
    if ($doc_id > 0) {
        try {
            $stmt = $pdo->prepare("SELECT file_path FROM documents WHERE id = ?");
            $stmt->execute([$doc_id]);
            $doc = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($doc && !empty($doc['file_path'])) {
                $abs = realpath(__DIR__ . '/..') . $doc['file_path'];
                if (file_exists($abs)) { @unlink($abs); }
            }
            $pdo->prepare("DELETE FROM documents WHERE id = ?")->execute([$doc_id]);
            $_SESSION['flash_message'] = "Le document a été supprimé.";
        } catch (Throwable $e) {
            $_SESSION['flash_message'] = "Erreur : suppression impossible.";
        }
    }
    header('Location: gestion_documents.php'); exit;
}

// 3.bis) PURGE des brouillons
if (isset($_GET['action']) && $_GET['action'] === 'purge_drafts') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    try {
        $q = $pdo->query("
            SELECT id, file_path FROM documents
            WHERE status='draft' AND LOWER(category) IN ('contrat','contrats','contract','contracts')
        ");
        $drafts = $q->fetchAll(PDO::FETCH_ASSOC);
        $base = realpath(__DIR__ . '/..');
        foreach ($drafts as $d) {
            $p = $base . $d['file_path'];
            if ($p && file_exists($p)) { @unlink($p); }
        }
        $pdo->exec("
            DELETE FROM documents
            WHERE status='draft' AND LOWER(category) IN ('contrat','contrats','contract','contracts')
        ");
        $_SESSION['flash_message'] = "Tous les brouillons de contrats ont été supprimés.";
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur lors de la purge : " . $e->getMessage();
    }
    header('Location: gestion_documents.php'); exit;
}

// 3.ter) Valider & signer (ADMIN) un brouillon existant → final + visible
if (isset($_GET['action'], $_GET['doc_id']) && $_GET['action'] === 'approve_sign') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    $doc_id = (int)$_GET['doc_id'];
    try {
        $row = $pdo->prepare("
            SELECT id, user_id, contract_id
            FROM documents 
            WHERE id=? AND (LOWER(category) IN ('contrat','contrats','contract','contracts'))
        ");
        $row->execute([$doc_id]);
        $doc = $row->fetch(PDO::FETCH_ASSOC);
        if (!$doc) throw new RuntimeException('Document introuvable.');

        if (!empty($doc['contract_id']) && function_exists('regenerate_contract_pdf_final')) {
            regenerate_contract_pdf_final($pdo, (int)$doc['contract_id'], $doc_id);
        }

        $sets = ["is_visible=1", "status='approved'", "validated_at=NOW()"];
        $params = [];
        if ($HAS_ADMIN_SIGNED_AT)  { $sets[] = "admin_signed_at = NOW()"; }
        if ($HAS_ADMIN_SIGN_ADMIN) { $sets[] = "admin_sign_admin_id = ?"; $params[] = (int)$_SESSION['admin_id']; }
        $params[] = $doc_id;

        $pdo->prepare("UPDATE documents SET ".implode(', ', $sets)." WHERE id=?")->execute($params);

        $_SESSION['flash_message'] = "Contrat finalisé et signé côté admin. Il est visible et signable par le client.";
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur validation/signature : " . $e->getMessage();
    }
    header('Location: gestion_documents.php'); exit;
}

/* ======== SIGNATURE ADMIN: Upload / Génération variantes / Validation ======== */

// Upload (PNG/JPG -> PNG fond blanc)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_admin_signature') {
    $lock = sig_lock_begin();
    if ($lock === null) { $_SESSION['flash_message'] = "Une autre sauvegarde est en cours, réessayez."; header('Location: gestion_documents.php'); exit; }
    try {
        if (!isset($_POST['csrf_token']) || !hash_equals($csrf_token, $_POST['csrf_token'])) {
            throw new Exception('Jeton CSRF invalide.', 403);
        }
        if (empty($_FILES['admin_signature']) || $_FILES['admin_signature']['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException("Veuillez sélectionner une image de signature (PNG/JPG).");
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($_FILES['admin_signature']['tmp_name']);
        if (!in_array($mime, ['image/png','image/jpeg'], true)) {
            throw new RuntimeException("Format non supporté. Utilisez PNG ou JPG.");
        }

        foreach (glob(GD_SIG_DIR.'admin-1.*') as $old) @unlink($old);
        $dst = GD_SIG_DIR . GD_ADMIN_SIG_FILENAME;

        if ($mime === 'image/png') {
            $src = imagecreatefrompng($_FILES['admin_signature']['tmp_name']);
        } else {
            $src = imagecreatefromjpeg($_FILES['admin_signature']['tmp_name']);
        }
        if (!$src) throw new RuntimeException("Lecture de l'image échouée.");
        if (!save_png_white_bg($src, $dst)) {
            imagedestroy($src);
            throw new RuntimeException("Sauvegarde PNG échouée.");
        }
        imagedestroy($src);

        $_SESSION['flash_message'] = "Signature administrateur enregistrée (fond blanc) → admin-1.png";
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur signature admin : " . $e->getMessage();
    } finally {
        sig_lock_end($lock);
    }
    header('Location: gestion_documents.php'); exit;
}

// Génération variantes (tampon)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate_stamp_variants') {
    try {
        if (!isset($_POST['csrf_token']) || !hash_equals($csrf_token, $_POST['csrf_token'])) {
            throw new Exception('Jeton CSRF invalide.', 403);
        }
        $theme = strtolower(trim($_POST['stamp_theme'] ?? 'aucun thème'));
        $map = [
            'aucun thème'=>'aucun','aucun'=>'aucun','none'=>'aucun',
            'noel'=>'noel','noël'=>'noel',
            'vacances toussaint'=>'vacances toussaint','toussaint'=>'vacances toussaint','vacances'=>'vacances toussaint',
            'paques'=>'paques','pâques'=>'paques',
            'noir'=>'noir',
        ];
        $theme = $map[$theme] ?? 'aucun';
        $count = (int)($_POST['variants_count'] ?? 6);
        $list  = generate_stamp_variants($theme, $count);
        $_SESSION['sig_variants_list'] = $list;
        $_SESSION['sig_variants_theme'] = $theme;
        $_SESSION['flash_message'] = "Variantes générées : " . count($list) . " pour le thème “{$theme}”. Cliquez “Valider” pour enregistrer.";
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur génération du tampon : " . $e->getMessage();
    }
    header('Location: gestion_documents.php'); exit;
}

// Valider une variante
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'validate_signature_variant') {
    $lock = sig_lock_begin();
    if ($lock === null) { $_SESSION['flash_message'] = "Une sauvegarde est déjà en cours, réessayez."; header('Location: gestion_documents.php'); exit; }
    try {
        if (!isset($_POST['csrf_token']) || !hash_equals($csrf_token, $_POST['csrf_token'])) {
            throw new Exception('Jeton CSRF invalide.', 403);
        }
        $pick = (string)($_POST['pick'] ?? '');
        if (!$pick || strpos($pick, '/documents/signatures/tmp/') !== 0) {
            throw new RuntimeException("Chemin invalide.");
        }
        promote_preview_to_final($pick);
        foreach (glob(GD_SIG_TMP_DIR.'*.png') as $old) @unlink($old);
        unset($_SESSION['sig_variants_list'], $_SESSION['sig_variants_theme']);
        $_SESSION['flash_message'] = "Signature validée ✅ (fond blanc) — admin-1.png créée.";
    } catch (Throwable $e) {
        $_SESSION['flash_message'] = "Erreur validation : " . $e->getMessage();
    } finally {
        sig_lock_end($lock);
    }
    header('Location: gestion_documents.php'); exit;
}

// Purger les variantes
if (isset($_GET['action']) && $_GET['action'] === 'purge_signature_variants') {
    if (!isset($_GET['token']) || !hash_equals($csrf_token, (string)$_GET['token'])) die('Jeton CSRF invalide.');
    foreach (glob(GD_SIG_TMP_DIR.'*.png') as $old) @unlink($old);
    unset($_SESSION['sig_variants_list'], $_SESSION['sig_variants_theme']);
    $_SESSION['flash_message'] = "Variantes de signature supprimées.";
    header('Location: gestion_documents.php'); exit;
}

/* ========================= LISTES / DONNÉES ========================= */

// A) Contrats sans PDF visible (à générer)
$missing_contracts = [];
try {
    if ($HAS_CONTRACT_ID) {
        $sql = "
          SELECT k.id AS contract_id, k.user_id, k.date_souscription, k.montant,
                 u.prenom, u.name AS user_nom, u.email
          FROM contrats k
          JOIN users u ON u.id = k.user_id
          LEFT JOIN documents d
            ON d.user_id = k.user_id
           AND d.contract_id = k.id
           AND (LOWER(d.category) IN ('contrat','contrats','contract','contracts'))
          WHERE d.id IS NULL
          ORDER BY u.prenom ASC, u.name ASC, k.id DESC
        ";
        $stmt = $pdo->query($sql);
        $missing_contracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $rowsK = $pdo->query("
            SELECT k.id AS contract_id, k.user_id, k.date_souscription, k.montant,
                   u.prenom, u.name AS user_nom, u.email
            FROM contrats k
            JOIN users u ON u.id = k.user_id
            ORDER BY k.date_souscription DESC, k.id DESC
        ")->fetchAll(PDO::FETCH_ASSOC);

        $docsByUser = [];
        $rowsD = $pdo->query("
            SELECT user_id, id, filename, file_path, category, is_visible
            FROM documents
            WHERE LOWER(category) IN ('contrat','contrats','contract','contracts')
        ")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rowsD as $d) { $docsByUser[(int)$d['user_id']][] = $d; }

        foreach ($rowsK as $k) {
            $uid = (int)$k['user_id']; $cid = (int)$k['contract_id'];
            $docs = $docsByUser[$uid] ?? [];
            $has = false;
            foreach ($docs as $d) { if (gd_doc_matches_contract($d, $cid)) { $has = true; break; } }
            if (!$has) $missing_contracts[] = $k;
        }
        usort($missing_contracts, function($a, $b){
            $na = trim(($a['prenom'] ?? '').' '.($a['user_nom'] ?? ''));
            $nb = trim(($b['prenom'] ?? '').' '.($b['user_nom'] ?? ''));
            return strcasecmp($na, $nb);
        });
    }
} catch (Throwable $e) { /* silencieux */ }

// B) Regrouper documents par statut
$docs_pending = [];  $docs_signed  = [];  $docs_drafts  = [];
try {
    $cols_extra = [];
    if ($HAS_CONTRACT_ID)       $cols_extra[] = 'd.contract_id';
    if ($HAS_CLIENT_SIGNED_AT)  $cols_extra[] = 'd.client_signed_at';
    if ($HAS_ADMIN_SIGNED_AT)   $cols_extra[] = 'd.admin_signed_at';

    $stmt = $pdo->query("
      SELECT d.id, d.user_id, d.filename, d.category, d.upload_date, d.file_path, d.status, d.is_visible,
             u.prenom, u.name AS user_nom, u.email
             ".($cols_extra ? (", ".implode(', ', $cols_extra)) : "")."
      FROM documents d
      JOIN users u ON d.user_id = u.id
      WHERE LOWER(d.category) IN ('contrat','contrats','contract','contracts')
      ORDER BY d.upload_date DESC
    ");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $doc) {
        $status  = strtolower((string)($doc['status'] ?? ''));
        $visible = (int)($doc['is_visible'] ?? 0) === 1;
        $clientSigned = isset($doc['client_signed_at']) && !empty($doc['client_signed_at']);

        if ($status === 'draft') {
            $docs_drafts[] = $doc;
        } else if ($visible && $clientSigned) {
            $docs_signed[] = $doc;
        } else if ($visible && !$clientSigned) {
            $docs_pending[] = $doc;
        }
    }
} catch (Throwable $e) { die('Erreur de chargement : ' . $e->getMessage()); }

// C) Signature admin actuelle ?
$admin_sig_preview = null;
$candidate = GD_SIG_DIR . GD_ADMIN_SIG_FILENAME;
if (file_exists($candidate)) { $admin_sig_preview = $candidate; }

/* ========================= UI ========================= */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Gestion des documents — Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style>
    :root { --primary:#2E7D32; --primaryDark:#1B5E20; --muted:#757575; --bg:#f6f8fb; --card:#fff; --bd:#e6e6e6; --br:14px; --overlay:rgba(0,0,0,.6); --ok:#1b5e20; --warn:#e65100; --info:#1565c0; }
    *{ box-sizing:border-box }
    body{ margin:0; font-family:system-ui, -apple-system, Segoe UI, Roboto, Arial; background:var(--bg); color:#222; }
    a{ color:inherit; text-decoration:none; }
    .sidebar{ width:260px; background:#fff; min-height:100vh; padding:18px; position:fixed; left:0; top:0; border-right:1px solid var(--bd); }
    .sidebar .title{ font-weight:800; font-size:18px; color:var(--primary); margin-bottom:18px }
    .sidebar a{ display:block; padding:10px 8px; color:#444; border-radius:8px; margin-bottom:8px; transition:.15s }
    .sidebar a.active, .sidebar a:hover{ background:var(--primary); color:#fff }
    .container{ margin-left:260px; padding:18px; }
    @media (max-width: 1024px){ .sidebar{ position:fixed; width:240px; transform:translateX(-100%); transition:transform .2s; z-index:10000 } .sidebar.open{ transform:none; } .container{ margin-left:0; padding-top:64px; } }
    .header{ display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; }
    .h1{ margin:0; font-size:22px; font-weight:800 }
    .muted{ color:#666 }
    .grid{ display:grid; gap:14px } .grid-cards{ grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); }
    .tile{ background:var(--card); border:1px solid var(--bd); border-radius:var(--br); padding:16px; display:flex; flex-direction:column; gap:12px; box-shadow:0 1px 2px rgba(0,0,0,.04); }
    .tile .t-title{ font-weight:800; font-size:16px } .tile .t-count{ font-size:28px; font-weight:900 } .tile .t-actions{ display:flex; gap:8px; flex-wrap:wrap }
    .btn{ display:inline-flex; align-items:center; gap:8px; padding:10px 14px; background:var(--primary); color:#fff; border:none; border-radius:10px; cursor:pointer; font-weight:700; }
    .btn.secondary{ background:#607d8b } .btn.warn{ background:#e53935 } .btn.ghost{ background:transparent; color:#333; border:1px solid var(--bd) }
    .flash{ padding:10px 12px; background:#e8f5e9; color:#1b5e20; border:1px solid #c8e6c9; border-radius:8px; margin:12px 0 }
    .table{ width:100%; border-collapse:collapse; font-size:14px } .table th, .table td{ padding:10px 12px; border-bottom:1px solid var(--bd); text-align:left; vertical-align:middle } .status{ display:inline-block; padding:3px 7px; border-radius:999px; font-size:12px; border:1px solid var(--bd); background:#fafafa }
    .status.draft{ color:var(--warn); border-color:#ffe0b2; background:#fff8e1 } .status.pending{ color:#1565c0; border-color:#bbdefb; background:#e3f2fd } .status.approved{ color:var(--ok); border-color:#c8e6c9; background:#e8f5e9 }
    .table-wrap{ overflow:auto; -webkit-overflow-scrolling:touch; } .table th{ position:sticky; top:0; background:#fff; z-index:1 } .table td, .table th{ white-space:nowrap; }
    @media (max-width: 700px){ .table td, .table th{ padding:10px 8px; } .table td:nth-child(2), .table th:nth-child(2){ white-space:normal; max-width: 320px; } }
    .modal { position:fixed; inset:0; background:var(--overlay); display:none; align-items:center; justify-content:center; padding:min(24px, 5vw); z-index:9999; }
    .modal.open { display:flex; } .modal-card { background:#fff; width:min(100%, 1100px); max-height:90vh; border-radius:clamp(8px, 2vw, 12px); overflow:hidden; display:flex; flex-direction:column; }
    .modal-header { display:flex; align-items:center; justify-content:space-between; background:#f2f4f7; padding:12px 14px; border-bottom:1px solid var(--bd); }
    .modal-title{ font-weight:800 } .modal-body { padding:12px; overflow:auto; } .modal-actions{ display:flex; gap:8px; padding:12px; border-top:1px solid var(--bd); justify-content:flex-end; background:#fafbfc; flex-wrap:wrap; }
    .modal-full .modal-card{ width:95vw; max-width:1600px; height:92vh; max-height:92vh; } .modal-full .modal-body{ height: calc(92vh - 56px); }
    .modal-dark .modal-card{ background:#000; width:min(100%, 1200px); } .modal-dark .modal-header{ background:#111; color:#fff; border-color:#222; } .modal-dark .modal-body{ padding:0; background:#111; } .modal-dark iframe{ width:100%; height:min(80vh, 100dvh - 140px); border:0; background:#111; }
    @media (max-width: 640px){ body{ font-size:16px; line-height:1.35; } .btn{ padding:12px 14px; border-radius:12px; } .tile{ padding:14px; gap:10px; } .modal-card{ width:100%; height:100dvh; border-radius:0; } .modal-header{ position:sticky; top:0; z-index:2; } .modal-body{ height: calc(100dvh - 56px - 56px); } .modal-dark iframe{ height: calc(100dvh - 56px); } .modal-full .modal-card{ width:100%; height:100dvh; } .modal-full .modal-body{ height: calc(100dvh - 56px); } }
    body.no-scroll{ height:100dvh; overflow:hidden; }
    .burger{ position:fixed; left:12px; top:12px; z-index:10001; display:none; padding:8px 12px; border-radius:10px; border:1px solid var(--bd); background:#fff; font-weight:700; cursor:pointer; }
    @media (max-width:1024px){ .burger{ display:inline-flex; } }
    td[style*="display:flex"], .t-actions{ gap:8px; flex-wrap:wrap; }
    .toolbar{ display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin: 8px 0 12px; }
    .toolbar .field{ display:flex; gap:6px; align-items:center; }
    .toolbar input[type="text"], .toolbar select{ padding:8px 10px; border:1px solid var(--bd); border-radius:10px; }
    .pill{ padding:6px 10px; border:1px solid var(--bd); border-radius:999px; background:#fff; cursor:pointer; font-weight:600; }
    .gallery{ display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; }
    .thumb{ background:#fff; border:1px solid var(--bd); border-radius:10px; padding:10px; display:flex; flex-direction:column; gap:8px; align-items:center; }
    .thumb img{ max-width:100%; height:auto; border-radius:8px; background:#fff; }
    .badge-miss{ display:inline-block; padding:2px 8px; border-radius:999px; background:#fff3cd; color:#663c00; border:1px solid #ffe0a3; font-size:12px; margin: 0 4px 4px 0; }
  </style>
</head>
<body>

<button class="burger" id="burgerBtn" aria-label="Ouvrir le menu">Menu</button>

<div class="sidebar" id="sidebar">
  <div class="title">La Serre — Admin</div>
  <a href="index.php">Tableau de bord</a>
  <a href="gestion_users.php">Utilisateurs</a>
  <a href="gestion_documents.php" class="active">Documents</a>
  <a href="../logout.php">Déconnexion</a>
</div>

<div class="container">
  <div class="header">
    <div>
      <div class="h1">Gestion des documents</div>
      <div class="muted">Vue compacte • Ouvrez une carte pour gérer</div>
    </div>
    <div class="t-actions">
      <a class="btn warn" href="?action=purge_drafts&token=<?= gd_h($csrf_token) ?>" onclick="return confirm('Supprimer TOUS les brouillons de contrats ?');">Purger les brouillons</a>
    </div>
  </div>

  <?php if (!empty($_SESSION['flash_message'])): ?>
    <div class="flash"><?= gd_h($_SESSION['flash_message']); ?></div>
    <?php unset($_SESSION['flash_message']); ?>
  <?php endif; ?>

  <!-- DASHBOARD DE CARTES -->
  <div class="grid grid-cards">
    <div class="tile">
      <div class="t-title">Contrats à générer</div>
      <div class="t-count"><?= (int)count($missing_contracts) ?></div>
      <div class="muted">Contrats sans PDF visible</div>
      <div class="t-actions">
        <button class="btn" onclick="openModal('modal-to-create', true); rememberUI({open:'modal-to-create'})">Ouvrir en grand</button>
      </div>
    </div>

    <div class="tile">
      <div class="t-title">En attente signature client</div>
      <div class="t-count"><?= (int)count($docs_pending) ?></div>
      <div class="muted">Visibles mais non signés</div>
      <div class="t-actions">
        <button class="btn" onclick="openModal('modal-pending', true); rememberUI({open:'modal-pending'})">Gérer</button>
      </div>
    </div>

    <div class="tile">
      <div class="t-title">Contrats signés</div>
      <div class="t-count"><?= (int)count($docs_signed) ?></div>
      <div class="muted">Signés par le client</div>
      <div class="t-actions">
        <button class="btn" onclick="openModal('modal-signed', true); rememberUI({open:'modal-signed'})">Voir</button>
      </div>
    </div>

    <div class="tile">
      <div class="t-title">Brouillons</div>
      <div class="t-count"><?= (int)count($docs_drafts) ?></div>
      <div class="muted">Non finalisés</div>
      <div class="t-actions">
        <button class="btn" onclick="openModal('modal-drafts', true); rememberUI({open:'modal-drafts'})">Gérer</button>
      </div>
    </div>

    <div class="tile">
      <div class="t-title">Uploader un document</div>
      <div class="muted">Associer PDF/ID à un client/contrat</div>
      <div class="t-actions">
        <button class="btn" onclick="openModal('modal-upload', true); rememberUI({open:'modal-upload'})">Ouvrir</button>
      </div>
    </div>

    <div class="tile">
      <div class="t-title">Signature administrateur</div>
      <div class="muted">Tampon (fond blanc) avec SIRET + site • Sauvegarde : admin-1.png</div>
      <div class="t-actions">
        <button class="btn" onclick="openModal('modal-sig', true); rememberUI({open:'modal-sig'})">Configurer</button>
      </div>
    </div>
  </div>
</div>

<!-- MODAL LARGE : Contrats à générer -->
<div class="modal modal-full" id="modal-to-create" aria-hidden="true" role="dialog">
  <div class="modal-card">
    <div class="modal-header">
      <div class="modal-title">Contrats à générer & prévisualiser</div>
      <button class="btn warn" onclick="closeModal('modal-to-create'); rememberUI({open:null})">Fermer</button>
    </div>
    <div class="modal-body">
      <?php if (empty($missing_contracts)): ?>
        <div class="muted">Aucun contrat à créer 👍</div>
      <?php else: ?>
        <div class="toolbar" id="mc-toolbar">
          <div class="field">
            <label class="muted">Rechercher :</label>
            <input type="text" id="mc-search" placeholder="Nom ou email">
          </div>
          <div class="field">
            <label class="muted">Trier par :</label>
            <select id="mc-sort-field">
              <option value="date">Date de souscription</option>
              <option value="montant">Montant</option>
              <option value="id"># Contrat</option>
            </select>
            <select id="mc-sort-dir">
              <option value="desc">Descendant</option>
              <option value="asc">Ascendant</option>
            </select>
            <button class="pill" id="mc-apply-sort">Appliquer</button>
          </div>
          <div class="field">
            <button class="pill" id="mc-reset">Réinitialiser</button>
          </div>
        </div>

        <p class="muted">Cliquez “Générer” pour créer le PDF. Si le profil client est incomplet, un choix vous sera proposé.</p>
        <div class="table-wrap">
          <table class="table" id="mc-table">
            <thead>
              <tr><th>Client</th><th>Email</th><th>Contrat #</th><th>Souscription</th><th>Montant</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($missing_contracts as $mc):
              $ts = !empty($mc['date_souscription']) ? strtotime($mc['date_souscription']) : 0;
              $fullname = trim(($mc['prenom'] ?? '').' '.($mc['user_nom'] ?? ''));
            ?>
              <tr
                data-user-id="<?= (int)$mc['user_id'] ?>"
                data-date="<?= (int)$ts ?>"
                data-montant="<?= (float)($mc['montant'] ?? 0) ?>"
                data-id="<?= (int)$mc['contract_id'] ?>"
                data-text="<?= gd_h(mb_strtolower($fullname.' '.($mc['email'] ?? ''), 'UTF-8')) ?>"
              >
                <td><?= gd_h($fullname) ?></td>
                <td class="muted"><?= gd_h($mc['email'] ?? '') ?></td>
                <td>#<?= (int)$mc['contract_id'] ?></td>
                <td><?= $ts ? date('d/m/Y', $ts) : '—' ?></td>
                <td><?= gd_money($mc['montant'] ?? null) ?></td>
                <td style="display:flex; flex-wrap:wrap; gap:8px;">
                  <?php if (!empty($GENERATE_CONTRACTS_AVAILABLE)): ?>
                    <a class="btn gen-preview-btn"
                       href="gestion_documents.php?action=generate_preview_admin&contract_id=<?= (int)$mc['contract_id'] ?>&token=<?= gd_h($csrf_token) ?>">
                       Générer
                    </a>
                  <?php else: ?>
                    <span class="muted">Module indisponible</span>
                  <?php endif; ?>

                  <button
                    class="btn secondary prefill-btn"
                    type="button"
                    data-user-id="<?= (int)$mc['user_id'] ?>"
                    data-contract-id="<?= (int)$mc['contract_id'] ?>"
                    data-name="<?= gd_h($fullname) ?>"
                  >Ajouter un PDF</button>

                  <button class="btn ghost" type="button" onclick="mcFilterByUser(<?= (int)$mc['user_id'] ?>)">Tous de ce client</button>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- MODAL LARGE : En attente / signés / brouillons (inchangé) -->
<div class="modal modal-full" id="modal-pending" aria-hidden="true" role="dialog">
  <div class="modal-card">
    <div class="modal-header"><div class="modal-title">En attente de signature client</div><button class="btn warn" onclick="closeModal('modal-pending'); rememberUI({open:null})">Fermer</button></div>
    <div class="modal-body">
      <?php if (empty($docs_pending)): ?>
        <div class="muted">Aucun contrat en attente.</div>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Client</th><th>Contrat</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($docs_pending as $doc): ?>
                <?php
                  $cid = $HAS_CONTRACT_ID && isset($doc['contract_id']) ? (int)$doc['contract_id'] : null;
                  $clientSignUrl = $cid ? '/sign_contract.php?contract_id='.$cid.'&as=client' : null;
                ?>
                <tr>
                  <td><?= gd_h(trim(($doc['prenom'] ?? '').' '.($doc['user_nom'] ?? ''))) ?><br><span class="muted"><?= gd_h($doc['email']) ?></span></td>
                  <td><?= gd_h($doc['filename']) ?><br><span class="status pending">en attente</span></td>
                  <td><?= !empty($doc['upload_date']) ? date('d/m/Y H:i', strtotime($doc['upload_date'])) : '—' ?></td>
                  <td style="display:flex; flex-wrap:wrap; gap:8px;">
                    <button class="btn secondary" type="button" onclick="previewDoc(<?= (int)$doc['id'] ?>)">Prévisualiser</button>
                    <?php if ($clientSignUrl): ?><button class="btn" type="button" onclick="openSignModal('<?= gd_h($clientSignUrl) ?>')">Ouvrir signature</button><?php endif; ?>
                    <a class="btn ghost" href="/download.php?id=<?= (int)$doc['id'] ?>">Télécharger</a>
                    <a class="btn warn" href="?action=delete&id=<?= (int)$doc['id'] ?>&token=<?= gd_h($csrf_token) ?>" onclick="return confirm('Supprimer ce document ?');">Supprimer</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal modal-full" id="modal-signed" aria-hidden="true" role="dialog">
  <div class="modal-card">
    <div class="modal-header"><div class="modal-title">Contrats signés</div><button class="btn warn" onclick="closeModal('modal-signed'); rememberUI({open:null})">Fermer</button></div>
    <div class="modal-body">
      <?php if (empty($docs_signed)): ?>
        <div class="muted">Aucun contrat signé pour le moment.</div>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Client</th><th>Contrat</th><th>Ajouté le</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($docs_signed as $doc): ?>
                <tr>
                  <td><?= gd_h(trim(($doc['prenom'] ?? '').' '.($doc['user_nom'] ?? ''))) ?><br><span class="muted"><?= gd_h($doc['email']) ?></span></td>
                  <td><?= gd_h($doc['filename']) ?><br><span class="status approved">signé</span></td>
                  <td><?= !empty($doc['upload_date']) ? date('d/m/Y H:i', strtotime($doc['upload_date'])) : '—' ?></td>
                  <td style="display:flex; flex-wrap:wrap; gap:8px;">
                    <button class="btn secondary" type="button" onclick="previewDoc(<?= (int)$doc['id'] ?>)">Prévisualiser</button>
                    <a class="btn ghost" href="/download.php?id=<?= (int)$doc['id'] ?>">Télécharger</a>
                    <a class="btn warn" href="?action=delete&id=<?= (int)$doc['id'] ?>&token=<?= gd_h($csrf_token) ?>" onclick="return confirm('Supprimer ce document ?');">Supprimer</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal modal-full" id="modal-drafts" aria-hidden="true" role="dialog">
  <div class="modal-card">
    <div class="modal-header"><div class="modal-title">Brouillons de contrats</div><button class="btn warn" onclick="closeModal('modal-drafts'); rememberUI({open:null})">Fermer</button></div>
    <div class="modal-body">
      <?php if (empty($docs_drafts)): ?>
        <div class="muted">Aucun brouillon.</div>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Client</th><th>Contrat</th><th>Créé le</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($docs_drafts as $doc): ?>
                <tr>
                  <td><?= gd_h(trim(($doc['prenom'] ?? '').' '.($doc['user_nom'] ?? ''))) ?><br><span class="muted"><?= gd_h($doc['email']) ?></span></td>
                  <td><?= gd_h($doc['filename']) ?><br><span class="status draft">brouillon</span></td>
                  <td><?= !empty($doc['upload_date']) ? date('d/m/Y H:i', strtotime($doc['upload_date'])) : '—' ?></td>
                  <td style="display:flex; flex-wrap:wrap; gap:8px;">
                    <button class="btn secondary" type="button" onclick="previewDoc(<?= (int)$doc['id'] ?>)">Prévisualiser</button>
                    <a class="btn" href="?action=approve_sign&doc_id=<?= (int)$doc['id'] ?>&token=<?= gd_h($csrf_token) ?>" onclick="return confirm('Finaliser ce brouillon, signer côté admin et le rendre visible ?');">Valider & signer (admin)</a>
                    <a class="btn warn" href="?action=delete&id=<?= (int)$doc['id'] ?>&token=<?= gd_h($csrf_token) ?>" onclick="return confirm('Supprimer ce brouillon ?');">Supprimer</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- MODAL LARGE : Upload & Signature admin -->
<div class="modal modal-full" id="modal-sig" aria-hidden="true" role="dialog">
  <div class="modal-card">
    <div class="modal-header">
      <div class="modal-title">Signature administrateur (tampon fond blanc)</div>
      <div class="t-actions">
        <a class="btn ghost" href="?action=purge_signature_variants&token=<?= gd_h($csrf_token) ?>" onclick="return confirm('Supprimer toutes les variantes générées ?');">Purger les variantes</a>
        <button class="btn warn" onclick="closeModal('modal-sig'); rememberUI({open:null})">Fermer</button>
      </div>
    </div>
    <div class="modal-body">
      <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap:16px;">
        <!-- Upload -->
        <form method="POST" enctype="multipart/form-data" class="tile" onsubmit="return lockOnce(this)">
          <div class="t-title">Uploader une signature (PNG/JPG) → admin-1.png</div>
          <input type="hidden" name="action" value="upload_admin_signature">
          <input type="hidden" name="csrf_token" value="<?= gd_h($csrf_token) ?>">
          <input type="file" name="admin_signature" accept="image/png, image/jpeg" required style="width:100%;">
          <div class="muted">Le fichier sera converti en PNG sur <b>fond blanc</b>.</div>
          <div><button class="btn" type="submit">Uploader</button></div>
        </form>

        <!-- Génération variantes -->
        <form method="POST" class="tile" onsubmit="return lockOnce(this)">
          <div class="t-title">Générer des variantes (tampon)</div>
          <input type="hidden" name="action" value="generate_stamp_variants">
          <input type="hidden" name="csrf_token" value="<?= gd_h($csrf_token) ?>">
          <label class="muted" for="stamp_theme">Thème</label>
          <select id="stamp_theme" name="stamp_theme" style="padding:10px 12px; border:1px solid var(--bd); border-radius:10px; width:100%; margin-bottom:8px;">
            <option>aucun thème</option>
            <option>noir</option>
            <option>noel</option>
            <option>vacances toussaint</option>
            <option>paques</option>
          </select>
          <label class="muted" for="variants_count">Nombre de variantes</label>
          <select id="variants_count" name="variants_count" style="padding:10px 12px; border:1px solid var(--bd); border-radius:10px; width:100%; margin-bottom:8px;">
            <option>3</option><option selected>6</option><option>9</option><option>12</option>
          </select>
          <div class="muted">Chaque variante → <b>fond blanc</b>. Choisissez “Valider”.</div>
          <div><button class="btn" type="submit">Générer</button></div>
        </form>

        <!-- Aperçu actuel -->
        <div class="tile">
          <div class="t-title">Signature actuelle (admin-1.png)</div>
          <?php if (!empty($admin_sig_preview)): ?>
            <img src="<?= gd_h(str_replace(realpath(__DIR__ . '/..'), '', $admin_sig_preview)) ?>" alt="Signature admin" style="max-width:100%; height:auto; background:#fff; padding:8px; border:1px solid var(--bd); border-radius:10px;">
            <div class="muted">Chemin : <?= gd_h($admin_sig_preview) ?></div>
          <?php else: ?>
            <div class="muted">Aucune signature finale enregistrée.</div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Galerie de variantes -->
      <?php
        $gallery = $_SESSION['sig_variants_list'] ?? [];
        $galTheme = $_SESSION['sig_variants_theme'] ?? null;
      ?>
      <?php if (!empty($gallery)): ?>
        <hr style="border:none; border-top:1px solid var(--bd); margin:18px 0;">
        <div class="t-title">Variantes générées <?= $galTheme ? ('— Thème : '.gd_h($galTheme)) : '' ?></div>
        <div class="gallery">
          <?php foreach ($gallery as $rel): ?>
            <div class="thumb">
              <img src="<?= gd_h($rel) ?>" alt="Variante">
              <form method="POST" style="margin-top:6px;" onsubmit="return lockOnce(this)">
                <input type="hidden" name="action" value="validate_signature_variant">
                <input type="hidden" name="csrf_token" value="<?= gd_h($csrf_token) ?>">
                <input type="hidden" name="pick" value="<?= gd_h($rel) ?>">
                <button class="btn" type="submit">Valider</button>
              </form>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- MODAL : Upload document -->
<div class="modal modal-full" id="modal-upload" aria-hidden="true" role="dialog">
  <div class="modal-card">
    <div class="modal-header"><div class="modal-title">Uploader un document</div><button class="btn warn" onclick="closeModal('modal-upload'); rememberUI({open:null})">Fermer</button></div>
    <div class="modal-body">
      <form id="upload-form" method="POST" enctype="multipart/form-data" autocomplete="off" class="grid" style="grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap:12px;">
        <input type="hidden" name="action" value="upload_doc">
        <input type="hidden" name="csrf_token" value="<?= gd_h($csrf_token) ?>">
        <input type="hidden" id="user_id" name="user_id">
        <?php if ($HAS_CONTRACT_ID): ?><input type="hidden" id="contract_id" name="contract_id"><?php endif; ?>

        <div class="rel" style="grid-column:1/-1;">
          <label class="muted">Associer au client</label>
          <input type="text" id="user_search" placeholder="Nom / email…" aria-autocomplete="list" aria-controls="search-results" style="width:100%; padding:10px 12px; border:1px solid var(--bd); border-radius:10px;">
          <div id="search-results" class="results" style="display:none; position:absolute; left:0; right:0; top:100%; background:#fff; border:1px solid var(--bd); border-top:none; border-radius:0 0 10px 10px; max-height:240px; overflow:auto; z-index:9"></div>
        </div>

        <div>
          <label class="muted">Catégorie</label>
          <select name="category" id="category" style="width:100%; padding:10px 12px; border:1px solid var(--bd); border-radius:10px;">
            <option value="Contrat" selected>Contrat</option>
            <option value="Pièce d'identité">Pièce d'identité</option>
            <option value="Autre">Autre</option>
          </select>
        </div>

        <div>
          <label class="muted">Fichier (PDF)</label>
          <input type="file" id="document" name="document" accept="application/pdf" required style="width:100%;">
        </div>

        <div style="align-self:end;"><button class="btn" type="submit">Uploader</button></div>

        <?php if ($HAS_CONTRACT_ID): ?>
          <div class="muted" style="grid-column:1/-1;">Astuce : ce formulaire peut être prérempli via la carte “Contrats à générer”.</div>
        <?php endif; ?>
      </form>
    </div>
  </div>
</div>

<!-- MODAL : Prévisualisation PDF (avec bouton Signer admin) -->
<div class="modal modal-dark" id="preview-modal" aria-hidden="true" role="dialog" aria-label="Prévisualisation du document">
  <div class="modal-card">
    <div class="modal-header"><div class="modal-title">Prévisualisation du PDF</div><div style="display:flex; gap:8px; align-items:center;"><button class="btn" id="admin-sign-btn" style="display:none;">Signer (admin)</button><button class="btn warn" onclick="closePreview()">Fermer</button></div></div>
    <div class="modal-body"><iframe id="preview-frame" src="about:blank" title="Aperçu PDF"></iframe></div>
  </div>
</div>

<!-- MODAL : Signature client -->
<div class="modal modal-dark" id="sign-modal" aria-hidden="true" role="dialog" aria-label="Signature du contrat">
  <div class="modal-card">
    <div class="modal-header"><div class="modal-title">Signature du contrat (client)</div><button class="btn warn" onclick="closeSign()">Fermer</button></div>
    <div class="modal-body"><iframe id="sign-frame" src="about:blank" title="Signature client"></iframe></div>
  </div>
</div>

<!-- ───────── AJOUT : MODAL “Profil incomplet : choisir une action” ───────── -->
<?php
  $missContractId = $_SESSION['profile_missing_contract_id'] ?? null;
  $missFields = $_SESSION['profile_missing_fields'] ?? [];
  $openProfileModal = $missContractId && is_array($missFields);
?>
<div class="modal" id="modal-profile-missing" aria-hidden="true" role="dialog" <?php if($openProfileModal) echo 'style="display:flex"'; ?>>
  <div class="modal-card" style="max-width:720px;">
    <div class="modal-header">
      <div class="modal-title">Profil client incomplet</div>
      <button class="btn warn" onclick="closeProfileMissing()">Fermer</button>
    </div>
    <div class="modal-body">
      <p>Certains champs du profil client sont manquants pour la génération du contrat <strong>#<?= $missContractId ? (int)$missContractId : 0 ?></strong>.</p>
      <?php if (!empty($missFields)): ?>
        <p class="muted" style="margin:8px 0;">Champs manquants :</p>
        <div style="display:flex; flex-wrap:wrap;">
          <?php foreach ($missFields as $f): ?>
            <span class="badge-miss"><?= gd_h($f) ?></span>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <hr style="border:none; border-top:1px solid #e6e6e6; margin:12px 0;">
      <p>Choisissez :</p>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <a class="btn" href="?action=force_generate&contract_id=<?= $missContractId ? (int)$missContractId : 0 ?>&token=<?= gd_h($csrf_token) ?>">Créer quand même</a>
        <a class="btn secondary" href="?action=send_profile_reminder&contract_id=<?= $missContractId ? (int)$missContractId : 0 ?>&token=<?= gd_h($csrf_token) ?>">Envoyer une relance au client</a>
      </div>
      <p class="muted" style="margin-top:8px;">Astuce : vous pouvez ensuite regénérer le contrat une fois le profil complété.</p>
    </div>
  </div>
</div>

<script>
  // Sidebar burger
  const burger = document.getElementById('burgerBtn');
  const sidebar = document.getElementById('sidebar');
  burger?.addEventListener('click', ()=> sidebar?.classList.toggle('open'));
  window.addEventListener('resize', ()=> { if (window.innerWidth > 1024) sidebar?.classList.remove('open'); });

  // Modals
  function lockScroll(){ document.body.classList.add('no-scroll'); }
  function unlockScroll(){ if (!document.querySelector('.modal.open')) document.body.classList.remove('no-scroll'); }
  function openModal(id, large=false){ const m=document.getElementById(id); if(!m) return; if (large) m.classList.add('modal-full'); else m.classList.remove('modal-full'); m.classList.add('open'); m.setAttribute('aria-hidden','false'); lockScroll(); }
  function closeModal(id){ const m=document.getElementById(id); if(!m) return; m.classList.remove('open'); m.setAttribute('aria-hidden','true'); unlockScroll(); }

  // PDF preview
  const previewModal = document.getElementById('preview-modal');
  const previewFrame = document.getElementById('preview-frame');
  function previewDoc(id){ previewFrame.src = `gestion_documents.php?action=stream&doc_id=${encodeURIComponent(id)}&token=<?= gd_h($csrf_token) ?>`; openModal('preview-modal'); }
  function closePreview(){ previewFrame.src='about:blank'; closeModal('preview-modal'); }
  previewModal?.addEventListener('click', (e)=> { if(e.target === previewModal) closePreview(); });

  // Signature client
  const signModal  = document.getElementById('sign-modal');
  const signFrame  = document.getElementById('sign-frame');
  function openSignModal(url){ signFrame.src = url; openModal('sign-modal'); }
  function closeSign(){ signFrame.src='about:blank'; closeModal('sign-modal'); }
  signModal?.addEventListener('click', (e)=> { if(e.target === signModal) closeSign(); });

  // ESC pour fermer
  document.addEventListener('keydown', (e)=>{ if (e.key === 'Escape'){ document.querySelectorAll('.modal.open').forEach(m=> m.classList.remove('open')); unlockScroll(); } });

  // Autocomplete clients
  const input = document.getElementById('user_search');
  const res   = document.getElementById('search-results');
  const uid   = document.getElementById('user_id');
  let debounceTimer = null, activeIndex = -1;
  function clearResults(){ if(!res) return; res.innerHTML=''; res.style.display='none'; activeIndex = -1; }
  function renderResults(list){
    if(!res) return; res.innerHTML = '';
    if (!list || !list.length){ clearResults(); return; }
    list.forEach((u, i) => {
      const div = document.createElement('div'); div.className = 'result-item' + (i === 0 ? ' active' : '');
      div.style.padding='8px 10px'; div.style.cursor='pointer';
      if (i === 0) activeIndex = 0;
      div.textContent = `${u.prenom} ${u.name} — ${u.email}`; div.dataset.id = u.id;
      div.addEventListener('click', () => { if(input) input.value = `${u.prenom} ${u.name}`; if(uid) uid.value = u.id; clearResults(); const file = document.getElementById('document'); if (file) file.focus(); });
      res.appendChild(div);
    }); res.style.display = 'block';
  }
  if (input) {
    input.addEventListener('input', () => {
      if(uid) uid.value = '';
      const q = input.value.trim(); if (q.length < 2) { clearResults(); return; }
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(()=>{
        fetch('gestion_documents.php?action=search_users&term=' + encodeURIComponent(q))
          .then(r => r.ok ? r.json() : []).then(renderResults).catch(()=> clearResults());
      }, 200);
    });
    input.addEventListener('keydown', (e) => {
      if (!res || res.style.display !== 'block') return;
      if (e.key === 'ArrowDown'){ e.preventDefault(); const items = res.querySelectorAll('.result-item'); activeIndex = Math.min(items.length-1, activeIndex+1); items.forEach((el,i)=> el.classList.toggle('active', i===activeIndex)); }
      else if (e.key === 'ArrowUp'){ e.preventDefault(); const items = res.querySelectorAll('.result-item'); activeIndex = Math.max(0, activeIndex-1); items.forEach((el,i)=> el.classList.toggle('active', i===activeIndex)); }
      else if (e.key === 'Enter'){ e.preventDefault(); const items = res.querySelectorAll('.result-item'); if (activeIndex>=0 && items[activeIndex]) { const id = items[activeIndex].dataset.id; const txt = items[activeIndex].textContent || ''; input.value = txt.split(' — ')[0]; if(uid) uid.value = id; clearResults(); } }
      else if (e.key === 'Escape'){ clearResults(); }
    });
    document.addEventListener('click', (e)=> { if (!e.target.closest('.rel')) clearResults(); });
  }

  // Préremplir upload
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.prefill-btn'); if (!btn) return;
    const userId = parseInt(btn.dataset.userId, 10) || ''; const contractId = parseInt(btn.dataset.contractId, 10) || ''; const displayName = btn.dataset.name || '';
    const uidEl = document.getElementById('user_id'); const cidEl = document.getElementById('contract_id'); const inputEl = document.getElementById('user_search');
    if(uidEl) uidEl.value = userId; if (cidEl) cidEl.value = contractId; if (inputEl) inputEl.value = displayName || '';
    const cat = document.getElementById('category'); if (cat) cat.value = 'Contrat';
    openModal('modal-upload', true); rememberUI({open:'modal-upload'});
  });

  // Upload AJAX
  const form = document.getElementById('upload-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit]'); const original = btn.textContent;
      btn.disabled = true; btn.textContent = 'Envoi...';
      fetch('gestion_documents.php', { method:'POST', body: new FormData(form) })
        .then(async r => { const data = await r.json().catch(()=> ({})); if (!r.ok || !data.success) throw new Error(data.message || 'Erreur inconnue'); alert('✅ ' + data.message); location.href = 'gestion_documents.php'; })
        .catch(err => { alert('❌ ' + err.message); btn.disabled = false; btn.textContent = original; });
    });
  }

  // Persistance d'UI
  function rememberUI(partial){ try{ const st = JSON.parse(sessionStorage.getItem('gd_state')||'{}'); sessionStorage.setItem('gd_state', JSON.stringify({...st, ...partial})); }catch{} }
  function readUI(){ try{ return JSON.parse(sessionStorage.getItem('gd_state')||'{}'); }catch{ return {}; } }

  // “Contrats à générer” : tri + filtres
  const mcTable = document.getElementById('mc-table');
  const mcSearch = document.getElementById('mc-search');
  const mcSortField = document.getElementById('mc-sort-field');
  const mcSortDir = document.getElementById('mc-sort-dir');
  const mcApplySort = document.getElementById('mc-apply-sort');
  const mcReset = document.getElementById('mc-reset');

  function mcRows(){ return Array.from(mcTable?.querySelectorAll('tbody tr') || []); }
  function mcApplyFilters(){
    const q = (mcSearch?.value || '').trim().toLowerCase();
    rememberUI({mcSearch: q});
    mcRows().forEach(tr => { const text = (tr.getAttribute('data-text') || '').toLowerCase(); tr.style.display = (!q || text.includes(q)) ? '' : 'none'; });
  }
  function mcSort(){
    const field = mcSortField?.value || 'date';
    const dir = (mcSortDir?.value || 'desc') === 'asc' ? 1 : -1;
    rememberUI({mcSortField: field, mcSortDir: dir===1?'asc':'desc'});
    const rows = mcRows().filter(tr => tr.style.display !== 'none');
    rows.sort((a,b)=>{
      let va, vb;
      if (field === 'montant'){ va = parseFloat(a.dataset.montant||'0'); vb = parseFloat(b.dataset.montant||'0'); }
      else if (field === 'id'){ va = parseInt(a.dataset.id||'0'); vb = parseInt(b.dataset.id||'0'); }
      else { va = parseInt(a.dataset.date||'0'); vb = parseInt(b.dataset.date||'0'); }
      if (va < vb) return -1*dir; if (va > vb) return 1*dir; return 0;
    });
    const tbody = mcTable?.querySelector('tbody'); rows.forEach(r => tbody.appendChild(r));
  }
  function mcFilterByUser(userId){
    rememberUI({mcUserFilter: parseInt(userId,10)||null, mcSearch:''});
    if (mcSearch) mcSearch.value = '';
    mcRows().forEach(tr => { tr.style.display = (parseInt(tr.dataset.userId||'0') === userId) ? '' : 'none'; });
  }
  window.mcFilterByUser = mcFilterByUser;

  mcSearch?.addEventListener('input', mcApplyFilters);
  mcApplySort?.addEventListener('click', ()=>{ mcApplyFilters(); mcSort(); });
  mcReset?.addEventListener('click', ()=>{ if (mcSearch) mcSearch.value = ''; rememberUI({mcUserFilter:null, mcSearch:'', mcSortField:'date', mcSortDir:'desc'}); mcRows().forEach(tr => tr.style.display = ''); if (mcSortField) mcSortField.value = 'date'; if (mcSortDir) mcSortDir.value = 'desc'; mcSort(); });

  // Mémoriser l'état avant “Générer”
  document.addEventListener('click', (e)=>{
    const a = e.target.closest('.gen-preview-btn'); if (!a) return;
    rememberUI({ open:'modal-to-create', mcSearch:(mcSearch?.value||'').trim().toLowerCase(), mcSortField: mcSortField?.value || 'date', mcSortDir: mcSortDir?.value || 'desc' });
    const rows = mcRows(); const anyHidden = rows.some(tr => tr.style.display === 'none');
    if (anyHidden){ const visible = rows.find(tr => tr.style.display !== 'none'); if (visible) rememberUI({mcUserFilter: parseInt(visible.dataset.userId||'0',10) || null}); } else { rememberUI({mcUserFilter: null}); }
  });

  // Ouverture auto de l’aperçu après génération + bouton signer
  const adminSignBtn = document.getElementById('admin-sign-btn');
  let currentPreviewDocId = null;
  document.addEventListener('DOMContentLoaded', ()=>{
    const st = readUI(); if (st.open){ openModal(st.open, true); }
    if (mcTable){
      if (st.mcSortField && mcSortField) mcSortField.value = st.mcSortField;
      if (st.mcSortDir && mcSortDir) mcSortDir.value = st.mcSortDir;
      if (st.mcSearch && mcSearch){ mcSearch.value = st.mcSearch; }
      if (typeof st.mcUserFilter === 'number'){
        mcRows().forEach(tr => { tr.style.display = (parseInt(tr.dataset.userId||'0') === st.mcUserFilter) ? '' : 'none'; });
      } else { mcApplyFilters(); }
      mcSort();
    }
    <?php
      $adminPreviewDocId = $_SESSION['open_admin_preview_doc_id'] ?? null;
      unset($_SESSION['open_admin_preview_doc_id']);
      if ($adminPreviewDocId):
    ?>
      currentPreviewDocId = <?= (int)$adminPreviewDocId ?>;
      previewFrame.src = `gestion_documents.php?action=stream&doc_id=${encodeURIComponent(currentPreviewDocId)}&token=<?= gd_h($csrf_token) ?>`;
      openModal('preview-modal'); if (adminSignBtn) adminSignBtn.style.display = 'inline-flex';
    <?php endif; ?>

    // Ouvrir automatiquement le modal “profil incomplet” si besoin
    <?php if (!empty($openProfileModal)): ?>
      (function(){ 
        const m = document.getElementById('modal-profile-missing');
        if(m){ m.classList.add('open'); m.setAttribute('aria-hidden','false'); document.body.classList.add('no-scroll'); }
      })();
    <?php endif; ?>
  });
  adminSignBtn?.addEventListener('click', ()=>{ if (!currentPreviewDocId) return; rememberUI({open:'modal-to-create'}); const url = `gestion_documents.php?action=admin_sign&doc_id=${encodeURIComponent(currentPreviewDocId)}&token=<?= gd_h($csrf_token) ?>`; window.location.href = url; });

  // Fermer modal profil-missing + purge variables serveur via callback (optionnel : ici local)
  function closeProfileMissing(){
    const m = document.getElementById('modal-profile-missing');
    if(!m) return;
    m.classList.remove('open'); m.setAttribute('aria-hidden','true'); m.style.display='none';
    document.body.classList.remove('no-scroll');
  }

  // Antidouble submit côté client (complément du flock serveur)
  let saveBusy = false;
  function lockOnce(form){
    if (saveBusy) return false;
    saveBusy = true;
    const btn = form.querySelector('button[type=submit]'); if (btn){ btn.disabled = true; btn.textContent = 'Traitement…'; }
    return true;
  }
</script>
</body>
</html>


