<?php
// ====================================================================================
// virements.php — Gestion Virements (KPI temps réel + tri réalisé / à traiter)
// v3.1 (demande Amaury 2025-10-22)
// ------------------------------------------------------------------------------------
// - KPI 1 « CA réalisé » = Somme de TOUS les contrats arrivés à échéance (intérêts inclus)
//   -> SUM(apport + apport*(taux_moyen/100)) sur contrats.date_fin <= aujourd'hui
// - KPI 2 « Clients payés » = nb de clients DISTINCT dont une demande est marquée Payé/Traité
// - KPI 3 « Restant à rembourser » = somme des demandes de retrait non traitées
//   (statuts en_attente / valide / partiel)
// - Deux sections : « À traiter » (pending) et « Réalisés » (done)
// - Dans « demande d'un retrait » (À traiter) : SUPPRESSION des champs Date/Ref virement
//   => on ne met à jour que le STATUT
// - Zéro création de table. Utilise `demandes_retrait`, `users`, `contrats`.
// ====================================================================================

session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: /admin/login.php'); exit(); }
$ADMIN_ID = (int)$_SESSION['admin_id'];

require_once '../db_connection.php';
if (isset($pdo) && $pdo instanceof PDO) { $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); }
elseif (function_exists('getPdoConnection')) { $pdo = getPdoConnection(); $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); }
else { http_response_code(500); die('Erreur: connexion PDO non initialisée.'); }

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function eur($x){ return number_format((float)$x, 2, ',', ' '); }

// ----------------------------
// Statuts — mapping souple
// ----------------------------
$STATUS_PENDING  = [ 'en_attente','En attente','valide','Validé','Validée','partiel','Partiel' ];
$STATUS_DONE     = [ 'paye','Payé','Payee','Payée','Traité','Traite' ];
$STATUS_EXCLUDED = [ 'Annulé','annule','Annule','litige','Litige' ];

function inClause(array $values): array { return [ implode(',', array_fill(0, count($values), '?')), $values ]; }

// ----------------------------
// POST : mise à jour d'une demande (statut UNIQUEMENT)
// ----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_demande'])) {
    $demande_id = (int)($_POST['demande_id'] ?? 0);
    $statut     = trim($_POST['statut'] ?? '');
    try {
        $stmt = $pdo->prepare("UPDATE demandes_retrait SET statut = :statut WHERE id = :id");
        $stmt->execute(['statut' => $statut, 'id' => $demande_id]);
        $_SESSION['virement_message'] = "La demande n°" . h($demande_id) . " a été mise à jour.";
        $_SESSION['virement_message_type'] = 'success';
    } catch (PDOException $e) {
        $_SESSION['virement_message'] = "Erreur lors de la mise à jour : " . $e->getMessage();
        $_SESSION['virement_message_type'] = 'error';
    }
    header('Location: virements.php');
    exit();
}

// ----------------------------
// Filtres
// ----------------------------
$q = trim($_GET['q'] ?? '');
$f_statut = trim($_GET['statut'] ?? 'all');

$searchSql = '';
$paramsBase = [];
if ($q !== '') { $searchSql = " AND (u.email LIKE ? OR u.name LIKE ? OR u.prenom LIKE ?)"; $paramsBase = ["%$q%","%$q%","%$q%" ]; }
$filterSql = '';
$paramsFilter = [];
if ($f_statut !== '' && $f_statut !== 'all') { $filterSql = " AND dr.statut = ?"; $paramsFilter[] = $f_statut; }

// ----------------------------
// KPI
// ----------------------------
// 1) CA réalisé = contrats échus (intérêts inclus)
$stmt = $pdo->prepare("SELECT COALESCE(SUM(apport + (apport * (taux_moyen/100))),0)
                        FROM contrats
                        WHERE date_fin IS NOT NULL AND DATE(date_fin) <= CURDATE()");
$stmt->execute();
$kpi_ca_realise = (float)$stmt->fetchColumn();

// 2) Clients payés = distinct users avec demandes Done
list($ph_done, $vals_done) = inClause($STATUS_DONE);
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM demandes_retrait WHERE statut IN ($ph_done)");
$stmt->execute($vals_done);
$kpi_paid_clients = (int)$stmt->fetchColumn();

// 3) Restant à rembourser = somme des demandes PENDING
list($ph_pend, $vals_pend) = inClause($STATUS_PENDING);
$stmt = $pdo->prepare("SELECT COALESCE(SUM(montant),0) FROM demandes_retrait WHERE statut IN ($ph_pend)");
$stmt->execute($vals_pend);
$kpi_left_sum = (float)$stmt->fetchColumn();

// ----------------------------
// Listes (pending/done)
// ----------------------------
list($ph_pending, $vals_pending) = inClause($STATUS_PENDING);
$sqlPending = "SELECT dr.*, u.prenom, u.name AS user_nom, u.email
               FROM demandes_retrait dr
               JOIN users u ON dr.user_id = u.id
               WHERE dr.statut IN ($ph_pending)
                 $filterSql $searchSql
               ORDER BY dr.date_demande DESC";
$paramsPending = array_merge($vals_pending, $paramsFilter, $paramsBase);
$stmt = $pdo->prepare($sqlPending); $stmt->execute($paramsPending); $demandes_pending = $stmt->fetchAll(PDO::FETCH_ASSOC);

list($ph_done2, $vals_done2) = inClause($STATUS_DONE);
$sqlDone = "SELECT dr.*, u.prenom, u.name AS user_nom, u.email
            FROM demandes_retrait dr
            JOIN users u ON dr.user_id = u.id
            WHERE dr.statut IN ($ph_done2)
              $filterSql $searchSql
            ORDER BY COALESCE(dr.date_virement, dr.date_demande) DESC";
$paramsDone = array_merge($vals_done2, $paramsFilter, $paramsBase);
$stmt = $pdo->prepare($sqlDone); $stmt->execute($paramsDone); $demandes_done = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestion des Virements — Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  <style>
    :root { --primary:#4CAF50; --primaryD:#388E3C; --text:#333; --muted:#757575; --bg:#f5f5f5; --card:#fff; --radius:10px; --shadow:0 1px 3px rgba(0,0,0,.12), 0 1px 2px rgba(0,0,0,.24); }
    *{box-sizing:border-box}
    body{margin:0;background:var(--bg);font-family:'Roboto',Arial,sans-serif;color:var(--text);display:flex}
    .sidebar{background:var(--card);width:260px;min-width:260px;height:100vh;padding:20px;position:fixed;top:0;left:0;box-shadow:var(--shadow);z-index:100}
    .sidebar-header{margin-bottom:20px;text-align:center;font-weight:700;color:var(--primary)}
    .sidebar ul{list-style:none;padding:0;margin:0}
    .sidebar a{display:flex;align-items:center;gap:10px;padding:10px;border-radius:8px;text-decoration:none;color:#666;margin-bottom:8px}
    .sidebar a:hover,.sidebar a.active{background:var(--primary);color:#fff}
    .container{margin-left:300px;padding:20px;width:calc(100% - 300px)}
    .page-header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:14px}
    .page-header h1{margin:0;font-size:22px}
    .card{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:16px}
    .kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:12px 0}
    .kpi{display:flex;align-items:center;gap:10px}
    .kpi .icon{color:var(--primary)}
    .kpi .value{font-weight:700;font-size:20px}
    .toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}
    input,select,button{font:inherit;border:1px solid #e0e0e0;border-radius:8px;padding:8px;background:#fff;color:var(--text)}
    .btn{border:0;border-radius:8px;padding:8px 12px;font-weight:600;cursor:pointer}
    .btn.pri{background:var(--primary);color:#fff}
    .btn.ghost{background:transparent;border:1px dashed #ccc}
    .section{margin-top:16px}
    .section h2{margin:0 0 8px 0;font-size:18px}
    .table-responsive{overflow:auto;border:1px solid #eee;border-radius:10px}
    table{width:100%;border-collapse:collapse}
    th,td{padding:10px;border-bottom:1px solid #f0f0f0;white-space:nowrap;vertical-align:middle}
    th{position:sticky;top:0;background:#fff;font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:#666}
    .badge{padding:3px 8px;border-radius:999px;border:1px solid #eee;background:#fafafa;font-size:11px;color:#666}
    .status{padding:4px 8px;border-radius:999px;font-size:12px;color:#fff}
    .st-attente{background:#ffc107}
    .st-traite,.st-paye{background:#2e7d32}
    .st-annule{background:#d32f2f}
    .muted{color:#999}
    @media (max-width: 900px){ .kpis{grid-template-columns:1fr} .container{margin-left:20px;width:calc(100% - 40px)} .sidebar{transform:translateX(-100%)} .sidebar.open{transform:translateX(0)} .toggle-btn{display:flex} }
    .toggle-btn{display:none;align-items:center;justify-content:center;position:fixed;top:15px;left:15px;background:var(--primary);color:#fff;border:none;border-radius:50%;width:50px;height:50px;cursor:pointer;z-index:1010;box-shadow:var(--shadow);font-size:24px}
  </style>
</head>
<body>

<button class="toggle-btn" onclick="toggleSidebar()"><span class="material-symbols-outlined">menu</span></button>

<div class="sidebar">
  <div class="sidebar-header">La Serre</div>
  <ul>
    <li><a href="index.php"><span class="material-symbols-outlined">dashboard</span>Tableau de Bord</a></li>
    <li><a href="virements.php" class="active"><span class="material-symbols-outlined">payments</span>Gestion Virements</a></li>
    <li><a href="gestion_users.php"><span class="material-symbols-outlined">group</span>Gestion Utilisateurs</a></li>
    <li><a href="gestion_contrats.php"><span class="material-symbols-outlined">description</span>Gestion Contrats</a></li>
    <li><a href="gestion_produits.php"><span class="material-symbols-outlined">inventory_2</span>Gestion Produits</a></li>
    <li><a href="gestion_documents.php"><span class="material-symbols-outlined">folder_open</span>Gestion Documents</a></li>
    <li><a href="rendez_vous.php"><span class="material-symbols-outlined">event</span>Gestion RDV</a></li>
    <li><a href="emailing.php"><span class="material-symbols-outlined">forward_to_inbox</span>Emailing</a></li>
    <li><a href="messagerie.php"><span class="material-symbols-outlined">mail</span>Messagerie</a></li>
    <li><a href="codepromo.php"><span class="material-symbols-outlined">sell</span>Codes Promo</a></li>
    <li><a href="parametres.php"><span class="material-symbols-outlined">settings</span>Paramètres</a></li>
    <li><a href="../logout.php"><span class="material-symbols-outlined">logout</span>Déconnexion</a></li>
  </ul>
</div>

<div class="container">
  <div class="page-header">
    <h1>Gestion des Virements</h1>
    <div class="toolbar" style="margin-left:auto">
      <form method="get" action="virements.php" style="display:flex; gap:8px; align-items:center;">
        <input type="text" name="q" placeholder="Nom / Email" value="<?= h($q) ?>">
        <select name="statut">
          <option value="all" <?= $f_statut==='all'? 'selected' : '' ?>>Tous statuts</option>
          <option value="En attente" <?= $f_statut==='En attente'? 'selected' : '' ?>>En attente</option>
          <option value="valide" <?= $f_statut==='valide'? 'selected' : '' ?>>Valide</option>
          <option value="partiel" <?= $f_statut==='partiel'? 'selected' : '' ?>>Partiel</option>
          <option value="Traité" <?= $f_statut==='Traité'? 'selected' : '' ?>>Traité</option>
          <option value="paye" <?= $f_statut==='paye'? 'selected' : '' ?>>Payé</option>
          <option value="Annulé" <?= $f_statut==='Annulé'? 'selected' : '' ?>>Annulé</option>
          <option value="Litige" <?= $f_statut==='Litige'? 'selected' : '' ?>>Litige</option>
        </select>
        <button class="btn">Filtrer</button>
        <a class="btn ghost" href="virements.php">Reset</a>
        <button type="button" class="btn pri" onclick="location.reload()">Actualiser</button>
      </form>
    </div>
  </div>

  <?php if (isset($_SESSION['virement_message'])): ?>
    <div class="card" style="border-left:4px solid <?= $_SESSION['virement_message_type']==='success' ? '#2e7d32' : '#d32f2f' ?>; margin-bottom:12px;">
      <?= h($_SESSION['virement_message']); ?>
    </div>
    <?php unset($_SESSION['virement_message'], $_SESSION['virement_message_type']); ?>
  <?php endif; ?>

  <div class="kpis">
    <div class="card kpi"><span class="material-symbols-outlined icon">trending_up</span><div><div class="value"><?= eur($kpi_ca_realise) ?> €</div><div class="muted">CA réalisé (contrats échus)</div></div></div>
    <div class="card kpi"><span class="material-symbols-outlined icon">verified</span><div><div class="value"><?= (int)$kpi_paid_clients ?></div><div class="muted">Clients payés</div></div></div>
    <div class="card kpi"><span class="material-symbols-outlined icon">hourglass_top</span><div><div class="value"><?= eur($kpi_left_sum) ?> €</div><div class="muted">Restant à rembourser</div></div></div>
  </div>

  <!-- À traiter -->
  <div class="section">
    <h2>À traiter <span class="badge"><?= count($demandes_pending) ?> demandes</span></h2>
    <div class="card table-responsive">
      <table>
        <thead>
          <tr>
            <th>Client</th>
            <th>Montant</th>
            <th>IBAN</th>
            <th>Date Demande</th>
            <th>Statut</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($demandes_pending)): ?>
          <tr><td colspan="6" style="text-align:center; padding:16px" class="muted">Aucune demande à traiter.</td></tr>
        <?php else: foreach ($demandes_pending as $demande): ?>
          <tr>
            <td>
              <strong><?= h(($demande['prenom'] ?? '').' '.($demande['user_nom'] ?? '')) ?></strong><br>
              <span class="muted"><?= h($demande['email'] ?? '') ?></span>
            </td>
            <td><strong><?= eur($demande['montant']) ?> €</strong></td>
            <td><?= h($demande['iban']) ?></td>
            <td><?= $demande['date_demande'] ? date('d/m/Y H:i', strtotime($demande['date_demande'])) : '-' ?></td>
            <td>
              <?php $cls = in_array($demande['statut'], ['En attente','en_attente','valide','Validé','Validée','partiel','Partiel']) ? 'st-attente' : (in_array($demande['statut'], ['Annulé','annule','Annule','litige','Litige']) ? 'st-annule' : 'st-traite'); ?>
              <span class="status <?= $cls ?>"><?= h($demande['statut']) ?></span>
            </td>
            <td>
              <form method="POST" action="virements.php" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap">
                <input type="hidden" name="demande_id" value="<?= (int)$demande['id'] ?>">
                <select name="statut" title="Changer le statut">
                  <option value="En attente" <?= ($demande['statut']==='En attente' || $demande['statut']==='en_attente') ? 'selected' : '' ?>>En attente</option>
                  <option value="valide" <?= ($demande['statut']==='valide' || $demande['statut']==='Validé' || $demande['statut']==='Validée') ? 'selected' : '' ?>>Valide</option>
                  <option value="partiel" <?= ($demande['statut']==='partiel' || $demande['statut']==='Partiel') ? 'selected' : '' ?>>Partiel</option>
                  <option value="paye" <?= (strtolower($demande['statut'])==='payé' || strtolower($demande['statut'])==='paye') ? 'selected' : '' ?>>Payé</option>
                  <option value="Traité" <?= ($demande['statut']==='Traité' || $demande['statut']==='Traite') ? 'selected' : '' ?>>Traité</option>
                  <option value="Annulé" <?= ($demande['statut']==='Annulé' || $demande['statut']==='annule' || $demande['statut']==='Annule') ? 'selected' : '' ?>>Annulé</option>
                  <option value="Litige" <?= ($demande['statut']==='Litige' || $demande['statut']==='litige') ? 'selected' : '' ?>>Litige</option>
                </select>
                <button type="submit" name="update_demande" class="btn pri" title="Mettre à jour">
                  <span class="material-symbols-outlined">save</span>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Réalisés -->
  <div class="section">
    <h2>Réalisés <span class="badge"><?= count($demandes_done) ?> virements</span></h2>
    <div class="card table-responsive">
      <table>
        <thead>
          <tr>
            <th>Client</th>
            <th>Montant</th>
            <th>IBAN</th>
            <th>Date Virement</th>
            <th>Réf.</th>
            <th>Statut</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($demandes_done)): ?>
          <tr><td colspan="7" style="text-align:center; padding:16px" class="muted">Aucun virement réalisé pour l'instant.</td></tr>
        <?php else: foreach ($demandes_done as $demande): ?>
          <tr>
            <td>
              <strong><?= h(($demande['prenom'] ?? '').' '.($demande['user_nom'] ?? '')) ?></strong><br>
              <span class="muted"><?= h($demande['email'] ?? '') ?></span>
            </td>
            <td><strong><?= eur($demande['montant']) ?> €</strong></td>
            <td><?= h($demande['iban']) ?></td>
            <td><?= $demande['date_virement'] ? date('d/m/Y', strtotime($demande['date_virement'])) : '-' ?></td>
            <td><?= h($demande['reference_virement'] ?? '') ?></td>
            <td><span class="status st-paye"><?= h($demande['statut']) ?></span></td>
            <td>
              <form method="POST" action="virements.php" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap">
                <input type="hidden" name="demande_id" value="<?= (int)$demande['id'] ?>">
                <select name="statut">
                  <option value="paye" <?= (strtolower($demande['statut'])==='payé' || strtolower($demande['statut'])==='paye') ? 'selected' : '' ?>>Payé</option>
                  <option value="Traité" <?= ($demande['statut']==='Traité' || $demande['statut']==='Traite') ? 'selected' : '' ?>>Traité</option>
                  <option value="Annulé" <?= ($demande['statut']==='Annulé' || $demande['statut']==='annule' || $demande['statut']==='Annule') ? 'selected' : '' ?>>Annulé</option>
                </select>
                <button type="submit" name="update_demande" class="btn pri" title="Mettre à jour">
                  <span class="material-symbols-outlined">save</span>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<script>
  function toggleSidebar(){ document.querySelector('.sidebar').classList.toggle('open'); }
  // Auto-refresh 60s pour garder les KPI à jour
  setInterval(()=>{ location.reload(); }, 60000);
</script>

</body>
</html>

