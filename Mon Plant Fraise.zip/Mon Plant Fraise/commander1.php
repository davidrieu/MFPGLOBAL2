<?php

require_once 'db_connection.php';
include 'back_to_top.php';

$products = []; 
$products_lft = [];

try {
    // 1. Récupération des produits classiques (fraises) avec la colonne `stock_grams`.
    $stmt_products = $pdo->query("SELECT * FROM products ORDER BY stock_grams > 0 DESC, variety_name ASC");
    $products = $stmt_products->fetchAll();

    // 2. Récupération des produits "La Fraise Touch" (prix à l'unité) avec la colonne `stock_unites`.
    $stmt_lft = $pdo->query("SELECT * FROM produits_lft ORDER BY stock_unites > 0 DESC, variety_name ASC");
    $products_lft = $stmt_lft->fetchAll();

} catch (PDOException $e) {
    die("Erreur lors de la récupération des produits : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commander - Mon Plant Fraise</title>
    <link rel="icon" href="images/logo-mpf.jpeg" type="image/jpeg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- MODIFIÉ : Ajout des polices Playfair Display et Lato pour le nouveau design -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Playfair+Display:wght@700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
<style>
    /* Styles Généraux */
    body, html {
        margin: 0; padding: 0; font-family: 'Montserrat', sans-serif; color: #333; line-height: 1.6; background-color: #f8f8f8;
        transition: background-color 0.4s ease;
    }
    .container {
        width: 90%; max-width: 1200px; margin: 0 auto; padding: 20px 0;
    }

    /* --- En-tête --- */
    header {
        display: flex; justify-content: space-between; align-items: center; padding: 15px 5%; background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    .logo { display: flex; align-items: center; font-weight: 700; font-size: 1.2rem; text-decoration: none; color: #333; }
    .logo img { height: 50px; margin-right: 10px; }
    .main-menu a { text-decoration: none; color: #555; margin-left: 25px; font-weight: 500; transition: color 0.3s ease; }
    .main-menu a:hover { color: #6B8E23; }
    #menu-toggle, .hamburger-menu { display: none; }

    /* --- Bannière --- */
    .banner { background-image: url('/images/banniere-commander.png'); background-size: cover; background-position: center; height: 300px; display: flex; justify-content: center; align-items: center; color: #fff; text-align: center; position: relative; }
    .banner::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0,0,0,0.4); z-index: 1; }
    .banner h1 { font-size: 3rem; font-weight: 700; z-index: 2; text-shadow: 0 2px 5px rgba(0,0,0,0.3); padding: 0 15px; }

    /* Section Commande */
    .order-section { 
        padding: 40px 20px; 
        text-align: center;
        transition: background-color 0.4s ease;
        border-radius: 12px;
    }
    .order-section h2 { 
        font-size: 2.2rem; 
        margin-bottom: 20px; 
        color: #333;
        transition: color 0.4s ease;
    }
    
    /* --- Styles pour les onglets --- */
    .tabs-container {
        display: flex;
        justify-content: center;
        margin-bottom: 40px;
        border-bottom: 1px solid #ddd;
    }
    .tab-button {
        padding: 15px 30px;
        cursor: pointer;
        border: none;
        background-color: transparent;
        font-size: 1.1rem;
        font-weight: 600;
        color: #777;
        position: relative;
        transition: color 0.3s ease;
    }
    .tab-button::after {
        content: '';
        position: absolute;
        bottom: -1px;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #6B8E23;
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    .tab-button.active {
        color: #333;
    }
    .tab-button.active::after {
        transform: scaleX(1);
    }
    .product-tab-content {
        display: none;
    }
    .product-tab-content.active {
        display: block;
    }

    /* --- Bandeau Partenariat --- */
    .partnership-banner {
        display: none; /* Caché par défaut */
        align-items: center;
        justify-content: center;
        gap: 15px;
        background-color: #f0f8ff;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 30px;
        border: 1px solid #d1e7fd;
    }
    .partnership-banner img {
        height: 40px;
    }
    .partnership-banner p {
        margin: 0;
        font-weight: 600;
        color: #0c5460;
    }


    /* --- STRUCTURE DE LA PAGE AVEC PANIER --- */
    .content-wrapper { display: flex; gap: 30px; align-items: flex-start; }
    .product-column { flex: 3; }
    .cart-column { flex: 1; position: sticky; top: 20px; background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); }
    .cart-column h3 { margin-top: 0; color: #6B8E23; font-size: 1.5rem; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }

    /* --- GRILLE DE CARTES PRODUITS (Style par défaut) --- */
    .variety-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px; }
    .variety-card { background-color: #fff; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); overflow: hidden; display: flex; flex-direction: column; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .variety-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
    .variety-card img { width: 100%; height: 180px; object-fit: cover; }
    .variety-content { padding: 20px; display: flex; flex-direction: column; flex-grow: 1; text-align: left; }
    .variety-content h3 { margin-top: 0; font-size: 1.5rem; color: #333; margin-bottom: 15px; }
    
    /* --- Styles pour la description (onglet LFT) --- */
    .product-description {
        font-size: 0.9em;
        color: #666;
        margin-bottom: 15px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
    }
    .read-more-link {
        color: #6B8E23;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
    }

    /* --- Styles pour la zone d'actions (Style par défaut) --- */
    .product-actions { margin-top: auto; padding-top: 15px; border-top: 1px solid #f0f0f0; }
    .options-selector { display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px; }
    .options-selector label { font-weight: 600; font-size: 0.9em; }
    .options-selector select { padding: 8px; border-radius: 5px; border: 1px solid #ccc; flex-grow: 1; margin-left: 10px; }
    .price-display { text-align: right; font-size: 1.6rem; font-weight: 700; color: #6B8E23; margin-bottom: 20px; }
    
    .cart-controls { display: flex; align-items: center; gap: 15px; }
    .quantity-control { display: flex; align-items: center; }
    .quantity-control button { background-color: #eee; border: 1px solid #ddd; padding: 8px 12px; font-size: 1rem; cursor: pointer; }
    .quantity-control input { width: 40px; text-align: center; border: 1px solid #ccc; border-left: none; border-right: none; padding: 8px 0; font-size: 1rem; }
    
    .add-to-cart-button { flex-grow: 1; background-color: #6B8E23; color: white; border: none; padding: 10px 15px; border-radius: 5px; font-weight: 600; cursor: pointer; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .add-to-cart-button:hover { background-color: #5A7C1F; }
    .add-to-cart-button .material-symbols-outlined { font-size: 1.5rem; }
    
    /* Style pour le message "Indisponible" */
    .unavailable-notice { padding: 30px 10px; margin-top: 20px; text-align: center; background-color: #f9f9f9; border-radius: 6px; color: #999; flex-grow: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; }
    .unavailable-notice .material-symbols-outlined { font-size: 2.5rem; }
    .unavailable-notice p { margin: 5px 0 0 0; font-weight: 600; }
    .unavailable-notice span { font-size: 0.9em; }

    /* --- NOUVEAU : Styles pour le thème "La Fraise Touch'" --- */
    .order-section.lft-theme .tab-button.active {
        color: #333; /* Reste noir */
    }
    .order-section.lft-theme .tab-button::after {
        background-color: #e6c589; /* Or/bronze */
    }
    .order-section.lft-theme .partnership-banner {
        background-color: #2c2c2c;
        border-color: #444;
    }
     .order-section.lft-theme .partnership-banner p {
        color: #e6c589;
    }

    #products-lft .variety-card {
        background-color: #222;
        border: 1px solid #444; /* Bordure subtile */
        box-shadow: none;
        text-align: center;
    }
    #products-lft .variety-content h3 {
        font-family: 'Playfair Display', serif;
        color: #fff; 
        font-size: 1.7rem;
    }
    #products-lft .product-description {
        font-family: 'Lato', sans-serif;
        color: #ccc;
    }
    #products-lft .read-more-link {
        display: none; /* Le bouton 'Voir' remplace ce lien */
    }
    #products-lft .price-display {
        color: #fff;
        font-family: 'Lato', serif;
        font-size: 1.5rem;
        text-align: center;
        margin-bottom: 15px;
    }
    #products-lft .product-actions {
        border-top: 1px solid #444;
    }
    /* --- NOUVEAU : Groupe de boutons pour LFT --- */
    #products-lft .lft-button-group {
        display: flex;
        gap: 10px;
        justify-content: center;
    }
    #products-lft .lft-button {
        background-color: transparent;
        border: 1px solid #e6c589;
        color: #e6c589;
        padding: 8px 16px;
        border-radius: 50px;
        font-family: 'Lato', sans-serif;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 0.9rem;
    }
    #products-lft .lft-button:hover {
        background-color: #e6c589;
        color: #1a1a1a;
    }
    
    /* --- Styles du Panier --- */
    #cart-items-list-sidebar { min-height: 80px; max-height: 400px; overflow-y: auto; margin-bottom: 20px; }
    .cart-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px dashed #eee; }
    #empty-cart-message-sidebar { text-align: center; color: #777; padding: 20px 0; }
    .summary-line.total { display: flex; justify-content: space-between; font-size: 1.4em; font-weight: 700; color: #6B8E23; margin-top: 15px; padding-top: 10px; border-top: 1px solid #eee; }
    .validate-order-button { background-color: #6B8E23; color: #fff; border: none; padding: 15px 30px; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: background-color 0.3s ease; width: 100%; margin-top: 30px; border-radius: 5px; }
    .validate-order-button:hover { background-color: #5A7C1F; }

    /* --- Styles pour le panier flottant et la modale --- */
    #floating-cart-btn {
        display: none; position: fixed; bottom: 20px; right: 20px; width: 60px; height: 60px; background-color: #6B8E23; color: white; border: none; border-radius: 50%; box-shadow: 0 4px 12px rgba(0,0,0,0.2); cursor: pointer; z-index: 1000; justify-content: center; align-items: center;
    }
    #cart-item-count {
        position: absolute; top: -5px; right: -5px; background-color: #e74c3c; color: white; border-radius: 50%; width: 24px; height: 24px; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; border: 2px solid white;
    }
    .cart-modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 2000; display: none; align-items: center; justify-content: center;
    }
    .cart-modal-overlay.open { display: flex; }
    .cart-modal-content { background-color: #fff; border-radius: 8px; width: 90%; max-width: 500px; max-height: 80vh; display: flex; flex-direction: column; }
    .cart-modal-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid #eee; }
    .cart-modal-header h3 { margin: 0; color: #6B8E23; font-size: 1.5rem; }
    .cart-modal-close { background: none; border: none; font-size: 2rem; cursor: pointer; color: #999; }
    .cart-modal-body { padding: 20px; overflow-y: auto; }
    .cart-modal-footer { padding: 20px; border-top: 1px solid #eee; }

    /* --- Styles pour la modale de description --- */
    .description-modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); z-index: 3000;
        display: none; align-items: center; justify-content: center;
    }
    .description-modal-overlay.open { display: flex; }
    .description-modal-content {
        background-color: #fff; border-radius: 8px; width: 90%; max-width: 600px; max-height: 85vh;
        display: flex; flex-direction: column; box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    .description-modal-header {
        display: flex; justify-content: space-between; align-items: center; padding: 15px 25px; border-bottom: 1px solid #eee;
    }
    .description-modal-header h3 { margin: 0; color: #333; font-size: 1.5rem; }
    .description-modal-close { background: none; border: none; font-size: 2.2rem; cursor: pointer; color: #999; }
    .description-modal-body { padding: 25px; overflow-y: auto; }
    .description-modal-body h4 { margin-top: 20px; margin-bottom: 10px; font-size: 1.1rem; color: #6B8E23; }
    .description-modal-body p, .description-modal-body ul { margin: 0; padding: 0; }
    .description-modal-body ul { list-style-type: none; }


    /* --- RESPONSIVE --- */
    @media (max-width: 992px) {
        .content-wrapper { flex-direction: column; }
        .cart-column { display: none; }
        #floating-cart-btn { display: flex; }
    }
    @media (max-width: 768px) {
        .hamburger-menu { display: block; cursor: pointer; z-index: 1001; }
        .hamburger-menu span { display: block; width: 25px; height: 3px; background-color: #333; margin: 5px 0; transition: 0.3s; }
        .main-menu { display: none; flex-direction: column; position: absolute; top: 70px; left: 0; width: 100%; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 10px 0; z-index: 1000; }
        .main-menu a { margin: 10px 0; text-align: center; width: 100%; }
        #menu-toggle:checked ~ .main-menu { display: flex; }
        .banner h1 { font-size: 2.2rem; }
        .order-section h2 { font-size: 1.8rem; }
        .variety-content h3 { font-size: 1.3rem; }
        .variety-grid { grid-template-columns: 1fr; }
    }
    /* Style pour le bouton "Retour en haut" */
    #scrollTopBtn {
        display: none; position: fixed; bottom: 20px; right: 30px; z-index: 1000; border: none; outline: none; background-color: #6B8E23; color: white; cursor: pointer; padding: 10px; border-radius: 50%; width: 50px; height: 50px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); transition: background-color 0.3s, transform 0.2s; align-items: center; justify-content: center;
    }
    #scrollTopBtn:hover {
        background-color: #5A7C1F; transform: scale(1.1);
    }
    #scrollTopBtn .material-symbols-outlined {
        font-size: 2rem;
    }
</style>
</head>
<body>
    <header>
        <a href="index.php" class="logo">
            <img src="/images/logo-mpf.jpeg" alt="Logo Mon Plant Fraise">
        </a>
        <div class="nav-container">
            <input type="checkbox" id="menu-toggle" style="display: none;"/>
            <label for="menu-toggle" class="hamburger-menu">
                <span></span><span></span><span></span>
            </label>
            <nav class="main-menu">
                <a href="index.php">Accueil</a>
                <a href="commander.php">Commander mes fruits</a>
                <a href="espace-client.php">Espace Client</a>
            </nav>
        </div>
    </header>

    <div class="banner">
        <h1>Composez votre panier de fruits frais</h1>
    </div>

    <div class="container order-section">
        <h2>Découvrez nos variétés gourmandes 🍓</h2>

        <!-- Conteneur des onglets -->
        <div class="tabs-container">
            <button class="tab-button active" data-tab="products-fraises">Nos Fraises</button>
            <button class="tab-button" data-tab="products-lft">La Fraise Touch'</button>
        </div>

        <!-- Bandeau de partenariat -->
        <div id="partnership-banner" class="partnership-banner">
            <!-- Assurez-vous que le chemin vers votre logo est correct -->
            <img src="/images/logo-lft.png" alt="Logo La Fraise Touch">
            <p>En partenariat avec La Fraise Touch'</p>
        </div>

        <div class="content-wrapper">
            <div class="product-column">

                <!-- Contenu pour l'onglet des fraises -->
                <div id="products-fraises" class="product-tab-content active">
                    <div class="variety-grid">
                        <?php foreach ($products as $product): ?>
                            <div class="variety-card" data-product-id="<?php echo $product['id']; ?>" data-product-type="fraise">
                                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['variety_name']); ?>">
                                <div class="variety-content">
                                    <h3><?php echo htmlspecialchars($product['variety_name']); ?></h3>
                                    
                                    <?php if ($product['stock_grams'] > 0): ?>
                                        <div class="product-actions">
                                            <div class="options-selector">
                                                <label for="weight-select-<?php echo $product['id']; ?>">Poids :</label>
                                                <select class="weight-select" id="weight-select-<?php echo $product['id']; ?>">
                                                    <option value="200gr" data-price="<?php echo $product['price_200g']; ?>">
                                                        200gr - <?php echo number_format($product['price_200g'], 2, ',', ' '); ?> €
                                                    </option>
                                                    <option value="500gr" data-price="<?php echo $product['price_500g']; ?>">
                                                        500gr - <?php echo number_format($product['price_500g'], 2, ',', ' '); ?> €
                                                    </option>
                                                    <option value="1kg" data-price="<?php echo $product['price_1kg']; ?>">
                                                        1kg - <?php echo number_format($product['price_1kg'], 2, ',', ' '); ?> €
                                                    </option>
                                                </select>
                                            </div>

                                            <div class="price-display">
                                                <?php echo number_format($product['price_200g'], 2, ',', ' '); ?> €
                                            </div>
                                            
                                            <div class="cart-controls">
                                                <div class="quantity-control">
                                                    <button onclick="changeQuantity(this, -1)">-</button>
                                                    <input type="number" value="1" min="1" readonly>
                                                    <button onclick="changeQuantity(this, 1)">+</button>
                                                </div>
                                                <button class="add-to-cart-button" data-variety="<?php echo htmlspecialchars($product['variety_name']); ?>">
                                                    <span class="material-symbols-outlined">add_shopping_cart</span>
                                                    Ajouter
                                                </button>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="unavailable-notice">
                                            <span class="material-symbols-outlined">inventory_2</span>
                                            <p>Indisponible</p>
                                            <span>Cette variété est en rupture de stock.</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Contenu pour l'onglet "La Fraise Touch" -->
                <div id="products-lft" class="product-tab-content">
                    <div class="variety-grid">
                        <?php foreach ($products_lft as $product_lft): ?>
                            <div class="variety-card" 
                                 data-product-id="<?php echo $product_lft['id']; ?>" 
                                 data-product-type="lft"
                                 data-name="<?php echo htmlspecialchars($product_lft['variety_name']); ?>"
                                 data-description="<?php echo htmlspecialchars($product_lft['description']); ?>"
                                 data-ingredients="<?php echo htmlspecialchars($product_lft['ingredients']); ?>">
                                <img src="<?php echo htmlspecialchars($product_lft['image_url']); ?>" alt="<?php echo htmlspecialchars($product_lft['variety_name']); ?>">
                                <div class="variety-content">
                                    <h3><?php echo htmlspecialchars($product_lft['variety_name']); ?></h3>

                                    <?php if (!empty($product_lft['description'])): ?>
                                        <p class="product-description"><?php echo htmlspecialchars($product_lft['description']); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if ($product_lft['stock_unites'] > 0): ?> 
                                        <div class="product-actions">
                                            <div class="price-display">
                                                <?php echo number_format($product_lft['price'], 2, ',', ' '); ?> €
                                            </div>
                                            
                                            <!-- NOUVEAU : Groupe de boutons pour LFT -->
                                            <div class="lft-button-group">
                                                <button class="lft-button view-details-button">Voir</button>
                                                <button class="lft-button add-to-cart-button" 
                                                        data-variety="<?php echo htmlspecialchars($product_lft['variety_name']); ?>"
                                                        data-price="<?php echo $product_lft['price']; ?>">
                                                    Ajouter au panier
                                                </button>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="unavailable-notice">
                                            <span class="material-symbols-outlined">inventory_2</span>
                                            <p>Indisponible</p>
                                            <span>Ce produit est en rupture de stock.</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

            </div>

            <div class="cart-column">
                <h3>Votre Panier</h3>
                <div id="cart-items-list-sidebar">
                    <p id="empty-cart-message-sidebar">Votre panier est vide pour le moment.</p>
                </div>
                
                <form id="checkout-form-sidebar" action="recapitulatif.php" method="POST">
                    <div id="cart-summary-total-sidebar">
                        <div class="summary-line total">
                            <strong>Total Provisoire :</strong>
                            <span id="cart-total-price-sidebar">0,00 €</span>
                        </div>
                        <input type="hidden" name="cart_data" id="cart-data-input-sidebar">
                        <button type="submit" class="validate-order-button">Valider ma commande</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <button id="floating-cart-btn" aria-label="Voir le panier">
        <span class="material-symbols-outlined">shopping_cart</span>
        <span id="cart-item-count">0</span>
    </button>
    
    <div class="cart-modal-overlay" id="cart-modal">
        <div class="cart-modal-content">
            <div class="cart-modal-header">
                <h3>Votre Panier</h3>
                <button class="cart-modal-close" id="cart-modal-close" aria-label="Fermer">&times;</button>
            </div>
            <div class="cart-modal-body">
                <div id="cart-items-list-modal">
                    <p id="empty-cart-message-modal">Votre panier est vide pour le moment.</p>
                </div>
            </div>
            <div class="cart-modal-footer">
                <form id="checkout-form-modal" action="recapitulatif.php" method="POST">
                    <div id="cart-summary-total-modal">
                        <div class="summary-line total">
                            <strong>Total Provisoire :</strong>
                            <span id="cart-total-price-modal">0,00 €</span>
                        </div>
                        <input type="hidden" name="cart_data" id="cart-data-input-modal">
                        <button type="submit" class="validate-order-button">Valider ma commande</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modale pour la description -->
    <div class="description-modal-overlay" id="description-modal">
        <div class="description-modal-content">
            <div class="description-modal-header">
                <h3 id="description-modal-title">Titre du Produit</h3>
                <button class="description-modal-close" id="description-modal-close" aria-label="Fermer">&times;</button>
            </div>
            <div class="description-modal-body">
                <h4>Description</h4>
                <p id="description-modal-text">Description complète du produit...</p>
                <h4>Ingrédients</h4>
                <ul id="description-modal-ingredients">
                    <!-- Les ingrédients seront insérés ici par JS -->
                </ul>
            </div>
        </div>
    </div>


<script>
    let cart = []; // Panier global
    const formatCurrency = (amount) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);

    function updateCartDisplay() {
        const sidebarList = document.getElementById('cart-items-list-sidebar');
        const sidebarTotalPrice = document.getElementById('cart-total-price-sidebar');
        const modalList = document.getElementById('cart-items-list-modal');
        const modalTotalPrice = document.getElementById('cart-total-price-modal');
        const itemCountBadge = document.getElementById('cart-item-count');
        
        let total = 0;
        let totalItems = 0;
        let cartHTML = '';

        if (cart.length === 0) {
            cartHTML = '<p id="empty-cart-message">Votre panier est vide pour le moment.</p>';
        } else {
            cart.forEach((item, index) => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                totalItems += item.quantity;
                
                cartHTML += `
                    <div class="cart-item">
                        <div class="cart-item-details">
                            <strong>${item.name} (${item.weight})</strong>
                            <span>${item.quantity} x ${formatCurrency(item.price)} = ${formatCurrency(itemTotal)}</span>
                        </div>
                        <button class="remove-item-btn" data-index="${index}" style="background:none; border:none; cursor:pointer; color: #cc0000;">
                            <span class="material-symbols-outlined">delete</span>
                        </button>
                    </div>
                `;
            });
        }
        
        sidebarList.innerHTML = cartHTML.replace('id="empty-cart-message"', 'id="empty-cart-message-sidebar"');
        modalList.innerHTML = cartHTML.replace('id="empty-cart-message"', 'id="empty-cart-message-modal"');
        sidebarTotalPrice.textContent = formatCurrency(total);
        modalTotalPrice.textContent = formatCurrency(total);
        itemCountBadge.textContent = totalItems;
        itemCountBadge.style.display = totalItems > 0 ? 'flex' : 'none';
    }

    // La fonction `addToCart` est mise à jour pour accepter "Unité" comme poids
    function addToCart(varietyName, weight, price, quantity) {
        const existingItemIndex = cart.findIndex(item => item.name === varietyName && item.weight === weight);

        if (existingItemIndex > -1) {
            cart[existingItemIndex].quantity += quantity;
        } else {
            cart.push({ name: varietyName, weight: weight, price: price, quantity: quantity });
        }
        updateCartDisplay();
    }

    function removeFromCart(index) {
        cart.splice(index, 1);
        updateCartDisplay();
    }

    function changeQuantity(button, change) {
        const input = button.parentNode.querySelector('input');
        let currentValue = parseInt(input.value);
        currentValue += change;
        if (currentValue < 1) {
            currentValue = 1;
        }
        input.value = currentValue;
    }

    document.addEventListener('DOMContentLoaded', () => {
        const productColumn = document.querySelector('.product-column');
        const orderSection = document.querySelector('.order-section');
        
        // --- Logique pour les onglets ---
        const tabsContainer = document.querySelector('.tabs-container');
        const partnershipBanner = document.getElementById('partnership-banner');

        tabsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('tab-button')) {
                const tabId = e.target.dataset.tab;

                // Gérer le style des boutons
                tabsContainer.querySelector('.active').classList.remove('active');
                e.target.classList.add('active');

                // Gérer l'affichage du contenu
                document.querySelector('.product-tab-content.active').classList.remove('active');
                document.getElementById(tabId).classList.add('active');

                // MODIFIÉ : Gérer le thème
                if (tabId === 'products-lft') {
                    orderSection.classList.add('lft-theme');
                    partnershipBanner.style.display = 'flex';
                } else {
                    orderSection.classList.remove('lft-theme');
                    partnershipBanner.style.display = 'none';
                }
            }
        });

        document.body.addEventListener('click', (e) => {
            const removeButton = e.target.closest('.remove-item-btn');
            if (removeButton) {
                const index = parseInt(removeButton.dataset.index);
                removeFromCart(index);
            }
        });

        // --- Gestion de l'ajout au panier ---
        productColumn.addEventListener('click', (e) => {
            const button = e.target.closest('.add-to-cart-button');
            if (!button) return; 

            const card = button.closest('.variety-card');
            const variety = button.dataset.variety;
            const productType = card.dataset.productType;

            let weight, price, quantity;

            if (productType === 'lft') {
                weight = 'Unité';
                price = parseFloat(button.dataset.price);
                quantity = 1; // Pas de sélecteur de quantité pour LFT, on ajoute 1 par défaut
            } else {
                const quantityInput = card.querySelector('.quantity-control input');
                quantity = parseInt(quantityInput.value);
                const weightSelect = card.querySelector('.weight-select');
                const selectedOption = weightSelect.options[weightSelect.selectedIndex];
                weight = selectedOption.value;
                price = parseFloat(selectedOption.dataset.price);
            }

            addToCart(variety, weight, price, quantity);

            // Animation du bouton pour LFT
            if (productType === 'lft') {
                button.textContent = 'Ajouté !';
                 setTimeout(() => {
                    button.textContent = 'Ajouter au panier';
                }, 1500);
            } else { // Animation pour les fraises
                 button.innerHTML = '<span class="material-symbols-outlined">done</span> Ajouté !';
                setTimeout(() => {
                    button.innerHTML = '<span class="material-symbols-outlined">add_shopping_cart</span> Ajouter';
                }, 1500);
            }
        });

        productColumn.addEventListener('change', (e) => {
            if (e.target.classList.contains('weight-select')) {
                const select = e.target;
                const card = select.closest('.variety-card');
                const priceDisplay = card.querySelector('.price-display');
                
                const selectedOption = select.options[select.selectedIndex];
                const price = parseFloat(selectedOption.dataset.price);

                priceDisplay.textContent = formatCurrency(price);
            }
        });
        
        // --- Logique pour la modale de description ---
        const descriptionModal = document.getElementById('description-modal');
        const descriptionModalTitle = document.getElementById('description-modal-title');
        const descriptionModalText = document.getElementById('description-modal-text');
        const descriptionModalIngredients = document.getElementById('description-modal-ingredients');
        const closeDescriptionModalBtn = document.getElementById('description-modal-close');

        productColumn.addEventListener('click', (e) => {
            // MODIFIÉ : Le clic se fait sur le bouton "Voir"
            if (e.target.classList.contains('view-details-button')) {
                e.preventDefault();
                const card = e.target.closest('.variety-card');
                
                const name = card.dataset.name;
                const description = card.dataset.description;
                const ingredients = card.dataset.ingredients.split(',').map(item => item.trim());

                descriptionModalTitle.textContent = name;
                descriptionModalText.textContent = description;
                
                descriptionModalIngredients.innerHTML = ''; 
                ingredients.forEach(ingredient => {
                    const li = document.createElement('li');
                    li.textContent = ingredient;
                    descriptionModalIngredients.appendChild(li);
                });

                descriptionModal.classList.add('open');
            }
        });

        const closeDescriptionModal = () => descriptionModal.classList.remove('open');
        closeDescriptionModalBtn.addEventListener('click', closeDescriptionModal);
        descriptionModal.addEventListener('click', (e) => {
            if (e.target === descriptionModal) {
                closeDescriptionModal();
            }
        });

        // --- Logique du panier et de la validation ---
        function handleCheckoutSubmit(event) {
            event.preventDefault(); 
            if (cart.length === 0) {
                alert("Votre panier est vide ! Vous ne pouvez pas continuer.");
                return;
            }
            const cartDataInput = event.target.querySelector('input[name="cart_data"]');
            cartDataInput.value = JSON.stringify(cart);
            event.target.submit(); 
        }
        
        document.getElementById('checkout-form-sidebar').addEventListener('submit', handleCheckoutSubmit);
        document.getElementById('checkout-form-modal').addEventListener('submit', handleCheckoutSubmit);

        const floatingCartBtn = document.getElementById('floating-cart-btn');
        const cartModal = document.getElementById('cart-modal');
        const closeModalBtn = document.getElementById('cart-modal-close');

        floatingCartBtn.addEventListener('click', () => cartModal.classList.add('open'));
        closeModalBtn.addEventListener('click', () => cartModal.classList.remove('open'));
        cartModal.addEventListener('click', (e) => {
            if (e.target === cartModal) {
                cartModal.classList.remove('open');
            }
        });

        updateCartDisplay();
    });
</script>
</body>
</html>


